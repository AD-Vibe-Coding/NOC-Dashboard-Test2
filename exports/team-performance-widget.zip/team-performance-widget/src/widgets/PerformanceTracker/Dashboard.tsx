import { useEffect, useMemo, useState } from "react";
import {
  ActionIcon,
  Alert,
  Badge,
  Box,
  Button,
  Card,
  Code,
  Grid,
  Group,
  Loader,
  Modal,
  Progress,
  ScrollArea,
  SegmentedControl,
  Select,
  Stack,
  Switch,
  Table,
  Text,
  ThemeIcon,
  Title,
  Tooltip,
} from "@mantine/core";
import {
  IconAlertTriangle,
  IconCalendar,
  IconClipboardCheck,
  IconClipboardList,
  IconClock,
  IconFilter,
  IconInfoCircle,
  IconTable,
  IconTool,
  IconPhone,
  IconPhoneIncoming,
  IconPhoneX,
  IconSearch,
  IconShieldCheck,
  IconTicket,
  IconUsersGroup,
} from "@tabler/icons-react";
import type { ComponentType, ReactNode } from "react";
import {
  LOCKED_TEAM,
  LOCKED_TEAM_NAMES,
  TIER_COLORS,
  TIER_LABELS,
  TIER_SHORT_LABELS,
  tierFor,
} from "./team";
import {
  aggregateMetrics,
  buildWorkloadContext,
  diagnoseMemberTickets,
  filterMetrics,
  isMaintenanceTicket,
  listAvailablePeriods,
  SHIFT_LABELS,
  type AggregateOptions,
  type DayFilter,
  type MemberSummary,
  type MemberTicketDiagnostic,
  type PerformanceMetric,
  type Queue,
  type ShiftFilter,
  type SourceBucket,
} from "./data";
import { type SourceType } from "./import";
import { ActiveFilterChips } from "./FilterChips";
import { KPI_BY_KEY, type KpiKey } from "./kpiConfig";
import { RawDataModal, type DisputeInfo } from "./RawDataModal";
import { DisputeForm, type DisputeField } from "./DisputeForm";

interface Props {
  metrics: PerformanceMetric[];
  scopedMember: string | null;
  isManager?: boolean;
  /** Optional: caller (the widget root) can provide the re-derive action so
   *  the diagnostic banner can offer a one-click "fix it" button. */
  onRederive?: () => void;
  /** True while onRederive is in flight. */
  isRederiving?: boolean;
  /** The logged-in user's canonical name. Needed for dispute submission. */
  currentUserName?: string;
  /** Called after a dispute is submitted or approved so metrics can be refreshed. */
  onDisputeChange?: () => void;
}

// =============================================================================
// Top-level component
// =============================================================================

export function PerformanceDashboard({
  metrics,
  scopedMember,
  isManager = false,
  onRederive,
  isRederiving,
  currentUserName,
  onDisputeChange,
}: Props) {
  // ---- Dispute state ----
  const [disputeMetric, setDisputeMetric] = useState<PerformanceMetric | null>(null);
  const [disputeField, setDisputeField] = useState<DisputeField | null>(null);
  const [disputeMap, setDisputeMap] = useState<Map<number, DisputeInfo[]>>(new Map());
  const [disputeRefresh, setDisputeRefresh] = useState(0);

  // Load disputes for badge display
  useEffect(() => {
    let cancelled = false;
    fetch("/api/metric_disputes")
      .then((r) => r.ok ? r.json() : [])
      .then((data: Array<{ id: number; metric_id: number; field_name: string; status: string; proposed_value: number; review_note: string | null }>) => {
        if (cancelled) return;
        const map = new Map<number, DisputeInfo[]>();
        for (const d of data) {
          const arr = map.get(d.metric_id) ?? [];
          arr.push({
            id: d.id,
            field_name: d.field_name,
            status: d.status,
            proposed_value: d.proposed_value,
            review_note: d.review_note,
          });
          map.set(d.metric_id, arr);
        }
        setDisputeMap(map);
      })
      .catch(() => {});
    return () => { cancelled = true; };
  }, [disputeRefresh]);

  function handleDisputeSubmitted() {
    setDisputeRefresh((k) => k + 1);
    onDisputeChange?.();
  }

  // ---- Filter state ----
  const [queueFilter, setQueueFilter] = useState<Queue | "all">("all");
  const [periodMode, setPeriodMode] = useState<"all" | "month" | "quarter">(
    "all",
  );
  const [periodValue, setPeriodValue] = useState<string | null>(null);
  // Maintenance-notification filter — defaults ON because these rows
  // aren't real incident work and skew the team KPIs upward. Toggle
  // applies to tickets only; call data is never affected.
  const [excludeMaintenance, setExcludeMaintenance] = useState(true);
  const [dayFilter, setDayFilter] = useState<DayFilter>("all");
  const [shiftFilter, setShiftFilter] = useState<ShiftFilter>("all");
  const [rawDataMember, setRawDataMember] = useState<string | null>(null);
  const [rawDrillContext, setRawDrillContext] = useState<{
    metricKey?: KpiKey | null;
    month?: string | null;
    sourceTab?: "tickets" | "calls" | "tasks" | "audits";
    title?: string;
    description?: string;
  } | null>(null);

  const periods = useMemo(() => listAvailablePeriods(metrics), [metrics]);

  // When the user switches mode, auto-select the most recent value if any
  // are available, otherwise reset to null.
  const effectivePeriodValue = useMemo(() => {
    if (periodMode === "all") return null;
    if (periodValue) return periodValue;
    const fallback =
      periodMode === "month" ? periods.months[0] : periods.quarters[0];
    return fallback ?? null;
  }, [periodMode, periodValue, periods]);

  const options: AggregateOptions = {
    queue: queueFilter,
    period:
      periodMode === "all" || !effectivePeriodValue
        ? { type: "all" }
        : periodMode === "month"
          ? { type: "month", value: effectivePeriodValue }
          : { type: "quarter", value: effectivePeriodValue },
    excludeMaintenance,
    dayFilter,
    shiftFilter,
  };

  const summaryMembers = useMemo(() => {
    const members = new Set(LOCKED_TEAM_NAMES);
    if (scopedMember) members.add(scopedMember);
    return Array.from(members);
  }, [scopedMember]);

  const filteredMetrics = useMemo(() => {
    const scopeRows = scopedMember
      ? metrics.filter((metric) => metric.member_name === scopedMember)
      : metrics;
    return filterMetrics(scopeRows, options);
  }, [metrics, scopedMember, options]);

  const workload = useMemo(() => buildWorkloadContext(filteredMetrics), [filteredMetrics]);

  const summaries = useMemo(
    () => aggregateMetrics(metrics, summaryMembers, options),
    [metrics, summaryMembers, options.queue, options.period, options.excludeMaintenance, options.dayFilter, options.shiftFilter],
  );

  const managerParity = useMemo(() => {
    if (!isManager || !scopedMember) return null;
    const managerScoped = aggregateMetrics(metrics, [scopedMember], options)[0] ?? null;
    const simulatedSelf = aggregateMetrics(
      metrics.filter((metric) => metric.member_name === scopedMember),
      [scopedMember],
      options,
    )[0] ?? null;
    if (!managerScoped || !simulatedSelf) return null;

    const checks = [
      { key: "tickets_acked" as KpiKey, label: "Tickets Acked" },
      { key: "avg_ack_time" as KpiKey, label: "Avg Ack Time" },
      { key: "within_24h" as KpiKey, label: "Within 24h" },
      { key: "carrier_under_15" as KpiKey, label: "Carrier ≤ 15 min" },
      { key: "inbound_calls" as KpiKey, label: "Inbound Calls" },
      { key: "refused_calls" as KpiKey, label: "Refused Calls" },
      { key: "tasks_worked" as KpiKey, label: "Tasks Worked" },
      { key: "sla_met" as KpiKey, label: "SLA-Met" },
    ].map((item) => {
      const def = KPI_BY_KEY[item.key];
      const managerValue = def.compute([managerScoped]).numeric;
      const selfValue = def.compute([simulatedSelf]).numeric;
      const matches =
        managerValue === selfValue ||
        (managerValue != null && selfValue != null && Math.abs(managerValue - selfValue) < 0.0001);
      return { ...item, managerValue, selfValue, matches };
    });

    return {
      allMatch: checks.every((check) => check.matches),
      checks,
    };
  }, [isManager, scopedMember, metrics, options]);

  function openMetricRows(
    memberName: string | null,
    metricKey: KpiKey,
    sourceTab: "tickets" | "calls" | "tasks" | "audits",
    title?: string,
    description?: string,
  ) {
    setRawDataMember(memberName);
    setRawDrillContext({
      metricKey,
      month: periodMode === "month" ? effectivePeriodValue : null,
      sourceTab,
      title,
      description,
    });
  }

  // ---- Auto-diagnostic: do we have ticket rows that don't have a
  // period_month? If so the user almost certainly imported with a buggy
  // parser version or has a `month` column format we don't yet recognize.
  // Show a yellow banner with actionable guidance.
  const ticketDiagnostic = useMemo(() => {
    let total = 0;
    let withMonth = 0;
    for (const m of metrics) {
      if (m.source_type !== "tickets") continue;
      total++;
      if (m.period_month) withMonth++;
    }
    return { total, withMonth, missing: total - withMonth };
  }, [metrics]);

  if (metrics.length === 0) {
    return <EmptyState />;
  }

  return (
    <Stack gap="md">
      {ticketDiagnostic.missing > 0 && ticketDiagnostic.withMonth === 0 && (
        <Alert
          color="yellow"
          variant="light"
          icon={<IconAlertTriangle size={14} />}
          title="Period data missing — re-derive needed"
        >
          <Stack gap="xs">
            <Text size="sm">
              {ticketDiagnostic.missing.toLocaleString()} ticket row
              {ticketDiagnostic.missing === 1 ? " has" : "s have"} no
              extractable month. These rows were imported before the latest
              parser update. Click below to re-process them against the stored
              <Code mx={4}>raw_json</Code>using the current logic — no
              re-import required.
            </Text>
            {onRederive && (
              <Group>
                <Button
                  size="xs"
                  color="cyan"
                  leftSection={<IconCalendar size={14} />}
                  loading={isRederiving}
                  onClick={onRederive}
                >
                  Re-derive periods now
                </Button>
                <Text size="xs" c="dimmed">
                  If the count stays at zero after re-deriving, click the 🔍 on
                  any member row to see what's actually in their{" "}
                  <Code>month</Code> column (column B) and{" "}
                  <Code>month_label</Code> fallback.
                </Text>
              </Group>
            )}
          </Stack>
        </Alert>
      )}
      <FilterBar
        queueFilter={queueFilter}
        onQueueChange={setQueueFilter}
        periodMode={periodMode}
        onPeriodModeChange={(m) => {
          setPeriodMode(m);
          setPeriodValue(null);
        }}
        periodValue={effectivePeriodValue}
        onPeriodValueChange={setPeriodValue}
        availableMonths={periods.months}
        availableQuarters={periods.quarters}
        excludeMaintenance={excludeMaintenance}
        onExcludeMaintenanceChange={setExcludeMaintenance}
        maintenanceCount={
          metrics.filter((m) => isMaintenanceTicket(m)).length
        }
        dayFilter={dayFilter}
        onDayFilterChange={setDayFilter}
        shiftFilter={shiftFilter}
        onShiftFilterChange={setShiftFilter}
      />

      <Card withBorder radius="md" p="sm">
        <Stack gap="xs">
          <ActiveFilterChips
            options={options}
            rowCount={filteredMetrics.length}
            scopeLabel={scopedMember ?? "Whole team"}
          />
          <Group gap="xs" wrap="wrap">
            <Badge variant="outline" color="grape">
              Scope source: {scopedMember ? (isManager ? "Manager drill-down" : "Self view") : "Team aggregate"}
            </Badge>
            <Badge variant="light" color="gray">
              Active days: {workload.activeDays}
            </Badge>
            <Badge variant="light" color="gray">
              Weekend load: {workload.weekendDays}
            </Badge>
            <Badge variant="light" color="gray">
              Shifts covered: {workload.shiftsCovered.length || 0}
            </Badge>
            {workload.ticketsPerDay != null && (
              <Badge variant="light" color="blue">
                Tickets/day: {workload.ticketsPerDay.toFixed(1)}
              </Badge>
            )}
          </Group>
        </Stack>
      </Card>

      {scopedMember ? (
        <MemberDetailView
          member={scopedMember}
          summary={
            summaries.find((s) => s.memberName === scopedMember) ?? null
          }
          activePeriodMonth={
            periodMode === "month" ? effectivePeriodValue : null
          }
          filterOptions={options}
          workload={workload}
          isManager={isManager}
          paritySummary={managerParity}
          onViewRawData={() =>
            openMetricRows(
              scopedMember,
              "tickets_acked",
              "tickets",
              `Raw Data — ${scopedMember}`,
              "Showing the currently filtered raw rows for this member. Use the KPI shortcuts below to jump to narrower row sets."
            )
          }
          onOpenMetricRows={(metricKey, sourceTab, title, description) =>
            openMetricRows(scopedMember, metricKey, sourceTab, title, description)
          }
        />
      ) : (
        <TeamOverview
          summaries={summaries}
          activePeriodMonth={
            periodMode === "month" ? effectivePeriodValue : null
          }
          filterOptions={options}
          workload={workload}
          onOpenMetricRows={(memberName, metricKey, sourceTab, title, description) =>
            openMetricRows(memberName, metricKey, sourceTab, title, description)
          }
        />
      )}

      <RawDataModal
        memberName={rawDataMember}
        metrics={metrics}
        filterOptions={options}
        drillContext={rawDrillContext ?? undefined}
        onClose={() => {
          setRawDataMember(null);
          setRawDrillContext(null);
        }}
        onDispute={
          currentUserName
            ? (m, f) => {
                setDisputeMetric(m);
                setDisputeField(f);
              }
            : undefined
        }
        disputesByMetricId={disputeMap}
      />

      <DisputeForm
        metric={disputeMetric}
        field={disputeField}
        submitterName={currentUserName ?? ""}
        onClose={() => {
          setDisputeMetric(null);
          setDisputeField(null);
        }}
        onSubmitted={handleDisputeSubmitted}
      />
    </Stack>
  );
}

// =============================================================================
// Filter bar — Queue + Period selectors
// =============================================================================

function FilterBar({
  queueFilter,
  onQueueChange,
  periodMode,
  onPeriodModeChange,
  periodValue,
  onPeriodValueChange,
  availableMonths,
  availableQuarters,
  excludeMaintenance,
  onExcludeMaintenanceChange,
  maintenanceCount,
  dayFilter,
  onDayFilterChange,
  shiftFilter,
  onShiftFilterChange,
}: {
  queueFilter: Queue | "all";
  onQueueChange: (q: Queue | "all") => void;
  periodMode: "all" | "month" | "quarter";
  onPeriodModeChange: (m: "all" | "month" | "quarter") => void;
  periodValue: string | null;
  onPeriodValueChange: (v: string | null) => void;
  availableMonths: string[];
  availableQuarters: string[];
  excludeMaintenance: boolean;
  onExcludeMaintenanceChange: (v: boolean) => void;
  maintenanceCount: number;
  dayFilter: DayFilter;
  onDayFilterChange: (v: DayFilter) => void;
  shiftFilter: ShiftFilter;
  onShiftFilterChange: (v: ShiftFilter) => void;
}) {
  const periodOptions = useMemo(() => {
    if (periodMode === "month") {
      return availableMonths.map((v) => ({
        value: v,
        label: formatMonthLabel(v),
      }));
    }
    if (periodMode === "quarter") {
      return availableQuarters.map((v) => ({ value: v, label: v }));
    }
    return [];
  }, [periodMode, availableMonths, availableQuarters]);

  return (
    <Card withBorder radius="md" p="sm">
      <Group gap="md" wrap="wrap">
        <Group gap={6} wrap="nowrap">
          <ThemeIcon
            variant="light"
            color="gray"
            radius="md"
            size="sm"
            aria-label="Queue filter"
          >
            <IconFilter size={12} />
          </ThemeIcon>
          <Text size="xs" c="dimmed" fw={600}>
            Queue
          </Text>
          <SegmentedControl
            size="xs"
            value={queueFilter}
            onChange={(v) => onQueueChange(v as Queue | "all")}
            data={[
              { value: "all", label: "All" },
              { value: "noc", label: "NOC" },
              { value: "mobility", label: "Mobility" },
            ]}
          />
        </Group>

        <Group gap={6} wrap="nowrap">
          <ThemeIcon
            variant="light"
            color="gray"
            radius="md"
            size="sm"
            aria-label="Period filter"
          >
            <IconCalendar size={12} />
          </ThemeIcon>
          <Text size="xs" c="dimmed" fw={600}>
            Period
          </Text>
          <SegmentedControl
            size="xs"
            value={periodMode}
            onChange={(v) =>
              onPeriodModeChange(v as "all" | "month" | "quarter")
            }
            data={[
              { value: "all", label: "All time" },
              { value: "month", label: "Month" },
              { value: "quarter", label: "Quarter" },
            ]}
          />
          {periodMode !== "all" && periodOptions.length > 0 && (
            <Select
              size="xs"
              w={170}
              data={periodOptions}
              value={periodValue}
              onChange={onPeriodValueChange}
              allowDeselect={false}
              comboboxProps={{ withinPortal: true }}
            />
          )}
          {periodMode !== "all" && periodOptions.length === 0 && (
            <Text size="xs" c="dimmed" fs="italic">
              (no {periodMode} data yet)
            </Text>
          )}
        </Group>

        {/* Maintenance-notification toggle (tickets only) */}
        <Group gap={6} wrap="nowrap">
          <ThemeIcon
            variant="light"
            color="gray"
            radius="md"
            size="sm"
            aria-label="Ticket category filter"
          >
            <IconTool size={12} />
          </ThemeIcon>
          <Tooltip
            label="When ON, ticket rows whose Issue Type is 'Maintenance Notification' are excluded from ticket KPIs. Call data is not affected."
            withinPortal
            multiline
            w={280}
          >
            <Switch
              size="xs"
              checked={excludeMaintenance}
              onChange={(e) =>
                onExcludeMaintenanceChange(e.currentTarget.checked)
              }
              label={`Exclude maintenance${maintenanceCount > 0 ? ` (${maintenanceCount})` : ""}`}
              styles={{ label: { fontSize: 11, fontWeight: 600 } }}
            />
          </Tooltip>
        </Group>

        {/* Weekday / Weekend toggle — applies to tickets, calls, and tasks */}
        <Group gap={6} wrap="nowrap">
          <ThemeIcon
            variant="light"
            color="gray"
            radius="md"
            size="sm"
            aria-label="Day type filter"
          >
            <IconCalendar size={12} />
          </ThemeIcon>
          <Tooltip
            label="Filter all KPIs (tickets, calls, tasks) to show only weekday or weekend data. Affects every metric on this page."
            withinPortal
            multiline
            w={260}
          >
            <SegmentedControl
              size="xs"
              value={dayFilter}
              onChange={(v) => onDayFilterChange(v as DayFilter)}
              data={[
                { label: "All days", value: "all" },
                { label: "Weekday", value: "weekday" },
                { label: "Weekend", value: "weekend" },
              ]}
              styles={{
                label: { fontSize: 11, fontWeight: 600, padding: "2px 8px" },
              }}
            />
          </Tooltip>
        </Group>

        {/* Shift filter — Early / Mid / Late */}
        <Group gap={6} wrap="nowrap">
          <ThemeIcon
            variant="light"
            color="gray"
            radius="md"
            size="sm"
            aria-label="Shift filter"
          >
            <IconClock size={12} />
          </ThemeIcon>
          <Tooltip
            label="Filter all KPIs by shift. Overlap hours (10 AM, 6 PM, 2 AM) are included in both adjacent shifts."
            withinPortal
            multiline
            w={260}
          >
            <Select
              size="xs"
              w={190}
              value={shiftFilter}
              onChange={(v) => onShiftFilterChange((v ?? "all") as ShiftFilter)}
              data={[
                { value: "all", label: SHIFT_LABELS.all },
                { value: "early", label: SHIFT_LABELS.early },
                { value: "mid", label: SHIFT_LABELS.mid },
                { value: "late", label: SHIFT_LABELS.late },
              ]}
              allowDeselect={false}
              comboboxProps={{ withinPortal: true }}
              styles={{
                input: { fontSize: 11, fontWeight: 600 },
              }}
            />
          </Tooltip>
        </Group>
      </Group>
    </Card>
  );
}

function formatMonthLabel(yyyyMm: string): string {
  const m = yyyyMm.match(/^(\d{4})-(\d{2})$/);
  if (!m) return yyyyMm;
  const date = new Date(parseInt(m[1], 10), parseInt(m[2], 10) - 1, 1);
  return date.toLocaleDateString(undefined, {
    month: "short",
    year: "numeric",
  });
}

// =============================================================================
// Team-wide view
// =============================================================================

function TeamOverview({
  summaries,
  activePeriodMonth,
  filterOptions,
  workload,
  onOpenMetricRows,
}: {
  summaries: MemberSummary[];
  activePeriodMonth: string | null;
  filterOptions: AggregateOptions;
  workload: ReturnType<typeof buildWorkloadContext>;
  onOpenMetricRows: (
    memberName: string | null,
    metricKey: KpiKey,
    sourceTab: "tickets" | "calls" | "tasks" | "audits",
    title?: string,
    description?: string,
  ) => void;
}) {
  // Track which source types have any data — only render their cards
  const hasTickets = summaries.some((s) => (s.byType.tickets?.rowCount ?? 0) > 0);
  const hasCalls = summaries.some((s) => (s.byType.calls?.rowCount ?? 0) > 0);
  const hasTasks = summaries.some((s) => (s.byType.tasks?.rowCount ?? 0) > 0);

  return (
    <Stack gap="lg">
      <Box>
        <Group gap="xs" mb="xs">
          <ThemeIcon variant="light" radius="md" size="md" color="green">
            <IconUsersGroup size={16} />
          </ThemeIcon>
          <Title order={5}>Team-wide performance</Title>
          <Badge variant="default" size="xs">
            {LOCKED_TEAM.length} members
          </Badge>
        </Group>
        <Stack gap={6}>
          <Text size="xs" c="dimmed">
            Aggregated across all imports matching the filters above. Manager
            view — drill into individuals via the View dropdown.
          </Text>
          <ActiveFilterChips options={filterOptions} rowCount={undefined} scopeLabel="Whole team" />
          <Group gap="xs" wrap="wrap">
            <Badge variant="light" color="gray">Active days: {workload.activeDays}</Badge>
            <Badge variant="light" color="gray">Weekend days: {workload.weekendDays}</Badge>
            <Badge variant="light" color="gray">Shifts covered: {workload.shiftsCovered.length || 0}</Badge>
            {workload.ticketsPerDay != null && <Badge variant="light" color="blue">Tickets/day: {workload.ticketsPerDay.toFixed(1)}</Badge>}
            {workload.callsPerDay != null && <Badge variant="light" color="green">Calls/day: {workload.callsPerDay.toFixed(1)}</Badge>}
          </Group>
        </Stack>
      </Box>

      <Grid gutter="md">
        {hasTickets && (
          <Grid.Col span={{ base: 12, lg: 12 }}>
            <TicketsKpiCard
              summaries={summaries}
              activePeriodMonth={activePeriodMonth}
              onOpenMetricRows={onOpenMetricRows}
            />
          </Grid.Col>
        )}
        {hasCalls && (
          <Grid.Col span={{ base: 12, lg: 12 }}>
            <CallsKpiCard
              summaries={summaries}
              onOpenMetricRows={onOpenMetricRows}
            />
          </Grid.Col>
        )}
        {hasTasks && (
          <Grid.Col span={{ base: 12, lg: 12 }}>
            <TasksKpiCard
              summaries={summaries}
              onOpenMetricRows={onOpenMetricRows}
            />
          </Grid.Col>
        )}
        {/* Generic legacy cards for queue/audit until they get
            user-defined KPIs of their own. */}
        {(["queue", "audit"] as SourceType[]).map((t) =>
          summaries.some((s) => (s.byType[t]?.rowCount ?? 0) > 0) ? (
            <Grid.Col key={t} span={{ base: 12, md: 6 }}>
              <GenericSourceCard sourceType={t} summaries={summaries} />
            </Grid.Col>
          ) : null,
        )}
      </Grid>
    </Stack>
  );
}

// =============================================================================
// Tickets KPI Card — NEW shape
// Top stats:  Tickets Acked · Avg Ack Time · Time-to-Carrier (% under 15)
// Per-member rows: tickets acked + within-24h%
// =============================================================================

function TicketsKpiCard({
  summaries,
  activePeriodMonth,
  onOpenMetricRows,
}: {
  summaries: MemberSummary[];
  activePeriodMonth: string | null;
  onOpenMetricRows: (
    memberName: string | null,
    metricKey: KpiKey,
    sourceTab: "tickets" | "calls" | "tasks" | "audits",
    title?: string,
    description?: string,
  ) => void;
}) {
  const [diagMember, setDiagMember] = useState<string | null>(null);

  const rows = summaries
    .map((s) => {
      const b = s.byType.tickets;
      if (!b || b.rowCount === 0) return null;
      const avgAck =
        b.ackMinutesSamples > 0 ? b.ackMinutesSum / b.ackMinutesSamples : null;
      const carrierPct =
        b.carrierTotalCount > 0
          ? (b.carrierUnder15Count / b.carrierTotalCount) * 100
          : null;
      // % of tickets closed within 24h, computed from
      // time_taken_to_close_tickets ("less than 24 hours" vs "more than
      // 24 hours"). Blank cells are excluded from BOTH numerator and
      // denominator so the percentage reflects only closed tickets that
      // had a value in the column.
      const within24Pct =
        b.within24TotalCount > 0
          ? (b.within24Count / b.within24TotalCount) * 100
          : null;
      const avgMttr =
        b.mttrMinutesSamples > 0
          ? b.mttrMinutesSum / b.mttrMinutesSamples
          : null;
      return {
        name: s.memberName,
        acked: b.rowCount,
        avgAck,
        carrierPct,
        carrierUnder: b.carrierUnder15Count,
        carrierTotal: b.carrierTotalCount,
        within24Pct,
        within24: b.within24Count,
        within24Total: b.within24TotalCount,
        avgMttr,
      };
    })
    .filter((r): r is NonNullable<typeof r> => r !== null)
    .sort((a, b) => b.acked - a.acked);

  const grandAcked = rows.reduce((s, r) => s + r.acked, 0);
  const grandAck =
    rows.length > 0
      ? rows.reduce((s, r) => s + (r.avgAck ?? 0) * (r.avgAck ? 1 : 0), 0) /
        Math.max(rows.filter((r) => r.avgAck != null).length, 1)
      : null;
  const grandCarrierUnder = rows.reduce((s, r) => s + r.carrierUnder, 0);
  const grandCarrierTotal = rows.reduce((s, r) => s + r.carrierTotal, 0);
  const grandCarrierPct =
    grandCarrierTotal > 0
      ? (grandCarrierUnder / grandCarrierTotal) * 100
      : null;
  const grandWithin24 = rows.reduce((s, r) => s + r.within24, 0);
  const grandWithin24Total = rows.reduce((s, r) => s + r.within24Total, 0);
  const grandWithin24Pct =
    grandWithin24Total > 0 ? (grandWithin24 / grandWithin24Total) * 100 : null;

  const maxAcked = rows.length > 0 ? Math.max(...rows.map((r) => r.acked)) : 0;

  return (
    <Card
      withBorder
      radius="md"
      p="md"
      style={{ borderTop: "2px solid var(--mantine-color-blue-6)" }}
    >
      <Stack gap="md">
        <Group gap="sm" wrap="nowrap">
          <ThemeIcon radius="md" variant="light" color="blue" size="lg">
            <IconTicket size={20} />
          </ThemeIcon>
          <Box style={{ flex: 1 }}>
            <Title order={5} style={{ lineHeight: 1.2 }}>
              Tickets
            </Title>
            <Text size="xs" c="dimmed">
              {rows.length} contributor{rows.length === 1 ? "" : "s"}
            </Text>
          </Box>
          <Group gap="lg" wrap="wrap" justify="flex-end">
            <KpiNumber
              label="Tickets Acked"
              value={grandAcked.toLocaleString()}
              color="blue"
            />
            <KpiNumber
              label="Avg Ack Time"
              value={grandAck != null ? formatMinutes(grandAck) : "—"}
              hint="from first_touch"
            />
            <KpiNumber
              label="Within 24h"
              value={
                grandWithin24Pct != null
                  ? `${Math.round(grandWithin24Pct)}%`
                  : "—"
              }
              hint={
                grandWithin24Total > 0
                  ? `${grandWithin24} / ${grandWithin24Total}`
                  : "no data"
              }
              color="grape"
            />
            <KpiNumber
              label="Carrier ≤ 15 min"
              value={
                grandCarrierPct != null
                  ? `${Math.round(grandCarrierPct)}%`
                  : "—"
              }
              hint={
                grandCarrierTotal > 0
                  ? `${grandCarrierUnder} / ${grandCarrierTotal}`
                  : "no data"
              }
              color="teal"
            />
          </Group>
        </Group>

        <Group gap="xs" wrap="wrap">
          <Button size="compact-xs" variant="light" color="blue" onClick={() => onOpenMetricRows(null, "tickets_acked", "tickets", "Raw Ticket Rows", "All ticket rows matching the active dashboard filters.")}>All ticket rows</Button>
          <Button size="compact-xs" variant="light" color="grape" onClick={() => onOpenMetricRows(null, "within_24h", "tickets", "Tickets Closed Within 24h", "Ticket rows used to compute the Within 24h KPI under the active filters.")}>Within 24h</Button>
          <Button size="compact-xs" variant="light" color="teal" onClick={() => onOpenMetricRows(null, "carrier_under_15", "tickets", "Carrier ≤ 15 min", "Ticket rows with carrier timing data under the active filters.")}>Carrier ≤ 15 min</Button>
          <Button size="compact-xs" variant="light" color="gray" onClick={() => onOpenMetricRows(null, "avg_ack_time", "tickets", "Ack Time Samples", "Ticket rows contributing to Avg Ack Time under the active filters.")}>Ack samples</Button>
        </Group>

        <Stack gap={4}>
          {rows.map((r) => {
            const tier = tierFor(r.name);
            const bar = maxAcked > 0 ? (r.acked / maxAcked) * 100 : 0;
            return (
              <Group gap="sm" wrap="nowrap" key={r.name}>
                <Box style={{ width: 160, flexShrink: 0 }}>
                  <Group gap={4} wrap="nowrap">
                    <Text size="xs" truncate fw={500}>
                      {r.name}
                    </Text>
                    {tier && (
                      <Badge
                        size="xs"
                        variant="light"
                        color={TIER_COLORS[tier]}
                        style={{ flexShrink: 0 }}
                      >
                        {TIER_SHORT_LABELS[tier]}
                      </Badge>
                    )}
                  </Group>
                </Box>
                <Tooltip
                  label={
                    <>
                      <div>
                        Tickets acked: {r.acked.toLocaleString()}
                        {grandAcked > 0 &&
                          ` (${((r.acked / grandAcked) * 100).toFixed(1)}% of team)`}
                      </div>
                      <div>
                        Avg ack time:{" "}
                        {r.avgAck != null ? formatMinutes(r.avgAck) : "—"}
                      </div>
                      <div>
                        Within 24h:{" "}
                        {r.within24Pct != null
                          ? `${Math.round(r.within24Pct)}% (${r.within24}/${r.within24Total})`
                          : "—"}
                      </div>
                      <div>
                        Carrier ≤ 15 min:{" "}
                        {r.carrierPct != null
                          ? `${Math.round(r.carrierPct)}% (${r.carrierUnder}/${r.carrierTotal})`
                          : "—"}
                      </div>
                      <div>
                        Avg MTTR:{" "}
                        {r.avgMttr != null ? formatMinutes(r.avgMttr) : "—"}
                      </div>
                    </>
                  }
                  withinPortal
                >
                  <Box style={{ flex: 1 }}>
                    <Progress value={bar} color="blue" size="md" radius="sm" />
                  </Box>
                </Tooltip>
                <Box style={{ width: 48, flexShrink: 0, textAlign: "right" }}>
                  <Text size="xs" ff="monospace" fw={700} c="blue.3">
                    {grandAcked > 0
                      ? `${Math.round((r.acked / grandAcked) * 100)}%`
                      : "—"}
                  </Text>
                </Box>
                <Box style={{ width: 78, flexShrink: 0, textAlign: "right" }}>
                  <Text size="xs" ff="monospace" fw={600}>
                    {r.acked.toLocaleString()}
                  </Text>
                  <Text size="xs" c="dimmed" ff="monospace">
                    {r.avgAck != null ? formatMinutes(r.avgAck) : "—"}
                  </Text>
                </Box>
                <Tooltip label="View raw ticket rows" withinPortal>
                  <ActionIcon
                    size="sm"
                    variant="subtle"
                    color="gray"
                    onClick={() =>
                      onOpenMetricRows(
                        r.name,
                        "tickets_acked",
                        "tickets",
                        `Raw Ticket Rows — ${r.name}`,
                        "Ticket rows for this member under the current dashboard filters."
                      )
                    }
                    aria-label="Raw data"
                  >
                    <IconTable size={14} />
                  </ActionIcon>
                </Tooltip>
                <Tooltip
                  label="Inspect — see which months this member's tickets are in"
                  withinPortal
                >
                  <ActionIcon
                    size="sm"
                    variant="subtle"
                    color="blue"
                    onClick={() => setDiagMember(r.name)}
                    aria-label="Inspect"
                  >
                    <IconSearch size={14} />
                  </ActionIcon>
                </Tooltip>
              </Group>
            );
          })}
        </Stack>
      </Stack>

      <TicketDiagnosticsModal
        memberName={diagMember}
        activePeriodMonth={activePeriodMonth}
        onClose={() => setDiagMember(null)}
      />
    </Card>
  );
}

// =============================================================================
// Diagnostics Modal — "Why is my count 61 instead of 162?"
// Shows the per-period breakdown for one member, plus a sample of raw_json
// snippets so the user can see exactly which column values determined the
// month resolution.
// =============================================================================

function TicketDiagnosticsModal({
  memberName,
  activePeriodMonth,
  onClose,
}: {
  memberName: string | null;
  activePeriodMonth: string | null;
  onClose: () => void;
}) {
  const [data, setData] = useState<MemberTicketDiagnostic | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!memberName) {
      setData(null);
      return;
    }
    let cancelled = false;
    setLoading(true);
    setError(null);
    diagnoseMemberTickets(memberName, {
      samplePeriod: activePeriodMonth,
      sampleSize: 10,
    })
      .then((d) => {
        if (!cancelled) setData(d);
      })
      .catch((err) => {
        if (!cancelled)
          setError(err instanceof Error ? err.message : String(err));
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [memberName, activePeriodMonth]);

  return (
    <Modal
      opened={memberName != null}
      onClose={onClose}
      title={
        memberName ? (
          <Group gap="xs">
            <IconSearch size={16} />
            <Text fw={600}>Ticket diagnostics — {memberName}</Text>
          </Group>
        ) : (
          "Ticket diagnostics"
        )
      }
      size="xl"
      withinPortal
    >
      {loading && (
        <Group justify="center" p="lg">
          <Loader size="sm" />
        </Group>
      )}
      {error && (
        <Text c="red" size="sm">
          {error}
        </Text>
      )}
      {!loading && !error && data && (
        <Stack gap="md">
          <Group gap="md" wrap="wrap">
            <Box>
              <Text size="xs" c="dimmed">
                Total ticket rows in DB
              </Text>
              <Text fw={700} size="xl" ff="monospace">
                {data.totalRows.toLocaleString()}
              </Text>
            </Box>
            {activePeriodMonth && (
              <Box>
                <Text size="xs" c="dimmed">
                  Rows for {formatMonthLabel(activePeriodMonth)}
                </Text>
                <Text fw={700} size="xl" ff="monospace" c="blue.4">
                  {(
                    data.byPeriod.find(
                      (p) => p.period_month === activePeriodMonth,
                    )?.count ?? 0
                  ).toLocaleString()}
                </Text>
              </Box>
            )}
            {data.byPeriod.find((p) => p.period_month == null) && (
              <Box>
                <Text size="xs" c="dimmed">
                  Rows with NO period (excluded from any month/quarter filter)
                </Text>
                <Text fw={700} size="xl" ff="monospace" c="orange.4">
                  {(
                    data.byPeriod.find((p) => p.period_month == null)?.count ??
                    0
                  ).toLocaleString()}
                </Text>
              </Box>
            )}
          </Group>

          <Box>
            <Text fw={600} size="sm" mb={4}>
              Distribution by period_month
            </Text>
            <Text size="xs" c="dimmed" mb="xs">
              Each ticket row gets one period_month value (derived from the{" "}
              <Code>month</Code> column &mdash; column B &mdash; with{" "}
              <Code>month_label</Code> as a fallback for legacy data). This
              shows exactly how the {data.totalRows} ticket rows are split
              across months. The "Tickets Acked" count for any selected month
              = the number of rows whose period_month matches that selection.
            </Text>
            <Table withTableBorder withColumnBorders striped highlightOnHover>
              <Table.Thead>
                <Table.Tr>
                  <Table.Th>period_month</Table.Th>
                  <Table.Th style={{ textAlign: "right" }}>Count</Table.Th>
                </Table.Tr>
              </Table.Thead>
              <Table.Tbody>
                {data.byPeriod.map((p) => (
                  <Table.Tr
                    key={p.period_month ?? "__null__"}
                    style={
                      p.period_month === activePeriodMonth
                        ? {
                            background:
                              "rgba(34, 139, 230, 0.12)",
                            fontWeight: 600,
                          }
                        : p.period_month == null
                          ? { color: "var(--mantine-color-orange-4)" }
                          : undefined
                    }
                  >
                    <Table.Td>
                      <Code>{p.period_month ?? "NULL"}</Code>
                      {p.period_month && (
                        <Text component="span" size="xs" c="dimmed" ml="xs">
                          {formatMonthLabel(p.period_month)}
                        </Text>
                      )}
                    </Table.Td>
                    <Table.Td style={{ textAlign: "right" }}>
                      {p.count.toLocaleString()}
                    </Table.Td>
                  </Table.Tr>
                ))}
              </Table.Tbody>
            </Table>
          </Box>

          <Box>
            <Group gap="xs" mb={4}>
              <Text fw={600} size="sm">
                Sample raw rows
                {activePeriodMonth
                  ? ` for ${formatMonthLabel(activePeriodMonth)}`
                  : ""}
              </Text>
              <Tooltip
                label="What this shows: the exact column values stored in raw_json that determined the month. The parser uses `month` (column B) as the primary source, with `month_label` as a fallback. If period_month doesn't match what column B says, that's a parser issue."
                withinPortal
                multiline
                w={320}
              >
                <ThemeIcon
                  size="xs"
                  variant="subtle"
                  color="gray"
                  radius="xl"
                >
                  <IconInfoCircle size={12} />
                </ThemeIcon>
              </Tooltip>
            </Group>
            {data.samples.length === 0 ? (
              <Text size="xs" c="dimmed">
                No rows to sample.
              </Text>
            ) : (
              <ScrollArea h={280}>
                <Stack gap="xs">
                  {data.samples.map((s, idx) => (
                    <Card
                      key={`sample-${s.id}-${s.period_month ?? "no-month"}-${s.period_quarter ?? "no-quarter"}-${idx}`}
                      withBorder
                      radius="sm"
                      p="xs"
                      style={{
                        background: "var(--mantine-color-dark-7)",
                      }}
                    >
                      <Group gap="xs" wrap="wrap" mb={4}>
                        <Badge size="xs" variant="light" color="gray">
                          id #{s.id}
                        </Badge>
                        <Badge
                          size="xs"
                          variant="light"
                          color={
                            s.period_month === activePeriodMonth
                              ? "blue"
                              : s.period_month == null
                                ? "orange"
                                : "gray"
                          }
                        >
                          period_month: {s.period_month ?? "NULL"}
                        </Badge>
                        <Badge size="xs" variant="light" color="gray">
                          quarter: {s.period_quarter ?? "NULL"}
                        </Badge>
                        <Badge size="xs" variant="light" color="gray">
                          queue: {s.queue ?? "NULL"}
                        </Badge>
                      </Group>
                      <Code
                        block
                        style={{
                          fontSize: 11,
                          whiteSpace: "pre-wrap",
                          wordBreak: "break-word",
                        }}
                      >
                        {Object.keys(s.rawSnapshot).length === 0
                          ? "(no month-related columns found in raw_json)"
                          : JSON.stringify(s.rawSnapshot, null, 2)}
                      </Code>
                    </Card>
                  ))}
                </Stack>
              </ScrollArea>
            )}
          </Box>
        </Stack>
      )}
    </Modal>
  );
}

// =============================================================================
// Calls KPI Card — NEW shape
// Top stats: Inbound Calls (Answered) · Refused Calls · Avg Handle Time · Avg Speed of Answer
// Per-member rows: answered + refused
// =============================================================================

function CallsKpiCard({
  summaries,
  onOpenMetricRows,
}: {
  summaries: MemberSummary[];
  onOpenMetricRows: (
    memberName: string | null,
    metricKey: KpiKey,
    sourceTab: "tickets" | "calls" | "tasks" | "audits",
    title?: string,
    description?: string,
  ) => void;
}) {
  const rows = summaries
    .map((s) => {
      const b = s.byType.calls;
      if (!b || b.rowCount === 0) return null;
      const avgHandle =
        b.handleSecondsSamples > 0
          ? b.handleSecondsSum / b.handleSecondsSamples
          : null;
      const avgWait =
        b.waitSecondsSamples > 0
          ? b.waitSecondsSum / b.waitSecondsSamples
          : null;
      return {
        name: s.memberName,
        answered: b.answeredCount,
        refused: b.refusedCount,
        missed: b.missedCount,
        avgHandle,
        avgWait,
      };
    })
    .filter((r): r is NonNullable<typeof r> => r !== null)
    .sort((a, b) => b.answered - a.answered);

  const grandAnswered = rows.reduce((s, r) => s + r.answered, 0);
  const grandRefused = rows.reduce((s, r) => s + r.refused, 0);
  const grandHandleSum = rows.reduce((s, r) => s + (r.avgHandle ?? 0), 0);
  const grandHandleCount = rows.filter((r) => r.avgHandle != null).length;
  const grandWaitSum = rows.reduce((s, r) => s + (r.avgWait ?? 0), 0);
  const grandWaitCount = rows.filter((r) => r.avgWait != null).length;
  const avgHandleAll =
    grandHandleCount > 0 ? grandHandleSum / grandHandleCount : null;
  const avgWaitAll =
    grandWaitCount > 0 ? grandWaitSum / grandWaitCount : null;

  const maxAnswered =
    rows.length > 0 ? Math.max(...rows.map((r) => r.answered)) : 0;

  return (
    <Card
      withBorder
      radius="md"
      p="md"
      style={{ borderTop: "2px solid var(--mantine-color-green-6)" }}
    >
      <Stack gap="md">
        <Group gap="sm" wrap="nowrap">
          <ThemeIcon radius="md" variant="light" color="green" size="lg">
            <IconPhone size={20} />
          </ThemeIcon>
          <Box style={{ flex: 1 }}>
            <Title order={5} style={{ lineHeight: 1.2 }}>
              Inbound Calls
            </Title>
            <Text size="xs" c="dimmed">
              {rows.length} contributor{rows.length === 1 ? "" : "s"}
            </Text>
          </Box>
          <Group gap="lg" wrap="wrap" justify="flex-end">
            <KpiNumber
              label="Answered"
              value={grandAnswered.toLocaleString()}
              color="green"
              icon={<IconPhoneIncoming size={12} />}
            />
            <KpiNumber
              label="Refused"
              value={grandRefused.toLocaleString()}
              color="red"
              hint="no answer (by other)"
              icon={<IconPhoneX size={12} />}
            />
            <KpiNumber
              label="Avg Handle"
              value={avgHandleAll != null ? formatSeconds(avgHandleAll) : "—"}
              hint="from Duration"
            />
            <KpiNumber
              label="Avg Speed of Answer"
              value={avgWaitAll != null ? formatSeconds(avgWaitAll) : "—"}
              hint="from Wait Time"
              color="teal"
            />
          </Group>
        </Group>

        <Group gap="xs" wrap="wrap">
          <Button size="compact-xs" variant="light" color="green" onClick={() => onOpenMetricRows(null, "inbound_calls", "calls", "Answered Call Rows", "Call rows contributing to answered inbound call volume under the active filters.")}>Answered calls</Button>
          <Button size="compact-xs" variant="light" color="red" onClick={() => onOpenMetricRows(null, "refused_calls", "calls", "Refused Call Rows", "Call rows contributing to refused / no-answer counts under the active filters.")}>Refused calls</Button>
          <Button size="compact-xs" variant="light" color="gray" onClick={() => onOpenMetricRows(null, "avg_handle_time", "calls", "Handle Time Samples", "Call rows with Duration values used for Avg Handle Time.")}>Handle samples</Button>
          <Button size="compact-xs" variant="light" color="teal" onClick={() => onOpenMetricRows(null, "avg_speed_of_answer", "calls", "Speed of Answer Samples", "Call rows with Wait Time values used for Avg Speed of Answer.")}>Speed-of-answer samples</Button>
        </Group>

        <Stack gap={4}>
          {rows.map((r) => {
            const tier = tierFor(r.name);
            const bar = maxAnswered > 0 ? (r.answered / maxAnswered) * 100 : 0;
            return (
              <Group gap="sm" wrap="nowrap" key={r.name}>
                <Box style={{ width: 160, flexShrink: 0 }}>
                  <Group gap={4} wrap="nowrap">
                    <Text size="xs" truncate fw={500}>
                      {r.name}
                    </Text>
                    {tier && (
                      <Badge
                        size="xs"
                        variant="light"
                        color={TIER_COLORS[tier]}
                        style={{ flexShrink: 0 }}
                      >
                        {TIER_SHORT_LABELS[tier]}
                      </Badge>
                    )}
                  </Group>
                </Box>
                <Tooltip
                  label={
                    <>
                      <div>
                        Answered: {r.answered}
                        {grandAnswered > 0 &&
                          ` (${((r.answered / grandAnswered) * 100).toFixed(1)}% of team)`}
                      </div>
                      <div>Refused: {r.refused}</div>
                      <div>Other missed: {r.missed}</div>
                      <div>
                        Avg handle:{" "}
                        {r.avgHandle != null ? formatSeconds(r.avgHandle) : "—"}
                      </div>
                      <div>
                        Avg speed of answer:{" "}
                        {r.avgWait != null ? formatSeconds(r.avgWait) : "—"}
                      </div>
                    </>
                  }
                  withinPortal
                >
                  <Box style={{ flex: 1 }}>
                    <Progress
                      value={bar}
                      color="green"
                      size="md"
                      radius="sm"
                    />
                  </Box>
                </Tooltip>
                <Box style={{ width: 48, flexShrink: 0, textAlign: "right" }}>
                  <Text size="xs" ff="monospace" fw={700} c="green.3">
                    {grandAnswered > 0
                      ? `${Math.round((r.answered / grandAnswered) * 100)}%`
                      : "—"}
                  </Text>
                </Box>
                <Box style={{ width: 88, flexShrink: 0, textAlign: "right" }}>
                  <Text size="xs" ff="monospace" fw={600} c="green.4">
                    {r.answered.toLocaleString()}
                  </Text>
                  <Text
                    size="xs"
                    ff="monospace"
                    c={r.refused > 0 ? "red.4" : "dimmed"}
                  >
                    {r.refused} refused
                  </Text>
                </Box>
                <Tooltip label="View raw call rows" withinPortal>
                  <ActionIcon
                    size="sm"
                    variant="subtle"
                    color="gray"
                    onClick={() =>
                      onOpenMetricRows(
                        r.name,
                        "inbound_calls",
                        "calls",
                        `Raw Call Rows — ${r.name}`,
                        "Call rows for this member under the current dashboard filters."
                      )
                    }
                    aria-label="Raw data"
                  >
                    <IconTable size={14} />
                  </ActionIcon>
                </Tooltip>
              </Group>
            );
          })}
        </Stack>
      </Stack>
    </Card>
  );
}

// =============================================================================
// Tasks KPI Card
// Top stats: Total Tasks Worked · SLA-Met %
// Per-member rows: tasks + SLA-Met %
// =============================================================================

function TasksKpiCard({
  summaries,
  onOpenMetricRows,
}: {
  summaries: MemberSummary[];
  onOpenMetricRows: (
    memberName: string | null,
    metricKey: KpiKey,
    sourceTab: "tickets" | "calls" | "tasks" | "audits",
    title?: string,
    description?: string,
  ) => void;
}) {
  const rows = summaries
    .map((s) => {
      const b = s.byType.tasks;
      if (!b || b.rowCount === 0) return null;
      const slaPct =
        b.slaMetTotalCount > 0
          ? (b.slaMetCount / b.slaMetTotalCount) * 100
          : null;
      return {
        name: s.memberName,
        tasks: b.rowCount,
        slaMet: b.slaMetCount,
        slaTotal: b.slaMetTotalCount,
        slaPct,
      };
    })
    .filter((r): r is NonNullable<typeof r> => r !== null)
    .sort((a, b) => b.tasks - a.tasks);

  const grandTasks = rows.reduce((s, r) => s + r.tasks, 0);
  const grandSlaMet = rows.reduce((s, r) => s + r.slaMet, 0);
  const grandSlaTotal = rows.reduce((s, r) => s + r.slaTotal, 0);
  const grandSlaPct =
    grandSlaTotal > 0 ? (grandSlaMet / grandSlaTotal) * 100 : null;

  const maxTasks = rows.length > 0 ? Math.max(...rows.map((r) => r.tasks)) : 0;

  return (
    <Card
      withBorder
      radius="md"
      p="md"
      style={{ borderTop: "2px solid var(--mantine-color-orange-6)" }}
    >
      <Stack gap="md">
        <Group gap="sm" wrap="nowrap">
          <ThemeIcon radius="md" variant="light" color="orange" size="lg">
            <IconClipboardList size={20} />
          </ThemeIcon>
          <Box style={{ flex: 1 }}>
            <Title order={5} style={{ lineHeight: 1.2 }}>
              Tasks
            </Title>
            <Text size="xs" c="dimmed">
              {rows.length} contributor{rows.length === 1 ? "" : "s"}
            </Text>
          </Box>
          <Group gap="lg" wrap="wrap" justify="flex-end">
            <KpiNumber
              label="Total Tasks Worked"
              value={grandTasks.toLocaleString()}
              color="orange"
            />
            <KpiNumber
              label="SLA-Met"
              value={
                grandSlaPct != null ? `${Math.round(grandSlaPct)}%` : "—"
              }
              hint={
                grandSlaTotal > 0
                  ? `${grandSlaMet} / ${grandSlaTotal}`
                  : "no Y/N data"
              }
              color="teal"
            />
          </Group>
        </Group>

        <Group gap="xs" wrap="wrap">
          <Button size="compact-xs" variant="light" color="orange" onClick={() => onOpenMetricRows(null, "tasks_worked", "tasks", "Task Rows", "Task rows matching the active dashboard filters.")}>All task rows</Button>
          <Button size="compact-xs" variant="light" color="teal" onClick={() => onOpenMetricRows(null, "sla_met", "tasks", "SLA-Met Task Rows", "Task rows contributing to the SLA-Met KPI under the active filters.")}>SLA rows</Button>
        </Group>

        <Stack gap={4}>
          {rows.map((r) => {
            const tier = tierFor(r.name);
            const bar = maxTasks > 0 ? (r.tasks / maxTasks) * 100 : 0;
            return (
              <Group gap="sm" wrap="nowrap" key={r.name}>
                <Box style={{ width: 160, flexShrink: 0 }}>
                  <Group gap={4} wrap="nowrap">
                    <Text size="xs" truncate fw={500}>
                      {r.name}
                    </Text>
                    {tier && (
                      <Badge
                        size="xs"
                        variant="light"
                        color={TIER_COLORS[tier]}
                        style={{ flexShrink: 0 }}
                      >
                        {TIER_SHORT_LABELS[tier]}
                      </Badge>
                    )}
                  </Group>
                </Box>
                <Tooltip
                  label={
                    <>
                      <div>
                        Tasks worked: {r.tasks.toLocaleString()}
                        {grandTasks > 0 &&
                          ` (${((r.tasks / grandTasks) * 100).toFixed(1)}% of team)`}
                      </div>
                      <div>
                        SLA-Met:{" "}
                        {r.slaPct != null
                          ? `${Math.round(r.slaPct)}% (${r.slaMet}/${r.slaTotal})`
                          : "—"}
                      </div>
                    </>
                  }
                  withinPortal
                >
                  <Box style={{ flex: 1 }}>
                    <Progress
                      value={bar}
                      color="orange"
                      size="md"
                      radius="sm"
                    />
                  </Box>
                </Tooltip>
                <Box style={{ width: 48, flexShrink: 0, textAlign: "right" }}>
                  <Text size="xs" ff="monospace" fw={700} c="orange.3">
                    {grandTasks > 0
                      ? `${Math.round((r.tasks / grandTasks) * 100)}%`
                      : "—"}
                  </Text>
                </Box>
                <Box style={{ width: 88, flexShrink: 0, textAlign: "right" }}>
                  <Text size="xs" ff="monospace" fw={600} c="orange.4">
                    {r.tasks.toLocaleString()}
                  </Text>
                  <Text size="xs" ff="monospace" c="dimmed">
                    {r.slaPct != null ? `${Math.round(r.slaPct)}% SLA` : "—"}
                  </Text>
                </Box>
                <Tooltip label="View raw task rows" withinPortal>
                  <ActionIcon
                    size="sm"
                    variant="subtle"
                    color="gray"
                    onClick={() =>
                      onOpenMetricRows(
                        r.name,
                        "tasks_worked",
                        "tasks",
                        `Raw Task Rows — ${r.name}`,
                        "Task rows for this member under the current dashboard filters."
                      )
                    }
                    aria-label="Raw data"
                  >
                    <IconTable size={14} />
                  </ActionIcon>
                </Tooltip>
              </Group>
            );
          })}
        </Stack>
      </Stack>
    </Card>
  );
}

// =============================================================================
// Generic source card (queue / audit) — legacy shape preserved
// =============================================================================

interface GenericConfig {
  label: string;
  icon: ComponentType<{ size?: number }>;
  color: string;
  totalLabel: string;
  successLabel: string;
  showDuration: boolean;
  showScore: boolean;
}

const GENERIC_CONFIGS: Record<SourceType, GenericConfig> = {
  tickets: {
    label: "Tickets",
    icon: IconTicket,
    color: "blue",
    totalLabel: "Owned",
    successLabel: "Within 24h",
    showDuration: true,
    showScore: false,
  },
  calls: {
    label: "Inbound Calls",
    icon: IconPhone,
    color: "green",
    totalLabel: "Calls",
    successLabel: "Answered",
    showDuration: true,
    showScore: false,
  },
  tasks: {
    label: "Tasks",
    icon: IconClipboardList,
    color: "violet",
    totalLabel: "Tasks",
    successLabel: "Completed",
    showDuration: false,
    showScore: false,
  },
  queue: {
    label: "Queue Availability",
    icon: IconClock,
    color: "orange",
    totalLabel: "Sessions",
    successLabel: "",
    showDuration: true,
    showScore: true,
  },
  audit: {
    label: "Audit",
    icon: IconShieldCheck,
    color: "pink",
    totalLabel: "Audits",
    successLabel: "Passed",
    showDuration: false,
    showScore: true,
  },
};

function GenericSourceCard({
  sourceType,
  summaries,
}: {
  sourceType: SourceType;
  summaries: MemberSummary[];
}) {
  const config = GENERIC_CONFIGS[sourceType];
  const rows = summaries
    .map((s) => ({
      name: s.memberName,
      b: s.byType[sourceType],
    }))
    .filter((r) => r.b && r.b.rowCount > 0)
    .map((r) => ({
      name: r.name,
      total: r.b!.totalSum,
      success: r.b!.successSum,
      duration: r.b!.durationSum,
      score: r.b!.latestScore,
      scoreText: r.b!.latestScoreText,
      rowCount: r.b!.rowCount,
    }))
    .sort((a, b) => {
      if (config.showScore && (a.score != null || b.score != null)) {
        return (b.score ?? -1) - (a.score ?? -1);
      }
      return b.total - a.total;
    });

  const grandTotal = rows.reduce((n, r) => n + r.total, 0);
  const grandSuccess = rows.reduce((n, r) => n + r.success, 0);
  const grandDuration = rows.reduce((n, r) => n + r.duration, 0);
  const maxTotal = rows.length > 0 ? Math.max(...rows.map((r) => r.total)) : 0;

  const Icon = config.icon;

  return (
    <Card
      withBorder
      radius="md"
      p="md"
      h="100%"
      style={{
        borderTop: `2px solid var(--mantine-color-${config.color}-6)`,
      }}
    >
      <Stack gap="sm">
        <Group gap="sm">
          <ThemeIcon radius="md" variant="light" color={config.color} size="lg">
            <Icon size={20} />
          </ThemeIcon>
          <Box style={{ flex: 1 }}>
            <Title order={5}>{config.label}</Title>
            <Text size="xs" c="dimmed">
              {rows.length} contributor{rows.length === 1 ? "" : "s"}
            </Text>
          </Box>
          <Stack gap={0} align="flex-end">
            <Text
              size="lg"
              fw={700}
              ff="monospace"
              c={`${config.color}.4`}
            >
              {grandTotal.toLocaleString()}
            </Text>
            <Text size="xs" c="dimmed" tt="uppercase" fw={600}>
              {config.totalLabel}
            </Text>
          </Stack>
        </Group>
        <Group gap="lg">
          {config.successLabel && grandSuccess > 0 && (
            <Box>
              <Text size="xs" c="dimmed">
                {config.successLabel}
              </Text>
              <Text size="sm" fw={600} ff="monospace">
                {grandSuccess.toLocaleString()}
                {grandTotal > 0 && (
                  <Text component="span" size="xs" c="dimmed" ml={4}>
                    ({Math.round((grandSuccess / grandTotal) * 100)}%)
                  </Text>
                )}
              </Text>
            </Box>
          )}
          {config.showDuration && grandDuration > 0 && (
            <Box>
              <Text size="xs" c="dimmed">
                Duration
              </Text>
              <Text size="sm" fw={600} ff="monospace">
                {formatMinutes(grandDuration)}
              </Text>
            </Box>
          )}
          {sourceType === "audit" && rows.length > 0 && (
            <Box>
              <Text size="xs" c="dimmed">
                Average score
              </Text>
              <Text size="sm" fw={600} ff="monospace">
                {Math.round(rows.reduce((sum, r) => sum + (r.score ?? 0) * (r.rowCount > 0 ? r.rowCount : 0), 0) /
                  Math.max(rows.reduce((sum, r) => sum + r.rowCount, 0), 1))}
              </Text>
            </Box>
          )}
        </Group>
        <Stack gap={4}>
          {rows.map((r) => {
            const tier = tierFor(r.name);
            const bar = maxTotal > 0 ? (r.total / maxTotal) * 100 : 0;
            return (
              <Group gap="sm" wrap="nowrap" key={r.name}>
                <Box style={{ width: 140, flexShrink: 0 }}>
                  <Group gap={4} wrap="nowrap">
                    <Text size="xs" truncate fw={500}>
                      {r.name}
                    </Text>
                    {tier && (
                      <Badge
                        size="xs"
                        variant="light"
                        color={TIER_COLORS[tier]}
                      >
                        {TIER_SHORT_LABELS[tier]}
                      </Badge>
                    )}
                  </Group>
                </Box>
                <Box style={{ flex: 1 }}>
                  <Progress value={bar} color={config.color} size="md" />
                </Box>
                <Box style={{ width: 60, textAlign: "right" }}>
                  <Text size="xs" ff="monospace" fw={600}>
                    {config.showScore && r.scoreText
                      ? r.scoreText
                      : r.total.toLocaleString()}
                  </Text>
                </Box>
              </Group>
            );
          })}
        </Stack>
      </Stack>
    </Card>
  );
}

// =============================================================================
// Single-member detail view
// =============================================================================

function MemberDetailView({
  member,
  summary,
  activePeriodMonth,
  filterOptions,
  workload,
  isManager,
  paritySummary,
  onViewRawData,
  onOpenMetricRows,
}: {
  member: string;
  summary: MemberSummary | null;
  activePeriodMonth: string | null;
  filterOptions: AggregateOptions;
  workload: ReturnType<typeof buildWorkloadContext>;
  isManager: boolean;
  paritySummary: {
    allMatch: boolean;
    checks: Array<{
      key: KpiKey;
      label: string;
      managerValue: number | null;
      selfValue: number | null;
      matches: boolean;
    }>;
  } | null;
  onViewRawData: () => void;
  onOpenMetricRows: (
    metricKey: KpiKey,
    sourceTab: "tickets" | "calls" | "tasks" | "audits",
    title?: string,
    description?: string,
  ) => void;
}) {
  const [diagOpen, setDiagOpen] = useState(false);
  const tier = tierFor(member);
  const hasData =
    (summary?.byType && Object.keys(summary.byType).length > 0) ?? false;

  const tickets = summary?.byType.tickets;
  const calls = summary?.byType.calls;

  return (
    <Stack gap="lg">
      <Card
        withBorder
        radius="md"
        p="md"
        style={{
          borderColor: tier
            ? `var(--mantine-color-${TIER_COLORS[tier]}-7)`
            : undefined,
        }}
      >
        <Group justify="space-between">
          <Group gap="md">
            <Box
              style={{
                width: 48,
                height: 48,
                borderRadius: "50%",
                background: tier
                  ? `var(--mantine-color-${TIER_COLORS[tier]}-9)`
                  : "var(--mantine-color-dark-5)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                color: tier
                  ? `var(--mantine-color-${TIER_COLORS[tier]}-2)`
                  : "var(--mantine-color-dimmed)",
                fontWeight: 700,
                fontSize: 18,
              }}
            >
              {member
                .split(" ")
                .map((p) => p[0])
                .slice(0, 2)
                .join("")}
            </Box>
            <Box>
              <Title order={4}>{member}</Title>
              <Group gap="xs" wrap="wrap">
                {tier && (
                  <Badge variant="light" color={TIER_COLORS[tier]}>
                    {TIER_LABELS[tier]}
                  </Badge>
                )}
                <Badge variant="outline" color="grape">
                  Scope source: {isManager ? "Manager drill-down" : "Self view"}
                </Badge>
              </Group>
            </Box>
          </Group>
          <Group gap="xs">
            <Tooltip label="View raw data rows" withinPortal>
              <ActionIcon
                size="md"
                variant="light"
                color="gray"
                onClick={onViewRawData}
                aria-label="View raw data"
              >
                <IconTable size={16} />
              </ActionIcon>
            </Tooltip>
            {(tickets?.rowCount ?? 0) > 0 && (
              <Tooltip
                label="Inspect ticket rows — see which months they're in"
                withinPortal
              >
                <ActionIcon
                  size="md"
                  variant="light"
                  color="blue"
                  onClick={() => setDiagOpen(true)}
                  aria-label="Inspect tickets"
                >
                  <IconSearch size={16} />
                </ActionIcon>
              </Tooltip>
            )}
          </Group>
        </Group>
        <Stack gap={8} mt="sm">
          <ActiveFilterChips options={filterOptions} scopeLabel={member} />
          <Group gap="xs" wrap="wrap">
            <Badge variant="light" color="gray">Active days: {workload.activeDays}</Badge>
            <Badge variant="light" color="gray">Weekend days: {workload.weekendDays}</Badge>
            <Badge variant="light" color="gray">Shifts covered: {workload.shiftsCovered.length || 0}</Badge>
            {workload.ticketsPerDay != null && <Badge variant="light" color="blue">Tickets/day: {workload.ticketsPerDay.toFixed(1)}</Badge>}
            {workload.callsPerDay != null && <Badge variant="light" color="green">Calls/day: {workload.callsPerDay.toFixed(1)}</Badge>}
            {workload.tasksPerDay != null && <Badge variant="light" color="orange">Tasks/day: {workload.tasksPerDay.toFixed(1)}</Badge>}
          </Group>
        </Stack>
      </Card>

      <TicketDiagnosticsModal
        memberName={diagOpen ? member : null}
        activePeriodMonth={activePeriodMonth}
        onClose={() => setDiagOpen(false)}
      />

      {paritySummary && (
        <Card
          withBorder
          radius="md"
          p="md"
          bg={paritySummary.allMatch ? "teal.0" : "red.0"}
          style={{ borderColor: paritySummary.allMatch ? "var(--mantine-color-teal-4)" : "var(--mantine-color-red-4)" }}
        >
          <Stack gap="xs">
            <Group justify="space-between" wrap="wrap">
              <Group gap="xs" wrap="wrap">
                <Badge variant="light" color={paritySummary.allMatch ? "teal" : "red"}>
                  {paritySummary.allMatch ? "Parity check passed" : "Parity mismatch detected"}
                </Badge>
                <Text size="xs" c="dimmed">
                  Manager drill-down compared against a simulated self-view for the same member and active filters.
                </Text>
              </Group>
              <Button
                size="compact-xs"
                variant="light"
                color={paritySummary.allMatch ? "teal" : "red"}
                onClick={() =>
                  onOpenMetricRows(
                    "tickets_acked",
                    "tickets",
                    `Parity raw rows — ${member}`,
                    "Open the raw rows behind this member scope to verify manager and self views are using the same filtered records."
                  )
                }
              >
                Open parity rows
              </Button>
            </Group>
            <Group gap="xs" wrap="wrap">
              {paritySummary.checks.map((check) => (
                <Badge
                  key={check.key}
                  variant="light"
                  color={check.matches ? "teal" : "red"}
                >
                  {check.label}: {check.matches ? "match" : "mismatch"}
                </Badge>
              ))}
            </Group>
          </Stack>
        </Card>
      )}

      {!hasData ? (
        <Card withBorder radius="md" p="xl">
          <Stack align="center" gap="sm">
            <IconClipboardCheck size={40} color="var(--mantine-color-dimmed)" />
            <Text size="sm" c="dimmed" ta="center">
              No metrics for {member} in the selected queue + period.
            </Text>
          </Stack>
        </Card>
      ) : (
        <Grid gutter="md">
          {/* Tickets — always shown */}
          <Grid.Col span={{ base: 12, md: 6 }}>
            {tickets && tickets.rowCount > 0
              ? <MemberTicketCard b={tickets} onOpenMetricRows={onOpenMetricRows} />
              : <EmptySectionCard label="Tickets" icon={IconTicket} color="blue" />}
          </Grid.Col>

          {/* Calls — always shown */}
          <Grid.Col span={{ base: 12, md: 6 }}>
            {calls && calls.rowCount > 0
              ? <MemberCallCard b={calls} onOpenMetricRows={onOpenMetricRows} />
              : <EmptySectionCard label="Calls" icon={IconPhone} color="green" />}
          </Grid.Col>

          {/* Tasks — always shown */}
          <Grid.Col span={{ base: 12, md: 6 }}>
            {summary?.byType.tasks && summary.byType.tasks.rowCount > 0
              ? <MemberTaskCard b={summary.byType.tasks} onOpenMetricRows={onOpenMetricRows} />
              : <EmptySectionCard label="Tasks" icon={IconClipboardList} color="violet" />}
          </Grid.Col>

          {/* Audit — always shown */}
          {(() => {
            const b = summary?.byType["audit"];
            return (
              <Grid.Col span={{ base: 12, md: 6 }}>
                {b && b.rowCount > 0
                  ? <MemberGenericCard sourceType="audit" b={b} />
                  : <EmptySectionCard label="Audit" icon={IconShieldCheck} color="pink" />}
              </Grid.Col>
            );
          })()}

          {/* Queue — only shown when data exists */}
          {(() => {
            const b = summary?.byType["queue"];
            if (!b || b.rowCount === 0) return null;
            return (
              <Grid.Col span={{ base: 12, sm: 6, lg: 4 }}>
                <MemberGenericCard sourceType="queue" b={b} />
              </Grid.Col>
            );
          })()}
        </Grid>
      )}
    </Stack>
  );
}

function EmptySectionCard({ label, icon: Icon, color }: { label: string; icon: ComponentType<{ size?: number }>; color: string }) {
  return (
    <Card withBorder radius="md" p="md" h="100%" style={{ borderTop: `2px solid var(--mantine-color-${color}-9)` }}>
      <Group gap="sm" mb="xs">
        <ThemeIcon variant="light" color={color} radius="md">
          <Icon size={16} />
        </ThemeIcon>
        <Text fw={600} size="sm">{label}</Text>
      </Group>
      <Text size="xs" c="dimmed">No data imported yet for this period.</Text>
    </Card>
  );
}

function MemberTicketCard({
  b,
  onOpenMetricRows,
}: {
  b: SourceBucket;
  onOpenMetricRows: (
    metricKey: KpiKey,
    sourceTab: "tickets" | "calls" | "tasks" | "audits",
    title?: string,
    description?: string,
  ) => void;
}) {
  const avgAck =
    b.ackMinutesSamples > 0 ? b.ackMinutesSum / b.ackMinutesSamples : null;
  const avgMttr =
    b.mttrMinutesSamples > 0 ? b.mttrMinutesSum / b.mttrMinutesSamples : null;
  const carrierPct =
    b.carrierTotalCount > 0
      ? (b.carrierUnder15Count / b.carrierTotalCount) * 100
      : null;
  // Within-24h % uses ONLY the rows where time_taken_to_close_tickets
  // had a recognised value ("less than 24 hours" / "more than 24 hours").
  // Blank cells (open tickets, etc.) are excluded from both numerator
  // and denominator.
  const within24Pct =
    b.within24TotalCount > 0
      ? (b.within24Count / b.within24TotalCount) * 100
      : null;

  return (
    <Card
      withBorder
      radius="md"
      p="md"
      h="100%"
      style={{ borderTop: "2px solid var(--mantine-color-blue-6)" }}
    >
      <Group gap="sm" mb="md">
        <ThemeIcon variant="light" color="blue" radius="md">
          <IconTicket size={16} />
        </ThemeIcon>
        <Text fw={600}>Tickets</Text>
      </Group>
      <Group gap="xs" mb="sm" wrap="wrap">
        <Button size="compact-xs" variant="light" color="blue" onClick={() => onOpenMetricRows("tickets_acked", "tickets", "Member Ticket Rows", "Ticket rows for this member under the active filters.")}>All rows</Button>
        <Button size="compact-xs" variant="light" color="gray" onClick={() => onOpenMetricRows("avg_ack_time", "tickets", "Member Ack Samples", "Ticket rows contributing to Avg Ack Time for this member.")}>Ack samples</Button>
        <Button size="compact-xs" variant="light" color="teal" onClick={() => onOpenMetricRows("carrier_under_15", "tickets", "Member Carrier Rows", "Ticket rows with carrier timing data for this member.")}>Carrier rows</Button>
        <Button size="compact-xs" variant="light" color="grape" onClick={() => onOpenMetricRows("within_24h", "tickets", "Member Within-24h Rows", "Ticket rows contributing to the Within 24h KPI for this member.")}>Within 24h rows</Button>
      </Group>
      <Grid gutter="sm">
        <Grid.Col span={6}>
          <KpiBlock
            label="Tickets Acked"
            value={b.rowCount.toLocaleString()}
            color="blue"
          />
        </Grid.Col>
        <Grid.Col span={6}>
          <KpiBlock
            label="Avg Ack Time"
            value={avgAck != null ? formatMinutes(avgAck) : "—"}
            hint={`${b.ackMinutesSamples} sample${b.ackMinutesSamples === 1 ? "" : "s"}`}
          />
        </Grid.Col>
        <Grid.Col span={6}>
          <KpiBlock
            label="Carrier ≤ 15 min"
            value={carrierPct != null ? `${Math.round(carrierPct)}%` : "—"}
            hint={
              b.carrierTotalCount > 0
                ? `${b.carrierUnder15Count} / ${b.carrierTotalCount}`
                : "no data"
            }
            color="teal"
          />
        </Grid.Col>
        <Grid.Col span={6}>
          <KpiBlock
            label="Within 24h"
            value={within24Pct != null ? `${Math.round(within24Pct)}%` : "—"}
            hint={
              b.within24TotalCount > 0
                ? `${b.within24Count} / ${b.within24TotalCount}`
                : "no data"
            }
            color="grape"
          />
        </Grid.Col>
        <Grid.Col span={6}>
          <KpiBlock
            label="Avg MTTR"
            value={avgMttr != null ? formatMinutes(avgMttr) : "—"}
            hint={`${b.mttrMinutesSamples} sample${b.mttrMinutesSamples === 1 ? "" : "s"}`}
          />
        </Grid.Col>
      </Grid>
    </Card>
  );
}

function MemberCallCard({
  b,
  onOpenMetricRows,
}: {
  b: SourceBucket;
  onOpenMetricRows: (
    metricKey: KpiKey,
    sourceTab: "tickets" | "calls" | "tasks" | "audits",
    title?: string,
    description?: string,
  ) => void;
}) {
  const avgHandle =
    b.handleSecondsSamples > 0
      ? b.handleSecondsSum / b.handleSecondsSamples
      : null;
  const avgWait =
    b.waitSecondsSamples > 0
      ? b.waitSecondsSum / b.waitSecondsSamples
      : null;

  return (
    <Card
      withBorder
      radius="md"
      p="md"
      h="100%"
      style={{ borderTop: "2px solid var(--mantine-color-green-6)" }}
    >
      <Group gap="sm" mb="md">
        <ThemeIcon variant="light" color="green" radius="md">
          <IconPhone size={16} />
        </ThemeIcon>
        <Text fw={600}>Inbound Calls</Text>
      </Group>
      <Group gap="xs" mb="sm" wrap="wrap">
        <Button size="compact-xs" variant="light" color="green" onClick={() => onOpenMetricRows("inbound_calls", "calls", "Member Call Rows", "Call rows for this member under the active filters.")}>All rows</Button>
        <Button size="compact-xs" variant="light" color="red" onClick={() => onOpenMetricRows("refused_calls", "calls", "Member Refused Call Rows", "Call rows contributing to refused / no-answer counts for this member.")}>Refused rows</Button>
        <Button size="compact-xs" variant="light" color="gray" onClick={() => onOpenMetricRows("avg_handle_time", "calls", "Member Handle Samples", "Call rows with Duration values for this member.")}>Handle samples</Button>
        <Button size="compact-xs" variant="light" color="teal" onClick={() => onOpenMetricRows("avg_speed_of_answer", "calls", "Member Wait Samples", "Call rows with Wait Time values for this member.")}>Wait samples</Button>
      </Group>
      <Grid gutter="sm">
        <Grid.Col span={6}>
          <KpiBlock
            label="Inbound Calls (Answered)"
            value={b.answeredCount.toLocaleString()}
            color="green"
          />
        </Grid.Col>
        <Grid.Col span={6}>
          <KpiBlock
            label="Refused Calls"
            value={b.refusedCount.toLocaleString()}
            color={b.refusedCount > 0 ? "red" : undefined}
            hint='"No Answer (Answered by Other)"'
          />
        </Grid.Col>
        <Grid.Col span={6}>
          <KpiBlock
            label="Avg Handle Time"
            value={avgHandle != null ? formatSeconds(avgHandle) : "—"}
            hint="from Duration"
          />
        </Grid.Col>
        <Grid.Col span={6}>
          <KpiBlock
            label="Avg Speed of Answer"
            value={avgWait != null ? formatSeconds(avgWait) : "—"}
            hint="from Wait Time"
            color="teal"
          />
        </Grid.Col>
      </Grid>
    </Card>
  );
}

function MemberTaskCard({
  b,
  onOpenMetricRows,
}: {
  b: SourceBucket;
  onOpenMetricRows: (
    metricKey: KpiKey,
    sourceTab: "tickets" | "calls" | "tasks" | "audits",
    title?: string,
    description?: string,
  ) => void;
}) {
  const slaPct =
    b.slaMetTotalCount > 0
      ? (b.slaMetCount / b.slaMetTotalCount) * 100
      : null;

  return (
    <Card
      withBorder
      radius="md"
      p="md"
      h="100%"
      style={{ borderTop: "2px solid var(--mantine-color-orange-6)" }}
    >
      <Group gap="sm" mb="md">
        <ThemeIcon variant="light" color="orange" radius="md">
          <IconClipboardList size={16} />
        </ThemeIcon>
        <Text fw={600}>Tasks</Text>
      </Group>
      <Group gap="xs" mb="sm" wrap="wrap">
        <Button size="compact-xs" variant="light" color="orange" onClick={() => onOpenMetricRows("tasks_worked", "tasks", "Member Task Rows", "Task rows for this member under the active filters.")}>All rows</Button>
        <Button size="compact-xs" variant="light" color="teal" onClick={() => onOpenMetricRows("sla_met", "tasks", "Member SLA Rows", "Task rows contributing to SLA-Met for this member.")}>SLA rows</Button>
      </Group>
      <Grid gutter="sm">
        <Grid.Col span={6}>
          <KpiBlock
            label="Total Tasks Worked"
            value={b.rowCount.toLocaleString()}
            color="orange"
          />
        </Grid.Col>
        <Grid.Col span={6}>
          <KpiBlock
            label="SLA-Met"
            value={slaPct != null ? `${Math.round(slaPct)}%` : "—"}
            hint={
              b.slaMetTotalCount > 0
                ? `${b.slaMetCount} / ${b.slaMetTotalCount}`
                : "no Y/N data"
            }
            color="teal"
          />
        </Grid.Col>
      </Grid>
    </Card>
  );
}

function MemberGenericCard({
  sourceType,
  b,
}: {
  sourceType: SourceType;
  b: SourceBucket;
}) {
  const cfg = GENERIC_CONFIGS[sourceType];
  const successRate =
    b.totalSum > 0 ? Math.round((b.successSum / b.totalSum) * 100) : null;
  const Icon = cfg.icon;

  return (
    <Card
      withBorder
      radius="md"
      p="md"
      h="100%"
      style={{ borderTop: `2px solid var(--mantine-color-${cfg.color}-6)` }}
    >
      <Group gap="sm" mb="xs">
        <ThemeIcon variant="light" color={cfg.color} radius="md">
          <Icon size={16} />
        </ThemeIcon>
        <Text fw={600} size="sm">
          {cfg.label}
        </Text>
      </Group>
      <Group gap="lg" align="flex-end" mb="xs">
        <Box>
          <Text size="xl" fw={700} ff="monospace" c={`${cfg.color}.4`}>
            {b.totalSum.toLocaleString() || "—"}
          </Text>
          <Text size="xs" c="dimmed" tt="uppercase" fw={600}>
            {cfg.totalLabel}
          </Text>
        </Box>
        {cfg.successLabel && b.successSum > 0 && (
          <Box>
            <Text size="md" fw={600} ff="monospace">
              {b.successSum.toLocaleString()}
            </Text>
            <Text size="xs" c="dimmed">
              {cfg.successLabel}
              {successRate != null && ` · ${successRate}%`}
            </Text>
          </Box>
        )}
      </Group>
      {cfg.showScore && b.latestScoreText && (
        <Box mt="xs">
          <Text size="xs" c="dimmed">
            Latest score
          </Text>
          <Text size="sm" fw={600} c={`${cfg.color}.4`}>
            {b.latestScoreText}
          </Text>
        </Box>
      )}
      {cfg.showDuration && b.durationSum > 0 && (
        <Box mt="xs">
          <Text size="xs" c="dimmed">
            Time logged
          </Text>
          <Text size="sm" fw={600}>
            {formatMinutes(b.durationSum)}
          </Text>
        </Box>
      )}
    </Card>
  );
}

// =============================================================================
// UI primitives
// =============================================================================

function KpiNumber({
  label,
  value,
  hint,
  color,
  icon,
}: {
  label: string;
  value: string;
  hint?: string;
  color?: string;
  icon?: ReactNode;
}) {
  return (
    <Box ta="right">
      <Group gap={4} justify="flex-end">
        {icon && (
          <Box c={color ? `${color}.4` : undefined} style={{ display: "flex" }}>
            {icon}
          </Box>
        )}
        <Text size="xs" c="dimmed" tt="uppercase" fw={600}>
          {label}
        </Text>
      </Group>
      <Text
        size="lg"
        fw={700}
        ff="monospace"
        c={color ? `${color}.4` : undefined}
      >
        {value}
      </Text>
      {hint && (
        <Text size="xs" c="dimmed">
          {hint}
        </Text>
      )}
    </Box>
  );
}

function KpiBlock({
  label,
  value,
  hint,
  color,
}: {
  label: string;
  value: string;
  hint?: string;
  color?: string;
}) {
  return (
    <Card withBorder radius="sm" p="sm" bg="var(--mantine-color-dark-6)">
      <Text size="xs" c="dimmed" tt="uppercase" fw={600}>
        {label}
      </Text>
      <Text
        size="xl"
        fw={700}
        ff="monospace"
        c={color ? `${color}.4` : undefined}
        style={{ lineHeight: 1.2 }}
      >
        {value}
      </Text>
      {hint && (
        <Text size="xs" c="dimmed">
          {hint}
        </Text>
      )}
    </Card>
  );
}

function EmptyState() {
  return (
    <Card withBorder radius="md" p="xl">
      <Stack align="center" gap="md">
        <ThemeIcon size={56} radius="xl" variant="light" color="green">
          <IconUsersGroup size={28} />
        </ThemeIcon>
        <Stack align="center" gap={4}>
          <Title order={5}>No performance data yet</Title>
          <Text size="sm" c="dimmed" ta="center" maw={420}>
            Import an Excel workbook with ticket, call, task, queue, or audit
            data to populate the team performance dashboard.
          </Text>
        </Stack>
      </Stack>
    </Card>
  );
}

// =============================================================================
// Formatters
// =============================================================================

function formatMinutes(mins: number): string {
  if (!isFinite(mins) || mins <= 0) return "0m";
  if (mins < 1) return `${Math.round(mins * 60)}s`;
  if (mins < 60) {
    const whole = Math.floor(mins);
    const sec = Math.round((mins - whole) * 60);
    if (sec > 0 && whole < 10) return `${whole}m ${sec}s`;
    return `${Math.round(mins)}m`;
  }
  const h = Math.floor(mins / 60);
  const m = Math.round(mins - h * 60);
  if (h < 24) return m > 0 ? `${h}h ${m}m` : `${h}h`;
  const d = Math.floor(h / 24);
  return `${d}d ${h - d * 24}h`;
}

/** Format a number of seconds as `MM:SS` (or `H:MM:SS` if >= 1h). */
function formatSeconds(sec: number): string {
  if (!isFinite(sec) || sec <= 0) return "0s";
  const total = Math.round(sec);
  if (total < 60) return `${total}s`;
  const m = Math.floor(total / 60);
  const s = total - m * 60;
  if (m < 60) return `${m}:${String(s).padStart(2, "0")}`;
  const h = Math.floor(m / 60);
  const mm = m - h * 60;
  return `${h}:${String(mm).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}
