import { defineConfig, type Plugin, loadEnv } from 'vite'
import react from '@vitejs/plugin-react'
import { resolve } from 'path'
import { appendFileSync } from 'fs'
import { appbuilderApiDevServer } from "./vite-plugins/appbuilder-api-dev-server";

function debugLog(msg: string) {
  try { appendFileSync('/tmp/ai-grounding.log', `[${new Date().toISOString()}] ${msg}\n`) } catch {}
}

// ---------------------------------------------------------------------------
// Devs.ai proxy: keeps AI_API_KEY server-side. Browser POSTs to /api/ai/chat
// with { messages, model? } and gets back the upstream SSE stream untouched.
// ---------------------------------------------------------------------------
function aiProxyPlugin(): Plugin {
  let env: Record<string, string> = {}
  return {
    name: 'ai-proxy',
    configureServer(server) {
      env = loadEnv('development', process.cwd(), '')

      server.middlewares.use('/api/ai/chat', async (req, res) => {
        if (req.method === 'OPTIONS') {
          res.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Content-Type' })
          res.end(); return
        }
        if (req.method !== 'POST') { res.statusCode = 405; res.end('Method not allowed'); return }

        try {
          // ── Security: cap request body size at 128 KB ──────
          const chunks: Buffer[] = []
          let totalBytes = 0
          for await (const chunk of req) {
            chunks.push(chunk as Buffer)
            totalBytes += (chunk as Buffer).length
            if (totalBytes > 128 * 1024) {
              res.statusCode = 413
              res.end('Request too large')
              return
            }
          }
          const body = JSON.parse(Buffer.concat(chunks).toString() || '{}')

          const apiKey = env.AI_API_KEY
          const platformUrl = env.AI_PLATFORM_URL || 'https://devs.ai'
          const model = body.model || env.AI_AGENT_ID

          if (!apiKey) {
            res.writeHead(500, { 'Content-Type': 'application/json' })
            res.end(JSON.stringify({ error: 'AI Assistant is temporarily unavailable. Please contact your admin.' }))
            return
          }

          // ── Security: validate message structure ───────────
          const messages: any[] = Array.isArray(body.messages) ? [...body.messages] : []
          // Strip any messages with oversized content
          const safeMessages = messages.map((m) => ({
            role: String(m.role ?? 'user').slice(0, 20),
            content: String(m.content ?? '').slice(0, 32000),
          }))

          const skipGround = body.skipGround === true

          // ── Parallel context gathering ────────────────────
          // We fetch: (1) Confluence pages, (2) roster/shift data, (3) team list
          // All run in parallel with 5s timeout each so they never block chat.
          const withTimeout = <T>(p: Promise<T>, ms: number, fallback: T): Promise<T> =>
            Promise.race([p, new Promise<T>((r) => setTimeout(() => r(fallback), ms))])

          let confluenceBlock = ''
          let rosterBlock = ''
          let teamBlock = ''

          if (!skipGround) {
            const lastUser = [...safeMessages].reverse().find((m) => m.role === 'user')
            const userText: string = String(lastUser?.content ?? '').trim().slice(0, 600)

            // ── 1. Confluence grounding (server creds only, never client-supplied) ──
            const cfGround = async () => {
              if (!userText || !env.CONFLUENCE_URL || !env.CONFLUENCE_EMAIL || !env.CONFLUENCE_TOKEN) return
              const cfBase = env.CONFLUENCE_URL.replace(/\/+$/, '') + '/wiki'
              const cfAuth = 'Basic ' + Buffer.from(`${env.CONFLUENCE_EMAIL}:${env.CONFLUENCE_TOKEN}`).toString('base64')

              const STOP = new Set(['a','an','the','i','me','my','we','our','you','your','they','their','it','its','is','am','are','was','were','be','been','being','do','does','did','done','will','would','should','could','can','may','might','and','or','but','if','then','than','that','this','these','those','to','of','for','in','on','at','by','with','as','from','about','into','over','under','between','what','when','where','who','whom','why','how','which','whose','please','search','tell','show','give','find','look','help','assist','wiki','page','pages','document','documentation','have','has','had','here','there','use','using','need','want','say','says','said','cite','title','source','summary','summarize','context','content','info','information','detail','details','provide','share','read','also','too','related','regarding','some','any','all','more','most','few'])
              const tokens = userText.toLowerCase().replace(/[^\w\s&-]+/g, ' ').split(/\s+/).filter((t) => t.length >= 2 && !STOP.has(t))
              const keywords = Array.from(new Set(tokens)).sort((a, b) => b.length - a.length).slice(0, 8)
              if (!keywords.length) return

              const esc = (k: string) => k.replace(/"/g, '\\"')
              const anyTitle = keywords.map((k) => `title ~ "${esc(k)}"`).join(' OR ')
              const anyText  = keywords.map((k) => `text ~ "${esc(k)}"`).join(' OR ')
              const safeQ = keywords.join(' ').replace(/"/g, '\\"').slice(0, 200)

              const passes = [
                `type=page AND (${anyTitle})`,
                `type=page AND title ~ "${safeQ}"`,
                `type=page AND (${anyText})`,
                `type=page AND text ~ "${safeQ}"`,
              ]

              const seen = new Set<string>()
              const merged: any[] = []
              for (const cql of passes) {
                if (merged.length >= 8) break
                const r = await fetch(
                  `${cfBase}/rest/api/search?cql=${encodeURIComponent(cql)}&limit=10&expand=content.body.view,content.space`,
                  { headers: { Authorization: cfAuth, Accept: 'application/json' } },
                ).then((rr) => rr.ok ? rr.json() : null).catch(() => null)
                if (!r?.results) continue
                for (const hit of r.results) {
                  const c = hit.content ?? {}
                  const id = c.id
                  if (!id || seen.has(id)) continue
                  seen.add(id)
                  const raw = c.body?.view?.value ?? hit.excerpt ?? ''
                  const text = String(raw).replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 600)
                  const webui = c._links?.webui ?? ''
                  const url = webui ? (webui.startsWith('http') ? webui : `${cfBase}${webui}`) : ''
                  const spaceKey = c.space?.key || c._expandable?.space?.split('/').pop() || '?'
                  merged.push({ title: c.title, url, excerpt: text, space: spaceKey })
                  if (merged.length >= 8) break
                }
              }

              if (merged.length) {
                confluenceBlock = `## Company Wiki (Confluence) — USE AS PRIMARY SOURCE\n` +
                  `Always cite these inline as [1], [2] etc. Prefer them over general knowledge.\n\n` +
                  merged.map((p, i) => `[${i + 1}] **${p.title}** (space: ${p.space})\n${p.excerpt}\nURL: ${p.url}`).join('\n\n')
                console.log(`[ai-chat] confluence grounded: ${merged.length} pages — ${merged.slice(0,3).map((p)=>p.title).join(' · ')}`)
              }
            }

            // ── 2. Roster context (who's on shift) ───────────
            const rosterGround = async () => {
              // Only fetch if question looks roster/shift/team related
              const rosterKeywords = ['shift','roster','on duty','on shift','who is','who\'s','schedule','working','today','tonight','morning','evening','overnight','team','coverage']
              const lower = userText.toLowerCase()
              if (!rosterKeywords.some((k) => lower.includes(k))) return

              try {
                const sheetId = env.ROSTER_SHEET_ID
                if (!sheetId) return

                // Parse date/time from the user's question for a specific date lookup
                // Default to today Pacific
                const now = new Date()
                const pacificStr = now.toLocaleString('en-US', { timeZone: 'America/Los_Angeles' })
                const pacificDate = new Date(pacificStr)

                // Fetch the roster XLSX
                const xlsxUrl = `https://docs.google.com/spreadsheets/d/${sheetId}/export?format=xlsx`
                const xlsxRes = await fetch(xlsxUrl, { redirect: 'follow', headers: { 'User-Agent': 'NOCToolkit/1.0' } })
                if (!xlsxRes.ok) return

                const buffer = await xlsxRes.arrayBuffer()
                const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
                const monthTab = `${MONTHS[pacificDate.getMonth()]}${String(pacificDate.getFullYear()).slice(-2)}`

                // Dynamic import xlsx (already loaded in scope via rosterProxyPlugin)
                const wb = XLSX.read(buffer, { type: 'array' })
                const sheet = wb.Sheets[wb.SheetNames.find((s) => s.toLowerCase() === monthTab.toLowerCase()) || monthTab]
                if (!sheet) return

                const rows = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '', raw: false }) as string[][]
                if (!rows.length) return

                const headers = (rows[0] || []).map((h) => String(h).trim())
                const dayLabel = `${pacificDate.getDate()}-${MONTHS[pacificDate.getMonth()]}`

                // Find the column for today
                let todayCol = -1
                for (let i = 1; i < headers.length; i++) {
                  if (headers[i].toLowerCase() === dayLabel.toLowerCase()) { todayCol = i; break }
                }

                let memberStart = 1
                const r1 = rows[1] || []
                if ((!r1[0] || r1[0] === '') && /^(Sun|Mon|Tue|Wed|Thu|Fri|Sat)/i.test(String(r1[1] || ''))) memberStart = 2

                // Collect ALL entries for today
                const todayEntries: { name: string; shift: string }[] = []
                for (let r = memberStart; r < rows.length; r++) {
                  const row = rows[r] || []
                  const name = String(row[0] || '').trim()
                  if (!name || /^(total|summary|leave|note)/i.test(name)) continue
                  const cell = todayCol >= 0 ? String(row[todayCol] || '').trim() : ''
                  if (cell) todayEntries.push({ name, shift: cell })
                }

                // Parse current time for active detection
                const nowH = pacificDate.getHours()
                const nowMin = pacificDate.getMinutes()
                const nowTotalMin = nowH * 60 + nowMin

                const to24Min = (h: string, mm: string, ap: string) => {
                  let H = parseInt(h, 10) % 12
                  if (ap.toUpperCase() === 'PM') H += 12
                  return H * 60 + parseInt(mm, 10)
                }

                const active: string[] = []
                const scheduled: string[] = []
                for (const { name, shift } of todayEntries) {
                  const m = shift.match(/(\d{1,2}):(\d{2})\s*(AM|PM)\s*to\s*(\d{1,2}):(\d{2})\s*(AM|PM)/i)
                  if (m) {
                    const startMin = to24Min(m[1], m[2], m[3])
                    const endMin = to24Min(m[4], m[5], m[6])
                    const isActive = startMin <= endMin
                      ? nowTotalMin >= startMin && nowTotalMin < endMin
                      : nowTotalMin >= startMin || nowTotalMin < endMin
                    if (isActive) active.push(`${name} (${shift})`)
                    else scheduled.push(`${name} (${shift})`)
                  } else {
                    scheduled.push(`${name}: ${shift}`)
                  }
                }

                const pacificTimeStr = pacificDate.toLocaleString('en-US', { timeZone: 'America/Los_Angeles', weekday: 'long', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true })
                rosterBlock = `## NOC Shift Roster — ${dayLabel} (${monthTab})\nCurrent Pacific Time: ${pacificTimeStr}\n\n` +
                  (active.length ? `**Currently on shift (ACTIVE NOW):**\n${active.map((n) => `• ${n}`).join('\n')}\n\n` : `**No one detected as active right now.**\n\n`) +
                  (scheduled.length ? `**Scheduled today (not currently active):**\n${scheduled.map((n) => `• ${n}`).join('\n')}` : '')

                console.log(`[ai-chat] roster context: ${active.length} active, ${scheduled.length} scheduled`)
              } catch { /* non-critical */ }
            }

            // ── 3. Team member context ────────────────────────
            const teamGround = async () => {
              const teamKeywords = ['team','member','staff','employee','who is','contact','email','role','admin','sriram','anirudh','matt','perry','lokesh','akash','karthik','hamza','samiti','pranav','akram','kenya','zubair','abishek','ashraf','otukho']
              const lower = userText.toLowerCase()
              if (!teamKeywords.some((k) => lower.includes(k))) return

              try {
                const SUPABASE_URL = env.VITE_SUPABASE_URL || env.SUPABASE_URL || ''
                const SUPABASE_KEY = env.VITE_SUPABASE_SERVICE_ROLE_KEY || env.SUPABASE_SERVICE_ROLE_KEY || ''
                if (!SUPABASE_URL || !SUPABASE_KEY) return

                const r = await fetch(`${SUPABASE_URL}/rest/v1/users?select=first_name,last_name,email,role&order=first_name`, {
                  headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` },
                })
                if (!r.ok) return
                const users: any[] = await r.json()
                if (!Array.isArray(users) || !users.length) return

                const ROLE_LABEL: Record<string, string> = { super_admin: 'Super Admin', admin: 'Admin', user: 'NOC Engineer' }
                teamBlock = `## NOC Team Members\n` +
                  users.map((u) => `• ${u.first_name} ${u.last_name} — ${ROLE_LABEL[u.role] ?? u.role} — ${u.email}`).join('\n')

                console.log(`[ai-chat] team context: ${users.length} members`)
              } catch { /* non-critical */ }
            }

            try {
              await Promise.all([
                withTimeout(cfGround(), 5000, undefined),
                withTimeout(rosterGround(), 6000, undefined),
                withTimeout(teamGround(), 4000, undefined),
              ])
            } catch { /* never block chat */ }
          }

          // ── Inject all context into the last user message ──
          const lastUserIdx = (() => { for (let i = safeMessages.length - 1; i >= 0; i--) if (safeMessages[i].role === 'user') return i; return -1 })()
          if (lastUserIdx >= 0 && (confluenceBlock || rosterBlock || teamBlock)) {
            const contextBlocks = [confluenceBlock, rosterBlock, teamBlock].filter(Boolean).join('\n\n---\n\n')
            const origContent = String(safeMessages[lastUserIdx].content ?? '')
            safeMessages[lastUserIdx] = {
              ...safeMessages[lastUserIdx],
              content: `You are the NOC AI Assistant for AppDirect / vCom BU.

PRIORITY RULES:
1. ALWAYS use Confluence company wiki data first — cite pages inline as [1], [2] etc.
2. Use roster data for any shift/schedule/coverage questions.
3. Use team data for any people/contact questions.
4. Only use general knowledge if the answer is NOT in the company data above.
5. Add a "Sources" section at the end listing any cited Confluence pages.

${contextBlocks}

---
USER QUESTION:
${origContent}`,
            }
          }

          const upstreamBody = JSON.stringify({ model, messages: safeMessages, stream: true })
          const upstream = await fetch(`${platformUrl}/api/v1/chats/completions`, {
            method: 'POST',
            headers: {
              Authorization: `Bearer ${apiKey}`,
              'Content-Type': 'application/json',
            },
            body: upstreamBody,
          })

          res.writeHead(upstream.status, {
            'Content-Type': 'text/event-stream',
            'Cache-Control': 'no-cache',
            Connection: 'keep-alive',
          })

          if (!upstream.body) {
            res.end()
            return
          }
          const reader = upstream.body.getReader()
          while (true) {
            const { done, value } = await reader.read()
            if (done) break
            res.write(value)
          }
          res.end()
        } catch (err) {
          if (!res.headersSent) {
            res.writeHead(500, { 'Content-Type': 'application/json' })
          }
          res.end(
            JSON.stringify({
              error: err instanceof Error ? err.message : 'Proxy error',
            }),
          )
        }
      })
    },
  }
}

// ---------------------------------------------------------------------------
// AI completion proxy: same as /api/ai/chat but aggregates the SSE stream
// into a single JSON response. Used for structured data extractions (e.g.
// "give me the carrier support numbers as JSON") where streaming is overkill.
// ---------------------------------------------------------------------------
function aiCompletionPlugin(): Plugin {
  let env: Record<string, string> = {}
  return {
    name: 'ai-completion',
    configureServer(server) {
      env = loadEnv('development', process.cwd(), '')

      server.middlewares.use('/api/ai/complete', async (req, res) => {
        if (req.method === 'OPTIONS') {
          res.writeHead(204, {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type',
          })
          res.end()
          return
        }
        if (req.method !== 'POST') {
          res.statusCode = 405
          res.end('Method not allowed')
          return
        }

        const sendJson = (status: number, payload: unknown) => {
          res.writeHead(status, { 'Content-Type': 'application/json' })
          res.end(JSON.stringify(payload))
        }

        try {
          const chunks: Buffer[] = []
          for await (const chunk of req) chunks.push(chunk as Buffer)
          const body = JSON.parse(Buffer.concat(chunks).toString() || '{}')

          const apiKey = env.AI_API_KEY
          const platformUrl = env.AI_PLATFORM_URL || 'https://devs.ai'
          const model = body.model || env.AI_AGENT_ID

          if (!apiKey) return sendJson(500, { error: 'AI Assistant is temporarily unavailable. Please contact your admin.' })

          const upstream = await fetch(`${platformUrl}/api/v1/chats/completions`, {
            method: 'POST',
            headers: {
              Authorization: `Bearer ${apiKey}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              model,
              messages: body.messages,
              stream: true,
            }),
          })

          if (!upstream.ok || !upstream.body) {
            return sendJson(upstream.status || 500, {
              error: `Upstream error ${upstream.status}`,
            })
          }

          // Aggregate the SSE stream into one text blob
          const reader = upstream.body.getReader()
          const decoder = new TextDecoder()
          let buffer = ''
          let currentEvent = ''
          let currentData = ''
          let fullText = ''

          while (true) {
            const { done, value } = await reader.read()
            if (done) break
            buffer += decoder.decode(value, { stream: true })
            const lines = buffer.split('\n')
            buffer = lines.pop() ?? ''
            for (const line of lines) {
              if (line.startsWith('event: ')) currentEvent = line.slice(7).trim()
              else if (line.startsWith('data: ')) currentData = line.slice(6)
              else if (line === '') {
                if (currentEvent && currentData) {
                  try {
                    const parsed = JSON.parse(currentData)
                    if (currentEvent === 'message.delta' && parsed.content?.text) {
                      fullText += parsed.content.text
                    }
                  } catch {
                    /* ignore */
                  }
                }
                currentEvent = ''
                currentData = ''
              }
            }
          }

          return sendJson(200, { text: fullText, model })
        } catch (err) {
          return sendJson(500, {
            error: err instanceof Error ? err.message : 'Proxy error',
          })
        }
      })
    },
  }
}

// ---------------------------------------------------------------------------
// Confluence proxy: avoids browser CORS issues with Atlassian Cloud. The
// browser POSTs the user's Confluence creds (URL/email/token) + query, the
// server makes the Basic-auth call to Confluence and returns trimmed results.
// Credentials are NEVER stored server-side — they live in the user's
// localStorage and are sent per-request.
// ---------------------------------------------------------------------------
interface ConfluenceSearchBody {
  baseUrl?: string
  email?: string
  token?: string
  spaceKey?: string
  query?: string
  limit?: number
}

function confluenceProxyPlugin(): Plugin {
  return {
    name: 'confluence-proxy',
    configureServer(server) {
      server.middlewares.use('/api/confluence/search', async (req, res) => {
        if (req.method === 'OPTIONS') {
          res.writeHead(204, {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type',
          })
          res.end()
          return
        }
        if (req.method !== 'POST') {
          res.statusCode = 405
          res.end('Method not allowed')
          return
        }

        const sendJson = (status: number, payload: unknown) => {
          res.writeHead(status, { 'Content-Type': 'application/json' })
          res.end(JSON.stringify(payload))
        }

        try {
          const chunks: Buffer[] = []
          for await (const chunk of req) chunks.push(chunk as Buffer)
          const body: ConfluenceSearchBody = JSON.parse(
            Buffer.concat(chunks).toString() || '{}',
          )

          const { baseUrl, email, token, spaceKey, query, limit = 5 } = body
          if (!baseUrl || !email || !token) {
            return sendJson(400, {
              error: 'Confluence not configured. Add Base URL, email, and API token in AI Settings.',
            })
          }
          if (!query || !query.trim()) {
            return sendJson(400, { error: 'query is required' })
          }

          // Normalise base URL: strip trailing slash, ensure /wiki suffix if missing
          let base = baseUrl.replace(/\/+$/, '')
          if (!/\/wiki$/.test(base) && /atlassian\.net$/.test(base)) {
            base = `${base}/wiki`
          }

          // Escape double quotes inside the user query for CQL
          const safeQuery = query.replace(/"/g, '\\"')
          const cqlParts = [`type = "page"`, `text ~ "${safeQuery}"`]
          if (spaceKey && spaceKey.trim()) {
            cqlParts.push(`space = "${spaceKey.trim()}"`)
          }
          const cql = cqlParts.join(' AND ')

          const url = new URL(`${base}/rest/api/search`)
          url.searchParams.set('cql', cql)
          url.searchParams.set('limit', String(Math.min(limit, 10)))
          url.searchParams.set('expand', 'content.body.view,content.space')

          const auth = Buffer.from(`${email}:${token}`).toString('base64')
          const upstream = await fetch(url.toString(), {
            method: 'GET',
            headers: {
              Authorization: `Basic ${auth}`,
              Accept: 'application/json',
            },
          })

          if (!upstream.ok) {
            const text = await upstream.text()
            return sendJson(upstream.status, {
              error: `Confluence error ${upstream.status}: ${text.slice(0, 300)}`,
            })
          }

          const data = (await upstream.json()) as {
            results?: Array<{
              title?: string
              url?: string
              excerpt?: string
              content?: {
                id?: string
                title?: string
                space?: { key?: string; name?: string }
                body?: { view?: { value?: string } }
                _links?: { webui?: string }
              }
              resultGlobalContainer?: { title?: string }
            }>
          }

          const results = (data.results ?? []).map((r) => {
            const content = r.content ?? {}
            const rawHtml = content.body?.view?.value ?? r.excerpt ?? ''
            const text = rawHtml
              .replace(/<[^>]+>/g, ' ')
              .replace(/&nbsp;/g, ' ')
              .replace(/&amp;/g, '&')
              .replace(/&lt;/g, '<')
              .replace(/&gt;/g, '>')
              .replace(/\s+/g, ' ')
              .trim()
            const webui = content._links?.webui ?? r.url ?? ''
            const link = webui
              ? webui.startsWith('http')
                ? webui
                : `${base}${webui}`
              : ''
            return {
              title: content.title ?? r.title ?? 'Untitled',
              space:
                content.space?.name ??
                content.space?.key ??
                r.resultGlobalContainer?.title ??
                null,
              url: link,
              excerpt: text.slice(0, 800),
            }
          })

          return sendJson(200, { results })
        } catch (err) {
          return sendJson(500, {
            error: err instanceof Error ? err.message : 'Proxy error',
          })
        }
      })
    },
  }
}

// ---------------------------------------------------------------------------
// Roster proxy: fetches the public NOC shift roster Google Sheet as XLSX
// server-side, parses the requested month tab (e.g. May26), computes the
// active shift members based on current Pacific Time, and returns JSON.
// ---------------------------------------------------------------------------
import * as XLSX from 'xlsx'

interface RosterMember {
  name: string;            // raw name from sheet
  shifts: Record<string, string>;  // { "May 18": "06:00 AM to 03:00 PM", ... }
}
interface ActiveMember {
  name: string;
  start: string;           // "06:00 AM"
  end: string;             // "03:00 PM"
  shift: string;           // raw shift text
}

// Cache: avoid re-downloading the XLSX on every request
let xlsxCache: { buffer: ArrayBuffer; ts: number } | null = null
const XLSX_CACHE_MS = 5 * 60 * 1000 // 5 min

const MONTHS_FULL = ['January','February','March','April','May','June','July','August','September','October','November','December']
const MONTHS_SHORT3 = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']

function currentMonthTabName(): string {
  // Always use Pacific Time to pick the tab
  const now = new Date()
  const pacific = new Date(
    now.toLocaleString('en-US', { timeZone: 'America/Los_Angeles' })
  )
  const m = MONTHS_SHORT3[pacific.getMonth()]
  const yy = String(pacific.getFullYear()).slice(-2)
  return `${m}${yy}` // e.g. "May26"
}

function pacificNow() {
  const now = new Date()
  // Locale tricks to extract individual fields in Pacific time
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: 'America/Los_Angeles',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).formatToParts(now)
  const get = (t: string) => parts.find((p) => p.type === t)?.value ?? '00'
  const year = +get('year')
  const month = +get('month')
  const day = +get('day')
  let hour = +get('hour')
  const minute = +get('minute')
  if (hour === 24) hour = 0 // some locales return "24"
  return { year, month, day, hour, minute, totalMinutes: hour * 60 + minute }
}

// "06:00 AM to 03:00 PM" → { startMin, endMin } in minutes since midnight Pacific
function parseShift(text: string): { start: string; end: string; startMin: number; endMin: number } | null {
  if (!text) return null
  const m = text.match(/(\d{1,2}):(\d{2})\s*(AM|PM)\s*to\s*(\d{1,2}):(\d{2})\s*(AM|PM)/i)
  if (!m) return null
  const to24 = (h: string, mm: string, ap: string) => {
    let H = parseInt(h, 10) % 12
    if (ap.toUpperCase() === 'PM') H += 12
    return H * 60 + parseInt(mm, 10)
  }
  const startMin = to24(m[1], m[2], m[3])
  const endMin = to24(m[4], m[5], m[6])
  return {
    start: `${m[1]}:${m[2]} ${m[3].toUpperCase()}`,
    end: `${m[4]}:${m[5]} ${m[6].toUpperCase()}`,
    startMin,
    endMin,
  }
}

function isActiveAt(shift: ReturnType<typeof parseShift>, nowMin: number): boolean {
  if (!shift) return false
  // Wraps midnight (e.g. 10:30 PM to 07:30 AM): startMin > endMin
  if (shift.startMin <= shift.endMin) {
    return nowMin >= shift.startMin && nowMin < shift.endMin
  }
  return nowMin >= shift.startMin || nowMin < shift.endMin
}

// Parse one month-tab sheet into { members: [{ name, shifts: { day -> raw } }] }
function parseMonthSheet(sheet: XLSX.WorkSheet): { headerDays: string[]; members: RosterMember[] } {
  const rows = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '', raw: false }) as string[][]
  if (rows.length === 0) return { headerDays: [], members: [] }

  // Row 0: headers like ["PST Time Zone", "1-May", "2-May", ...]
  const headers = (rows[0] || []).map((h) => String(h).trim())
  const dayCols: { col: number; label: string }[] = []
  for (let i = 1; i < headers.length; i++) {
    const h = headers[i]
    if (h) dayCols.push({ col: i, label: h })
  }

  // Row 1 is typically weekday names — skip if first cell is empty AND second
  // cell is a weekday name. Members start from row 2.
  let memberStart = 1
  const row1 = rows[1] || []
  if (
    (row1[0] === '' || !row1[0]) &&
    /^(Sun|Mon|Tue|Wed|Thu|Fri|Sat)/i.test(String(row1[1] || ''))
  ) {
    memberStart = 2
  }

  const members: RosterMember[] = []
  for (let r = memberStart; r < rows.length; r++) {
    const row = rows[r] || []
    const name = String(row[0] || '').trim()
    if (!name) continue
    // Skip rows that look like totals / sub-headers
    if (/^(total|summary|leave|note)/i.test(name)) continue
    const shifts: Record<string, string> = {}
    for (const dc of dayCols) {
      const cell = String(row[dc.col] || '').trim()
      if (cell) shifts[dc.label] = cell
    }
    members.push({ name, shifts })
  }
  return { headerDays: dayCols.map((d) => d.label), members }
}

function rosterProxyPlugin(): Plugin {
  let env: Record<string, string> = {}
  return {
    name: 'roster-proxy',
    configureServer(server) {
      env = loadEnv('development', process.cwd(), '')

      const fetchXLSX = async (): Promise<ArrayBuffer> => {
        if (xlsxCache && Date.now() - xlsxCache.ts < XLSX_CACHE_MS) {
          return xlsxCache.buffer
        }
        const sheetId = env.ROSTER_SHEET_ID
        if (!sheetId) throw new Error('ROSTER_SHEET_ID not set in .env')
        const url = `https://docs.google.com/spreadsheets/d/${sheetId}/export?format=xlsx`
        const upstream = await fetch(url, {
          redirect: 'follow',
          headers: {
            'User-Agent':
              'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          },
        })
        if (!upstream.ok) {
          throw new Error(`Google upstream ${upstream.status}`)
        }
        const buffer = await upstream.arrayBuffer()
        xlsxCache = { buffer, ts: Date.now() }
        return buffer
      }

      // GET /api/roster?month=May26  (or omit for current month)
      server.middlewares.use('/api/roster', async (req, res) => {
        if (req.method !== 'GET') {
          res.statusCode = 405
          res.end('Method not allowed')
          return
        }
        try {
          const buffer = await fetchXLSX()
          const wb = XLSX.read(buffer, { type: 'array' })
          const allSheets = wb.SheetNames

          // Determine requested month tab
          const url = new URL(req.url || '/', 'http://localhost')
          const requested =
            url.searchParams.get('month') || currentMonthTabName()
          // Find the sheet name case-insensitively, fall back to exact
          const sheetName =
            allSheets.find((s) => s.toLowerCase() === requested.toLowerCase()) ||
            requested
          const sheet = wb.Sheets[sheetName]

          if (!sheet) {
            res.writeHead(404, { 'Content-Type': 'application/json' })
            res.end(
              JSON.stringify({
                error: `Tab "${requested}" not found`,
                availableTabs: allSheets,
              }),
            )
            return
          }

          const parsed = parseMonthSheet(sheet)

          // Compute "active now" for today (Pacific)
          const p = pacificNow()
          // The header labels in this sheet look like "1-May" — build the
          // probable label for today.
          const todayLabel = `${p.day}-${MONTHS_SHORT3[p.month - 1]}`
          const todayActive: ActiveMember[] = []
          const todayAll: { name: string; cell: string }[] = []
          for (const m of parsed.members) {
            const cell = m.shifts[todayLabel] || ''
            if (!cell) continue
            todayAll.push({ name: m.name, cell })
            const shift = parseShift(cell)
            if (shift && isActiveAt(shift, p.totalMinutes)) {
              todayActive.push({
                name: m.name,
                start: shift.start,
                end: shift.end,
                shift: cell,
              })
            }
          }

          // Month-tabs only (filter out non-roster sheets like NOC_State, Cabs etc.)
          const monthTabs = allSheets.filter((s) => /^[A-Z][a-z]{2}\d{2}$/.test(s))

          res.writeHead(200, {
            'Content-Type': 'application/json',
            'Cache-Control': 'no-cache',
          })
          res.end(
            JSON.stringify({
              sheetName,
              monthTabs,
              allTabs: allSheets,
              headerDays: parsed.headerDays,
              members: parsed.members,
              today: {
                label: todayLabel,
                pacificISO: `${p.year}-${String(p.month).padStart(2,'0')}-${String(p.day).padStart(2,'0')}T${String(p.hour).padStart(2,'0')}:${String(p.minute).padStart(2,'0')}:00-07:00`,
                pacificTime: `${String(p.hour % 12 || 12).padStart(2,'0')}:${String(p.minute).padStart(2,'0')} ${p.hour >= 12 ? 'PM' : 'AM'}`,
                allShifts: todayAll,
                active: todayActive,
              },
            }),
          )
        } catch (err) {
          if (!res.headersSent) {
            res.writeHead(500, { 'Content-Type': 'application/json' })
          }
          res.end(
            JSON.stringify({
              error: err instanceof Error ? err.message : 'Proxy error',
            }),
          )
        }
      })
    },
  }
}

// ---------------------------------------------------------------------------
// Confluence REST API proxy — uses server-side env vars (CONFLUENCE_EMAIL +
// CONFLUENCE_TOKEN) to talk directly to Atlassian Cloud's REST v1 API.
// Token never reaches the browser. Endpoints:
//   GET  /api/confluence/tree?root=<id>      -> recursive page tree
//   GET  /api/confluence/page?id=<id>        -> page body + attachments
//   GET  /api/confluence/search?q=<text>     -> CQL search (scoped to ancestor)
//   GET  /api/confluence/attachment?id=<id>  -> proxies attachment download
// ---------------------------------------------------------------------------
// Search result cache — avoids hammering Confluence on repeated queries
const searchCache = new Map<string, { ts: number; data: unknown }>();
const SEARCH_CACHE_MS = 5 * 60 * 1000; // 5 minutes
interface PageNode {
  id: string;
  title: string;
  url: string;
  parentId: string | null;
  childCount: number;
  hasAttachments?: boolean;
  children?: PageNode[];
}

function confluenceRestPlugin(): Plugin {
  let env: Record<string, string> = {}
  let cachedTree: { ts: number; data: PageNode | null; rootId: string | null } = { ts: 0, data: null, rootId: null }
  const TREE_CACHE_MS = 5 * 60 * 1000

  return {
    name: 'confluence-rest',
    configureServer(server) {
      env = loadEnv('development', process.cwd(), '')

      const baseUrl = () => (env.CONFLUENCE_URL || '').replace(/\/+$/, '') + '/wiki'
      const auth = () =>
        'Basic ' +
        Buffer.from(`${env.CONFLUENCE_EMAIL}:${env.CONFLUENCE_TOKEN}`).toString('base64')

      const sendJson = (res: any, status: number, payload: unknown) => {
        res.writeHead(status, { 'Content-Type': 'application/json', 'Cache-Control': 'no-cache' })
        res.end(JSON.stringify(payload))
      }

      const requireCreds = (res: any): boolean => {
        if (!env.CONFLUENCE_URL || !env.CONFLUENCE_EMAIL || !env.CONFLUENCE_TOKEN) {
          sendJson(res, 500, { error: 'Confluence search is temporarily unavailable.' })
          return false
        }
        return true
      }

      const cf = async (path: string): Promise<any> => {
        const url = `${baseUrl()}${path}`
        const r = await fetch(url, { headers: { Authorization: auth(), Accept: 'application/json' } })
        if (!r.ok) throw new Error(`Confluence ${r.status}: ${url}`)
        return r.json()
      }

      // ─── Tree (recursive) ──────────────────────────────────
      server.middlewares.use('/api/confluence/tree', async (req, res) => {
        if (!requireCreds(res)) return
        try {
          const url = new URL(req.url || '', 'http://x')
          const rootId = url.searchParams.get('root') || env.CONFLUENCE_MOBILITY_ROOT || ''
          const force = url.searchParams.get('force') === '1'

          if (!force && cachedTree.data && cachedTree.rootId === rootId && Date.now() - cachedTree.ts < TREE_CACHE_MS) {
            return sendJson(res, 200, { tree: cachedTree.data, cached: true, fetchedAt: new Date(cachedTree.ts).toISOString() })
          }

          // Fetch root
          const root = await cf(`/rest/api/content/${rootId}?expand=children.attachment.metadata`)
          const baseHref = baseUrl()
          const rootNode: PageNode = {
            id: root.id,
            title: root.title,
            url: `${baseHref}${root._links?.webui ?? ''}`,
            parentId: null,
            childCount: 0,
            hasAttachments: (root.children?.attachment?.results?.length ?? 0) > 0,
            children: [],
          }

          // Walk children breadth-first
          const queue: PageNode[] = [rootNode]
          while (queue.length) {
            const node = queue.shift()!
            let start = 0
            const limit = 100
            while (true) {
              const data = await cf(
                `/rest/api/content/${node.id}/child/page?limit=${limit}&start=${start}&expand=children.attachment.metadata`,
              )
              const results = data.results ?? []
              for (const p of results) {
                const child: PageNode = {
                  id: p.id,
                  title: p.title,
                  url: `${baseHref}${p._links?.webui ?? ''}`,
                  parentId: node.id,
                  childCount: 0,
                  hasAttachments: (p.children?.attachment?.results?.length ?? 0) > 0,
                  children: [],
                }
                node.children!.push(child)
                queue.push(child)
              }
              node.childCount = node.children!.length
              if (results.length < limit) break
              start += limit
            }
          }

          cachedTree = { ts: Date.now(), data: rootNode, rootId: rootId }
          return sendJson(res, 200, { tree: rootNode, cached: false, fetchedAt: new Date().toISOString() })
        } catch (err) {
          return sendJson(res, 500, { error: err instanceof Error ? err.message : 'tree fetch failed' })
        }
      })

      // ─── Single page (body + attachments) ──────────────────
      server.middlewares.use('/api/confluence/page', async (req, res) => {
        if (!requireCreds(res)) return
        try {
          const url = new URL(req.url || '', 'http://x')
          const id = url.searchParams.get('id')
          if (!id) return sendJson(res, 400, { error: 'id required' })
          const data = await cf(
            `/rest/api/content/${id}?expand=body.view,version,space`,
          )

          // Fetch all attachments separately (expand=children.attachment is limited to 25)
          let allAttachments: any[] = []
          try {
            let attStart = 0
            while (true) {
              const attData = await cf(`/rest/api/content/${id}/child/attachment?limit=50&start=${attStart}&expand=metadata,extensions`)
              const results = attData.results ?? []
              allAttachments = allAttachments.concat(results)
              if (results.length < 50) break
              attStart += 50
            }
          } catch { /* attachments are non-critical */ }
          // Merge into data structure for backward compat
          data.children = { attachment: { results: allAttachments } }
          const baseHref = baseUrl()
          const cfBaseRoot = baseHref.replace(/\/wiki$/, '')

          // Build attachment list AND a filename→{pageId,attId} lookup map.
          // The REST endpoint GET /wiki/rest/api/content/{pageId}/child/attachment/{attId}/download
          // works with Basic auth and returns the real image binary.
          // The old /wiki/download/attachments/... path requires browser cookies — always 401.
          const attResults: any[] = data.children?.attachment?.results ?? []
          const filenameToAttId = new Map<string, string>() // filename → numeric attachment id

          const atts = attResults.map((a: any) => {
            const mediaType = a.metadata?.mediaType || a.extensions?.mediaType || 'application/octet-stream'
            const isImage = mediaType.startsWith('image/')
            const isPdf   = mediaType === 'application/pdf'
            const attNumId = String(a.id).replace(/^att/, '') // strip 'att' prefix

            // Track all attachments for image rewriting
            if (a.title) filenameToAttId.set(a.title, attNumId)

            // Use REST download endpoint — works with API token!
            const downloadUrl = isImage
              ? `/api/confluence/image?pageId=${encodeURIComponent(id)}&attId=${encodeURIComponent(attNumId)}`
              : `/api/confluence/attachment?id=${encodeURIComponent(a.id)}`

            return {
              id: a.id,
              title: a.title,
              mediaType,
              fileSize: a.extensions?.fileSize ?? null,
              downloadUrl,
              confluenceUrl: `${baseHref}${a._links?.webui ?? ''}`,
              isImage,
              isPdf,
            }
          })

          // ── HTML image rewriting ─────────────────────────────────────────
          // Strategy: For every img src that references /wiki/download/attachments/{pageId}/{filename},
          // look up the attachment ID from our map and rewrite to the working REST endpoint.
          // This bypasses Atlassian's cookie-only restriction on the download path.
          let html: string = data.body?.view?.value ?? ''

          const decodeHtmlEntities = (s: string) =>
            s.replace(/&amp;/g, '&').replace(/&#38;/g, '&').replace(/&lt;/g, '<')
             .replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#34;/g, '"').replace(/&#39;/g, "'")

          // Build a URL → proxied URL converter using the attachment ID map
          const rewriteImgUrl = (rawUrl: string): string => {
            const decoded = decodeHtmlEntities(rawUrl)
            // Extract filename from /wiki/download/attachments/{pageId}/{filename}
            const attMatch = decoded.match(/\/(?:wiki\/)?download\/(?:attachments|thumbnails)\/(\d+)\/([^?#]+)/)
            if (attMatch) {
              const pathPageId = attMatch[1]
              const filename = decodeURIComponent(attMatch[2])
              const attNumId = filenameToAttId.get(filename)
              if (attNumId) {
                // Use the working REST endpoint
                return `/api/confluence/image?pageId=${encodeURIComponent(pathPageId)}&attId=${encodeURIComponent(attNumId)}`
              }
              // Attachment not in our list (maybe loaded from different page) — fall back to REST lookup
              return `/api/confluence/image?pageId=${encodeURIComponent(pathPageId)}&filename=${encodeURIComponent(filename)}`
            }
            // Non-attachment image (inline diagrams, emoticons etc.) — use path proxy
            let path = decoded
            if (decoded.startsWith(cfBaseRoot)) path = decoded.slice(cfBaseRoot.length)
            if (!path.startsWith('/')) path = '/' + path
            return `/api/confluence/image?path=${encodeURIComponent(path)}`
          }

          // Rewrite ALL img src attributes
          html = html.replace(/<img\b([^>]*?)\bsrc="([^"]+)"/gi, (_m, pre, src) => {
            const s = String(src)
            if (s.startsWith('/api/confluence/image')) return _m // already proxied
            if (s.startsWith('data:')) return _m // inline base64 — leave alone
            if (!s.includes('download') && !s.includes('/wiki/') && !s.includes(cfBaseRoot)) return _m
            return `<img${pre}src="${rewriteImgUrl(s)}"`
          })

          // Rewrite data-image-src (Confluence lazy-load attribute)
          html = html.replace(/\bdata-image-src="([^"]+)"/gi, (_m, src) => {
            const s = String(src)
            if (!s.includes('download') && !s.includes('/wiki/')) return _m
            return `data-image-src="${rewriteImgUrl(s)}"`
          })

          // Rewrite srcset
          html = html.replace(/\bsrcset="([^"]+)"/gi, (_m, srcset) => {
            const rewritten = String(srcset).split(',').map((part) => {
              const bits = part.trim().split(/\s+/)
              const raw = bits[0] || ''
              const size = bits.slice(1).join(' ')
              const proxied = (raw.includes('download') || raw.includes('/wiki/')) ? rewriteImgUrl(raw) : raw
              return [proxied, size].filter(Boolean).join(' ')
            }).join(', ')
            return `srcset="${rewritten}"`
          })

          // Anchor hrefs — make relative /wiki/ absolute so links work
          html = html.replace(/href="\/wiki\//g, `href="${cfBaseRoot}/wiki/`)

          // 10. Absolute https://... image srcs in any remaining img tags → proxy
          html = html.replace(
            new RegExp(`<img\\b([^>]*?)\\bsrc="(https?://${cfBaseRoot.replace(/^https?:\/\//, '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}[^"]+)"`, 'gi'),
            (_m, pre, fullUrl) => {
              try {
                const u = new URL(fullUrl)
                const path = u.pathname + u.search
                return `<img${pre}src="${proxyImg(path)}"`
              } catch { return _m }
            }
          )

          return sendJson(res, 200, {
            id: data.id,
            title: data.title,
            spaceKey: data.space?.key,
            version: data.version?.number,
            lastUpdated: data.version?.when,
            updatedBy: data.version?.by?.displayName,
            url: `${baseHref}${data._links?.webui ?? ''}`,
            html,
            attachments: atts,
          })
        } catch (err) {
          return sendJson(res, 500, { error: err instanceof Error ? err.message : 'page fetch failed' })
        }
      })

      // ─── Search (CQL) ──────────────────────────────────────
      server.middlewares.use('/api/confluence/search', async (req, res) => {
        if (!requireCreds(res)) return
        try {
          const url = new URL(req.url || '', 'http://x')
          const rawQ = (url.searchParams.get('q') || '').trim()
          const ancestor = url.searchParams.get('ancestor') || env.CONFLUENCE_MOBILITY_ROOT || ''
          const limit = Math.min(parseInt(url.searchParams.get('limit') || '20'), 50)
          if (!rawQ) return sendJson(res, 400, { error: 'q required' })

          // ── Cache check ───────────────────────────────────
          const cacheKey = `${rawQ}|${ancestor}|${limit}`
          const cached = searchCache.get(cacheKey)
          if (cached && Date.now() - cached.ts < SEARCH_CACHE_MS) {
            res.setHeader('X-Cache', 'HIT')
            return sendJson(res, 200, cached.data)
          }

          // ── Stop-word stripping & keyword extraction ───────
          const STOP = new Set([
            'i','me','my','we','our','you','your','they','them','their','it','its','this','that','these','those',
            'is','am','are','was','were','be','been','being','do','does','did','have','has','had',
            'a','an','the','and','or','but','if','then','else','so','as','at','by','for','from','in','into','of','on','onto','to','with','without','about','via',
            'need','want','please','search','searching','find','show','give','tell','help','can','could','would','should','will','shall',
            'how','what','where','when','why','which','who','whom',
            'use','using','using','look','looking',
            'mobility', // sometimes the user *will* type this — but for an ancestor=Mobility scope it adds zero signal. Keep title-search exposure via raw.
          ])
          const cleanWords = rawQ
            .toLowerCase()
            .replace(/[^a-z0-9\s]/g, ' ')
            .split(/\s+/)
            .filter((w) => w.length >= 2 && !STOP.has(w))

          // If user typed "mobility" explicitly, still pass it through — it differentiates from
          // ALL mobility-scoped content vs typed-keyword content.
          if (/\bmobility\b/i.test(rawQ) && !cleanWords.includes('mobility')) cleanWords.push('mobility')

          // De-dup
          const keywords = Array.from(new Set(cleanWords))

          // ── Build smart CQL ────────────────────────────────
          const safe = (s: string) => s.replace(/"/g, '\\"')
          const scope: string[] = ['type=page']
          if (ancestor) scope.push(`ancestor=${ancestor}`)
          if (env.CONFLUENCE_SPACE) scope.push(`space=${env.CONFLUENCE_SPACE}`)

          const phrase = safe(rawQ.slice(0, 200)) // raw phrase, capped
          const titleAndOfOr = keywords.length
            ? keywords.map((k) => `title ~ "${safe(k)}*"`).join(' AND ')
            : ''
          const textAndOfOr = keywords.length
            ? keywords.map((k) => `text ~ "${safe(k)}*"`).join(' AND ')
            : ''

          // Pass A — strongest: every keyword in the title (AND, wildcard prefix).
          // Pass B — every keyword in body text (AND).
          // Pass C — phrase fallback (whole sentence in title or body).
          // Pass D — ANY keyword in title (OR) — fires when not every keyword can be on one page.
          // Pass E — ANY keyword in body (OR).
          const titleOrOfAny = keywords.length
            ? `(${keywords.map((k) => `title ~ "${safe(k)}*"`).join(' OR ')})`
            : ''
          const textOrOfAny = keywords.length
            ? `(${keywords.map((k) => `text ~ "${safe(k)}*"`).join(' OR ')})`
            : ''
          const passes: string[] = []
          if (titleAndOfOr) passes.push([...scope, titleAndOfOr].join(' AND '))
          if (textAndOfOr) passes.push([...scope, textAndOfOr].join(' AND '))
          passes.push([...scope, `(title ~ "${phrase}" OR text ~ "${phrase}")`].join(' AND '))
          if (titleOrOfAny) passes.push([...scope, titleOrOfAny].join(' AND '))
          if (textOrOfAny) passes.push([...scope, textOrOfAny].join(' AND '))

          const baseHref = baseUrl()
          const seen = new Set<string>()
          const merged: any[] = []

          for (const cql of passes) {
            if (merged.length >= limit) break
            try {
              const data = await cf(
                `/rest/api/search?cql=${encodeURIComponent(cql)}&limit=${limit}&expand=content.body.view`,
              )
              for (const r of data.results ?? []) {
                const c = r.content ?? {}
                const id = c.id ?? r.url ?? c.title
                if (!id || seen.has(id)) continue
                seen.add(id)
                const raw = c.body?.view?.value ?? r.excerpt ?? ''
                const text = raw
                  .replace(/<[^>]+>/g, ' ')
                  .replace(/&nbsp;/g, ' ')
                  .replace(/&amp;/g, '&')
                  .replace(/&lt;/g, '<')
                  .replace(/&gt;/g, '>')
                  .replace(/\s+/g, ' ')
                  .trim()
                const webui = c._links?.webui ?? r.url ?? ''
                merged.push({
                  id: c.id ?? null,
                  title: c.title ?? r.title ?? 'Untitled',
                  url: webui ? (webui.startsWith('http') ? webui : `${baseHref}${webui}`) : '',
                  snippet: text.slice(0, 280),
                  excerpt: text.slice(0, 800),
                })
                if (merged.length >= limit) break
              }
            } catch {
              /* try next pass */
            }
          }

          // ── Fallback: fuzzy tree title match (covers conversational queries & typos) ──
          if (merged.length < 3 && ancestor) {
            // Lazily warm the tree cache so the fuzzy fallback always works
            if (!cachedTree.data || cachedTree.rootId !== ancestor || Date.now() - cachedTree.ts > TREE_CACHE_MS) {
              try {
                const root = await cf(`/rest/api/content/${ancestor}?expand=children.attachment.metadata`)
                const baseHref = baseUrl()
                const rootNode: PageNode = {
                  id: root.id, title: root.title, url: `${baseHref}${root._links?.webui ?? ''}`,
                  parentId: null, childCount: 0, children: [],
                }
                const q: PageNode[] = [rootNode]
                while (q.length) {
                  const node = q.shift()!
                  let start = 0
                  while (true) {
                    const data = await cf(
                      `/rest/api/content/${node.id}/child/page?limit=100&start=${start}`,
                    )
                    for (const p of data.results ?? []) {
                      const child: PageNode = {
                        id: p.id, title: p.title, url: `${baseHref}${p._links?.webui ?? ''}`,
                        parentId: node.id, childCount: 0, children: [],
                      }
                      node.children!.push(child); q.push(child)
                    }
                    node.childCount = node.children!.length
                    if ((data.results ?? []).length < 100) break
                    start += 100
                  }
                }
                cachedTree = { ts: Date.now(), data: rootNode, rootId: ancestor }
              } catch {
                /* fail silently */
              }
            }

            if (cachedTree.data) {
              const flat: any[] = []
              const walk = (n: any) => { flat.push(n); for (const c of n.children ?? []) walk(c) }
              walk(cachedTree.data)

              // Fuzzy edit-distance helper (Levenshtein, allowed depending on length)
              const lev = (a: string, b: string): number => {
                if (a === b) return 0
                if (!a.length) return b.length
                if (!b.length) return a.length
                const prev = new Array(b.length + 1).fill(0).map((_, i) => i)
                const curr = new Array(b.length + 1).fill(0)
                for (let i = 1; i <= a.length; i++) {
                  curr[0] = i
                  for (let j = 1; j <= b.length; j++) {
                    const cost = a[i - 1] === b[j - 1] ? 0 : 1
                    curr[j] = Math.min(curr[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
                  }
                  for (let j = 0; j <= b.length; j++) prev[j] = curr[j]
                }
                return prev[b.length]
              }

              const existingIds = new Set(merged.map((m) => m.id).filter(Boolean))
              const scored = flat
                .map((n) => {
                  if (n.id === ancestor) return { node: n, score: 0 } // skip the root itself
                  const title = String(n.title || '').toLowerCase()
                  const titleTokens = title.split(/\s+/).filter(Boolean)
                  let score = 0
                  for (const k of keywords) {
                    if (title.includes(k)) score += 20
                    // prefix match
                    if (titleTokens.some((t) => t.startsWith(k.slice(0, Math.min(4, k.length))))) score += 5
                    // fuzzy: any token within edit-distance ≤2 of the keyword (catches typos)
                    const allowed = k.length >= 7 ? 2 : 1
                    if (titleTokens.some((t) => lev(t, k) <= allowed)) score += 8
                  }
                  return { node: n, score }
                })
                .filter((x) => x.score > 0 && !existingIds.has(x.node.id))
                .sort((a, b) => b.score - a.score)
                .slice(0, limit - merged.length)
              for (const { node } of scored) {
                merged.push({
                  id: node.id,
                  title: node.title,
                  url: node.url,
                  snippet: '(matched from page index — open to load content)',
                  excerpt: '',
                })
              }
            }
          }

          const result = { results: merged, count: merged.length, query: rawQ, keywords }
          searchCache.set(cacheKey, { ts: Date.now(), data: result })
          return sendJson(res, 200, result)
        } catch (err) {
          return sendJson(res, 500, { error: err instanceof Error ? err.message : 'search failed' })
        }
      })

      // ─── Attachment download (proxies binary) ──────────────
      server.middlewares.use('/api/confluence/attachment', async (req, res) => {
        if (!requireCreds(res)) {
          return
        }
        try {
          const url = new URL(req.url || '', 'http://x')
          const id = url.searchParams.get('id')
          if (!id) {
            res.statusCode = 400
            res.end('id required')
            return
          }
          // Get attachment metadata to find the download URL
          const meta = await cf(`/rest/api/content/${id}`)
          const downloadPath = meta._links?.download
          if (!downloadPath) {
            res.statusCode = 404
            res.end('attachment download link not found')
            return
          }
          const fullUrl = `${baseUrl()}${downloadPath}`
          const upstream = await fetch(fullUrl, { headers: { Authorization: auth() } })
          if (!upstream.ok) {
            res.statusCode = upstream.status
            res.end('upstream error')
            return
          }
          const buf = Buffer.from(await upstream.arrayBuffer())
          res.writeHead(200, {
            'Content-Type': upstream.headers.get('content-type') || 'application/octet-stream',
            'Content-Length': String(buf.length),
            'Cache-Control': 'private, max-age=300',
          })
          res.end(buf)
        } catch (err) {
          res.statusCode = 500
          res.end(err instanceof Error ? err.message : 'attachment error')
        }
      })

      // ─── Image proxy ───────────────────────────────────────
      // KEY DISCOVERY: /wiki/download/attachments/{pageId}/{filename}?api=v2
      // always returns 401/302-to-login with API tokens.
      // The ONLY working server-side approach is:
      //   GET /wiki/rest/api/content/{pageId}/child/attachment/{attId}/download
      // which returns 200 + binary image with Basic auth.
      //
      // Params:
      //   ?pageId=X&attId=Y  → use REST endpoint (primary, always works)
      //   ?pageId=X&filename=F → lookup attId from Confluence then download
      //   ?path=P  → legacy fallback for non-attachment images (emoticons etc.)
      const transparentPng = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==', 'base64')

      const sendTransparentPng = (res: any) => {
        res.writeHead(200, {
          'Content-Type': 'image/png',
          'Content-Length': String(transparentPng.length),
          'Cache-Control': 'no-cache',
        })
        res.end(transparentPng)
      }

      server.middlewares.use('/api/confluence/image', async (req, res) => {
        if (!requireCreds(res)) return
        try {
          const url = new URL(req.url || '', 'http://x')
          const pageId = url.searchParams.get('pageId') || ''
          const attId  = url.searchParams.get('attId')  || ''
          const filename = url.searchParams.get('filename') || ''
          let   path   = url.searchParams.get('path')   || ''

          // ── Primary: REST attachment download (works with API token!) ──
          if (pageId && attId) {
            const restUrl = `${baseUrl()}/rest/api/content/${pageId}/child/attachment/${attId}/download`
            const upstream = await fetch(restUrl, {
              headers: { Authorization: auth(), Accept: 'image/*,*/*;q=0.8' },
              redirect: 'follow',
            })
            if (!upstream.ok) { sendTransparentPng(res); return }
            const buf = Buffer.from(await upstream.arrayBuffer())
            const ct = upstream.headers.get('content-type') || 'image/png'
            // Verify it's actually an image (not HTML login page)
            if (ct.startsWith('text/')) { sendTransparentPng(res); return }
            res.writeHead(200, {
              'Content-Type': ct,
              'Content-Length': String(buf.length),
              'Cache-Control': 'private, max-age=3600',
            })
            res.end(buf)
            return
          }

          // ── Secondary: filename lookup then REST download ──
          if (pageId && filename) {
            try {
              // Find attachment ID by filename
              const attData = await cf(`/rest/api/content/${pageId}/child/attachment?filename=${encodeURIComponent(filename)}&limit=1&expand=metadata`)
              const attResult = attData.results?.[0]
              if (attResult) {
                const foundId = String(attResult.id).replace(/^att/, '')
                const restUrl = `${baseUrl()}/rest/api/content/${pageId}/child/attachment/${foundId}/download`
                const upstream = await fetch(restUrl, {
                  headers: { Authorization: auth(), Accept: 'image/*,*/*;q=0.8' },
                  redirect: 'follow',
                })
                if (upstream.ok) {
                  const buf = Buffer.from(await upstream.arrayBuffer())
                  const ct = upstream.headers.get('content-type') || 'image/png'
                  if (!ct.startsWith('text/')) {
                    res.writeHead(200, { 'Content-Type': ct, 'Content-Length': String(buf.length), 'Cache-Control': 'private, max-age=3600' })
                    res.end(buf)
                    return
                  }
                }
              }
            } catch { /* fall through to transparent PNG */ }
            sendTransparentPng(res)
            return
          }

          // ── Legacy fallback: path-based (for emoticons/macros, NOT attachment images) ──
          try { path = decodeURIComponent(path) } catch { /* keep as-is */ }
          path = path.replace(/&amp;/g, '&').replace(/&#38;/g, '&')
          if (!path || !path.startsWith('/')) { sendTransparentPng(res); return }

          // Reject if this looks like a download/attachment path — it won't work
          if (path.includes('/download/attachments/') || path.includes('/download/thumbnails/')) {
            // Try to extract pageId+filename and use REST instead
            const m = path.match(/\/download\/(?:attachments|thumbnails)\/(\d+)\/([^?#]+)/)
            if (m) {
              const extractedPageId = m[1]
              const extractedFilename = decodeURIComponent(m[2].split('?')[0])
              try {
                const attData = await cf(`/rest/api/content/${extractedPageId}/child/attachment?filename=${encodeURIComponent(extractedFilename)}&limit=1`)
                const attResult = attData.results?.[0]
                if (attResult) {
                  const foundId = String(attResult.id).replace(/^att/, '')
                  const restUrl = `${baseUrl()}/rest/api/content/${extractedPageId}/child/attachment/${foundId}/download`
                  const upstream = await fetch(restUrl, { headers: { Authorization: auth() }, redirect: 'follow' })
                  if (upstream.ok) {
                    const buf = Buffer.from(await upstream.arrayBuffer())
                    const ct = upstream.headers.get('content-type') || 'image/png'
                    if (!ct.startsWith('text/')) {
                      res.writeHead(200, { 'Content-Type': ct, 'Content-Length': String(buf.length), 'Cache-Control': 'private, max-age=3600' })
                      res.end(buf); return
                    }
                  }
                }
              } catch { /* fall through */ }
            }
            sendTransparentPng(res)
            return
          }

          const cfBase = (env.CONFLUENCE_URL || '').replace(/\/+$/, '')
          const fullUrl = `${cfBase}${path}`
          const upstream = await fetch(fullUrl, {
            headers: { Authorization: auth(), Accept: 'image/*,*/*;q=0.8' },
            redirect: 'follow',
          })
          if (!upstream.ok) { sendTransparentPng(res); return }
          const buf = Buffer.from(await upstream.arrayBuffer())
          const ct = upstream.headers.get('content-type') || 'image/png'
          if (ct.startsWith('text/')) { sendTransparentPng(res); return }
          res.writeHead(200, { 'Content-Type': ct, 'Content-Length': String(buf.length), 'Cache-Control': 'private, max-age=3600' })
          res.end(buf)
        } catch (err) {
          sendTransparentPng(res)
        }
      })

      // ─── XLSX preview ──────────────────────────────────────
      // Fetches an Excel attachment, parses with `xlsx`, returns
      // { sheets: [{name, headers, rows}] } JSON for table rendering.
      server.middlewares.use('/api/confluence/xlsx', async (req, res) => {
        if (!requireCreds(res)) return
        try {
          const url = new URL(req.url || '', 'http://x')
          const id = url.searchParams.get('id')
          if (!id) return sendJson(res, 400, { error: 'id required' })
          const meta = await cf(`/rest/api/content/${id}`)
          const dl = meta._links?.download
          if (!dl) return sendJson(res, 404, { error: 'no download link' })
          const upstream = await fetch(`${baseUrl()}${dl}`, { headers: { Authorization: auth() } })
          if (!upstream.ok) return sendJson(res, upstream.status, { error: `upstream ${upstream.status}` })
          const buf = Buffer.from(await upstream.arrayBuffer())
          const wb = XLSX.read(buf, { type: 'buffer' })
          const sheets = wb.SheetNames.map((name) => {
            const ws = wb.Sheets[name]
            const aoa = XLSX.utils.sheet_to_json(ws, { header: 1, defval: '' }) as unknown[][]
            const headers = (aoa[0] ?? []).map((c) => String(c ?? ''))
            const rows = aoa.slice(1, 501).map((r) => r.map((c) => String(c ?? '')))
            return { name, headers, rows, totalRows: Math.max(0, aoa.length - 1) }
          })
          return sendJson(res, 200, { title: meta.title, sheets })
        } catch (err) {
          return sendJson(res, 500, { error: err instanceof Error ? err.message : 'xlsx error' })
        }
      })

      // ─── Device troubleshooting search ─────────────────────
      // Returns top Confluence pages for a given device category, used by
      // the Mobility "Device Troubleshooting" tab.
      server.middlewares.use('/api/confluence/devices', async (req, res) => {
        if (!requireCreds(res)) return
        try {
          const url = new URL(req.url || '', 'http://x')
          const device = (url.searchParams.get('device') || '').toLowerCase()
          const ancestor = url.searchParams.get('ancestor') || env.CONFLUENCE_MOBILITY_ROOT || ''
          const space = env.CONFLUENCE_SPACE
          const QUERIES: Record<string, string[]> = {
            'iphone':         ['iPhone', 'iOS', 'Apple'],
            'android-phone':  ['Android', 'Samsung', 'Pixel'],
            'ipad':           ['iPad', 'tablet iPad'],
            'android-tablet': ['Android tablet', 'Galaxy Tab'],
            'sim':            ['SIM', 'eSIM', 'activate SIM', 'physical SIM'],
          }
          const terms = QUERIES[device] || [device]
          const safe = (s: string) => s.replace(/"/g, '\\"')
          const seen = new Set<string>()
          const results: any[] = []
          for (const term of terms) {
            const parts = [`type=page`]
            if (ancestor) parts.push(`ancestor=${ancestor}`)
            if (space) parts.push(`space=${space}`)
            parts.push(`(title ~ "${safe(term)}" OR text ~ "${safe(term)}")`)
            const cql = parts.join(' AND ')
            const data = await cf(`/rest/api/search?cql=${encodeURIComponent(cql)}&limit=10&expand=content.body.view`)
            for (const r of (data.results ?? [])) {
              const c = r.content ?? {}
              const id = c.id
              if (!id || seen.has(id)) continue
              seen.add(id)
              const raw = c.body?.view?.value ?? r.excerpt ?? ''
              const text = raw.replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim()
              const webui = c._links?.webui ?? ''
              results.push({
                id,
                title: c.title ?? 'Untitled',
                url: webui ? (webui.startsWith('http') ? webui : `${baseUrl()}${webui}`) : '',
                snippet: text.slice(0, 240),
                matchedTerm: term,
              })
              if (results.length >= 15) break
            }
            if (results.length >= 15) break
          }
          return sendJson(res, 200, { device, count: results.length, results })
        } catch (err) {
          return sendJson(res, 500, { error: err instanceof Error ? err.message : 'devices error' })
        }
      })

      // ─── Escalation contacts auto-fill (cached 15 min) ─────
      // GET /api/confluence/escalations?carrier=<carrier-name>
      // Returns Confluence pages that look like an escalation list, so the
      // UI can show "Open in Confluence" links and (later) parse contacts.
      const escalationsCache = new Map<string, { data: any; ts: number }>()
      const ESC_CACHE_TTL = 15 * 60 * 1000
      server.middlewares.use('/api/confluence/escalations', async (req, res) => {
        if (!requireCreds(res)) return
        try {
          const url = new URL(req.url || '', 'http://x')
          const carrier = (url.searchParams.get('carrier') || '').trim()
          if (!carrier) return sendJson(res, 400, { error: 'carrier required' })
          const key = carrier.toLowerCase()
          const hit = escalationsCache.get(key)
          if (hit && Date.now() - hit.ts < ESC_CACHE_TTL) {
            return sendJson(res, 200, { ...hit.data, cached: true })
          }
          const safe = (s: string) => s.replace(/"/g, '\\"')
          const baseHref = baseUrl()
          const space = env.CONFLUENCE_SPACE
          const queries = [
            `${carrier} escalation`,
            `${carrier} escalation list`,
            `${carrier} contact list`,
          ]
          const seen = new Set<string>()
          const results: any[] = []
          for (const q of queries) {
            const parts = [`type=page`, `(title ~ "${safe(q)}" OR text ~ "${safe(q)}")`]
            if (space) parts.push(`space=${space}`)
            const cql = parts.join(' AND ')
            const data = await cf(`/rest/api/search?cql=${encodeURIComponent(cql)}&limit=5&expand=content.body.view`).catch(() => ({ results: [] }))
            for (const r of (data.results ?? [])) {
              const c = r.content ?? {}
              const id = c.id
              if (!id || seen.has(id)) continue
              seen.add(id)
              const raw = c.body?.view?.value ?? r.excerpt ?? ''
              const text = raw.replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim()
              const webui = c._links?.webui ?? ''
              results.push({
                id, title: c.title ?? 'Untitled',
                url: webui ? (webui.startsWith('http') ? webui : `${baseHref}${webui}`) : '',
                excerpt: text.slice(0, 800),
              })
              if (results.length >= 8) break
            }
            if (results.length >= 8) break
          }
          const payload = { carrier, count: results.length, results, cached: false }
          escalationsCache.set(key, { data: payload, ts: Date.now() })
          return sendJson(res, 200, payload)
        } catch (err) {
          return sendJson(res, 500, { error: err instanceof Error ? err.message : 'escalations error' })
        }
      })

      // ─── Auto-ground helper for the AI Assistant ───────────
      // GET /api/confluence/auto-ground?q=<query>&scope=all|space|root
      // Returns top 8 wiki pages with 600-char excerpts. Searches across the
      // ENTIRE vikicloud Confluence by default (every space) so the AI agent
      // gets the widest possible grounding. Add ?scope=space to scope to TS.
      server.middlewares.use('/api/confluence/auto-ground', async (req, res) => {
        if (!requireCreds(res)) return
        try {
          const url = new URL(req.url || '', 'http://x')
          const q = (url.searchParams.get('q') || '').trim().slice(0, 200)
          const scope = (url.searchParams.get('scope') || 'all').toLowerCase()
          if (!q) return sendJson(res, 400, { error: 'q required' })
          const safe = q.replace(/"/g, '\\"')

          // Scope filter — default is the entire vikicloud instance
          const filter = scope === 'space' && env.CONFLUENCE_SPACE
            ? ` AND space=${env.CONFLUENCE_SPACE}`
            : ''

          // Two parallel passes: title-match (high precision) + text-match (recall)
          const titleCql = `type=page AND title ~ "${safe}"${filter}`
          const textCql  = `type=page AND text ~ "${safe}"${filter}`
          const [titleRes, textRes] = await Promise.all([
            cf(`/rest/api/search?cql=${encodeURIComponent(titleCql)}&limit=10&expand=content.body.view,content.space`).catch(() => ({ results: [] })),
            cf(`/rest/api/search?cql=${encodeURIComponent(textCql)}&limit=10&expand=content.body.view,content.space`).catch(() => ({ results: [] })),
          ])

          const baseHref = baseUrl()
          const seen = new Set<string>()
          const pages: any[] = []
          for (const data of [titleRes, textRes]) {
            for (const r of (data.results ?? [])) {
              const c = r.content ?? {}
              const id = c.id
              if (!id || seen.has(id)) continue
              seen.add(id)
              const raw = c.body?.view?.value ?? r.excerpt ?? ''
              const text = String(raw).replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 600)
              const webui = c._links?.webui ?? ''
              const spaceKey = c.space?.key || c._expandable?.space?.split('/').pop() || '?'
              pages.push({
                i: pages.length + 1, id, title: c.title,
                url: webui ? (webui.startsWith('http') ? webui : `${baseHref}${webui}`) : '',
                space: spaceKey,
                excerpt: text,
              })
              if (pages.length >= 8) break
            }
            if (pages.length >= 8) break
          }
          return sendJson(res, 200, { query: q, scope, count: pages.length, pages })
        } catch (err) {
          return sendJson(res, 500, { error: err instanceof Error ? err.message : 'auto-ground error' })
        }
      })
    },
  }
}

// ---------------------------------------------------------------------------
// AI reranker proxy — calls a premium LLM (gpt-5 by default) to re-rank
// raw Confluence search results by semantic relevance and emit smart
// suggestions. Used by the Mobility Smart Search bar.
// ---------------------------------------------------------------------------
function aiRerankerPlugin(): Plugin {
  let env: Record<string, string> = {}
  return {
    name: 'ai-reranker',
    configureServer(server) {
      env = loadEnv('development', process.cwd(), '')
      server.middlewares.use('/api/ai/rerank', async (req, res) => {
        if (req.method !== 'POST') {
          res.statusCode = 405
          res.end('Method not allowed')
          return
        }
        try {
          const chunks: Buffer[] = []
          for await (const chunk of req) chunks.push(chunk as Buffer)
          const body = JSON.parse(Buffer.concat(chunks).toString() || '{}')
          const apiKey = env.AI_API_KEY
          const platformUrl = env.AI_PLATFORM_URL || 'https://devs.ai'
          const model = body.model || env.AI_FAST_MODEL || 'gpt-4o-mini'

          const prompt = `You are a Confluence search reranker for a NOC team.

USER QUERY: ${JSON.stringify(body.query ?? '')}

CANDIDATE PAGES (from Confluence CQL search):
${JSON.stringify(body.results ?? [], null, 2)}

Return ONLY a JSON object (no markdown fences, no commentary) with this shape:

{
  "ranked": [
    {"id": "<page id>", "title": "<page title>", "url": "<page url>", "relevance": 0-100, "why": "<1 sentence why this matches>"}
  ],
  "topMatch": "<id of best match, or null>",
  "didYouMean": "<corrected query if user mistyped, or null>",
  "suggestions": ["<related search>", "..."]
}

Rules:
- Re-rank by SEMANTIC match to the query, not just keyword overlap
- relevance 100 = perfect title match; 70+ = strong; 40+ = related; <40 = weak
- Drop results with relevance < 30
- topMatch only if best result has relevance >= 70
- didYouMean only if you spot a clear typo
- suggestions = 3 related queries that might also help
- Keep "why" under 80 chars`

          const upstream = await fetch(`${platformUrl}/api/v1/chats/completions`, {
            method: 'POST',
            headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
            body: JSON.stringify({
              model,
              messages: [{ role: 'user', content: prompt }],
              stream: true,
            }),
          })

          if (!upstream.ok || !upstream.body) {
            res.writeHead(upstream.status, { 'Content-Type': 'application/json' })
            res.end(JSON.stringify({ error: `Rerank upstream ${upstream.status}` }))
            return
          }

          // Aggregate SSE deltas
          const reader = upstream.body.getReader()
          const decoder = new TextDecoder()
          let buf = ''
          let ev = ''
          let dt = ''
          let text = ''
          while (true) {
            const { done, value } = await reader.read()
            if (done) break
            buf += decoder.decode(value, { stream: true })
            const lines = buf.split('\n')
            buf = lines.pop() ?? ''
            for (const line of lines) {
              if (line.startsWith('event: ')) ev = line.slice(7).trim()
              else if (line.startsWith('data: ')) dt = line.slice(6)
              else if (line === '') {
                if (ev === 'message.delta' && dt) {
                  try {
                    const p = JSON.parse(dt)
                    if (p.content?.text) text += p.content.text
                  } catch {}
                }
                ev = ''
                dt = ''
              }
            }
          }
          res.writeHead(200, { 'Content-Type': 'application/json' })
          res.end(JSON.stringify({ text, model }))
        } catch (err) {
          res.writeHead(500, { 'Content-Type': 'application/json' })
          res.end(JSON.stringify({ error: err instanceof Error ? err.message : 'rerank error' }))
        }
      })

      // ─── In-memory LRU cache for smart-search ──────────────────
      const smartCache = new Map<string, { data: any; ts: number }>()
      const SMART_CACHE_TTL = 10 * 60 * 1000 // 10 min
      const SMART_CACHE_MAX = 200
      const cacheGet = (key: string) => {
        const hit = smartCache.get(key)
        if (!hit) return null
        if (Date.now() - hit.ts > SMART_CACHE_TTL) {
          smartCache.delete(key)
          return null
        }
        // LRU touch
        smartCache.delete(key); smartCache.set(key, hit)
        return hit.data
      }
      const cacheSet = (key: string, data: any) => {
        if (smartCache.size >= SMART_CACHE_MAX) {
          const oldest = smartCache.keys().next().value
          if (oldest) smartCache.delete(oldest)
        }
        smartCache.set(key, { data, ts: Date.now() })
      }

      // ─── /api/ai/smart-search-stream — fast SSE pipeline ───────
      // Emits:
      //   event: candidates (raw CQL hits, ~400-800ms)
      //   event: intent     (LLM intent extraction, ~1-2s, parallel)
      //   event: curated    (final LLM rerank, ~2-3s)
      //   event: done
      server.middlewares.use('/api/ai/smart-search-stream', async (req, res) => {
        if (req.method !== 'POST') { res.statusCode = 405; res.end('Method not allowed'); return }
        const chunks: Buffer[] = []
        for await (const chunk of req) chunks.push(chunk as Buffer)
        const body = JSON.parse(Buffer.concat(chunks).toString() || '{}')
        const rawQuery: string = String(body.query ?? '').trim()
        const ancestor: string = String(body.ancestor ?? env.CONFLUENCE_MOBILITY_ROOT ?? '')
        const premium: boolean = !!body.premium
        if (!rawQuery) { res.statusCode = 400; res.end('query required'); return }

        const cacheKey = `${rawQuery.toLowerCase()}|${ancestor}|${premium ? 'p' : 'f'}`
        const cached = cacheGet(cacheKey)
        if (cached) {
          res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' })
          res.write(`event: candidates\ndata: ${JSON.stringify({ candidates: cached.raw ?? [], cached: true })}\n\n`)
          if (cached.intent) res.write(`event: intent\ndata: ${JSON.stringify(cached.intent)}\n\n`)
          res.write(`event: curated\ndata: ${JSON.stringify({ curated: cached.curated ?? [], topMatch: cached.topMatch, didYouMean: cached.didYouMean, suggestions: cached.suggestions ?? [], cached: true })}\n\n`)
          res.write(`event: done\ndata: {}\n\n`)
          res.end()
          return
        }

        res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' })
        const emit = (event: string, payload: unknown) => {
          res.write(`event: ${event}\ndata: ${JSON.stringify(payload)}\n\n`)
        }

        const apiKey = env.AI_API_KEY
        const platformUrl = env.AI_PLATFORM_URL || 'https://devs.ai'
        const fastModel = env.AI_FAST_MODEL || 'gpt-4o-mini'
        const premiumModel = env.AI_RERANK_MODEL || 'gpt-5'
        const model = premium ? premiumModel : fastModel

        const cfBase = (env.CONFLUENCE_URL || '').replace(/\/+$/, '') + '/wiki'
        const cfAuth = 'Basic ' + Buffer.from(`${env.CONFLUENCE_EMAIL}:${env.CONFLUENCE_TOKEN}`).toString('base64')
        const cf = async (path: string): Promise<any> => {
          const r = await fetch(`${cfBase}${path}`, { headers: { Authorization: cfAuth, Accept: 'application/json' } })
          if (!r.ok) throw new Error(`Confluence ${r.status}`)
          return r.json()
        }

        const callLLM = async (prompt: string, llmModel: string): Promise<string> => {
          const upstream = await fetch(`${platformUrl}/api/v1/chats/completions`, {
            method: 'POST',
            headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
            body: JSON.stringify({ model: llmModel, messages: [{ role: 'user', content: prompt }], stream: true }),
          })
          if (!upstream.ok || !upstream.body) throw new Error(`LLM ${upstream.status}`)
          const reader = upstream.body.getReader()
          const decoder = new TextDecoder()
          let buf = '', ev = '', dt = '', text = ''
          while (true) {
            const { done, value } = await reader.read()
            if (done) break
            buf += decoder.decode(value, { stream: true })
            const lines = buf.split('\n'); buf = lines.pop() ?? ''
            for (const line of lines) {
              if (line.startsWith('event: ')) ev = line.slice(7).trim()
              else if (line.startsWith('data: ')) dt = line.slice(6)
              else if (line === '') {
                if (ev === 'message.delta' && dt) {
                  try { const p = JSON.parse(dt); if (p.content?.text) text += p.content.text } catch {}
                }
                ev = ''; dt = ''
              }
            }
          }
          return text
        }

        const extractJSON = <T = any>(text: string): T | null => {
          if (!text) return null
          let cleaned = text.trim()
          const m = cleaned.match(/```(?:json)?\s*([\s\S]*?)```/)
          if (m) cleaned = m[1].trim()
          const s = cleaned.indexOf('{'); const e = cleaned.lastIndexOf('}')
          if (s === -1 || e === -1) return null
          try { return JSON.parse(cleaned.slice(s, e + 1)) as T } catch { return null }
        }

        const safe = (s: string) => s.replace(/"/g, '\\"')
        const scope: string[] = ['type=page']
        if (ancestor) scope.push(`ancestor=${ancestor}`)
        if (env.CONFLUENCE_SPACE) scope.push(`space=${env.CONFLUENCE_SPACE}`)
        const baseHref = cfBase

        // ── Fast lane: kick off ALL CQL passes in parallel using the raw query immediately ──
        // (we don't wait for the LLM intent — we use the query words directly).
        const tokenize = (q: string) => q.toLowerCase().replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).filter((w) => w.length >= 2)
        const STOP = new Set(['the','a','an','and','or','of','to','for','in','on','with','about','please','need','find','show','help','can','tell','me','my','our','their','it','is','are','what','how','why','when','where','do','does','did','have','has','from','this','that','i','you'])
        const tokens = tokenize(rawQuery).filter((t) => !STOP.has(t))
        const passesParallel: string[] = []
        // 1. phrase match in title
        passesParallel.push([...scope, `title ~ "${safe(rawQuery)}"`].join(' AND '))
        // 2. phrase match in body
        passesParallel.push([...scope, `text ~ "${safe(rawQuery)}"`].join(' AND '))
        // 3. all-tokens AND in title
        if (tokens.length) passesParallel.push([...scope, tokens.map((t) => `title ~ "${safe(t)}*"`).join(' AND ')].join(' AND '))
        // 4. all-tokens AND in text
        if (tokens.length) passesParallel.push([...scope, tokens.map((t) => `text ~ "${safe(t)}*"`).join(' AND ')].join(' AND '))
        // 5. any-token OR in title (low precision fallback)
        if (tokens.length) passesParallel.push([...scope, `(${tokens.map((t) => `title ~ "${safe(t)}*"`).join(' OR ')})`].join(' AND '))

        const cqlPromises = passesParallel.map((cql) =>
          cf(`/rest/api/search?cql=${encodeURIComponent(cql)}&limit=10&expand=content.body.view`).catch(() => ({ results: [] }))
        )

        // ── Start intent extraction in parallel with CQL ──
        const intentPrompt = `Analyze this NOC engineer's search query:
Query: ${JSON.stringify(rawQuery)}

Return ONLY JSON, no commentary:
{
  "intent": "<one short sentence: what is the user trying to find?>",
  "searchTerms": ["<3-5 SHORT keywords>"],
  "phraseHints": ["<longer phrases likely in titles>"],
  "queryType": "lookup|how-to|troubleshooting|reference|contact"
}`
        const intentPromise = callLLM(intentPrompt, fastModel).then((t) => extractJSON<any>(t)).catch(() => null)

        // Wait for first CQL results (fastest pass wins)
        const seen = new Set<string>()
        const candidates: any[] = []
        const collectFromResult = (r: any) => {
          for (const item of (r?.results ?? [])) {
            const c = item.content ?? {}
            const id = c.id
            if (!id || seen.has(id)) continue
            seen.add(id)
            const raw = c.body?.view?.value ?? item.excerpt ?? ''
            const text = raw.replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim()
            const webui = c._links?.webui ?? ''
            candidates.push({
              id,
              title: c.title ?? 'Untitled',
              url: webui ? (webui.startsWith('http') ? webui : `${baseHref}${webui}`) : '',
              snippet: text.slice(0, 300),
            })
            if (candidates.length >= 20) return
          }
        }

        // Race-collect: emit first batch as soon as any CQL pass returns hits
        let firstEmitted = false
        const results = await Promise.all(cqlPromises.map(async (p, idx) => {
          const r = await p
          collectFromResult(r)
          if (!firstEmitted && candidates.length > 0) {
            firstEmitted = true
            emit('candidates', { candidates: candidates.slice(0, 10), partial: true })
          }
          return r
        }))

        // Final dedup pass complete
        if (candidates.length === 0 && !firstEmitted) emit('candidates', { candidates: [], partial: false })
        else emit('candidates', { candidates, partial: false })

        // Emit intent when ready (likely already resolved)
        const intent = await intentPromise
        if (intent) emit('intent', intent)

        if (candidates.length === 0) {
          emit('curated', { curated: [], topMatch: null, didYouMean: null, suggestions: [] })
          emit('done', { ms: Date.now() })
          res.end()
          return
        }

        // ── Stage 3: filter + rerank with fast model (or gpt-5 if premium) ──
        const filterPrompt = `Filter and rerank these Confluence pages by semantic relevance.

User query: ${JSON.stringify(rawQuery)}
User intent: ${JSON.stringify(intent?.intent ?? 'unknown')}
Query type: ${intent?.queryType ?? 'unknown'}

Pages:
${JSON.stringify(candidates.map((c) => ({ id: c.id, title: c.title, snippet: c.snippet.slice(0, 200) })), null, 2)}

Return ONLY JSON:
{
  "curated": [{"id": "...", "relevance": 0-100, "why": "<≤80 chars>"}],
  "topMatch": "<id>" or null,
  "didYouMean": "<correction>" or null,
  "suggestions": ["<3 follow-ups>"]
}

RULES:
- Drop relevance < 50
- Max 5 curated, sorted desc
- topMatch only if best >= 75
- Reward title matches heavily
- For activation queries, prefer how-to pages
- For contact queries, prefer pages with carrier names`

        let curated: any[] = []
        let topMatch: string | null = null
        let didYouMean: string | null = null
        let suggestions: string[] = []
        try {
          const filterText = await callLLM(filterPrompt, model)
          const parsed = extractJSON<any>(filterText)
          if (parsed?.curated && Array.isArray(parsed.curated)) {
            const byId = new Map(candidates.map((c) => [c.id, c]))
            curated = parsed.curated
              .filter((x: any) => x?.id && byId.has(x.id) && Number(x.relevance) >= 50)
              .slice(0, 5)
              .map((x: any) => ({
                ...byId.get(x.id),
                relevance: Math.round(Number(x.relevance) || 0),
                why: String(x.why || '').slice(0, 100),
              }))
          }
          topMatch = parsed?.topMatch ?? null
          didYouMean = parsed?.didYouMean ?? null
          suggestions = Array.isArray(parsed?.suggestions) ? parsed.suggestions.slice(0, 3) : []
        } catch {/* fall back to raw */}

        const finalPayload = { curated, topMatch, didYouMean, suggestions, model, intent, raw: candidates }
        emit('curated', { curated, topMatch, didYouMean, suggestions })
        emit('done', { ms: Date.now() })
        cacheSet(cacheKey, finalPayload)
        res.end()
      })

      // ─── Original /api/ai/smart-search (non-streaming, kept for compat) ──
      server.middlewares.use('/api/ai/smart-search', async (req, res) => {
        const sendJsonLocal = (s: number, p: unknown) => {
          res.writeHead(s, { 'Content-Type': 'application/json' })
          res.end(JSON.stringify(p))
        }
        if (req.method !== 'POST') {
          res.statusCode = 405; res.end('Method not allowed'); return
        }
        try {
          const chunks: Buffer[] = []
          for await (const chunk of req) chunks.push(chunk as Buffer)
          const body = JSON.parse(Buffer.concat(chunks).toString() || '{}')
          const rawQuery: string = String(body.query ?? '').trim()
          const ancestor: string = String(body.ancestor ?? env.CONFLUENCE_MOBILITY_ROOT ?? '')
          if (!rawQuery) return sendJsonLocal(400, { error: 'query required' })

          const apiKey = env.AI_API_KEY
          const platformUrl = env.AI_PLATFORM_URL || 'https://devs.ai'
          const model = body.model || env.AI_FAST_MODEL || 'gpt-4o-mini'

          // ── Local Confluence helpers (since cf/auth/baseUrl are scoped to confluenceRestPlugin) ──
          const cfBase = (env.CONFLUENCE_URL || '').replace(/\/+$/, '') + '/wiki'
          const cfAuth = 'Basic ' + Buffer.from(`${env.CONFLUENCE_EMAIL}:${env.CONFLUENCE_TOKEN}`).toString('base64')
          const cf = async (path: string): Promise<any> => {
            const r = await fetch(`${cfBase}${path}`, { headers: { Authorization: cfAuth, Accept: 'application/json' } })
            if (!r.ok) throw new Error(`Confluence ${r.status}`)
            return r.json()
          }

          const callLLM = async (prompt: string): Promise<string> => {
            const upstream = await fetch(`${platformUrl}/api/v1/chats/completions`, {
              method: 'POST',
              headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
              body: JSON.stringify({ model, messages: [{ role: 'user', content: prompt }], stream: true }),
            })
            if (!upstream.ok || !upstream.body) throw new Error(`LLM ${upstream.status}`)
            const reader = upstream.body.getReader()
            const decoder = new TextDecoder()
            let buf = '', ev = '', dt = '', text = ''
            while (true) {
              const { done, value } = await reader.read()
              if (done) break
              buf += decoder.decode(value, { stream: true })
              const lines = buf.split('\n')
              buf = lines.pop() ?? ''
              for (const line of lines) {
                if (line.startsWith('event: ')) ev = line.slice(7).trim()
                else if (line.startsWith('data: ')) dt = line.slice(6)
                else if (line === '') {
                  if (ev === 'message.delta' && dt) {
                    try { const p = JSON.parse(dt); if (p.content?.text) text += p.content.text } catch {}
                  }
                  ev = ''; dt = ''
                }
              }
            }
            return text
          }

          const extractJSON = <T = any>(text: string): T | null => {
            if (!text) return null
            let cleaned = text.trim()
            const m = cleaned.match(/```(?:json)?\s*([\s\S]*?)```/)
            if (m) cleaned = m[1].trim()
            const s = cleaned.indexOf('{'); const e = cleaned.lastIndexOf('}')
            if (s === -1 || e === -1) return null
            try { return JSON.parse(cleaned.slice(s, e + 1)) as T } catch { return null }
          }

          // ── Stage 1: intent extraction ──
          const intentPrompt = `Analyze this NOC engineer's search query about company Mobility/wireless operations (carriers, devices, SIM activation, troubleshooting, etc.):

Query: ${JSON.stringify(rawQuery)}

Return ONLY this JSON (no markdown, no commentary):
{
  "intent": "<one short sentence: what is the user actually trying to find?>",
  "searchTerms": ["<3-6 SHORT keywords/phrases for Confluence search — drop stopwords>"],
  "phraseHints": ["<longer multi-word phrases likely to appear in the page title>"],
  "queryType": "lookup|how-to|troubleshooting|reference|contact",
  "synonyms": {"<original term>": "<comma-separated synonyms>"}
}

Examples:
- "I need you to search mobility activation task template" → searchTerms: ["mobility task template", "activation"], phraseHints: ["Mobility Task Template"]
- "how do I activate an eSIM on Quantum Shift" → searchTerms: ["eSIM", "activate", "Quantum Shift"], phraseHints: ["eSIM activation", "Quantum Shift eSIM"]
- "AT&T support number" → searchTerms: ["AT&T", "support"], queryType: "contact"
- "please find telspire sim actvation" → searchTerms: ["telispire", "SIM", "activation"], phraseHints: ["Telispire physical SIM"]
- "phone won't turn on" → searchTerms: ["phone", "power", "device troubleshooting"], queryType: "troubleshooting"`

          let intent: any = null
          try {
            const intentText = await callLLM(intentPrompt)
            intent = extractJSON(intentText)
          } catch (e) {
            // fall back without intent
          }

          // ── Stage 2: run Confluence searches ──
          const terms: string[] = (intent?.searchTerms ?? []).filter((t: any) => typeof t === 'string' && t.length >= 2)
          const phraseHints: string[] = (intent?.phraseHints ?? []).filter((t: any) => typeof t === 'string')
          if (!terms.length) terms.push(rawQuery)

          const safe = (s: string) => s.replace(/"/g, '\\"')
          const scope: string[] = ['type=page']
          if (ancestor) scope.push(`ancestor=${ancestor}`)
          if (env.CONFLUENCE_SPACE) scope.push(`space=${env.CONFLUENCE_SPACE}`)
          const baseHref = (env.CONFLUENCE_URL || '').replace(/\/+$/, '') + '/wiki'

          const seen = new Set<string>()
          const candidates: any[] = []
          const passes: string[] = []

          // Phrase-match passes (highest precision)
          for (const ph of phraseHints) {
            passes.push([...scope, `(title ~ "${safe(ph)}" OR text ~ "${safe(ph)}")`].join(' AND '))
          }
          // All-terms passes
          if (terms.length) {
            const titleAnd = terms.map((k) => `title ~ "${safe(k)}*"`).join(' AND ')
            const textAnd = terms.map((k) => `text ~ "${safe(k)}*"`).join(' AND ')
            passes.push([...scope, titleAnd].join(' AND '))
            passes.push([...scope, textAnd].join(' AND '))
          }
          // Any-term passes (low precision, only if we still need more)
          for (const t of terms) {
            passes.push([...scope, `(title ~ "${safe(t)}*" OR text ~ "${safe(t)}*")`].join(' AND '))
          }

          const limit = 20
          for (const cql of passes) {
            if (candidates.length >= limit) break
            try {
              const data = await cf(`/rest/api/search?cql=${encodeURIComponent(cql)}&limit=${limit}&expand=content.body.view`)
              for (const r of (data.results ?? [])) {
                const c = r.content ?? {}
                const id = c.id
                if (!id || seen.has(id)) continue
                seen.add(id)
                const raw = c.body?.view?.value ?? r.excerpt ?? ''
                const text = raw.replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim()
                const webui = c._links?.webui ?? ''
                candidates.push({
                  id,
                  title: c.title ?? 'Untitled',
                  url: webui ? (webui.startsWith('http') ? webui : `${baseHref}${webui}`) : '',
                  snippet: text.slice(0, 300),
                })
                if (candidates.length >= limit) break
              }
            } catch {/* ignore individual pass */}
          }

          if (candidates.length === 0) {
            return sendJsonLocal(200, {
              query: rawQuery, intent, curated: [], raw: [],
              count: 0, model, message: 'No Confluence pages matched'
            })
          }

          // ── Stage 3: LLM filter + rerank ──
          const filterPrompt = `You are a Confluence search assistant for a NOC team. Filter and rerank these pages by semantic relevance to what the user is actually trying to do.

User's natural language query: ${JSON.stringify(rawQuery)}
User's intent (extracted): ${JSON.stringify(intent?.intent ?? 'unknown')}
Query type: ${intent?.queryType ?? 'unknown'}

Candidate pages from Confluence:
${JSON.stringify(candidates.map((c) => ({ id: c.id, title: c.title, snippet: c.snippet })), null, 2)}

Return ONLY this JSON (no markdown, no commentary):
{
  "curated": [
    {"id": "<page id>", "relevance": 0-100, "why": "<≤80 chars: why this is a great answer for the user's intent>"}
  ],
  "topMatch": "<id of best>" or null,
  "didYouMean": "<corrected query>" or null,
  "suggestions": ["<related search 1>", "<2>", "<3>"]
}

RULES:
- DROP any page with relevance < 50 — be strict, prefer fewer, higher-confidence results
- Return at MOST 5 curated items, sorted by relevance descending
- topMatch only if highest result has relevance >= 75
- Reward title matches heavily; "Mobility Task Template" should rank very high for "activation task template"
- For activation queries, prefer step-by-step or how-to pages over reference docs
- For contact queries, prefer pages with carrier names in the title
- suggestions = 3 related follow-up queries the user might want next`

          let curated: any[] = []
          let topMatch: string | null = null
          let didYouMean: string | null = null
          let suggestions: string[] = []
          try {
            const filterText = await callLLM(filterPrompt)
            const parsed = extractJSON<any>(filterText)
            if (parsed?.curated && Array.isArray(parsed.curated)) {
              const byId = new Map(candidates.map((c) => [c.id, c]))
              curated = parsed.curated
                .filter((x: any) => x?.id && byId.has(x.id) && Number(x.relevance) >= 50)
                .slice(0, 5)
                .map((x: any) => ({
                  ...byId.get(x.id),
                  relevance: Math.round(Number(x.relevance) || 0),
                  why: String(x.why || '').slice(0, 100),
                }))
            }
            topMatch = parsed?.topMatch ?? null
            didYouMean = parsed?.didYouMean ?? null
            suggestions = Array.isArray(parsed?.suggestions) ? parsed.suggestions.slice(0, 3) : []
          } catch {/* fall back to raw */}

          return sendJsonLocal(200, {
            query: rawQuery,
            intent,
            curated,
            raw: candidates,
            count: curated.length,
            rawCount: candidates.length,
            topMatch,
            didYouMean,
            suggestions,
            model,
          })
        } catch (err) {
          return sendJsonLocal(500, { error: err instanceof Error ? err.message : 'smart-search error' })
        }
      })
    },
  }
}

// ---------------------------------------------------------------------------
// NOC Tools proxy
// GET /api/ping?host=<h>&minutes=0&continuous=0  → SSE stream of ping lines
//   minutes=0  → 4-packet standard (quick)
//   minutes=N  → timed continuous (N * 60 pings, 1/sec)
//   continuous=1 → infinite until client disconnects
// GET /api/whois?query=<q>  → enriched IP (ipapi + ARIN RDAP) or domain RDAP
// ---------------------------------------------------------------------------
function nocToolsPlugin(): Plugin {
  return {
    name: 'noc-tools',
    configureServer(server) {

      // ── Ping (SSE streaming) ─────────────────────────────────────────────
      // ── Sandbox keep-alive proxy — server-side fetch, returns real HTTP status ──
      server.middlewares.use('/api/sandbox-ping', async (req, res) => {
        const url = new URL(req.url || '/', 'http://localhost')
        const target = url.searchParams.get('url') || ''
        res.writeHead(200, { 'Content-Type': 'application/json', 'Cache-Control': 'no-cache' })
        if (!target.startsWith('https://')) {
          res.end(JSON.stringify({ ok: false, status: 0, error: 'Invalid URL' })); return
        }
        try {
          const controller = new AbortController()
          const timeout = setTimeout(() => controller.abort(), 20000)
          const r = await fetch(target, {
            method: 'GET',
            signal: controller.signal,
            headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/124.0 NOC-KeepAlive/1.0' },
            redirect: 'follow',
          })
          clearTimeout(timeout)
          res.end(JSON.stringify({ ok: r.ok || r.status < 500, status: r.status, error: null }))
        } catch (e: any) {
          res.end(JSON.stringify({ ok: false, status: 0, error: e?.message ?? 'Network error' }))
        }
      })

      server.middlewares.use('/api/ping', async (req, res) => {
        if (req.method !== 'GET') { res.statusCode = 405; res.end(); return }
        const url = new URL(req.url || '/', 'http://localhost')
        const host = (url.searchParams.get('host') || '').trim()
        const minutes = Math.min(30, Math.max(0, parseInt(url.searchParams.get('minutes') || '0', 10)))
        const continuous = url.searchParams.get('continuous') === '1'

        if (!host || !/^[a-zA-Z0-9.\-_:]+$/.test(host)) {
          res.writeHead(400, { 'Content-Type': 'application/json' })
          res.end(JSON.stringify({ error: 'Invalid host — use a hostname or IP address' }))
          return
        }

        // SSE headers
        res.writeHead(200, {
          'Content-Type': 'text/event-stream',
          'Cache-Control': 'no-cache',
          'Connection': 'keep-alive',
          'X-Accel-Buffering': 'no',
        })

        const sendEvt = (event: string, data: string) => {
          try { res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`) } catch {}
        }

        const { spawn } = await import('child_process')
        const isWin = process.platform === 'win32'
        let args: string[]

        if (continuous) {
          args = isWin ? ['-t', host] : ['-i', '1', host]
        } else if (minutes > 0) {
          const count = minutes * 60
          args = isWin ? ['-n', String(count), host] : ['-c', String(count), '-i', '1', host]
        } else {
          args = isWin ? ['-n', '4', host] : ['-c', '4', '-W', '3', host]
        }

        const timeoutMs = continuous ? 35 * 60 * 1000 : (minutes > 0 ? (minutes + 2) * 60 * 1000 : 20000)
        const child = spawn('ping', args)
        let killed = false

        const killTimer = setTimeout(() => {
          if (!killed) { killed = true; child.kill(); sendEvt('done', 'timeout'); res.end() }
        }, timeoutMs)

        child.stdout?.on('data', (chunk: Buffer) => {
          chunk.toString().split('\n').forEach(line => { if (line.trim()) sendEvt('line', line) })
        })
        child.stderr?.on('data', (chunk: Buffer) => {
          chunk.toString().split('\n').forEach(line => { if (line.trim()) sendEvt('line', line) })
        })
        child.on('close', () => {
          clearTimeout(killTimer)
          if (!killed) { killed = true; sendEvt('done', ''); res.end() }
        })
        child.on('error', (err: Error) => {
          clearTimeout(killTimer)
          sendEvt('error', err.message); res.end()
        })
        req.on('close', () => { clearTimeout(killTimer); if (!killed) { killed = true; child.kill() } })
      })

      // ── WHOIS — enriched with ipapi.co + ARIN RDAP ──────────────────────
      server.middlewares.use('/api/whois', async (req, res) => {
        if (req.method !== 'GET') { res.statusCode = 405; res.end(); return }
        const url = new URL(req.url || '/', 'http://localhost')
        const query = (url.searchParams.get('query') || '').trim().replace(/^https?:\/\//, '').split('/')[0].toLowerCase()
        if (!query) {
          res.writeHead(400, { 'Content-Type': 'application/json' })
          res.end(JSON.stringify({ error: 'No query provided' })); return
        }
        try {
          const isIP = /^(\d{1,3}\.){3}\d{1,3}$/.test(query) || /^[0-9a-f:]+$/.test(query)
          let data: any

          if (isIP) {
            // Fetch both ipapi.co and ARIN RDAP in parallel
            const [ipapiR, arinR] = await Promise.allSettled([
              fetch(`https://ipapi.co/${query}/json/`, { headers: { 'User-Agent': 'NOCToolkit/1.0' } }).then(r => r.ok ? r.json() : null),
              fetch(`https://rdap.arin.net/registry/ip/${query}`, { headers: { Accept: 'application/rdap+json', 'User-Agent': 'NOCToolkit/1.0' } }).then(r => r.ok ? r.json() : null).catch(() => null),
            ])
            const ipapi = ipapiR.status === 'fulfilled' ? ipapiR.value : null
            const arin  = arinR.status  === 'fulfilled' ? arinR.value  : null

            // Parse ARIN data
            let arinOrgName: string | null = null
            let arinNetName: string | null = arin?.name ?? null
            let arinHandle:  string | null = arin?.handle ?? null
            let arinCidr:    string | null = null
            let arinStartIp: string | null = arin?.startAddress ?? null
            let arinEndIp:   string | null = arin?.endAddress ?? null
            let abuseEmail:  string | null = null
            let abusePhone:  string | null = null
            let arinCountry: string | null = arin?.country ?? null

            if (arin?.cidr0_cidrs?.length) {
              const c = arin.cidr0_cidrs[0]
              arinCidr = `${c.v4prefix || c.v6prefix}/${c.length}`
            }
            // Walk ARIN entities for org + abuse contact
            const walkEntities = (entities: any[]): void => {
              if (!Array.isArray(entities)) return
              for (const e of entities) {
                const roles: string[] = e.roles ?? []
                const fn: string = e.vcardArray?.[1]?.find((v: any) => v[0] === 'fn')?.[3] ?? ''
                if (roles.includes('registrant') && fn && !arinOrgName) arinOrgName = fn
                if (roles.includes('abuse')) {
                  const vcard = e.vcardArray?.[1] ?? []
                  abuseEmail = abuseEmail || vcard.find((v: any) => v[0] === 'email')?.[3] || null
                  const tel = vcard.find((v: any) => v[0] === 'tel')
                  abusePhone = abusePhone || (typeof tel?.[3] === 'string' ? tel[3] : tel?.[3]?.uri?.replace('tel:', '')) || null
                }
                if (e.entities) walkEntities(e.entities)
              }
            }
            walkEntities(arin?.entities ?? [])

            data = {
              type: 'ip',
              ip: ipapi?.ip || query,
              // Location
              country_name: ipapi?.country_name ?? arinCountry,
              country_code: ipapi?.country_code,
              region: ipapi?.region,
              city: ipapi?.city,
              latitude: ipapi?.latitude,
              longitude: ipapi?.longitude,
              timezone: ipapi?.timezone,
              hostname: ipapi?.hostname,
              // ISP / Org — two sources so NOC can see both consumer brand + technical name
              isp_consumer: ipapi?.org,         // e.g. "AS15133 Consolidated Communications"
              org_arin: arinOrgName,             // e.g. "CCIG" or "Fidium"
              // Network
              asn: ipapi?.asn || (arin?.arin_originas0_originautnums?.[0] ? `AS${arin.arin_originas0_originautnums[0]}` : null),
              network_name: arinNetName,
              network_handle: arinHandle,
              cidr: arinCidr,
              start_ip: arinStartIp,
              end_ip: arinEndIp,
              // Abuse
              abuse_email: abuseEmail,
              abuse_phone: abusePhone,
            }
          } else {
            // Domain RDAP
            const rdapR = await fetch(`https://rdap.org/domain/${query}`)
            if (!rdapR.ok) throw new Error(`Domain not found or RDAP unavailable (${rdapR.status})`)
            const rdap = await rdapR.json()
            const getEntity = (roles: string[]) => rdap.entities?.find((e: any) => e.roles?.some((r: string) => roles.includes(r)))
            const getName = (e: any): string | null => e?.vcardArray?.[1]?.find((v: any) => v[0] === 'fn')?.[3] ?? null
            const getEvent = (type: string) => rdap.events?.find((e: any) => e.eventAction === type)?.eventDate
            const getEmail = (e: any): string | null => e?.vcardArray?.[1]?.find((v: any) => v[0] === 'email')?.[3] ?? null
            const registrar  = getEntity(['registrar'])
            const registrant = getEntity(['registrant'])
            const admin      = getEntity(['administrative'])
            const tech       = getEntity(['technical'])
            const abuse      = getEntity(['abuse'])
            data = {
              type: 'domain',
              ldhName: rdap.ldhName,
              handle: rdap.handle,
              status: Array.isArray(rdap.status) ? rdap.status.join(', ') : rdap.status,
              registrar: getName(registrar) || registrar?.handle,
              registered: getEvent('registration'),
              expires: getEvent('expiration'),
              updated: getEvent('last changed'),
              nameservers: rdap.nameservers?.map((ns: any) => ns.ldhName).join(', '),
              registrant: getName(registrant),
              registrant_email: getEmail(registrant),
              admin: getName(admin),
              tech: getName(tech),
              abuse_email: getEmail(abuse),
            }
          }
          res.writeHead(200, { 'Content-Type': 'application/json', 'Cache-Control': 'no-cache' })
          res.end(JSON.stringify(data))
        } catch (err) {
          res.writeHead(500, { 'Content-Type': 'application/json' })
          res.end(JSON.stringify({ error: err instanceof Error ? err.message : 'Lookup failed' }))
        }
      })
    },
  }
}

// ---------------------------------------------------------------------------
// Activity tracking proxy
// POST /api/activity  { userId, userName, event: 'login'|'heartbeat'|'logout', tool? }
// Writes to Supabase user_sessions table. Google Sheets sync added when SA key available.
// ---------------------------------------------------------------------------
function activityPlugin(): Plugin {
  let env: Record<string, string> = {}
  return {
    name: 'activity-proxy',
    configureServer(server) {
      env = loadEnv('development', process.cwd(), '')
      // Single handler for ALL /api/activity/* routes — avoids middleware ordering bugs
      server.middlewares.use('/api/activity', async (req, res) => {
        res.setHeader('Content-Type', 'application/json')
        if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return }

        const reqUrl = req.url || '/'
        const supabaseUrl  = env.SUPABASE_URL
        const supabaseKey  = env.SUPABASE_SERVICE_ROLE_KEY

        const sbFetch = (path: string, method = 'GET', body?: unknown) =>
          fetch(`${supabaseUrl}/rest/v1${path}`, {
            method,
            headers: {
              apikey: supabaseKey,
              Authorization: `Bearer ${supabaseKey}`,
              'Content-Type': 'application/json',
              ...(method === 'POST' ? { Prefer: 'resolution=merge-duplicates' } : {}),
            },
            body: body ? JSON.stringify(body) : undefined,
          })

        // ── GET /api/activity/sessions ────────────────────────────────────
        if (req.method === 'GET' && reqUrl.includes('sessions')) {
          if (!supabaseUrl || !supabaseKey) { res.writeHead(200); res.end('[]'); return }
          try {
            const r = await sbFetch('/user_sessions?order=last_seen_at.desc')
            const data = await r.json()
            res.writeHead(200); res.end(JSON.stringify(Array.isArray(data) ? data : []))
          } catch { res.writeHead(200); res.end('[]') }
          return
        }

        // ── POST /api/activity  (login / heartbeat / logout / inactive) ───
        if (req.method !== 'POST') { res.writeHead(405); res.end('{}'); return }
        try {
          const chunks: Buffer[] = []
          for await (const c of req) chunks.push(c as Buffer)
          const body = JSON.parse(Buffer.concat(chunks).toString())
          const { userId, userName, userEmail, event, tool } = body
          if (!userId || !event) { res.writeHead(400); res.end(JSON.stringify({ error: 'userId + event required' })); return }

          if (supabaseUrl && supabaseKey) {
            const now = new Date().toISOString()
            if (event === 'login') {
              await sbFetch('/user_sessions', 'POST', {
                user_id: userId, user_name: userName, user_email: userEmail,
                status: 'active', last_seen_at: now, logged_in_at: now, logged_out_at: null,
                last_tool: tool || null,
              })
            } else if (event === 'heartbeat') {
              await sbFetch(`/user_sessions?user_id=eq.${encodeURIComponent(userId)}`, 'PATCH', {
                status: 'active', last_seen_at: now, ...(tool ? { last_tool: tool } : {}),
              })
            } else if (event === 'inactive') {
              await sbFetch(`/user_sessions?user_id=eq.${encodeURIComponent(userId)}`, 'PATCH', {
                status: 'inactive', last_seen_at: now,
              })
            } else if (event === 'logout') {
              await sbFetch(`/user_sessions?user_id=eq.${encodeURIComponent(userId)}`, 'PATCH', {
                status: 'offline', logged_out_at: now, last_seen_at: now,
              })
            }
          }
          res.writeHead(200); res.end(JSON.stringify({ ok: true }))
        } catch (err) {
          res.writeHead(500); res.end(JSON.stringify({ error: 'activity log failed' }))
        }
      })
    },
  }
}

export default defineConfig({
  optimizeDeps: { exclude: ['@electric-sql/pglite'] },
  plugins: [appbuilderApiDevServer(), react(), aiProxyPlugin(), aiCompletionPlugin(), confluenceRestPlugin(), aiRerankerPlugin(), rosterProxyPlugin(), nocToolsPlugin(), activityPlugin()],
  resolve: {
    alias: {
      '@': resolve(__dirname, './src'),
    },
  },
  server: {
    host: '0.0.0.0',
    port: 5173,
    allowedHosts: true,
  },
})
