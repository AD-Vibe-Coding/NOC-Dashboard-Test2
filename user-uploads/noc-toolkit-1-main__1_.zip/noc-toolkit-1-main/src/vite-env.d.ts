/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_AI_AGENT_ID?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
