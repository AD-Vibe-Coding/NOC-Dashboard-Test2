import { Check, X } from 'lucide-react';
import { checkPasswordStrength } from '../../lib/auth/passwordStrength';

interface Props {
  password: string;
}

export function PasswordStrengthMeter({ password }: Props) {
  if (!password) return null;
  const { score, checks, label, color, textColor, barWidth, isDefault } = checkPasswordStrength(password);

  return (
    <div className="mt-2 space-y-2">
      {/* Strength bar */}
      <div className="flex items-center gap-2">
        <div className="flex-1 h-1.5 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-300 ${color}`}
            style={{ width: barWidth }}
          />
        </div>
        <span className={`text-[11px] font-semibold whitespace-nowrap ${textColor}`}>{label}</span>
      </div>

      {/* Criteria checklist */}
      <div className="grid grid-cols-1 gap-0.5">
        {checks.map((c) => (
          <div key={c.label} className="flex items-center gap-1.5">
            {c.pass
              ? <Check className="w-3 h-3 text-emerald-500 flex-shrink-0" />
              : <X className="w-3 h-3 text-slate-400 dark:text-slate-500 flex-shrink-0" />
            }
            <span className={`text-[11px] ${c.pass ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-500 dark:text-slate-400'}`}>
              {c.label}
            </span>
          </div>
        ))}
        {isDefault && (
          <div className="flex items-center gap-1.5 mt-0.5">
            <X className="w-3 h-3 text-red-500 flex-shrink-0" />
            <span className="text-[11px] text-red-600 dark:text-red-400 font-medium">
              Cannot use a default or common password
            </span>
          </div>
        )}
      </div>
    </div>
  );
}
