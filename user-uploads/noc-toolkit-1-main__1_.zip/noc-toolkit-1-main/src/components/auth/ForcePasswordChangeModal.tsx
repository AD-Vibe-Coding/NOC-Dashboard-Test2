import { useState } from 'react';
import { Shield, Eye, EyeOff, X, AlertTriangle, Check, LogIn } from 'lucide-react';
import toast from 'react-hot-toast';
import { useAuth } from '../../hooks/useAuth';
import { PasswordStrengthMeter } from './PasswordStrengthMeter';
import { checkPasswordStrength } from '../../lib/auth/passwordStrength';

export function ForcePasswordChangeModal() {
  const { updatePassword, dismissPasswordWarning, user } = useAuth();
  const [current, setCurrent] = useState('');
  const [newPw, setNewPw] = useState('');
  const [confirm, setConfirm] = useState('');
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [loading, setLoading] = useState(false);

  const strength = checkPasswordStrength(newPw);

  const [done, setDone] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!strength.isAcceptable) {
      toast.error(strength.isDefault ? 'Cannot use a default password' : 'Password does not meet strength requirements');
      return;
    }
    if (newPw !== confirm) { toast.error('Passwords do not match'); return; }
    setLoading(true);
    const err = await updatePassword(current, newPw);
    setLoading(false);
    if (err) { toast.error(err); return; }
    // Password changed — user stays logged in, modal will close automatically
    // because mustChangePassword is now false in AuthContext state
    setDone(true);
    toast.success('✅ Password changed successfully!', { duration: 3000 });
  };

  const canSubmit = !loading && !!current && !!newPw && !!confirm && newPw === confirm && strength.isAcceptable;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="w-full max-w-md bg-white dark:bg-slate-800 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-700 overflow-hidden">
        {/* Header */}
        <div className="bg-amber-50 dark:bg-amber-500/10 border-b border-amber-200 dark:border-amber-500/20 px-6 py-4">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-amber-100 dark:bg-amber-500/20 rounded-lg flex items-center justify-center flex-shrink-0">
                <AlertTriangle className="w-5 h-5 text-amber-600 dark:text-amber-400" />
              </div>
              <div>
                <h2 className="text-base font-semibold text-slate-900 dark:text-white">Secure Your Account</h2>
                <p className="text-xs text-amber-700 dark:text-amber-300 mt-0.5">
                  You're using the default password — please set a personal one. You'll stay logged in after changing.
                </p>
              </div>
            </div>
            <button
              onClick={dismissPasswordWarning}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors flex-shrink-0 mt-0.5"
              title="Remind me next login"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="px-6 py-5 space-y-4">
          <div className="flex items-start gap-2 p-3 rounded-lg bg-blue-50 dark:bg-blue-500/10 border border-blue-200 dark:border-blue-500/20">
            <Shield className="w-4 h-4 text-blue-500 mt-0.5 flex-shrink-0" />
            <p className="text-xs text-blue-700 dark:text-blue-300 leading-relaxed">
              Hi <strong>{user?.firstName}</strong> — your account uses the shared default password{' '}
              <code className="bg-blue-100 dark:bg-blue-500/20 px-1 rounded font-mono">1234567</code>.
              Change it now to secure your account. You'll stay logged in.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-3">
            {/* Current password */}
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Current Password</label>
              <div className="relative">
                <input
                  type={showCurrent ? 'text' : 'password'}
                  value={current}
                  onChange={e => setCurrent(e.target.value)}
                  placeholder="Enter 1234567"
                  className="input-base pr-10 w-full"
                  autoComplete="current-password"
                />
                <button type="button" onClick={() => setShowCurrent(v => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300">
                  {showCurrent ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* New password + strength */}
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">New Password</label>
              <div className="relative">
                <input
                  type={showNew ? 'text' : 'password'}
                  value={newPw}
                  onChange={e => setNewPw(e.target.value)}
                  placeholder="Min. 8 chars, uppercase, number, symbol"
                  className="input-base pr-10 w-full"
                  autoComplete="new-password"
                />
                <button type="button" onClick={() => setShowNew(v => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300">
                  {showNew ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              <PasswordStrengthMeter password={newPw} />
            </div>

            {/* Confirm */}
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Confirm New Password</label>
              <div className="relative">
                <input
                  type={showNew ? 'text' : 'password'}
                  value={confirm}
                  onChange={e => setConfirm(e.target.value)}
                  placeholder="Re-enter new password"
                  className={`input-base w-full ${confirm && newPw !== confirm ? 'border-red-400 dark:border-red-500' : ''}`}
                  autoComplete="new-password"
                />
                {confirm && (
                  <span className="absolute right-3 top-1/2 -translate-y-1/2">
                    {newPw === confirm
                      ? <Check className="w-4 h-4 text-emerald-500" />
                      : <X className="w-4 h-4 text-red-500" />}
                  </span>
                )}
              </div>
              {confirm && newPw !== confirm && (
                <p className="text-[11px] text-red-500 mt-1">Passwords do not match</p>
              )}
            </div>

            <button type="submit" disabled={!canSubmit || done} className="btn-primary w-full justify-center mt-1">
              {loading
                ? <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                : done
                  ? <Check className="w-4 h-4" />
                  : <Shield className="w-4 h-4" />}
              {done ? 'Password Changed ✓' : 'Change Password'}
            </button>
          </form>

          <p className="text-[10px] text-slate-400 dark:text-slate-500 text-center">
            Click <strong>✕</strong> to skip for now — reminder appears on next login.
          </p>
        </div>
      </div>
    </div>
  );
}
