import type { Role } from '../../types/auth';
import { ROLE_LABELS } from '../../types/auth';
import { useAuth } from '../../hooks/useAuth';

const COLORS: Record<Role, string> = {
  super_admin: 'bg-violet-100 text-violet-700 dark:bg-violet-500/20 dark:text-violet-300',
  admin: 'bg-blue-100 text-blue-700 dark:bg-blue-500/20 dark:text-blue-300',
  user: 'bg-slate-100 text-slate-600 dark:bg-slate-600/30 dark:text-slate-300',
};

/** Renders NOTHING if the current viewer is not a Super Admin. */
export function RoleBadge({ role }: { role: Role }) {
  const { isSuperAdmin } = useAuth();
  if (!isSuperAdmin) return null;
  return (
    <span className={`inline-flex items-center px-2 py-0.5 text-[11px] font-medium rounded-full ${COLORS[role]}`}>
      {ROLE_LABELS[role]}
    </span>
  );
}
