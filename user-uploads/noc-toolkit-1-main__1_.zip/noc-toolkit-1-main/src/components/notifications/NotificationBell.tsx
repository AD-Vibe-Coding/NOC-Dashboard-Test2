import { useState, useRef, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Bell, X, Check, CheckCheck, ExternalLink,
  Info, AlertTriangle, CheckCircle, AlertCircle,
  Trash2, Megaphone,
} from 'lucide-react';
import { useNotifications } from '../../context/NotificationContext';
import type { Notification } from '../../lib/notifications/db';

function timeAgo(iso: string): string {
  const diff = Math.floor((Date.now() - new Date(iso).getTime()) / 1000);
  if (diff < 60) return 'just now';
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  return `${Math.floor(diff / 86400)}d ago`;
}

function NotifIcon({ type }: { type: Notification['type'] }) {
  if (type === 'success') return <CheckCircle className="w-4 h-4 text-emerald-500 flex-shrink-0 mt-0.5" />;
  if (type === 'warning') return <AlertTriangle className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />;
  if (type === 'error')   return <AlertCircle  className="w-4 h-4 text-red-500 flex-shrink-0 mt-0.5" />;
  if (type === 'system')  return <Megaphone    className="w-4 h-4 text-violet-500 flex-shrink-0 mt-0.5" />;
  return <Info className="w-4 h-4 text-blue-500 flex-shrink-0 mt-0.5" />;
}

const TYPE_BG: Record<Notification['type'], string> = {
  info:    'border-l-blue-400',
  success: 'border-l-emerald-400',
  warning: 'border-l-amber-400',
  error:   'border-l-red-400',
  system:  'border-l-violet-400',
};

export function NotificationBell() {
  const { notifications, unreadCount, markRead, markAllRead, remove } = useNotifications();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [open]);

  return (
    <div className="relative" ref={ref}>
      {/* Bell button */}
      <button
        onClick={() => setOpen(v => !v)}
        className="relative p-2 rounded-lg text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
        aria-label={`Notifications${unreadCount > 0 ? ` (${unreadCount} unread)` : ''}`}
      >
        <Bell className={`w-5 h-5 ${unreadCount > 0 ? 'text-slate-700 dark:text-slate-200' : ''}`} />
        {unreadCount > 0 && (
          <span className="absolute top-0.5 right-0.5 min-w-[18px] h-[18px] px-1 bg-red-500 text-white text-[9px] font-bold rounded-full flex items-center justify-center leading-none">
            {unreadCount > 99 ? '99+' : unreadCount}
          </span>
        )}
      </button>

      {/* Dropdown */}
      {open && (
        <div className="absolute right-0 top-full mt-2 w-80 sm:w-96 bg-white dark:bg-slate-800 rounded-xl shadow-2xl border border-slate-200 dark:border-slate-700 z-50 overflow-hidden">

          {/* Header */}
          <div className="flex items-center justify-between px-4 py-3 border-b border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-700/50">
            <div className="flex items-center gap-2">
              <Bell className="w-4 h-4 text-slate-600 dark:text-slate-300" />
              <span className="text-sm font-semibold text-slate-900 dark:text-white">Notifications</span>
              {unreadCount > 0 && (
                <span className="px-1.5 py-0.5 text-[10px] font-bold bg-red-100 dark:bg-red-500/20 text-red-600 dark:text-red-400 rounded-full">
                  {unreadCount} new
                </span>
              )}
            </div>
            <div className="flex items-center gap-1">
              {unreadCount > 0 && (
                <button
                  onClick={markAllRead}
                  className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium text-primary-600 dark:text-primary-400 hover:bg-primary-50 dark:hover:bg-primary-500/10 rounded-md transition-colors"
                  title="Mark all as read"
                >
                  <CheckCheck className="w-3.5 h-3.5" /> Mark all read
                </button>
              )}
              <button
                onClick={() => setOpen(false)}
                className="p-1 rounded-md text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* List */}
          <div className="max-h-[420px] overflow-y-auto">
            {notifications.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-14 text-slate-400 dark:text-slate-500">
                <Bell className="w-9 h-9 mb-3 opacity-20" />
                <p className="text-sm font-medium">No notifications</p>
                <p className="text-xs mt-1">You're all caught up! 🎉</p>
              </div>
            ) : (
              <div className="divide-y divide-slate-100 dark:divide-slate-700/40">
                {notifications.map(n => (
                  <div
                    key={n.id}
                    className={`group relative flex items-start gap-3 px-4 py-3 border-l-[3px] transition-colors cursor-default ${
                      TYPE_BG[n.type]
                    } ${
                      !n.read
                        ? 'bg-blue-50/60 dark:bg-blue-500/5 hover:bg-blue-50 dark:hover:bg-blue-500/10'
                        : 'bg-white dark:bg-transparent hover:bg-slate-50 dark:hover:bg-slate-700/20'
                    }`}
                    onClick={() => !n.read && markRead(n.id)}
                  >
                    <NotifIcon type={n.type} />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <p className={`text-xs font-semibold leading-snug ${
                          !n.read ? 'text-slate-900 dark:text-white' : 'text-slate-600 dark:text-slate-300'
                        }`}>
                          {n.title}
                        </p>
                        {!n.read && (
                          <span className="w-2 h-2 rounded-full bg-blue-500 flex-shrink-0 mt-1" />
                        )}
                      </div>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 leading-relaxed line-clamp-2">
                        {n.message}
                      </p>
                      <div className="flex items-center justify-between mt-1.5 gap-2">
                        <div className="flex items-center gap-1.5 text-[10px] text-slate-400 dark:text-slate-500">
                          <span>{timeAgo(n.createdAt)}</span>
                          {n.createdByName && (
                            <><span>·</span><span>from {n.createdByName}</span></>
                          )}
                        </div>
                        {/* Action buttons — show on hover */}
                        <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                          {n.link && (
                            <Link
                              to={n.link}
                              onClick={e => { e.stopPropagation(); markRead(n.id); setOpen(false); }}
                              className="p-1 rounded text-slate-400 hover:text-blue-500 dark:hover:text-blue-400 transition-colors"
                              title="Open"
                            >
                              <ExternalLink className="w-3 h-3" />
                            </Link>
                          )}
                          {!n.read && (
                            <button
                              onClick={e => { e.stopPropagation(); markRead(n.id); }}
                              className="p-1 rounded text-slate-400 hover:text-emerald-500 dark:hover:text-emerald-400 transition-colors"
                              title="Mark as read"
                            >
                              <Check className="w-3 h-3" />
                            </button>
                          )}
                          <button
                            onClick={e => { e.stopPropagation(); remove(n.id); }}
                            className="p-1 rounded text-slate-400 hover:text-red-500 dark:hover:text-red-400 transition-colors"
                            title="Delete"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Footer */}
          {notifications.length > 0 && (
            <div className="px-4 py-2.5 border-t border-slate-100 dark:border-slate-700/40 bg-slate-50 dark:bg-slate-700/30 text-center">
              <span className="text-[11px] text-slate-400 dark:text-slate-500">
                {notifications.length} notification{notifications.length !== 1 ? 's' : ''} · hover to manage
              </span>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
