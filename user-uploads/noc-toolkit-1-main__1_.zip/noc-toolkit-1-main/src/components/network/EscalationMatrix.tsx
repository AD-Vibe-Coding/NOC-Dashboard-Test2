import { useMemo, useState } from 'react';
import {
  Search, Phone, Mail, ChevronDown, ChevronRight, Sparkles, Clock, AlertCircle, Shield, Crown,
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import {
  NETWORK_ESCALATIONS,
  TIER_META,
  type EscalationTier,
  type NetworkCarrierEscalation,
} from '../../data/networkEscalations';

const TIER_ORDER: EscalationTier[] = ['L1', 'L2', 'L3', 'L4', 'L5'];

const TIER_COLORS: Record<EscalationTier, { dot: string; bg: string; text: string; ring: string }> = {
  L1: { dot: 'bg-emerald-500',  bg: 'bg-emerald-50 dark:bg-emerald-500/10',  text: 'text-emerald-700 dark:text-emerald-300',  ring: 'ring-emerald-200 dark:ring-emerald-500/30' },
  L2: { dot: 'bg-amber-500',    bg: 'bg-amber-50   dark:bg-amber-500/10',    text: 'text-amber-700 dark:text-amber-300',      ring: 'ring-amber-200 dark:ring-amber-500/30' },
  L3: { dot: 'bg-orange-500',   bg: 'bg-orange-50  dark:bg-orange-500/10',   text: 'text-orange-700 dark:text-orange-300',    ring: 'ring-orange-200 dark:ring-orange-500/30' },
  L4: { dot: 'bg-red-500',      bg: 'bg-red-50     dark:bg-red-500/10',      text: 'text-red-700 dark:text-red-300',          ring: 'ring-red-200 dark:ring-red-500/40' },
  L5: { dot: 'bg-rose-700',     bg: 'bg-rose-50    dark:bg-rose-700/10',     text: 'text-rose-700 dark:text-rose-300',        ring: 'ring-rose-200 dark:ring-rose-700/40' },
};

interface Props {
  filter?: string;
}

export function EscalationMatrix({ filter: externalFilter }: Props) {
  const [internalFilter, setInternalFilter] = useState('');
  const filter = externalFilter ?? internalFilter;

  const visible = useMemo(() => {
    const q = filter.trim().toLowerCase();
    if (!q) return NETWORK_ESCALATIONS;
    return NETWORK_ESCALATIONS.filter((c) =>
      c.name.toLowerCase().includes(q) ||
      c.key.toLowerCase().includes(q) ||
      (c.services ?? []).some((s) => s.toLowerCase().includes(q)),
    );
  }, [filter]);

  return (
    <div className="space-y-4">
      {externalFilter === undefined && (
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={internalFilter}
            onChange={(e) => setInternalFilter(e.target.value)}
            placeholder="Filter carriers by name or service…"
            className="w-full pl-9 pr-3 py-2 text-sm rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-primary-500"
          />
        </div>
      )}

      {/* Tier legend */}
      <div className="flex flex-wrap items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400">
        <span className="font-semibold text-slate-700 dark:text-slate-200">Escalation tiers:</span>
        {TIER_ORDER.map((t) => (
          <span key={t} className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full ${TIER_COLORS[t].bg} ${TIER_COLORS[t].text}`}>
            <span className={`w-1.5 h-1.5 rounded-full ${TIER_COLORS[t].dot}`} />
            {TIER_META[t].label.split('—')[0].trim()}
          </span>
        ))}
        <span className="ml-auto text-slate-400">{visible.length} {visible.length === 1 ? 'carrier' : 'carriers'}</span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {visible.map((c) => <CarrierEscalationCard key={c.key} carrier={c} />)}
      </div>

      {visible.length === 0 && (
        <div className="card text-center py-8 text-sm text-slate-500">
          No carriers match "{filter}".
        </div>
      )}
    </div>
  );
}

function CarrierEscalationCard({ carrier }: { carrier: NetworkCarrierEscalation }) {
  const navigate = useNavigate();
  const [openTier, setOpenTier] = useState<EscalationTier | null>('L1');
  const hasL4Plus = !!(carrier.tiers.L4 || carrier.tiers.L5);

  const askAI = () => {
    const prompt = `What's the L1 → L5 escalation matrix for ${carrier.name}? When should I escalate to each tier, and who do I contact at each level? Cite the Confluence escalation page if available.`;
    navigate(`/ai-assistant?prompt=${encodeURIComponent(prompt)}`);
  };

  return (
    <div className={`card !p-0 overflow-hidden border-2 transition-all ${
      hasL4Plus ? 'border-red-200 dark:border-red-500/30' : 'border-slate-200 dark:border-slate-700'
    }`}>
      <div className={`px-3 py-2 border-b border-slate-200 dark:border-slate-700 bg-${carrier.logoColor}-50 dark:bg-${carrier.logoColor}-500/10`}>
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white truncate">{carrier.name}</h3>
            {carrier.services && carrier.services.length > 0 && (
              <p className="text-[10px] text-slate-500 dark:text-slate-400 truncate">
                {carrier.services.join(' · ')}
              </p>
            )}
          </div>
          <button
            onClick={askAI}
            className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md text-[10px] font-medium bg-violet-100 dark:bg-violet-500/20 hover:bg-violet-200 dark:hover:bg-violet-500/30 text-violet-700 dark:text-violet-300 flex-shrink-0"
            title="Ask AI about this carrier's escalation flow"
          >
            <Sparkles className="w-3 h-3" /> AI
          </button>
        </div>
      </div>

      <div className="divide-y divide-slate-100 dark:divide-slate-700/50">
        {TIER_ORDER.map((tier) => {
          const contact = carrier.tiers[tier];
          const color = TIER_COLORS[tier];
          const isOpen = openTier === tier;
          const isMissing = !contact || (!contact.phones.length && !contact.emails.length);
          return (
            <div key={tier} className={isMissing ? 'opacity-50' : ''}>
              <button
                onClick={() => setOpenTier(isOpen ? null : tier)}
                className="w-full flex items-center gap-2 px-3 py-2 text-left hover:bg-slate-50 dark:hover:bg-slate-700/30 transition-colors"
              >
                <span className={`w-2 h-2 rounded-full ${color.dot} flex-shrink-0`} />
                <span className={`text-[10px] font-bold uppercase tracking-wider ${color.text} font-mono w-6 flex-shrink-0`}>{tier}</span>
                <span className="text-xs text-slate-700 dark:text-slate-300 flex-1 truncate">
                  {contact?.title ?? TIER_META[tier].subtitle}
                </span>
                {tier === 'L5' && <Crown className="w-3 h-3 text-rose-500 flex-shrink-0" />}
                {tier === 'L4' && <Shield className="w-3 h-3 text-red-500 flex-shrink-0" />}
                {isMissing && <span className="text-[9px] text-slate-400 mr-1">— not set —</span>}
                {isOpen ? <ChevronDown className="w-3 h-3 text-slate-400 flex-shrink-0" /> : <ChevronRight className="w-3 h-3 text-slate-400 flex-shrink-0" />}
              </button>
              {isOpen && contact && (
                <div className={`px-3 py-2 ${color.bg} text-[11px] space-y-1.5`}>
                  {contact.name && (
                    <div className="font-semibold text-slate-900 dark:text-white">{contact.name}</div>
                  )}
                  {contact.phones.map((p) => (
                    <a key={p} href={`tel:${p.replace(/[^0-9+]/g, '')}`} className="flex items-center gap-1.5 font-mono hover:underline text-slate-700 dark:text-slate-200">
                      <Phone className="w-3 h-3" /> {p}
                    </a>
                  ))}
                  {contact.emails.map((e) => (
                    <a key={e} href={`mailto:${e}`} className="flex items-center gap-1.5 hover:underline text-slate-700 dark:text-slate-200 break-all">
                      <Mail className="w-3 h-3" /> {e}
                    </a>
                  ))}
                  {contact.hours && (
                    <div className="flex items-center gap-1.5 text-slate-500 dark:text-slate-400">
                      <Clock className="w-3 h-3" /> {contact.hours}
                    </div>
                  )}
                  {contact.whenToEscalate && (
                    <div className="flex items-start gap-1.5 text-slate-600 dark:text-slate-300">
                      <AlertCircle className="w-3 h-3 mt-0.5 flex-shrink-0" />
                      <span><strong>When to escalate:</strong> {contact.whenToEscalate}</span>
                    </div>
                  )}
                  {contact.notes && (
                    <div className="text-slate-500 dark:text-slate-400 italic">{contact.notes}</div>
                  )}
                  {contact.source === 'hardcoded' && (
                    <div className="text-[9px] text-slate-400 dark:text-slate-500">Built-in baseline · auto-enriched from Confluence</div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
