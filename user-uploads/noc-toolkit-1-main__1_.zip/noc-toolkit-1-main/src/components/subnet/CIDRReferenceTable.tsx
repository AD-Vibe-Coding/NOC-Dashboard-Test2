import { Table } from 'lucide-react';
import { cidrReferenceTable } from '../../utils/subnetCalculator';

export function CIDRReferenceTable() {
  return (
    <div className="card">
      <div className="flex items-center gap-3 mb-5">
        <div className="w-8 h-8 bg-purple-100 dark:bg-purple-500/10 rounded-lg flex items-center justify-center">
          <Table className="w-4 h-4 text-purple-600 dark:text-purple-400" />
        </div>
        <h2 className="text-lg font-semibold text-slate-900 dark:text-white">Quick Reference Table</h2>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-slate-200 dark:border-slate-700">
              <th className="text-left py-2.5 pr-4 font-semibold text-slate-600 dark:text-slate-400">CIDR</th>
              <th className="text-left py-2.5 pr-4 font-semibold text-slate-600 dark:text-slate-400">Subnet Mask</th>
              <th className="text-right py-2.5 pr-4 font-semibold text-slate-600 dark:text-slate-400">Total</th>
              <th className="text-right py-2.5 pr-4 font-semibold text-slate-600 dark:text-slate-400">Usable</th>
              <th className="text-left py-2.5 font-semibold text-slate-600 dark:text-slate-400">Common Use</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
            {cidrReferenceTable.map((row) => (
              <tr key={row.cidr} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                <td className="py-2.5 pr-4 font-mono font-medium text-primary-600 dark:text-primary-400">
                  /{row.cidr}
                </td>
                <td className="py-2.5 pr-4 font-mono text-slate-700 dark:text-slate-300">{row.subnetMask}</td>
                <td className="py-2.5 pr-4 text-right text-slate-700 dark:text-slate-300">
                  {typeof row.total === 'number' ? row.total.toLocaleString() : row.total}
                </td>
                <td className="py-2.5 pr-4 text-right font-medium text-slate-900 dark:text-slate-100">
                  {typeof row.usable === 'number' ? row.usable.toLocaleString() : row.usable}
                </td>
                <td className="py-2.5 text-slate-600 dark:text-slate-400">{row.commonUse}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <p className="mt-4 text-xs text-slate-500 dark:text-slate-400 italic">
        * /31 uses RFC 3021 — no network/broadcast, both IPs usable for point-to-point links.
      </p>
    </div>
  );
}
