import type { SubnetResult } from '../../types';
import { Map } from 'lucide-react';

interface IPVisualMapProps {
  result: SubnetResult;
}

const roleConfig = {
  network: {
    bg: 'bg-red-50 dark:bg-red-500/10',
    border: 'border-red-200 dark:border-red-500/30',
    dot: 'bg-red-500',
    text: 'text-red-700 dark:text-red-400',
    icon: '🔴',
  },
  gateway: {
    bg: 'bg-amber-50 dark:bg-amber-500/10',
    border: 'border-amber-200 dark:border-amber-500/30',
    dot: 'bg-amber-500',
    text: 'text-amber-700 dark:text-amber-400',
    icon: '🟡',
  },
  usable: {
    bg: 'bg-emerald-50 dark:bg-emerald-500/10',
    border: 'border-emerald-200 dark:border-emerald-500/30',
    dot: 'bg-emerald-500',
    text: 'text-emerald-700 dark:text-emerald-400',
    icon: '🟢',
  },
  broadcast: {
    bg: 'bg-red-50 dark:bg-red-500/10',
    border: 'border-red-200 dark:border-red-500/30',
    dot: 'bg-red-500',
    text: 'text-red-700 dark:text-red-400',
    icon: '🔴',
  },
};

export function IPVisualMap({ result }: IPVisualMapProps) {
  const displayIPs = result.allIPs;
  const isLarge = result.totalIPs > 256;

  return (
    <div className="card">
      <div className="flex items-center gap-3 mb-5">
        <div className="w-8 h-8 bg-emerald-100 dark:bg-emerald-500/10 rounded-lg flex items-center justify-center">
          <Map className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
        </div>
        <div>
          <h2 className="text-lg font-semibold text-slate-900 dark:text-white">Visual IP Map</h2>
          {isLarge && (
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Showing first 256 of {result.totalIPs.toLocaleString()} IPs
            </p>
          )}
        </div>
      </div>

      {/* Legend */}
      <div className="flex flex-wrap gap-4 mb-4 pb-4 border-b border-slate-200 dark:border-slate-700">
        <div className="flex items-center gap-1.5 text-xs">
          <span className="w-2.5 h-2.5 rounded-full bg-red-500" />
          <span className="text-slate-600 dark:text-slate-400">Reserved (Network/Broadcast)</span>
        </div>
        <div className="flex items-center gap-1.5 text-xs">
          <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
          <span className="text-slate-600 dark:text-slate-400">Gateway</span>
        </div>
        <div className="flex items-center gap-1.5 text-xs">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
          <span className="text-slate-600 dark:text-slate-400">Usable (Assignable)</span>
        </div>
      </div>

      {/* IP List */}
      <div className="space-y-1.5 max-h-[400px] overflow-y-auto pr-1">
        {displayIPs.map((entry) => {
          const config = roleConfig[entry.role];
          return (
            <div
              key={entry.ip}
              className={`flex items-center gap-3 px-3 py-2 rounded-lg border ${config.bg} ${config.border}`}
            >
              <span className="text-sm">{config.icon}</span>
              <span className="font-mono text-sm font-medium text-slate-900 dark:text-slate-100 min-w-[130px]">
                {entry.ip}
              </span>
              <span className="text-xs text-slate-400 dark:text-slate-500">→</span>
              <span className={`text-sm ${config.text}`}>{entry.label}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
