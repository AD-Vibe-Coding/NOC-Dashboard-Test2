import { useState } from 'react';
import { Calculator, Globe } from 'lucide-react';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { parseSubnetInput, parseSubnetWithMask, calculateSubnet } from '../../utils/subnetCalculator';
import type { SubnetResult } from '../../types';

interface SubnetCalculatorProps {
  onResult: (result: SubnetResult) => void;
}

export function SubnetCalculator({ onResult }: SubnetCalculatorProps) {
  const [input, setInput] = useState('');
  const [subnetMask, setSubnetMask] = useState('');
  const [mode, setMode] = useState<'cidr' | 'mask'>('cidr');
  const [error, setError] = useState('');
  const [result, setResult] = useState<SubnetResult | null>(null);

  const handleCalculate = () => {
    setError('');
    let parsed;

    if (mode === 'cidr') {
      parsed = parseSubnetInput(input.trim());
      if (!parsed) {
        setError('Invalid input. Use formats like: /29, 192.168.1.0/29');
        return;
      }
    } else {
      parsed = parseSubnetWithMask(input.trim(), subnetMask.trim());
      if (!parsed) {
        setError('Invalid IP address or subnet mask.');
        return;
      }
    }

    const calcResult = calculateSubnet(parsed.ip, parsed.cidr);
    setResult(calcResult);
    onResult(calcResult);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') handleCalculate();
  };

  return (
    <div className="card">
      <div className="flex items-center gap-3 mb-5">
        <div className="w-8 h-8 bg-primary-100 dark:bg-primary-500/10 rounded-lg flex items-center justify-center">
          <Calculator className="w-4 h-4 text-primary-600 dark:text-primary-400" />
        </div>
        <h2 className="text-lg font-semibold text-slate-900 dark:text-white">CIDR Calculator</h2>
      </div>

      {/* Mode Toggle */}
      <div className="flex gap-2 mb-4">
        <button
          onClick={() => setMode('cidr')}
          className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
            mode === 'cidr'
              ? 'bg-primary-500 text-white'
              : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600'
          }`}
        >
          CIDR Notation
        </button>
        <button
          onClick={() => setMode('mask')}
          className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
            mode === 'mask'
              ? 'bg-primary-500 text-white'
              : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600'
          }`}
        >
          IP + Subnet Mask
        </button>
      </div>

      {/* Input Fields */}
      <div className="space-y-3 mb-4">
        {mode === 'cidr' ? (
          <Input
            label="CIDR Notation"
            placeholder="e.g., /29 or 192.168.1.0/29"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            error={error}
            helperText="Enter a CIDR prefix (/29) or full notation (192.168.1.0/29)"
          />
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <Input
              label="IP Address"
              placeholder="e.g., 192.168.1.0"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
            />
            <Input
              label="Subnet Mask"
              placeholder="e.g., 255.255.255.248"
              value={subnetMask}
              onChange={(e) => setSubnetMask(e.target.value)}
              onKeyDown={handleKeyDown}
              error={error}
            />
          </div>
        )}
      </div>

      <Button onClick={handleCalculate}>
        <Globe className="w-4 h-4" />
        Calculate
      </Button>

      {/* Results Table */}
      {result && (
        <div className="mt-6 animate-fade-in">
          <h3 className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-3">Results</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                <ResultRow label="Network Address" value={result.networkAddress} badge="🔒 Reserved" />
                <ResultRow label="Subnet Mask" value={result.subnetMask} />
                <ResultRow label="Wildcard Mask" value={result.wildcardMask} />
                <ResultRow label="Gateway (First IP)" value={result.gateway} badge={result.cidr <= 30 ? "🔒 Router" : undefined} />
                <ResultRow label="Usable IP Range" value={`${result.usableRange.start} — ${result.usableRange.end}`} />
                <ResultRow label="Broadcast Address" value={result.broadcastAddress} badge="🔒 Reserved" />
                <ResultRow label="Total IPs" value={result.totalIPs.toLocaleString()} />
                <ResultRow label="Usable IPs" value={result.usableIPs.toLocaleString()} highlight />
                <ResultRow label="CIDR Notation" value={`/${result.cidr}`} />
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

function ResultRow({ label, value, badge, highlight }: { label: string; value: string; badge?: string; highlight?: boolean }) {
  return (
    <tr>
      <td className="py-2.5 pr-4 text-slate-500 dark:text-slate-400 font-medium whitespace-nowrap">{label}</td>
      <td className={`py-2.5 font-mono ${highlight ? 'text-primary-600 dark:text-primary-400 font-bold' : 'text-slate-900 dark:text-slate-100'}`}>
        {value}
        {badge && <span className="ml-2 text-xs text-slate-400 dark:text-slate-500">{badge}</span>}
      </td>
    </tr>
  );
}
