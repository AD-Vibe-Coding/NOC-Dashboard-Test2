import { CompanyBadge, DevsAiBadge } from '../ui/Brand';

export function Footer() {
  return (
    <footer className="border-t border-slate-200 dark:border-slate-700/50 py-4 px-6">
      <div className="flex flex-col sm:flex-row items-center justify-center gap-2 sm:gap-3">
        <p className="text-[10px] leading-none tracking-wide text-slate-400/80 dark:text-slate-500/80 select-none">
          © <span className="font-medium">Sriram Parisa</span> · NOC Toolkit · {new Date().getFullYear()}
        </p>
        <span className="hidden sm:inline text-slate-300 dark:text-slate-700">·</span>
        <CompanyBadge size="xs" />
        <span className="hidden sm:inline text-slate-300 dark:text-slate-700">·</span>
        <DevsAiBadge size="xs" />
      </div>
    </footer>
  );
}
