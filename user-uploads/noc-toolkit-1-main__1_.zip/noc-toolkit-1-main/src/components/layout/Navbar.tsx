import { Menu, X, Shield, ExternalLink } from 'lucide-react';
import { ThemeToggle } from '../ui/ThemeToggle';
import { CompanyBadge } from '../ui/Brand';
import { LiveClock } from '../ui/LiveClock';
import { UserMenu } from './UserMenu';
import { NotificationBell } from '../notifications/NotificationBell';

const NOC_DASHBOARD_URL = 'https://sb-48rvj5c9ycdl.vercel.run/';

interface NavbarProps {
  sidebarOpen: boolean;
  onToggleSidebar: () => void;
}

export function Navbar({ sidebarOpen, onToggleSidebar }: NavbarProps) {
  return (
    <header className="sticky top-0 z-30 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-700/50">
      <div className="flex items-center justify-between h-16 px-4 lg:px-6">
        {/* Left: logo + brand */}
        <div className="flex items-center gap-3">
          <button
            onClick={onToggleSidebar}
            className="lg:hidden p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 transition-colors"
            aria-label="Toggle sidebar"
          >
            {sidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 bg-primary-500 rounded-lg flex items-center justify-center">
              <Shield className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-slate-900 dark:text-white leading-tight">NOC Toolkit</h1>
              <p className="text-[10px] text-slate-500 dark:text-slate-400 leading-none hidden sm:block">Operations Toolkit</p>
            </div>
          </div>
          <div className="hidden md:flex items-center ml-2 pl-3 border-l border-slate-200 dark:border-slate-700/70">
            <CompanyBadge size="sm" />
          </div>
        </div>

        {/* Right: actions */}
        <div className="flex items-center gap-1.5">
          <a
            href={NOC_DASHBOARD_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-violet-100 hover:bg-violet-200 dark:bg-violet-500/15 dark:hover:bg-violet-500/25 text-violet-700 dark:text-violet-300 transition-colors border border-violet-200 dark:border-violet-500/30"
            title="Open NOC Dashboard by Anirudh"
          >
            <Shield className="w-3.5 h-3.5" />
            <span className="hidden md:inline">NOC Dashboard</span>
            <ExternalLink className="w-3 h-3 opacity-70" />
          </a>
          <LiveClock className="hidden lg:flex px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-xs" />
          <NotificationBell />
          <ThemeToggle />
          <UserMenu />
        </div>
      </div>
    </header>
  );
}
