import { useState } from 'react';
import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  Wrench,
  Globe,
  Phone,
  Smartphone,
  BookOpen,
  Network,
  Users,
  Settings as SettingsIcon,
  BarChart3,
  ShieldCheck,
  ChevronDown,
  ChevronRight,
  FileText,
  type LucideIcon,
} from 'lucide-react';
import { AIBadge } from '../ai/AIBadge';
import { useAuth } from '../../hooks/useAuth';

type NavItem = {
  path: string;
  label: string;
  icon?: LucideIcon;
  ai?: boolean;
};

type NavGroup = {
  label: string;
  icon: LucideIcon;
  children: NavItem[];
};

type NavEntry = NavItem | NavGroup;

function isGroup(entry: NavEntry): entry is NavGroup {
  return 'children' in entry;
}

const navEntries: NavEntry[] = [
  { path: '/', label: 'Dashboard', icon: LayoutDashboard },
  { path: '/maintenance', label: 'Maintenance Notes', icon: Wrench },
  { path: '/noc-tools', label: 'IP / Log Tools', icon: Globe },
  { path: '/carriers', label: 'Carrier Contacts', icon: Phone },
  { path: '/mobility', label: 'Mobility', icon: Smartphone },
  { path: '/network', label: 'Network', icon: Network },
  { path: '/runbooks', label: 'Runbooks', icon: FileText },
  { path: '/ai-assistant', label: 'AI Assistant', ai: true },
  { path: '/documentation', label: 'Documentation', icon: BookOpen },
  { path: '/team', label: 'Team', icon: Users },
  { path: '/settings', label: 'Settings', icon: SettingsIcon },
];

interface SidebarProps {
  open: boolean;
  onClose: () => void;
}

function NavItemLink({ item, onClose }: { item: NavItem; onClose: () => void }) {
  const Icon = item.icon;
  return (
    <NavLink
      to={item.path}
      onClick={onClose}
      className={({ isActive }) =>
        `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-150 ${
          isActive
            ? 'bg-primary-50 dark:bg-primary-500/10 text-primary-600 dark:text-primary-400'
            : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-slate-200'
        }`
      }
      end={item.path === '/'}
    >
      {item.ai ? (
        <span className="flex items-center justify-center flex-shrink-0" style={{ width: 18, height: 18 }}>
          <AIBadge size="xs" />
        </span>
      ) : Icon ? (
        <Icon className="flex-shrink-0" style={{ width: '18px', height: '18px' }} />
      ) : null}
      <span>{item.label}</span>
    </NavLink>
  );
}

function NavGroupSection({ group, onClose }: { group: NavGroup; onClose: () => void }) {
  const [open, setOpen] = useState(true);
  const Icon = group.icon;

  return (
    <div>
      <button
        onClick={() => setOpen((v) => !v)}
        className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-slate-200 transition-all duration-150"
      >
        <Icon className="flex-shrink-0" style={{ width: '18px', height: '18px' }} />
        <span className="flex-1 text-left">{group.label}</span>
        {open ? (
          <ChevronDown className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
        ) : (
          <ChevronRight className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
        )}
      </button>
      {open && (
        <div className="ml-4 space-y-0.5 mt-0.5">
          {group.children.map((child) => (
            <NavItemLink key={child.path} item={child} onClose={onClose} />
          ))}
        </div>
      )}
    </div>
  );
}

export function Sidebar({ open, onClose }: SidebarProps) {
  const { isSuperAdmin, isAdmin } = useAuth();

  const entries: NavEntry[] = [
    ...navEntries,
    ...(isAdmin ? [{ path: '/admin', label: 'Admin Controls', icon: ShieldCheck } as NavItem] : []),
    ...(isSuperAdmin ? [{ path: '/analytics', label: 'Analytics', icon: BarChart3 } as NavItem] : []),
  ];

  return (
    <>
      {/* Mobile overlay */}
      {open && (
        <div
          className="fixed inset-0 z-20 bg-black/50 lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed top-16 left-0 z-20 h-[calc(100vh-4rem)] w-64 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-700/50 transform transition-transform duration-200 lg:translate-x-0 ${
          open ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <nav className="p-3 space-y-1 overflow-y-auto h-full pb-20">
          {entries.map((entry, idx) =>
            isGroup(entry) ? (
              <NavGroupSection key={idx} group={entry} onClose={onClose} />
            ) : (
              <NavItemLink key={entry.path} item={entry} onClose={onClose} />
            ),
          )}
        </nav>
      </aside>
    </>
  );
}
