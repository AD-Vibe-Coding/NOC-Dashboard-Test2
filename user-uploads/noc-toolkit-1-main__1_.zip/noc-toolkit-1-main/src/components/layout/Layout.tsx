import { useState, Suspense } from 'react';
import { Outlet } from 'react-router-dom';
import { Navbar } from './Navbar';
import { Sidebar } from './Sidebar';
import { Footer } from './Footer';
import { useUniversalCopy } from '../../hooks/useUniversalCopy';
import { ForcePasswordChangeModal } from '../auth/ForcePasswordChangeModal';
import { useAuth } from '../../hooks/useAuth';
import { useActivityTracker } from '../../hooks/useActivityTracker';

/** Invisible fallback — eagerly-loaded pages never show this */
function ContentLoader() { return null; }

export function Layout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { mustChangePassword, user } = useAuth();

  useUniversalCopy();
  useActivityTracker(user);

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-900">
      {mustChangePassword && <ForcePasswordChangeModal />}
      <Navbar sidebarOpen={sidebarOpen} onToggleSidebar={() => setSidebarOpen(!sidebarOpen)} />
      <div className="flex flex-1">
        <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        <main className="flex-1 lg:ml-64 flex flex-col min-h-[calc(100vh-4rem)]">
          <div className="flex-1 p-4 lg:p-6 animate-fade-in">
            <Suspense fallback={<ContentLoader />}>
              <Outlet />
            </Suspense>
          </div>
          <Footer />
        </main>
      </div>
    </div>
  );
}
