import { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Settings, Users, LogOut } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { RoleBadge } from '../auth/RoleBadge';

const COLORS = ['bg-primary-500','bg-emerald-500','bg-amber-500','bg-indigo-500','bg-rose-500','bg-cyan-500','bg-violet-500','bg-orange-500'];
function avatarColor(name: string) { let h = 0; for (const c of name) h = (h * 31 + c.charCodeAt(0)) | 0; return COLORS[Math.abs(h) % COLORS.length]; }

export function UserMenu() {
  const { user, logout, isSuperAdmin } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false); };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  if (!user) return null;
  const initials = `${user.firstName[0]}${user.lastName[0]}`.toUpperCase();

  return (
    <div ref={ref} className="relative">
      <button onClick={() => setOpen(!open)} className="flex items-center gap-2 px-2 py-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
        <div className={`w-8 h-8 rounded-full ${avatarColor(user.username)} flex items-center justify-center text-white text-xs font-bold`}>
          {initials}
        </div>
        <span className="hidden sm:block text-sm font-medium text-slate-700 dark:text-slate-200 max-w-[120px] truncate">{user.firstName}</span>
      </button>

      {open && (
        <div className="absolute right-0 mt-1 w-64 bg-white dark:bg-slate-800 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700 py-2 z-50 animate-fade-in">
          <div className="px-4 py-2.5 border-b border-slate-100 dark:border-slate-700/50">
            <p className="text-sm font-semibold text-slate-900 dark:text-white">{user.firstName} {user.lastName}</p>
            <p className="text-xs text-slate-500 dark:text-slate-400 truncate">{user.email}</p>
            {isSuperAdmin && <div className="mt-1.5"><RoleBadge role={user.role} /></div>}
          </div>
          <div className="py-1">
            <button onClick={() => { setOpen(false); navigate('/settings'); }} className="w-full flex items-center gap-3 px-4 py-2 text-sm text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700/50">
              <Settings className="w-4 h-4" /> Settings
            </button>
            <button onClick={() => { setOpen(false); navigate('/team'); }} className="w-full flex items-center gap-3 px-4 py-2 text-sm text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700/50">
              <Users className="w-4 h-4" /> Team
            </button>
          </div>
          <div className="border-t border-slate-100 dark:border-slate-700/50 pt-1">
            <button onClick={() => { setOpen(false); logout(); navigate('/login'); }} className="w-full flex items-center gap-3 px-4 py-2 text-sm text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-500/10">
              <LogOut className="w-4 h-4" /> Sign out
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
