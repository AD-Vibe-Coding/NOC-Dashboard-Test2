import { useState, useEffect, useMemo } from 'react';
import { ChevronRight, ChevronDown, FileText, Folder, Search, RefreshCw, ExternalLink, Loader2, Paperclip, Globe } from 'lucide-react';
import { fetchTree, filterTree, flattenTree, type PageNode } from '../../lib/confluence/restClient';

interface Props {
  rootId: string;
  selectedId: string | null;
  onSelect: (page: PageNode) => void;
  /** Label override — defaults to the loaded root's title. */
  scopeLabel?: string;
}

interface NodeProps {
  node: PageNode;
  depth: number;
  selectedId: string | null;
  onSelect: (page: PageNode) => void;
  filtering: boolean;
}

function TreeNode({ node, depth, selectedId, onSelect, filtering }: NodeProps) {
  // Auto-expand top 2 levels by default; auto-expand when filtering (search active)
  const [open, setOpen] = useState(depth < 2 || filtering);
  useEffect(() => { if (filtering) setOpen(true); }, [filtering]);
  const hasChildren = (node.children?.length ?? 0) > 0;
  const isSelected = selectedId === node.id;
  const Icon = hasChildren ? Folder : FileText;

  return (
    <div>
      <div
        className={`flex items-center gap-1 py-1.5 px-2 rounded-md cursor-pointer text-sm transition-colors ${
          isSelected
            ? 'bg-primary-100 dark:bg-primary-500/20 text-primary-700 dark:text-primary-300 font-medium'
            : 'hover:bg-slate-100 dark:hover:bg-slate-700/50 text-slate-700 dark:text-slate-300'
        }`}
        style={{ paddingLeft: `${depth * 12 + 8}px` }}
        onClick={() => onSelect(node)}
      >
        {hasChildren ? (
          <button
            onClick={(e) => { e.stopPropagation(); setOpen((o) => !o); }}
            className="flex-shrink-0 p-0.5 rounded hover:bg-slate-200 dark:hover:bg-slate-600"
            aria-label={open ? 'Collapse' : 'Expand'}
          >
            {open ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
          </button>
        ) : (
          <span className="w-4 flex-shrink-0" />
        )}
        <Icon className={`w-3.5 h-3.5 flex-shrink-0 ${hasChildren ? 'text-amber-500' : 'text-slate-400'}`} />
        <span className="truncate flex-1">{node.title}</span>
        {node.hasAttachments && (
          <Paperclip className="w-3 h-3 text-slate-400 flex-shrink-0" />
        )}
        {hasChildren && (
          <span className="text-[10px] text-slate-400 dark:text-slate-500 flex-shrink-0">{node.childCount}</span>
        )}
        {/* Open in Confluence — always visible, large click target */}
        {node.url && (
          <a
            href={node.url}
            target="_blank"
            rel="noopener noreferrer"
            onClick={e => e.stopPropagation()}
            title={`Open "${node.title}" in Confluence`}
            className="flex-shrink-0 p-1 rounded hover:bg-primary-100 dark:hover:bg-primary-500/20 text-primary-500 dark:text-primary-400 opacity-60 hover:opacity-100 transition-all"
          >
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        )}
      </div>
      {open && hasChildren && (
        <div>
          {node.children!.map((c) => (
            <TreeNode key={c.id} node={c} depth={depth + 1} selectedId={selectedId} onSelect={onSelect} filtering={filtering} />
          ))}
        </div>
      )}
    </div>
  );
}

export function MobilityTree({ rootId, selectedId, onSelect, scopeLabel }: Props) {
  const [tree, setTree] = useState<PageNode | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filterQ, setFilterQ] = useState('');
  const [fetchedAt, setFetchedAt] = useState<Date | null>(null);
  const [cached, setCached] = useState(false);

  const load = async (force = false) => {
    setLoading(true);
    setError(null);
    const res = await fetchTree(rootId, force);
    if (res.error) setError(res.error);
    else {
      setTree(res.tree);
      setFetchedAt(new Date(res.fetchedAt));
      setCached(res.cached);
    }
    setLoading(false);
  };

  useEffect(() => {
    load();
    // Refresh every 15 seconds (server caches 5 min, so most polls are <50ms)
    const id = setInterval(() => load(), 15 * 1000);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rootId]);

  // Re-render every second so the "Xs ago" label stays live
  const [, setNow] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setNow((n) => n + 1), 1000);
    return () => clearInterval(id);
  }, []);

  const filtered = useMemo(() => {
    if (!tree) return null;
    return filterTree(tree, filterQ);
  }, [tree, filterQ]);

  const totalCount = useMemo(() => (tree ? flattenTree(tree).length : 0), [tree]);
  const visibleCount = useMemo(() => (filtered ? flattenTree(filtered).length : 0), [filtered]);

  return (
    <div className="card !p-3 h-full flex flex-col">
      {/* Header */}
      <div className="flex items-center gap-2 mb-2">
        <Folder className="w-4 h-4 text-primary-500" />
        <h3 className="text-sm font-semibold text-slate-900 dark:text-white flex-1 truncate" title={tree?.title || scopeLabel || 'Pages'}>
          {scopeLabel ? `${scopeLabel} Pages` : (tree?.title ? `${tree.title} Pages` : 'Pages')}
        </h3>
        <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
          {filterQ ? `${visibleCount}/${totalCount}` : totalCount}
        </span>
        <button
          onClick={() => load(true)}
          disabled={loading}
          className="p-1 rounded hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-500 disabled:opacity-50"
          title="Refresh tree"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {/* Filter input */}
      <div className="relative mb-2">
        <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
        <input
          type="text"
          value={filterQ}
          onChange={(e) => setFilterQ(e.target.value)}
          placeholder="Filter pages…"
          className="w-full pl-7 pr-2 py-1.5 text-xs rounded-md bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-1 focus:ring-primary-500"
        />
      </div>

      {/* Status — live ticker, auto-refreshes every 15s */}
      {fetchedAt && (
        <div className="text-[10px] text-slate-400 dark:text-slate-500 mb-2 flex items-center gap-1.5">
          <span className={`w-1.5 h-1.5 rounded-full ${
            loading ? 'bg-violet-500 animate-pulse' : cached ? 'bg-amber-400' : 'bg-emerald-500 animate-pulse'
          }`} />
          <span>{loading ? 'Polling…' : cached ? 'Cached' : 'Fresh'}</span>
          <span className="text-slate-300 dark:text-slate-600">·</span>
          <span title={fetchedAt.toISOString()}>
            {(() => {
              const sec = Math.max(0, Math.floor((Date.now() - fetchedAt.getTime()) / 1000));
              return sec < 60 ? `${sec}s ago` : `${Math.floor(sec / 60)}m ago`;
            })()}
          </span>
          <span className="ml-auto text-slate-400 dark:text-slate-500">auto · 15s</span>
        </div>
      )}

      {/* Tree body */}
      <div className="flex-1 overflow-y-auto -mx-2">
        {loading && !tree ? (
          <div className="flex items-center justify-center py-8 text-slate-400 text-xs">
            <Loader2 className="w-4 h-4 mr-2 animate-spin" /> Building tree from Confluence…
          </div>
        ) : error ? (
          <div className="px-2 py-3 text-xs text-red-600 dark:text-red-400">
            {error}
          </div>
        ) : filtered ? (
          <TreeNode node={filtered} depth={0} selectedId={selectedId} onSelect={onSelect} filtering={!!filterQ.trim()} />
        ) : (
          <div className="text-center py-6 text-xs text-slate-400">No pages match "{filterQ}"</div>
        )}
      </div>

      {tree && (
        <a
          href={tree.url}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-2 inline-flex items-center justify-center gap-1 px-2 py-1 text-[11px] font-medium rounded-md bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-600 dark:text-slate-300 transition-colors"
        >
          Open "{tree.title}" in Confluence <ExternalLink className="w-3 h-3" />
        </a>
      )}
    </div>
  );
}
