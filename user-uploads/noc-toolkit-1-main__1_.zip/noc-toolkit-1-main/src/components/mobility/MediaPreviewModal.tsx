import { useEffect, useState } from 'react';
import {
  X, Download, ExternalLink, ZoomIn, ZoomOut, RotateCw,
  FileText, FileSpreadsheet, FileType, Image as ImageIcon, Loader2, Maximize2,
} from 'lucide-react';
import { fetchXlsx, type XlsxResponse, type Attachment } from '../../lib/confluence/restClient';

interface Props {
  att: Attachment | null;
  onClose: () => void;
}

function formatBytes(n: number | null): string {
  if (n == null) return '';
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}

// ─── Image viewer with zoom + pan ───────────────────────────────
function ImageViewer({ src, title }: { src: string; title: string }) {
  const [zoom, setZoom] = useState(1);
  const [rotate, setRotate] = useState(0);

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 text-xs">
        <button onClick={() => setZoom((z) => Math.max(0.25, z - 0.25))} className="p-1.5 rounded hover:bg-slate-200 dark:hover:bg-slate-700" title="Zoom out"><ZoomOut className="w-4 h-4" /></button>
        <span className="font-mono w-12 text-center">{Math.round(zoom * 100)}%</span>
        <button onClick={() => setZoom((z) => Math.min(4, z + 0.25))} className="p-1.5 rounded hover:bg-slate-200 dark:hover:bg-slate-700" title="Zoom in"><ZoomIn className="w-4 h-4" /></button>
        <button onClick={() => setZoom(1)} className="px-2 py-1 rounded hover:bg-slate-200 dark:hover:bg-slate-700 text-[11px]" title="Reset">100%</button>
        <button onClick={() => setRotate((r) => (r + 90) % 360)} className="p-1.5 rounded hover:bg-slate-200 dark:hover:bg-slate-700 ml-2" title="Rotate"><RotateCw className="w-4 h-4" /></button>
      </div>
      <div className="flex-1 overflow-auto bg-slate-50 dark:bg-slate-900 flex items-center justify-center p-4">
        <img
          src={src}
          alt={title}
          style={{ transform: `scale(${zoom}) rotate(${rotate}deg)`, transformOrigin: 'center', transition: 'transform 0.15s' }}
          className="max-w-none"
        />
      </div>
    </div>
  );
}

// ─── PDF viewer (iframe with Chrome native viewer) ──────────────
function PdfViewer({ src, title }: { src: string; title: string }) {
  return (
    <div className="h-full flex flex-col">
      <iframe src={`${src}#toolbar=1&navpanes=0&view=FitH`} className="flex-1 w-full bg-slate-100 dark:bg-slate-900 border-0" title={title} />
    </div>
  );
}

// ─── XLSX viewer (parses server-side, renders as tables) ────────
function XlsxViewer({ attachmentId }: { attachmentId: string }) {
  const [data, setData] = useState<XlsxResponse | null>(null);
  const [activeSheet, setActiveSheet] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    fetchXlsx(attachmentId).then((d) => {
      setData(d);
      setLoading(false);
    });
  }, [attachmentId]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full text-sm text-slate-500">
        <Loader2 className="w-5 h-5 mr-2 animate-spin" /> Parsing spreadsheet…
      </div>
    );
  }
  if (!data || data.error || !data.sheets.length) {
    return <div className="p-6 text-sm text-red-600">{data?.error ?? 'No sheets found'}</div>;
  }

  const sheet = data.sheets[activeSheet];
  const showingRows = sheet.rows.length;
  const moreRows = sheet.totalRows > showingRows;

  return (
    <div className="h-full flex flex-col">
      {/* Sheet tabs */}
      {data.sheets.length > 1 && (
        <div className="flex items-center gap-1 px-3 py-1.5 bg-slate-100 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 overflow-x-auto">
          {data.sheets.map((s, i) => (
            <button
              key={s.name + i}
              onClick={() => setActiveSheet(i)}
              className={`px-2.5 py-1 text-xs font-medium rounded whitespace-nowrap ${
                i === activeSheet
                  ? 'bg-white dark:bg-slate-900 text-emerald-700 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-500/40'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              {s.name}
            </button>
          ))}
        </div>
      )}

      {/* Table */}
      <div className="flex-1 overflow-auto bg-white dark:bg-slate-900">
        <table className="w-full text-xs border-collapse">
          <thead className="sticky top-0 bg-slate-50 dark:bg-slate-800 z-10 shadow-sm">
            <tr>
              <th className="px-2 py-1.5 text-left font-semibold text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-700 w-10">#</th>
              {sheet.headers.map((h, i) => (
                <th key={i} className="px-2 py-1.5 text-left font-semibold text-slate-700 dark:text-slate-200 border-b border-slate-200 dark:border-slate-700 whitespace-nowrap">
                  {h || `Col ${i + 1}`}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {sheet.rows.map((row, ri) => (
              <tr key={ri} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                <td className="px-2 py-1 text-[10px] text-slate-400 dark:text-slate-500 border-b border-slate-100 dark:border-slate-800 font-mono">{ri + 2}</td>
                {sheet.headers.map((_, ci) => (
                  <td key={ci} className="px-2 py-1 text-slate-700 dark:text-slate-300 border-b border-slate-100 dark:border-slate-800 whitespace-nowrap">
                    {row[ci] ?? ''}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {moreRows && (
        <div className="px-3 py-1.5 bg-amber-50 dark:bg-amber-500/10 border-t border-amber-200 dark:border-amber-500/30 text-[11px] text-amber-700 dark:text-amber-300">
          Showing first {showingRows} of {sheet.totalRows} rows — download the file for the complete spreadsheet.
        </div>
      )}
    </div>
  );
}

// ─── Generic "no preview" fallback ──────────────────────────────
function NoPreviewFallback({ att }: { att: Attachment }) {
  return (
    <div className="flex flex-col items-center justify-center h-full p-8 text-center">
      <FileText className="w-16 h-16 text-slate-300 dark:text-slate-600 mb-4" />
      <p className="text-base font-semibold text-slate-700 dark:text-slate-300 mb-1">{att.title}</p>
      <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
        {att.mediaType} {att.fileSize ? `· ${formatBytes(att.fileSize)}` : ''}
      </p>
      <p className="text-sm text-slate-500 dark:text-slate-400 mb-5 max-w-md">
        This file type can't be previewed here. Download it or open the original in Confluence.
      </p>
      <div className="flex gap-2">
        <a
          href={att.downloadUrl}
          download={att.title}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-emerald-500 hover:bg-emerald-600 text-white text-sm font-medium"
        >
          <Download className="w-4 h-4" /> Download
        </a>
        <a
          href={att.confluenceUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 text-sm font-medium"
        >
          <ExternalLink className="w-4 h-4" /> Open in Confluence
        </a>
      </div>
    </div>
  );
}

// ─── Main modal component ───────────────────────────────────────
export function MediaPreviewModal({ att, onClose }: Props) {
  // ESC closes the modal
  useEffect(() => {
    if (!att) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [att, onClose]);

  if (!att) return null;

  const isXlsx = /sheet|excel|csv|xlsx?/i.test(att.mediaType) || /\.(xlsx?|csv)$/i.test(att.title);
  const isWord = /msword|wordprocessingml|docx?/i.test(att.mediaType) || /\.docx?$/i.test(att.title);

  const Icon = att.isImage ? ImageIcon : att.isPdf ? FileType : isXlsx ? FileSpreadsheet : FileText;
  const iconColor = att.isImage
    ? 'text-purple-500'
    : att.isPdf
    ? 'text-red-500'
    : isXlsx
    ? 'text-emerald-500'
    : 'text-blue-500';

  return (
    <div
      className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
    >
      <div
        className="bg-white dark:bg-slate-900 rounded-xl shadow-2xl w-full max-w-6xl h-full max-h-[90vh] flex flex-col overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal header */}
        <div className="flex items-center gap-3 px-4 py-3 border-b border-slate-200 dark:border-slate-700">
          <Icon className={`w-5 h-5 flex-shrink-0 ${iconColor}`} />
          <div className="min-w-0 flex-1">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white truncate">{att.title}</h3>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              {att.mediaType} {att.fileSize ? `· ${formatBytes(att.fileSize)}` : ''}
            </p>
          </div>
          <a
            href={att.downloadUrl}
            download={att.title}
            className="inline-flex items-center gap-1 px-2 py-1.5 rounded-md bg-emerald-100 dark:bg-emerald-500/20 hover:bg-emerald-200 dark:hover:bg-emerald-500/30 text-emerald-700 dark:text-emerald-300 text-xs font-medium"
            title="Download"
          >
            <Download className="w-3.5 h-3.5" /> Download
          </a>
          <a
            href={att.confluenceUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 px-2 py-1.5 rounded-md hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 text-xs"
            title="Open in Confluence"
          >
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
          <a
            href={att.downloadUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="p-1.5 rounded-md hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-500"
            title="Open full screen"
          >
            <Maximize2 className="w-3.5 h-3.5" />
          </a>
          <button onClick={onClose} className="p-1.5 rounded-md hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-500" aria-label="Close"><X className="w-4 h-4" /></button>
        </div>

        {/* Modal body — viewer */}
        <div className="flex-1 overflow-hidden">
          {att.isImage ? (
            <ImageViewer src={att.downloadUrl} title={att.title} />
          ) : att.isPdf ? (
            <PdfViewer src={att.downloadUrl} title={att.title} />
          ) : isXlsx ? (
            <XlsxViewer attachmentId={att.id} />
          ) : isWord ? (
            <NoPreviewFallback att={att} />
          ) : (
            <NoPreviewFallback att={att} />
          )}
        </div>
      </div>
    </div>
  );
}
