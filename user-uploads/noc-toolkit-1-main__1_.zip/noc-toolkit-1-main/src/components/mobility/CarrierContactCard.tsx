import { Phone, Mail, ExternalLink, Clock, FileText, Sparkles } from 'lucide-react';
import type { MobilityCarrier } from '../../lib/mobility/carriers';

function categoryBadge(cat: MobilityCarrier['category']) {
  switch (cat) {
    case 'Business':
      return 'bg-primary-100 text-primary-700 dark:bg-primary-500/20 dark:text-primary-300';
    case 'Retail':
      return 'bg-amber-100 text-amber-700 dark:bg-amber-500/20 dark:text-amber-300';
    case 'Specialty':
      return 'bg-violet-100 text-violet-700 dark:bg-violet-500/20 dark:text-violet-300';
  }
}

export function CarrierContactCard({ carrier }: { carrier: MobilityCarrier }) {
  const verified = !!carrier.verifiedAt;

  return (
    <div className="card relative group">
      {/* Brand color stripe */}
      <div
        className="absolute top-0 left-0 right-0 h-1 rounded-t-xl"
        style={{ backgroundColor: carrier.brandColor }}
      />

      <div className="pt-2">
        <div className="flex items-start justify-between gap-2 mb-3">
          <div className="min-w-0">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white leading-tight">
              {carrier.name}
            </h3>
            <div className="flex items-center gap-1.5 mt-1">
              <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium ${categoryBadge(carrier.category)}`}>
                {carrier.category}
              </span>
              {verified && (
                <span className="inline-flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded-full bg-emerald-100 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-300">
                  <Sparkles className="w-2.5 h-2.5" /> Confluence
                </span>
              )}
            </div>
          </div>
        </div>

        <div className="space-y-2">
          {/* Tier 1 phone */}
          {carrier.tier1Phone && (
            <a
              href={`tel:${carrier.tier1Phone.replace(/[^\d+]/g, '')}`}
              className="flex items-center gap-2 px-2.5 py-2 rounded-lg bg-slate-50 dark:bg-slate-700/50 hover:bg-primary-50 dark:hover:bg-primary-500/10 transition-colors"
            >
              <Phone className="w-3.5 h-3.5 text-primary-500 flex-shrink-0" />
              <div className="min-w-0 flex-1">
                <p className="text-[10px] text-slate-500 dark:text-slate-400">Tier 1 / NOC</p>
                <p className="text-sm font-mono font-semibold text-slate-900 dark:text-white">{carrier.tier1Phone}</p>
              </div>
            </a>
          )}

          {/* Escalation phone */}
          {carrier.escalationPhone && carrier.escalationPhone !== carrier.tier1Phone && (
            <a
              href={`tel:${carrier.escalationPhone.replace(/[^\d+]/g, '')}`}
              className="flex items-center gap-2 px-2.5 py-2 rounded-lg bg-slate-50 dark:bg-slate-700/50 hover:bg-amber-50 dark:hover:bg-amber-500/10 transition-colors"
            >
              <Phone className="w-3.5 h-3.5 text-amber-500 flex-shrink-0" />
              <div className="min-w-0 flex-1">
                <p className="text-[10px] text-slate-500 dark:text-slate-400">Escalation</p>
                <p className="text-sm font-mono font-semibold text-slate-900 dark:text-white">{carrier.escalationPhone}</p>
              </div>
            </a>
          )}

          {/* Email */}
          {carrier.supportEmail && (
            <a
              href={`mailto:${carrier.supportEmail}`}
              className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors group/email"
            >
              <Mail className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
              <span className="text-xs text-slate-700 dark:text-slate-300 truncate group-hover/email:text-primary-600 dark:group-hover/email:text-primary-400">
                {carrier.supportEmail}
              </span>
            </a>
          )}

          {/* Portal */}
          {carrier.portalUrl && (
            <a
              href={carrier.portalUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors group/portal"
            >
              <ExternalLink className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
              <span className="text-xs text-slate-700 dark:text-slate-300 truncate group-hover/portal:text-primary-600 dark:group-hover/portal:text-primary-400">
                Portal
              </span>
            </a>
          )}

          {/* Hours */}
          {carrier.hours && (
            <div className="flex items-center gap-2 px-2.5 py-1.5 text-xs text-slate-500 dark:text-slate-400">
              <Clock className="w-3.5 h-3.5 flex-shrink-0" />
              <span>{carrier.hours}</span>
            </div>
          )}

          {/* Notes */}
          {carrier.notes && (
            <div className="mt-2 px-2.5 py-2 rounded-lg bg-amber-50 dark:bg-amber-900/10 border border-amber-200 dark:border-amber-800/30">
              <div className="flex items-start gap-1.5">
                <FileText className="w-3.5 h-3.5 text-amber-500 flex-shrink-0 mt-0.5" />
                <p className="text-[11px] text-amber-800 dark:text-amber-300 leading-relaxed">{carrier.notes}</p>
              </div>
            </div>
          )}

          {/* Source pages */}
          {carrier.sourcePages && carrier.sourcePages.length > 0 && (
            <div className="pt-2 border-t border-slate-100 dark:border-slate-700">
              <p className="text-[10px] text-slate-400 dark:text-slate-500 mb-1">Sources (Confluence):</p>
              <div className="flex flex-wrap gap-1">
                {carrier.sourcePages.slice(0, 3).map((p, i) => (
                  <span key={i} className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-700/50 text-slate-600 dark:text-slate-400">
                    {p}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
