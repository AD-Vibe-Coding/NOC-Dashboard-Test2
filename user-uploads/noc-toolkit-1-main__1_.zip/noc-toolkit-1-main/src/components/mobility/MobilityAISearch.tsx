import { useState, useEffect, useRef, useCallback } from 'react';
import { Search, Loader2, ExternalLink, Sparkles, X, CheckCircle2, AlertCircle, Wand2 } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import {
  searchConfluence,
  CATEGORY_META,
  type SearchHit,
} from '../../lib/mobility/confluence-search';
import { fetchConfluencePageContent } from '../../lib/mobility/refresh';
import { AIBadge } from '../ai/AIBadge';

const EXAMPLE_QUERIES = [
  'iPhone activation steps',
  'Telispire SIM activation',
  'AT&T QuantumShift support number',
  'Android FAQ APN',
  'Mobility task template',
  'TLC classic troubleshooting',
];

interface Props {
  /** Optional initial query (e.g. from URL param) */
  initialQuery?: string;
}

export function MobilityAISearch({ initialQuery = '' }: Props) {
  const [query, setQuery] = useState(initialQuery);
  const [submittedQuery, setSubmittedQuery] = useState('');
  const [results, setResults] = useState<SearchHit[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastSearchAt, setLastSearchAt] = useState<Date | null>(null);
  const [expandedHit, setExpandedHit] = useState<string | null>(null);
  const [summaries, setSummaries] = useState<Record<string, { content: string; loading: boolean }>>({});
  const inputRef = useRef<HTMLInputElement>(null);
  const abortRef = useRef<AbortController | null>(null);

  const runSearch = useCallback(async (q: string) => {
    const trimmed = q.trim();
    if (!trimmed) return;
    abortRef.current?.abort();
    abortRef.current = new AbortController();
    setLoading(true);
    setError(null);
    setSubmittedQuery(trimmed);
    setResults([]);
    setExpandedHit(null);
    const res = await searchConfluence(trimmed, abortRef.current.signal);
    if (res.error) setError(res.error);
    setResults(res.results);
    setLastSearchAt(new Date());
    setLoading(false);
  }, []);

  const handleSubmit = (e?: React.FormEvent) => {
    e?.preventDefault();
    runSearch(query);
  };

  // Run initial query if provided
  useEffect(() => {
    if (initialQuery.trim()) runSearch(initialQuery);
  }, [initialQuery, runSearch]);

  const handleKey = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Escape') {
      setQuery('');
      setResults([]);
      setSubmittedQuery('');
      setError(null);
    }
  };

  const handleSummarize = async (hit: SearchHit) => {
    setExpandedHit(hit.url || hit.title);
    if (summaries[hit.title]?.content) return; // already loaded
    setSummaries((s) => ({ ...s, [hit.title]: { content: '', loading: true } }));
    const res = await fetchConfluencePageContent('', hit.title);
    setSummaries((s) => ({
      ...s,
      [hit.title]: { content: res.error ? `**Error:** ${res.error}` : res.content, loading: false },
    }));
  };

  const formatAge = (date: Date | null) => {
    if (!date) return null;
    const sec = Math.floor((Date.now() - date.getTime()) / 1000);
    if (sec < 60) return `${sec}s ago`;
    if (sec < 3600) return `${Math.floor(sec / 60)}m ago`;
    return `${Math.floor(sec / 3600)}h ago`;
  };

  return (
    <div className="card !p-0 overflow-hidden border-primary-200 dark:border-primary-500/30 shadow-md">
      {/* Header bar with live connection status */}
      <div className="flex items-center justify-between gap-2 px-4 py-2 bg-gradient-to-r from-primary-50 to-violet-50 dark:from-primary-500/10 dark:to-violet-500/10 border-b border-primary-100 dark:border-primary-500/20">
        <div className="flex items-center gap-2">
          <AIBadge size="xs" px={20} />
          <span className="text-xs font-semibold text-slate-700 dark:text-slate-200">
            Confluence AI Search
          </span>
          {error ? (
            <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-medium bg-red-100 dark:bg-red-500/20 text-red-700 dark:text-red-300">
              <AlertCircle className="w-2.5 h-2.5" /> Connection issue
            </span>
          ) : (
            <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-medium bg-emerald-100 dark:bg-emerald-500/20 text-emerald-700 dark:text-emerald-300">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              Connected
            </span>
          )}
        </div>
        <div className="text-[10px] text-slate-500 dark:text-slate-400 flex items-center gap-1">
          {lastSearchAt ? (
            <>
              <CheckCircle2 className="w-2.5 h-2.5 text-emerald-500" /> Last search {formatAge(lastSearchAt)}
            </>
          ) : (
            <span>Type a query and press Enter</span>
          )}
        </div>
      </div>

      {/* Search input */}
      <form onSubmit={handleSubmit} className="p-4 pb-2">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={handleKey}
            placeholder="Ask anything about mobility — &quot;How do I activate a Telispire SIM?&quot;, &quot;AT&amp;T support number&quot;..."
            className="w-full pl-12 pr-28 py-3.5 text-base rounded-xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 focus:border-primary-400 dark:focus:border-primary-500 focus:outline-none focus:ring-2 focus:ring-primary-200 dark:focus:ring-primary-500/30 text-slate-900 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-500 transition-all"
          />
          <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
            {query && (
              <button
                type="button"
                onClick={() => { setQuery(''); inputRef.current?.focus(); }}
                className="p-1.5 rounded-md hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors"
                aria-label="Clear"
              >
                <X className="w-4 h-4" />
              </button>
            )}
            <button
              type="submit"
              disabled={!query.trim() || loading}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-primary-500 hover:bg-primary-600 text-white disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Search className="w-3.5 h-3.5" />}
              {loading ? 'Searching' : 'Search'}
            </button>
          </div>
        </div>

        {/* Example queries (only when no search yet) */}
        {!submittedQuery && (
          <div className="flex flex-wrap gap-1.5 mt-3 items-center">
            <span className="text-[10px] uppercase tracking-wide text-slate-400 dark:text-slate-500 font-semibold mr-1">
              Try:
            </span>
            {EXAMPLE_QUERIES.map((ex) => (
              <button
                key={ex}
                type="button"
                onClick={() => { setQuery(ex); runSearch(ex); }}
                className="px-2 py-0.5 rounded-full text-[11px] bg-slate-100 dark:bg-slate-800 hover:bg-primary-100 dark:hover:bg-primary-500/20 text-slate-600 dark:text-slate-400 hover:text-primary-700 dark:hover:text-primary-300 transition-colors"
              >
                {ex}
              </button>
            ))}
          </div>
        )}
      </form>

      {/* Results */}
      {submittedQuery && (
        <div className="px-4 pb-4 space-y-2">
          {loading && (
            <div className="flex items-center justify-center py-8 text-sm text-slate-500 dark:text-slate-400">
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Searching Confluence wiki...
            </div>
          )}

          {!loading && error && (
            <div className="flex items-start gap-2 p-3 rounded-lg bg-red-50 dark:bg-red-900/10 border border-red-200 dark:border-red-800/30 text-xs">
              <AlertCircle className="w-4 h-4 text-red-500 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-red-700 dark:text-red-300">Search failed</p>
                <p className="text-red-600 dark:text-red-400 mt-0.5">{error}</p>
              </div>
            </div>
          )}

          {!loading && !error && results.length === 0 && submittedQuery && (
            <div className="text-center py-6 text-sm text-slate-500 dark:text-slate-400">
              No pages found for <span className="font-mono">"{submittedQuery}"</span>.
              Try a different keyword.
            </div>
          )}

          {!loading && results.length > 0 && (
            <>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                <span className="font-semibold">{results.length}</span> page{results.length === 1 ? '' : 's'} found
                {' '}for <span className="font-mono">"{submittedQuery}"</span>
              </p>
              {results.map((hit, idx) => {
                const cat = CATEGORY_META[hit.category];
                const isExpanded = expandedHit === (hit.url || hit.title);
                const sum = summaries[hit.title];
                const isTopMatch = idx === 0;
                return (
                  <div
                    key={`${hit.title}-${idx}`}
                    className={`rounded-lg border transition-all ${
                      isTopMatch
                        ? 'border-violet-300 dark:border-violet-500/40 bg-violet-50/40 dark:bg-violet-500/5 ring-1 ring-violet-200 dark:ring-violet-500/30'
                        : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800/50 hover:border-primary-200 dark:hover:border-primary-500/30'
                    }`}
                  >
                    <div className="p-3">
                      <div className="flex items-start gap-2 mb-1">
                        {isTopMatch && (
                          <span className="text-[9px] uppercase tracking-wide font-bold text-violet-700 dark:text-violet-300 bg-violet-100 dark:bg-violet-500/20 px-1.5 py-0.5 rounded">
                            Best match
                          </span>
                        )}
                        <span className={`text-[10px] font-medium px-1.5 py-0.5 rounded-full ${cat.className}`}>
                          {cat.emoji} {cat.label}
                        </span>
                      </div>
                      <h4 className="text-sm font-semibold text-slate-900 dark:text-white mb-1 leading-snug">
                        {hit.title}
                      </h4>
                      {hit.snippet && (
                        <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed mb-2">
                          {hit.snippet}
                        </p>
                      )}
                      <div className="flex items-center gap-2 flex-wrap">
                        {hit.url && (
                          <a
                            href={hit.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium bg-primary-500 hover:bg-primary-600 text-white transition-colors"
                          >
                            Open in Confluence <ExternalLink className="w-2.5 h-2.5" />
                          </a>
                        )}
                        <button
                          onClick={() => isExpanded ? setExpandedHit(null) : handleSummarize(hit)}
                          className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 transition-colors"
                        >
                          <Wand2 className="w-2.5 h-2.5" />
                          {isExpanded ? 'Hide summary' : 'Summarize'}
                        </button>
                      </div>
                    </div>

                    {isExpanded && (
                      <div className="border-t border-slate-200 dark:border-slate-700 p-3 bg-slate-50/50 dark:bg-slate-900/30">
                        {sum?.loading ? (
                          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                            <Loader2 className="w-3 h-3 animate-spin" />
                            Fetching page content via AI agent...
                          </div>
                        ) : sum?.content ? (
                          <div className="prose prose-xs dark:prose-invert max-w-none prose-p:my-1 prose-headings:my-1.5 prose-ul:my-1 prose-li:my-0 prose-h2:text-sm prose-h3:text-xs">
                            <ReactMarkdown>{sum.content}</ReactMarkdown>
                          </div>
                        ) : (
                          <p className="text-xs text-slate-500 dark:text-slate-400">No content fetched yet.</p>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}

              {/* Footer */}
              <div className="text-center pt-2">
                <p className="text-[10px] text-slate-400 dark:text-slate-500 inline-flex items-center gap-1">
                  <Sparkles className="w-2.5 h-2.5" />
                  Search grounded in your Confluence wiki via Devs.ai agent
                </p>
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}
