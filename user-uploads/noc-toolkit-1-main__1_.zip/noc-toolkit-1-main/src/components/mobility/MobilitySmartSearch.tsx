import { useState, useRef, useEffect } from 'react';
import {
  Search, Sparkles, ExternalLink, Loader2, X, BookOpen, ArrowRight,
  Lightbulb, Brain, ChevronDown, ChevronUp,
} from 'lucide-react';
import { smartSearchStream, type SmartSearchResponse, type CuratedHit, type SearchHit } from '../../lib/confluence/restClient';

interface Props {
  rootId: string;
  onOpenPage?: (pageId: string) => void;
  examples?: string[];
  /** Override placeholder text (e.g. for Network page). */
  placeholder?: string;
  /** Label shown in the connection banner (e.g. "Mobility" or "Network"). */
  scopeLabel?: string;
}

const DEFAULT_EXAMPLES = [
  'How do I activate a new eSIM on Quantum Shift?',
  'AT&T support phone number for the NOC',
  'iPhone won\'t connect to cellular',
  'Telispire physical SIM activation guide',
  'Mobility task template',
  'Granite escalation matrix',
];

export function MobilitySmartSearch({ rootId, onOpenPage, examples, placeholder, scopeLabel = 'Mobility' }: Props) {
  const EXAMPLE_QUERIES = examples ?? DEFAULT_EXAMPLES;
  const [query, setQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [isRefining, setIsRefining] = useState(false);
  const [result, setResult] = useState<SmartSearchResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [hasSearched, setHasSearched] = useState(false);
  const [lastSearchTime, setLastSearchTime] = useState<Date | null>(null);
  const [showRaw, setShowRaw] = useState(false);
  const [showIntent, setShowIntent] = useState(false);
  const [premium, setPremium] = useState(false);
  const [searchMs, setSearchMs] = useState<number | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const runSearch = async (q: string) => {
    const trimmed = q.trim();
    if (!trimmed) return;

    // Abort any in-flight search
    abortRef.current?.abort();
    const ctrl = new AbortController();
    abortRef.current = ctrl;

    const start = Date.now();
    setError(null);
    setIsSearching(true);
    setIsRefining(false);
    setResult({
      query: trimmed,
      intent: null,
      curated: [],
      raw: [],
      count: 0,
      rawCount: 0,
      topMatch: null,
      didYouMean: null,
      suggestions: [],
    });
    setHasSearched(true);
    setShowRaw(false);
    setSearchMs(null);

    let receivedCandidates = false;

    await smartSearchStream(
      trimmed,
      { ancestor: rootId, premium, signal: ctrl.signal },
      {
        onCandidates: (hits, _partial, _cached) => {
          receivedCandidates = true;
          setIsSearching(false);
          setIsRefining(true);
          setResult((prev) => ({
            ...(prev ?? { query: trimmed, intent: null, curated: [], raw: [], count: 0, rawCount: 0, topMatch: null, didYouMean: null, suggestions: [] }),
            raw: hits,
            rawCount: hits.length,
          }));
          setLastSearchTime(new Date());
        },
        onIntent: (intent) => {
          setResult((prev) => ({ ...(prev as SmartSearchResponse), intent }));
        },
        onCurated: (curated, extra) => {
          setIsRefining(false);
          setResult((prev) => ({
            ...(prev as SmartSearchResponse),
            curated,
            count: curated.length,
            topMatch: extra.topMatch,
            didYouMean: extra.didYouMean,
            suggestions: extra.suggestions,
          }));
          setSearchMs(Date.now() - start);
        },
        onError: (msg) => {
          setError(msg);
          setIsSearching(false);
          setIsRefining(false);
        },
        onDone: () => {
          setIsSearching(false);
          if (!receivedCandidates) setIsRefining(false);
        },
      },
    );
  };

  const onKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') runSearch(query);
    if (e.key === 'Escape') clear();
  };

  const clear = () => {
    setQuery('');
    setResult(null);
    setError(null);
    setHasSearched(false);
    setShowRaw(false);
    inputRef.current?.focus();
  };

  const handleResultClick = (id: string) => {
    if (id && onOpenPage) onOpenPage(id);
  };

  useEffect(() => { inputRef.current?.focus(); }, []);

  return (
    <div className="space-y-3">
      {/* Big search bar */}
      <div className="relative">
        <div className="absolute left-4 top-1/2 -translate-y-1/2 flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-violet-500" />
          <Search className="w-5 h-5 text-slate-400" />
        </div>
        <input
          ref={inputRef}
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={onKeyDown}
          placeholder={placeholder ?? 'Ask in plain English — "how do I activate eSIM on Quantum Shift?" …'}
          className="w-full pl-16 pr-32 py-4 text-base rounded-xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-violet-500 focus:border-transparent shadow-sm placeholder:text-slate-400"
        />
        <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
          {query && (
            <button onClick={clear} className="p-2 rounded-md hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-400" aria-label="Clear"><X className="w-4 h-4" /></button>
          )}
          <button
            onClick={() => runSearch(query)}
            disabled={!query.trim() || isSearching}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-gradient-to-r from-violet-500 to-indigo-500 hover:from-violet-600 hover:to-indigo-600 text-white text-sm font-semibold shadow-sm disabled:opacity-50"
          >
            {isSearching ? <Loader2 className="w-4 h-4 animate-spin" /> : <Brain className="w-4 h-4" />}
            Ask AI
          </button>
        </div>
      </div>

      {/* Connection status banner */}
      <div className="flex items-center gap-3 px-3 py-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-200 dark:border-emerald-500/30 text-[11px] flex-wrap">
        <span className="inline-flex items-center gap-1.5 text-emerald-700 dark:text-emerald-300">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span className="font-semibold">Viki / Confluence connected</span>
        </span>
        <span className="text-slate-500 dark:text-slate-400">·</span>
        <span className="text-slate-600 dark:text-slate-300">Space TS · {scopeLabel}</span>
        <span className="text-slate-500 dark:text-slate-400">·</span>
        {/* Speed toggle */}
        <button
          onClick={() => setPremium((p) => !p)}
          className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full font-medium transition-colors ${
            premium
              ? 'bg-violet-100 dark:bg-violet-500/20 text-violet-700 dark:text-violet-300'
              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
          }`}
          title={premium ? 'Premium gpt-5 — slower but slightly more accurate' : 'Fast gpt-4o-mini — ~2 sec'}
        >
          {premium ? <><Sparkles className="w-3 h-3" /> Premium (gpt-5)</> : <><Brain className="w-3 h-3" /> Fast (gpt-4o-mini)</>}
        </button>
        {searchMs !== null && (
          <>
            <span className="text-slate-500 dark:text-slate-400">·</span>
            <span className="text-slate-500 dark:text-slate-400 font-mono">{(searchMs / 1000).toFixed(1)}s</span>
          </>
        )}
        {lastSearchTime && (
          <>
            <span className="text-slate-500 dark:text-slate-400">·</span>
            <span className="text-slate-500 dark:text-slate-400">Last {lastSearchTime.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</span>
          </>
        )}
      </div>

      {/* Example queries */}
      {!hasSearched && (
        <div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mb-2 uppercase tracking-wider font-semibold flex items-center gap-1">
            <Lightbulb className="w-3 h-3" /> Try a natural-language question:
          </p>
          <div className="flex flex-wrap gap-1.5">
            {EXAMPLE_QUERIES.map((q) => (
              <button
                key={q}
                onClick={() => { setQuery(q); runSearch(q); }}
                className="inline-flex items-center gap-1 px-2.5 py-1 text-xs rounded-full bg-slate-100 dark:bg-slate-800 hover:bg-violet-100 dark:hover:bg-violet-500/20 hover:text-violet-700 dark:hover:text-violet-300 text-slate-600 dark:text-slate-400 transition-colors"
              >
                <Search className="w-3 h-3" /> {q}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* AI Intent (collapsible) */}
      {result?.intent && (
        <div className="rounded-lg border border-violet-200 dark:border-violet-500/30 bg-violet-50/40 dark:bg-violet-500/5 overflow-hidden">
          <button
            onClick={() => setShowIntent((s) => !s)}
            className="w-full flex items-center gap-2 px-3 py-2 text-left text-xs hover:bg-violet-100/50 dark:hover:bg-violet-500/10"
          >
            <Brain className="w-3.5 h-3.5 text-violet-600 dark:text-violet-400 flex-shrink-0" />
            <span className="font-semibold text-violet-700 dark:text-violet-300">AI understood:</span>
            <span className="text-slate-700 dark:text-slate-300 truncate flex-1">{result.intent.intent}</span>
            {showIntent ? <ChevronUp className="w-3 h-3 text-slate-400" /> : <ChevronDown className="w-3 h-3 text-slate-400" />}
          </button>
          {showIntent && (
            <div className="px-3 pb-2 text-[11px] space-y-1 border-t border-violet-100 dark:border-violet-500/20">
              <div><span className="text-slate-500 dark:text-slate-400">Search terms:</span> {result.intent.searchTerms.map((t) => <span key={t} className="inline-block px-1.5 py-0.5 mr-1 rounded bg-white dark:bg-slate-800 text-violet-700 dark:text-violet-300 font-mono">{t}</span>)}</div>
              {result.intent.phraseHints?.length > 0 && (
                <div><span className="text-slate-500 dark:text-slate-400">Phrase hints:</span> {result.intent.phraseHints.map((p) => <span key={p} className="inline-block px-1.5 py-0.5 mr-1 rounded bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300">"{p}"</span>)}</div>
              )}
              <div><span className="text-slate-500 dark:text-slate-400">Query type:</span> <span className="px-1.5 py-0.5 rounded bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300">{result.intent.queryType}</span></div>
            </div>
          )}
        </div>
      )}

      {/* "Did you mean" */}
      {result?.didYouMean && (
        <div className="px-3 py-2 rounded-lg bg-amber-50 dark:bg-amber-500/10 border border-amber-200 dark:border-amber-500/30 text-xs">
          <span className="text-slate-600 dark:text-slate-400">Did you mean </span>
          <button onClick={() => { setQuery(result.didYouMean!); runSearch(result.didYouMean!); }} className="font-semibold text-amber-700 dark:text-amber-300 hover:underline">{result.didYouMean}</button>
          <span className="text-slate-600 dark:text-slate-400">?</span>
        </div>
      )}

      {/* Error */}
      {error && (
        <div className="px-3 py-2 rounded-lg bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/30 text-xs text-red-700 dark:text-red-300">{error}</div>
      )}

      {/* Initial loading (no results yet) */}
      {isSearching && (
        <div className="card flex items-center gap-3 py-4">
          <Loader2 className="w-5 h-5 animate-spin text-violet-500" />
          <div className="text-sm">
            <p className="font-medium text-slate-900 dark:text-white">Searching Confluence…</p>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">First results in ~400ms · AI refining in parallel</p>
          </div>
        </div>
      )}

      {/* Refining pill — shown while AI is reranking but raw results are visible */}
      {isRefining && result && result.raw.length > 0 && (
        <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-violet-100 dark:bg-violet-500/20 text-violet-700 dark:text-violet-300 text-[11px] font-medium animate-pulse">
          <Loader2 className="w-3 h-3 animate-spin" />
          AI is refining {result.raw.length} matches…
        </div>
      )}

      {/* Results */}
      {hasSearched && result && (result.curated.length > 0 || result.raw.length > 0 || !isSearching) && (
        <div>
          {/* Curated results */}
          {result.curated.length > 0 ? (
            <>
              <div className="flex items-center justify-between mb-2 flex-wrap gap-2">
                <p className="text-xs">
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-violet-100 dark:bg-violet-500/20 text-violet-700 dark:text-violet-300 font-semibold">
                    <Sparkles className="w-3 h-3" /> AI-curated · {result.curated.length} {result.curated.length === 1 ? 'match' : 'matches'}
                  </span>
                  {result.rawCount > result.curated.length && (
                    <span className="ml-2 text-slate-500 dark:text-slate-400">from {result.rawCount} candidates</span>
                  )}
                </p>
                {result.rawCount > result.curated.length && (
                  <button
                    onClick={() => setShowRaw((s) => !s)}
                    className="text-[11px] text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 underline decoration-dotted"
                  >
                    {showRaw ? 'Hide' : 'Show'} all {result.rawCount} raw matches
                  </button>
                )}
              </div>
              <div className="space-y-2">
                {result.curated.map((r) => (
                  <CuratedResultCard
                    key={r.id ?? r.url}
                    hit={r}
                    isTop={result.topMatch === r.id}
                    onOpen={handleResultClick}
                  />
                ))}
              </div>
            </>
          ) : result.raw.length > 0 ? (
            // No curated yet (likely still refining) — show the raw top-5 as a preview
            <>
              <div className="flex items-center justify-between mb-2 flex-wrap gap-2">
                <p className="text-xs">
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold">
                    <Search className="w-3 h-3" /> {isRefining ? 'Initial keyword matches' : 'Keyword matches'} · {result.raw.length}
                  </span>
                </p>
              </div>
              <div className="space-y-1.5">
                {result.raw.slice(0, 6).map((r) => (
                  <RawResultCard key={r.id ?? r.url} hit={r} onOpen={handleResultClick} />
                ))}
              </div>
            </>
          ) : !isRefining && !isSearching ? (
            <div className="card text-center py-6 text-sm">
              <p className="text-slate-600 dark:text-slate-300">
                No matches for "{result.query}" in Confluence.
              </p>
            </div>
          ) : null}

          {/* Raw results (expandable) */}
          {showRaw && result.raw.length > 0 && (
            <div className="mt-3 pt-3 border-t border-dashed border-slate-200 dark:border-slate-700">
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mb-2 uppercase tracking-wider font-semibold">All raw keyword matches:</p>
              <div className="space-y-1.5">
                {result.raw.map((r) => (
                  <RawResultCard key={r.id ?? r.url} hit={r} onOpen={handleResultClick} />
                ))}
              </div>
            </div>
          )}

          {/* Suggestions */}
          {result.suggestions.length > 0 && (
            <div className="mt-3 pt-3 border-t border-slate-200 dark:border-slate-700">
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mb-1.5 uppercase tracking-wider font-semibold">
                <Sparkles className="w-3 h-3 inline mr-1 text-violet-500" /> You might also want to search for:
              </p>
              <div className="flex flex-wrap gap-1.5">
                {result.suggestions.map((s, i) => (
                  <button
                    key={i}
                    onClick={() => { setQuery(s); runSearch(s); }}
                    className="inline-flex items-center gap-1 px-2.5 py-1 text-xs rounded-full bg-violet-50 dark:bg-violet-500/10 hover:bg-violet-100 dark:hover:bg-violet-500/20 text-violet-700 dark:text-violet-300"
                  >
                    {s} <ArrowRight className="w-3 h-3" />
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ─── Curated result card (the "good" results) ──────────────────
function CuratedResultCard({ hit, isTop, onOpen }: { hit: CuratedHit; isTop: boolean; onOpen: (id: string) => void }) {
  const scoreColor = hit.relevance >= 80
    ? 'bg-emerald-500 text-white'
    : hit.relevance >= 65
    ? 'bg-emerald-400 text-white'
    : 'bg-amber-400 text-white';
  return (
    <div className={`card !p-3 transition-all ${
      isTop ? 'ring-2 ring-violet-500 border-violet-300 dark:border-violet-500/50 bg-violet-50/50 dark:bg-violet-500/5' : 'hover:border-primary-300 dark:hover:border-primary-500/40'
    }`}>
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2 mb-1 flex-wrap">
            {isTop && (
              <span className="inline-flex items-center gap-1 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide rounded-full bg-violet-500 text-white">
                <Sparkles className="w-2.5 h-2.5" /> Best match
              </span>
            )}
            <h4 className="text-sm font-semibold text-slate-900 dark:text-white">{hit.title}</h4>
            <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-bold font-mono ${scoreColor}`}>
              {hit.relevance}%
            </span>
          </div>
          {hit.why && (
            <p className="text-[11px] text-violet-700 dark:text-violet-300 italic mb-1">
              <Sparkles className="w-2.5 h-2.5 inline mr-1" /> {hit.why}
            </p>
          )}
          <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2">{hit.snippet}</p>
        </div>
        <div className="flex items-center gap-1 flex-shrink-0">
          {hit.id && (
            <button
              onClick={() => onOpen(hit.id!)}
              className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium rounded-md bg-primary-500 hover:bg-primary-600 text-white"
              title="View inline"
            >
              <BookOpen className="w-3 h-3" /> View
            </button>
          )}
          <a href={hit.url} target="_blank" rel="noopener noreferrer" className="p-1.5 rounded-md hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-500" title="Open in Confluence">
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>
    </div>
  );
}

// ─── Raw result card (the "all matches" list) ──────────────────
function RawResultCard({ hit, onOpen }: { hit: SearchHit; onOpen: (id: string) => void }) {
  return (
    <div className="flex items-center justify-between gap-2 px-3 py-1.5 rounded-md hover:bg-slate-50 dark:hover:bg-slate-800/60 border border-slate-100 dark:border-slate-700/50">
      <div className="min-w-0 flex-1">
        <p className="text-xs font-medium text-slate-700 dark:text-slate-300 truncate">{hit.title}</p>
      </div>
      <div className="flex items-center gap-1 flex-shrink-0">
        {hit.id && (
          <button onClick={() => onOpen(hit.id!)} className="p-1 rounded hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-500" title="View"><BookOpen className="w-3 h-3" /></button>
        )}
        <a href={hit.url} target="_blank" rel="noopener noreferrer" className="p-1 rounded hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-500" title="Open"><ExternalLink className="w-3 h-3" /></a>
      </div>
    </div>
  );
}
