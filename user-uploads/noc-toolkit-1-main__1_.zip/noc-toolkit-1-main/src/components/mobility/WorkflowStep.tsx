import { useState } from 'react';
import { ChevronDown, Info, ExternalLink } from 'lucide-react';
import type { VManagerWorkflow } from '../../lib/mobility/vmanager-workflows';

const VMANAGER_BASE = 'https://vmanager.vcomsolutions.com';

export function WorkflowStepCard({ workflow }: { workflow: VManagerWorkflow }) {
  const [open, setOpen] = useState(false);

  return (
    <div className="card">
      <button
        onClick={() => setOpen((o) => !o)}
        className="w-full flex items-start justify-between gap-3 text-left"
      >
        <div className="min-w-0 flex-1">
          <h3 className="text-sm font-semibold text-slate-900 dark:text-white">{workflow.title}</h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{workflow.blurb}</p>
        </div>
        <ChevronDown
          className={`w-4 h-4 text-slate-400 flex-shrink-0 mt-0.5 transition-transform ${open ? 'rotate-180' : ''}`}
        />
      </button>

      {open && (
        <div className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-700 animate-fade-in">
          <ol className="space-y-2">
            {workflow.steps.map((step, idx) => (
              <li key={idx} className="flex items-start gap-2">
                <span className="flex-shrink-0 w-5 h-5 rounded-full bg-primary-100 dark:bg-primary-500/20 text-primary-700 dark:text-primary-300 text-[10px] font-bold flex items-center justify-center mt-0.5">
                  {idx + 1}
                </span>
                <span className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                  {step.text}
                </span>
              </li>
            ))}
          </ol>

          {workflow.note && (
            <div className="mt-3 flex items-start gap-1.5 px-3 py-2 rounded-lg bg-primary-50 dark:bg-primary-500/10 border border-primary-200 dark:border-primary-500/20">
              <Info className="w-3.5 h-3.5 text-primary-500 flex-shrink-0 mt-0.5" />
              <p className="text-[11px] text-primary-700 dark:text-primary-300 leading-relaxed">{workflow.note}</p>
            </div>
          )}

          <a
            href={VMANAGER_BASE}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-3 inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium rounded-md bg-emerald-50 dark:bg-emerald-500/10 hover:bg-emerald-100 dark:hover:bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 transition-colors"
          >
            Open vManager <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      )}
    </div>
  );
}
