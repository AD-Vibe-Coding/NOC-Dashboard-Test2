import { useEffect, useState, useRef, useMemo } from 'react';
import {
  FileText, ExternalLink, Download, FileType, RefreshCw,
  Loader2, Calendar, User, ChevronDown, ChevronRight, FileSpreadsheet,
  Minimize2, Maximize2,
} from 'lucide-react';
import { fetchPage, type PageDetail, type Attachment } from '../../lib/confluence/restClient';
import { MediaPreviewModal } from './MediaPreviewModal';
import { CopySectionButton } from '../ui/CopySectionButton';

interface Props {
  pageId: string | null;
  onMinimize?: () => void;       // hide the renderer panel entirely
  minimizable?: boolean;
}

function formatBytes(n: number | null): string {
  if (n == null) return '';
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}

function attachmentIcon(att: Attachment) {
  if (att.isPdf) return { Icon: FileType, color: 'bg-red-100 dark:bg-red-500/20 text-red-600 dark:text-red-300' };
  const lower = (att.title + ' ' + att.mediaType).toLowerCase();
  if (/sheet|excel|csv|xlsx?/i.test(lower)) return { Icon: FileSpreadsheet, color: 'bg-emerald-100 dark:bg-emerald-500/20 text-emerald-600 dark:text-emerald-300' };
  return { Icon: FileText, color: 'bg-blue-100 dark:bg-blue-500/20 text-blue-600 dark:text-blue-300' };
}

// Only non-image attachments (PDFs, docs, spreadsheets) are shown in the list.
// Images are rendered inline within the page body via the proxy.
function AttachmentCard({ att, onPreview }: { att: Attachment; onPreview: (a: Attachment) => void }) {
  const { Icon, color } = attachmentIcon(att);
  const sizeLabel = formatBytes(att.fileSize);
  return (
    <div className="card !p-3 flex items-center gap-3">
      <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${color}`}>
        <Icon className="w-5 h-5" />
      </div>
      <div className="min-w-0 flex-1">
        <p className="text-sm font-medium text-slate-900 dark:text-white truncate">{att.title}</p>
        <p className="text-[11px] text-slate-500 dark:text-slate-400">
          {att.mediaType}{sizeLabel ? ` · ${sizeLabel}` : ''}
        </p>
      </div>
      {att.isPdf && (
        <button
          onClick={() => onPreview(att)}
          className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium rounded-md bg-violet-100 dark:bg-violet-500/20 hover:bg-violet-200 dark:hover:bg-violet-500/30 text-violet-700 dark:text-violet-300"
          title="Preview"
        >Preview</button>
      )}
      <a href={att.downloadUrl} download={att.title} className="p-1.5 rounded-md bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-600 dark:text-slate-300" title="Download">
        <Download className="w-3.5 h-3.5" />
      </a>
      <a href={att.confluenceUrl} target="_blank" rel="noopener noreferrer" className="p-1.5 rounded-md hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-500 dark:text-slate-400" title="Open in Confluence">
        <ExternalLink className="w-3.5 h-3.5" />
      </a>
    </div>
  );
}

// ─── Split HTML into collapsible sections at H2/H3 boundaries ────
interface Section {
  heading: string;
  level: 2 | 3 | null;     // null = before any heading
  html: string;
}

function splitIntoSections(rawHtml: string): Section[] {
  if (!rawHtml) return [];
  // Find every h2/h3 occurrence with regex
  const re = /<(h[23])\b[^>]*>([\s\S]*?)<\/\1>/gi;
  const matches: { idx: number; len: number; tag: 'h2' | 'h3'; text: string }[] = [];
  let m: RegExpExecArray | null;
  while ((m = re.exec(rawHtml)) !== null) {
    const text = m[2].replace(/<[^>]+>/g, '').replace(/&nbsp;/g, ' ').trim();
    matches.push({ idx: m.index, len: m[0].length, tag: m[1].toLowerCase() as 'h2' | 'h3', text });
  }
  if (matches.length === 0) {
    return [{ heading: '', level: null, html: rawHtml }];
  }
  const sections: Section[] = [];
  // Pre-heading content (intro)
  if (matches[0].idx > 0) {
    const intro = rawHtml.slice(0, matches[0].idx).trim();
    if (intro) sections.push({ heading: '', level: null, html: intro });
  }
  for (let i = 0; i < matches.length; i++) {
    const start = matches[i].idx + matches[i].len;
    const end = i + 1 < matches.length ? matches[i + 1].idx : rawHtml.length;
    const html = rawHtml.slice(start, end).trim();
    sections.push({
      heading: matches[i].text || '(untitled section)',
      level: matches[i].tag === 'h2' ? 2 : 3,
      html,
    });
  }
  return sections;
}

export function ConfluencePageRenderer({ pageId, onMinimize, minimizable }: Props) {
  const [page, setPage] = useState<PageDetail | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [previewAtt, setPreviewAtt] = useState<Attachment | null>(null); // used for PDF/doc previews only
  // Default: ALL sections collapsed. User clicks to expand what they want.
  const [openSections, setOpenSections] = useState<Set<number>>(new Set());
  const [allOpen, setAllOpen] = useState(false);
  // Compact view: only show H2/H3 titles as a TOC; click expands inline.
  const [compactView, setCompactView] = useState(false);
  const bodyRef = useRef<HTMLDivElement>(null);

  const load = async (id: string) => {
    setLoading(true);
    setError(null);
    setPage(null);
    const data = await fetchPage(id);
    if (data.error) setError(data.error);
    else setPage(data);
    setLoading(false);
    setOpenSections(new Set());
    setAllOpen(false);
  };

  useEffect(() => {
    if (pageId) load(pageId);
    else setPage(null);
  }, [pageId]);

  // Style embedded images and constrain overflow
  useEffect(() => {
    if (!bodyRef.current || !page) return;
    const imgs = bodyRef.current.querySelectorAll('img');
    imgs.forEach((img) => {
      img.style.maxWidth = '100%';
      img.style.height = 'auto';
      img.style.borderRadius = '6px';
      img.style.display = 'block';
      // Hide broken images silently — proxy returns 1×1 transparent PNG on failure
      img.addEventListener('error', () => { img.style.display = 'none'; }, { once: true });
    });
    // Constrain wide tables
    const tables = bodyRef.current.querySelectorAll('table');
    tables.forEach((t) => {
      (t as HTMLElement).style.maxWidth = '100%';
      (t as HTMLElement).style.tableLayout = 'auto';
      (t as HTMLElement).style.wordBreak = 'break-word';
    });
    // Constrain pre/code blocks
    const pres = bodyRef.current.querySelectorAll('pre');
    pres.forEach((p) => {
      (p as HTMLElement).style.maxWidth = '100%';
      (p as HTMLElement).style.overflowX = 'auto';
    });
  }, [page]);

  const sections = useMemo(() => (page ? splitIntoSections(page.html) : []), [page]);

  const toggleSection = (idx: number) => {
    setOpenSections((s) => {
      const next = new Set(s);
      if (next.has(idx)) next.delete(idx);
      else next.add(idx);
      return next;
    });
  };

  const toggleAll = () => {
    if (allOpen) {
      setOpenSections(new Set());
      setAllOpen(false);
    } else {
      setOpenSections(new Set(sections.map((_, i) => i)));
      setAllOpen(true);
    }
  };

  if (!pageId) {
    return (
      <div className="card flex flex-col items-center justify-center py-16 text-center">
        <FileText className="w-10 h-10 text-slate-300 dark:text-slate-600 mb-3" />
        <p className="text-sm font-medium text-slate-500 dark:text-slate-400">Select a page from the tree to view its content</p>
        <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">Or use the smart search at the top of the page</p>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="card flex items-center justify-center py-16 text-slate-500">
        <Loader2 className="w-5 h-5 mr-2 animate-spin" /> Loading page from Confluence…
      </div>
    );
  }

  if (error || !page) {
    return (
      <div className="card text-center py-12">
        <p className="text-sm text-red-600 dark:text-red-400 mb-2">Could not load page</p>
        <p className="text-xs text-slate-500">{error || 'unknown error'}</p>
      </div>
    );
  }

  const images = page.attachments.filter((a) => a.isImage);
  const files = page.attachments.filter((a) => !a.isImage);

  return (
    <>
      <div className="card">
        {/* Page header */}
        <div className="flex items-start justify-between gap-3 mb-3 pb-3 border-b border-slate-200 dark:border-slate-700">
          <div className="min-w-0 flex-1">
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">{page.title}</h2>
            <div className="flex items-center gap-3 mt-1 text-[11px] text-slate-500 dark:text-slate-400 flex-wrap">
              <span className="inline-flex items-center gap-1">
                <Calendar className="w-3 h-3" />
                {new Date(page.lastUpdated).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
              </span>
              {page.updatedBy && (
                <span className="inline-flex items-center gap-1">
                  <User className="w-3 h-3" /> {page.updatedBy}
                </span>
              )}
              <span className="text-slate-400 dark:text-slate-500">v{page.version}</span>
              <span className="px-1.5 py-0.5 rounded-full bg-primary-50 dark:bg-primary-500/10 text-primary-700 dark:text-primary-300 text-[10px] font-medium">{page.spaceKey}</span>
              {sections.length > 1 && (
                <span className="text-slate-400 dark:text-slate-500">· {sections.length} sections</span>
              )}
            </div>
          </div>
          <div className="flex items-center gap-1 flex-shrink-0">
            {sections.length > 1 && (
              <>
                <button
                  onClick={() => setCompactView((v) => !v)}
                  className={`inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium rounded-md ${
                    compactView
                      ? 'bg-violet-100 dark:bg-violet-500/20 text-violet-700 dark:text-violet-300'
                      : 'bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200'
                  }`}
                  title="Compact TOC view — show only section titles"
                >
                  🗂️ Compact
                </button>
                <button
                  onClick={toggleAll}
                  className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium rounded-md bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200"
                  title={allOpen ? 'Collapse all' : 'Expand all'}
                >
                  {allOpen ? 'Collapse all' : 'Expand all'}
                </button>
              </>
            )}
            <CopySectionButton targetRef={bodyRef} label={page.title} />
            <button onClick={() => load(page.id)} className="p-1.5 rounded-md hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-500" title="Refresh">
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
            {minimizable && onMinimize && (
              <button onClick={onMinimize} className="p-1.5 rounded-md hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-500" title="Minimize panel">
                <Minimize2 className="w-3.5 h-3.5" />
              </button>
            )}
            <a href={page.url} target="_blank" rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-primary-500 hover:bg-primary-600 active:bg-primary-700 text-white shadow-sm transition-colors"
              title="Open full page in Confluence">
              <ExternalLink className="w-3.5 h-3.5" />
              View in Confluence
            </a>
          </div>
        </div>



        {/* Body — collapsible sections */}
        <div ref={bodyRef}>
          {sections.length === 0 ? (
            <p className="text-sm text-slate-500 italic">This page has no content.</p>
          ) : sections.length === 1 && !sections[0].heading ? (
            // No sections detected — render full HTML directly
            <div
              className="confluence-body prose prose-sm dark:prose-invert max-w-none overflow-x-hidden break-words
                         prose-headings:font-semibold prose-h1:text-xl prose-h2:text-lg prose-h3:text-base
                         prose-table:text-xs prose-th:bg-slate-50 dark:prose-th:bg-slate-700
                         prose-th:px-2 prose-th:py-1.5 prose-td:px-2 prose-td:py-1.5
                         prose-strong:text-slate-900 dark:prose-strong:text-white
                         prose-a:text-primary-600 dark:prose-a:text-primary-400 prose-a:no-underline hover:prose-a:underline
                         prose-img:rounded-md prose-img:border prose-img:border-slate-200 dark:prose-img:border-slate-700
                         prose-ul:my-2 prose-ol:my-2 prose-li:my-0.5"
              dangerouslySetInnerHTML={{ __html: sections[0].html }}
            />
          ) : (
            <div className={compactView ? 'space-y-px' : 'space-y-1'}>
              {sections.map((s, i) => {
                const open = openSections.has(i);
                if (s.level === null) {
                  if (compactView) return null; // hide intro in compact TOC view
                  // Intro chunk (always visible, no heading)
                  return (
                    <div
                      key={i}
                      className="confluence-body prose prose-sm dark:prose-invert max-w-none mb-3
                                 prose-table:text-xs prose-strong:text-slate-900 dark:prose-strong:text-white"
                      dangerouslySetInnerHTML={{ __html: s.html }}
                    />
                  );
                }
                return (
                  <div key={i} className={compactView
                    ? 'border-b border-slate-100 dark:border-slate-800 last:border-0'
                    : 'border border-slate-200 dark:border-slate-700 rounded-lg overflow-hidden'}>
                    <button
                      onClick={() => toggleSection(i)}
                      className={`w-full flex items-center gap-2 text-left hover:bg-slate-50 dark:hover:bg-slate-800/50 ${
                        compactView ? 'px-2 py-1.5' : 'px-3 py-2'
                      } ${compactView && s.level === 3 ? 'pl-7' : ''}`}
                    >
                      {open ? <ChevronDown className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" /> : <ChevronRight className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />}
                      <span className={`flex-1 ${
                        compactView
                          ? (s.level === 2 ? 'text-xs font-semibold text-slate-800 dark:text-slate-200' : 'text-xs text-slate-600 dark:text-slate-400')
                          : (s.level === 2 ? 'text-sm font-semibold text-slate-900 dark:text-white' : 'text-sm font-medium text-slate-700 dark:text-slate-300')
                      }`}>
                        {s.heading}
                      </span>
                      {!open && !compactView && (
                        <span className="text-[10px] text-slate-400 dark:text-slate-500 flex-shrink-0">click to expand</span>
                      )}
                    </button>
                    {open && (
                      <div
                        className="px-4 py-3 border-t border-slate-100 dark:border-slate-700/60 confluence-body prose prose-sm dark:prose-invert max-w-none
                                   prose-table:text-xs prose-th:bg-slate-50 dark:prose-th:bg-slate-700
                                   prose-th:px-2 prose-th:py-1.5 prose-td:px-2 prose-td:py-1.5
                                   prose-strong:text-slate-900 dark:prose-strong:text-white
                                   prose-a:text-primary-600 dark:prose-a:text-primary-400
                                   prose-img:rounded-md prose-img:border prose-img:border-slate-200 dark:prose-img:border-slate-700
                                   prose-ul:my-2 prose-ol:my-2 prose-li:my-0.5"
                        dangerouslySetInnerHTML={{ __html: s.html }}
                      />
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Attachments */}
        {(images.length > 0 || files.length > 0) && (
          <div className="mt-6 pt-4 border-t border-slate-200 dark:border-slate-700">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white mb-3 flex items-center gap-2">
              Attachments
              <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 font-mono">
                {page.attachments.length}
              </span>
              <span className="text-[10px] text-slate-400 dark:text-slate-500 ml-auto font-normal">Click to preview</span>
            </h3>
            {images.length > 0 && (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-3">
                {images.map((a) => <AttachmentCard key={a.id} att={a} onPreview={setPreviewAtt} />)}
              </div>
            )}
            {files.length > 0 && (
              <div className="space-y-2">
                {files.map((a) => <AttachmentCard key={a.id} att={a} onPreview={setPreviewAtt} />)}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Media preview modal */}
      <MediaPreviewModal att={previewAtt} onClose={() => setPreviewAtt(null)} />
    </>
  );
}
