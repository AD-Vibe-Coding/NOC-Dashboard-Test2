import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Smartphone,
  Tablet,
  CreditCard,
  Sparkles,
  ChevronDown,
  Search,
  Globe2,
  Wifi,
  Signal,
  RefreshCw,
  BookOpen,
  ExternalLink,
  Loader2,
  Database,
} from 'lucide-react';
import { fetchDevicePages, type DeviceSearchHit } from '../../lib/confluence/restClient';
import { ConfluencePageRenderer } from './ConfluencePageRenderer';

const MOBILITY_ROOT_ID = '45648574';

type Device = 'iphone' | 'android-phone' | 'ipad' | 'android-tablet' | 'sim';

interface Issue {
  title: string;
  steps: string[];
  aiPrompt: string;
}

interface Section {
  id: Device;
  label: string;
  icon: typeof Smartphone;
  blurb: string;
  issues: Issue[];
}

const SECTIONS: Section[] = [
  {
    id: 'iphone',
    label: 'iPhone',
    icon: Smartphone,
    blurb: 'iOS cellular, WiFi, eSIM, profile, and activation issues.',
    issues: [
      {
        title: 'No cellular data / "No Service"',
        steps: [
          'Toggle Airplane Mode ON, wait 15s, then OFF.',
          'Settings → General → About → check Carrier version. If outdated, prompt user to update via WiFi.',
          'Settings → Cellular → Cellular Data Network → verify APN matches carrier specs (see APN table below).',
          'Settings → General → Transfer or Reset iPhone → Reset → Reset Network Settings (will clear saved WiFi).',
          'Physical SIM: remove, inspect, reseat. eSIM: Settings → Cellular → tap the line → check status.',
          'If still failing: confirm line is active in carrier portal (Verizon/AT&T/T-Mobile business console).',
        ],
        aiPrompt:
          'Walk me through the most likely causes of "No Service" on a corporate iPhone, ordered most-to-least likely. For each, give me the iOS path to fix it. End with the signs that this needs to escalate to the carrier.',
      },
      {
        title: 'Cellular works but no data / slow data',
        steps: [
          'Verify the cellular line has data enabled (Settings → Cellular → Cellular Data ON).',
          'Check Data Roaming if user is traveling: Settings → Cellular → Cellular Data Options → Data Roaming.',
          'Confirm 5G/LTE preference: Cellular Data Options → Voice & Data. Try LTE if 5G is unstable.',
          'Reset Network Settings.',
          'If on dual-SIM: confirm correct line is set as "Cellular Data" line (Settings → Cellular → Cellular Data).',
        ],
        aiPrompt:
          'A user has bars on their iPhone but data is unusable. Give me the iOS troubleshooting checklist and the carrier-side things I should verify.',
      },
      {
        title: 'WiFi connects but no internet',
        steps: [
          'Forget the network: Settings → WiFi → tap (i) → Forget This Network → rejoin.',
          'Toggle WiFi off/on.',
          'Try a different network (hotspot from a phone) to isolate device vs. network.',
          'Renew DHCP lease: Settings → WiFi → (i) → Renew Lease.',
          'Reset Network Settings if persistent.',
          'Check for captive portal (corporate guest WiFi). Open http://captive.apple.com to trigger redirect.',
        ],
        aiPrompt:
          'iPhone connects to WiFi but cannot reach the internet. Common causes? Walk me through diagnosis.',
      },
      {
        title: 'Activation / "Activation Required" loop',
        steps: [
          'Confirm SIM/eSIM is provisioned and active in carrier portal.',
          'Restart device. Settings → General → Shut Down, then power back on.',
          'For eSIM: Settings → Cellular → Add eSIM → use QR or activation code from carrier.',
          'If iCloud locked: needs Apple ID + password of last user, OR carrier-side bypass via Apple Business Manager / DEP.',
          'Force re-activation: connect to WiFi → restart → wait 1-2 minutes for activation servers.',
        ],
        aiPrompt: 'An iPhone is stuck on the Activation screen. What are the possible causes and the order I should troubleshoot them?',
      },
      {
        title: 'eSIM transfer from old iPhone',
        steps: [
          'Both phones must be on iOS 16+ and using the same Apple ID.',
          'On new iPhone during setup: tap "Transfer From Nearby iPhone".',
          'If after setup: Settings → Cellular → Add eSIM → Transfer From Nearby iPhone.',
          'Approve on old phone. Wait for confirmation.',
          'If carrier blocks transfer: contact carrier to release/re-issue eSIM QR code.',
        ],
        aiPrompt: 'How do I transfer an eSIM between iPhones for a user upgrading? Cover both during-setup and post-setup paths.',
      },
    ],
  },
  {
    id: 'android-phone',
    label: 'Android Phone',
    icon: Smartphone,
    blurb: 'Samsung Galaxy, Google Pixel, Motorola — cellular, APN, dual-SIM, and OEM quirks.',
    issues: [
      {
        title: 'No cellular signal / "Emergency calls only"',
        steps: [
          'Toggle Airplane Mode on/off.',
          'Settings → Network & Internet → SIMs → tap the line → Advanced → Access Point Names → verify APN.',
          'Settings → System → Reset Options → Reset Mobile Network Settings.',
          'Re-seat physical SIM. For eSIM, confirm profile is active (Network & Internet → SIMs).',
          'Confirm preferred network type: 5G/LTE/3G Auto. Drop to LTE only to test.',
          'Check IMEI is whitelisted in carrier portal: dial *#06# to display IMEI.',
        ],
        aiPrompt: 'Android phone shows "Emergency calls only". Walk me through NOC troubleshooting plus the carrier-side checks I need to make.',
      },
      {
        title: 'APN incorrect after SIM swap',
        steps: [
          'Settings → Network & Internet → SIMs → SIM line → Access Point Names.',
          'Tap (+) to add new APN with carrier-provided values (see table).',
          'Save and select the new APN.',
          'Toggle Airplane Mode to refresh data session.',
          'If APN options are greyed out: some carriers lock APN via SIM. Reboot, then retry.',
        ],
        aiPrompt: 'A user swapped their SIM on an Android phone and now has no data. Walk me through verifying and reconfiguring the APN.',
      },
      {
        title: 'WiFi calling not working',
        steps: [
          'Verify carrier supports WiFi calling on this device model.',
          'Settings → Network & Internet → SIMs → tap line → Wi-Fi calling → ON.',
          'Provide a valid E911 address when prompted (carrier requirement).',
          'Reboot device.',
          'If still off: confirm WiFi calling is enabled on the line in the carrier portal.',
        ],
        aiPrompt: 'How do I enable and troubleshoot WiFi calling on an Android phone on a business plan?',
      },
      {
        title: 'Dual-SIM (physical + eSIM) configuration',
        steps: [
          'Settings → Network & Internet → SIMs.',
          'Confirm both lines show as Active. Tap each to verify carrier and number.',
          'Set Calls / SMS / Mobile data defaults per user preference.',
          'For Samsung: Settings → Connections → SIM manager → Preferred SIMs.',
          'If one line drops repeatedly: try swapping which SIM is in slot vs. eSIM.',
        ],
        aiPrompt: 'How do I help a user set up dual-SIM (one physical, one eSIM) on a Samsung Galaxy on our business plan?',
      },
    ],
  },
  {
    id: 'ipad',
    label: 'iPad',
    icon: Tablet,
    blurb: 'iPad cellular + WiFi + MDM enrollment issues.',
    issues: [
      {
        title: 'Cellular iPad won\u2019t activate / no service',
        steps: [
          'Settings → Cellular Data → verify line is on.',
          'Settings → General → About → check Carrier and Modem firmware.',
          'For eSIM: Cellular Data → Add Cellular Plan → use carrier QR or activation code.',
          'Reset Network Settings.',
          'Confirm IMEI is provisioned in carrier portal: Settings → General → About → IMEI.',
          'WiFi-only iPad? Cellular menu won\u2019t appear — verify model number on apple.com.',
        ],
        aiPrompt: 'A new cellular iPad is not getting service on our T-Mobile business plan. Walk me through iOS-side troubleshooting and what to verify with the carrier.',
      },
      {
        title: 'iPad stuck on "Remote Management" / MDM enrollment',
        steps: [
          'Confirm device serial is in Apple Business Manager and assigned to your MDM.',
          'Connect to a working WiFi network.',
          'If skipped earlier: Settings → General → Transfer or Reset → Erase All Content and Settings → re-trigger Setup Assistant.',
          'If "Remote Management" doesn\u2019t auto-fill server URL: device may not be assigned in ABM.',
        ],
        aiPrompt: 'A new iPad bypassed Remote Management during setup. How do I re-trigger MDM enrollment without re-imaging?',
      },
    ],
  },
  {
    id: 'android-tablet',
    label: 'Android Tablet',
    icon: Tablet,
    blurb: 'Samsung Tab, Lenovo, Google Pixel Tablet — cellular and MDM.',
    issues: [
      {
        title: 'Tablet won\u2019t recognize the SIM',
        steps: [
          'Power off → remove SIM → inspect for damage / wrong cut → reseat.',
          'Boot and wait 60s. Some tablets need a full minute to negotiate.',
          'Settings → Connections / Network & Internet → SIM manager → verify SIM is listed.',
          'If still missing: try SIM in a known-good phone to isolate SIM vs. tablet.',
          'For Samsung Knox-managed: verify SIM control policy isn\u2019t blocking the carrier.',
        ],
        aiPrompt: 'A Samsung Galaxy Tab is not detecting its SIM after a swap. What\u2019s the troubleshooting order?',
      },
    ],
  },
  {
    id: 'sim',
    label: 'SIM / eSIM',
    icon: CreditCard,
    blurb: 'Activation, swap, port-in, eSIM provisioning, IMEI lookups across Verizon, AT&T, T-Mobile business.',
    issues: [
      {
        title: 'Activate a new physical SIM',
        steps: [
          'Verify line is provisioned in carrier portal and matches the SIM\u2019s ICCID.',
          'Insert SIM with device powered off.',
          'Power on and wait for carrier registration.',
          'If line is brand new: dial the activation number for the carrier.',
          'Verify IMEI is registered to the line in the carrier portal.',
        ],
        aiPrompt: 'Walk me through activating a new physical SIM on a corporate Verizon Wireless business line.',
      },
      {
        title: 'Issue a new eSIM (provision + install)',
        steps: [
          'In carrier portal: open the line → "Replace SIM" or "Issue eSIM" → request eSIM.',
          'Carrier delivers either a QR code or an Activation Code.',
          'On device: Settings → Cellular (iOS) or SIMs (Android) → Add eSIM → scan QR or paste code.',
          'Label the line so user can identify it (e.g., "Work").',
          'Verify call/SMS/data on the new eSIM.',
        ],
        aiPrompt: 'How do I provision and install a new eSIM on an iPhone for a user on AT&T business?',
      },
      {
        title: 'Port-in a number from another carrier',
        steps: [
          'Gather from old carrier: account number, account PIN, billing zip, full account holder name.',
          'Carrier portal: create the new line → choose "Port number" → enter the info above.',
          'Choose a temporary number if user needs service before port completes.',
          'Port window: typically 1-24 hours for mobile.',
          'Do NOT cancel the old line manually — the port completion cancels it automatically.',
        ],
        aiPrompt: 'Walk me through porting a number from one mobile carrier to our T-Mobile business plan.',
      },
      {
        title: 'IMEI lookup',
        steps: [
          'On the device: dial **#06#**.',
          'iOS: Settings → General → About → IMEI / MEID / EID.',
          'Android: Settings → About phone → IMEI information.',
          'Physical: printed on SIM tray (older devices) or on the back.',
          'For Apple, EID is for eSIM; IMEI is the device identifier carriers need.',
        ],
        aiPrompt: 'What are all the ways to find a device\u2019s IMEI?',
      },
    ],
  },
];

const APN_TABLE = [
  { carrier: 'Verizon Business', apn: 'vzwinternet', notes: '4G/5G data; no username/password' },
  { carrier: 'AT&T Business', apn: 'broadband', notes: 'Default for most business lines. IoT lines may use "i2gold".' },
  { carrier: 'T-Mobile Business', apn: 'fast.t-mobile.com', notes: '5G data; legacy lines may still use "epc.tmobile.com"' },
  { carrier: 'AT&T FirstNet', apn: 'firstnet-broadband', notes: 'Public safety lines' },
  { carrier: 'US Cellular Business', apn: 'usccinternet', notes: 'No username/password' },
];

export function DeviceTroubleshootingTab() {
  const navigate = useNavigate();
  const [active, setActive] = useState<Device>('iphone');
  const [search, setSearch] = useState('');
  const [openIdx, setOpenIdx] = useState<number | null>(0);

  const askAI = (prompt: string) => navigate(`/ai-assistant?prompt=${encodeURIComponent(prompt)}`);

  const section = SECTIONS.find((s) => s.id === active)!;
  const filteredIssues = section.issues.filter((i) =>
    !search.trim()
      ? true
      : i.title.toLowerCase().includes(search.toLowerCase()) ||
        i.steps.join(' ').toLowerCase().includes(search.toLowerCase()),
  );

  return (
    <div className="space-y-4">
      {/* Device tabs */}
      <div className="flex flex-wrap gap-2">
        {SECTIONS.map((s) => {
          const Icon = s.icon;
          const isActive = active === s.id;
          return (
            <button
              key={s.id}
              onClick={() => { setActive(s.id); setOpenIdx(0); setSearch(''); }}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium border transition-all ${
                isActive
                  ? 'bg-primary-50 dark:bg-primary-500/10 border-primary-300 dark:border-primary-500/40 text-primary-700 dark:text-primary-300'
                  : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:border-slate-300 dark:hover:border-slate-600'
              }`}
            >
              <Icon className="w-4 h-4" />
              {s.label}
            </button>
          );
        })}
      </div>

      <div className="card">
        <p className="text-sm text-slate-600 dark:text-slate-300 mb-3">{section.blurb}</p>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={`Search ${section.label} issues…`}
            className="input-base pl-10 text-sm"
          />
        </div>
      </div>

      {/* Live Confluence pages for this device category */}
      <ConfluenceDevicePages device={active} />

      <div className="space-y-2">
        <h3 className="text-sm font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-2 mt-2">
          Built-in playbooks
          <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-700 text-slate-500 font-normal">always available</span>
        </h3>
        {filteredIssues.map((issue, idx) => {
          const isOpen = openIdx === idx;
          return (
            <div key={issue.title} className="card !p-0 overflow-hidden transition-shadow">
              <button
                onClick={() => setOpenIdx(isOpen ? null : idx)}
                className="w-full flex items-center justify-between gap-3 p-4 text-left hover:bg-slate-50 dark:hover:bg-slate-700/30 transition-colors"
              >
                <span className="text-sm font-semibold text-slate-800 dark:text-slate-200">{issue.title}</span>
                <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform flex-shrink-0 ${isOpen ? 'rotate-180' : ''}`} />
              </button>
              {isOpen && (
                <div className="px-4 pb-4 pt-1 space-y-3 border-t border-slate-100 dark:border-slate-700/60">
                  <ol className="list-decimal pl-5 space-y-1.5 text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
                    {issue.steps.map((step, i) => <li key={i}>{step}</li>)}
                  </ol>
                  <button
                    onClick={() => askAI(issue.aiPrompt)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white transition-all"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    Ask AI for deeper help
                  </button>
                </div>
              )}
            </div>
          );
        })}
        {filteredIssues.length === 0 && (
          <div className="card text-center text-sm text-slate-500 dark:text-slate-400">No issues match "{search}".</div>
        )}
      </div>

      {/* APN Reference */}
      <div className="card">
        <div className="flex items-center gap-2 mb-3">
          <Globe2 className="w-4 h-4 text-primary-500" />
          <h2 className="text-sm font-semibold text-slate-800 dark:text-slate-200">APN Reference (US Business Plans)</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-xs text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-700">
                <th className="py-2 pr-4 font-medium">Carrier</th>
                <th className="py-2 pr-4 font-medium">APN</th>
                <th className="py-2 font-medium">Notes</th>
              </tr>
            </thead>
            <tbody>
              {APN_TABLE.map((row) => (
                <tr key={row.carrier} className="border-b border-slate-100 dark:border-slate-700/60 last:border-0">
                  <td className="py-2 pr-4 font-medium text-slate-800 dark:text-slate-200">{row.carrier}</td>
                  <td className="py-2 pr-4 font-mono text-xs text-primary-600 dark:text-primary-400">{row.apn}</td>
                  <td className="py-2 text-xs text-slate-600 dark:text-slate-400">{row.notes}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Quick AI diagnostics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {[
          { icon: Wifi, title: 'WiFi diagnostic', prompt: 'A user\u2019s device cannot get a working internet connection over WiFi. Walk me through a methodical NOC diagnostic that works across iOS and Android.' },
          { icon: Signal, title: 'Cellular diagnostic', prompt: 'A mobile device shows poor or no cellular signal indoors. Walk me through the NOC troubleshooting checklist for iOS and Android.' },
          { icon: RefreshCw, title: 'Factory reset checklist', prompt: 'What\u2019s the NOC pre-flight checklist before factory-resetting a corporate iPhone or Android phone?' },
        ].map((q) => (
          <button
            key={q.title}
            onClick={() => askAI(q.prompt)}
            className="card !p-3 text-left hover:border-primary-300 dark:hover:border-primary-500/40 transition-all"
          >
            <div className="flex items-center gap-2 mb-1">
              <div className="w-7 h-7 rounded-md bg-emerald-100 dark:bg-emerald-500/20 flex items-center justify-center">
                <q.icon className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              </div>
              <span className="text-sm font-medium text-slate-800 dark:text-slate-200">{q.title}</span>
            </div>
            <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1">
              <Sparkles className="w-3 h-3" /> Ask AI to walk you through
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

// ─── Confluence-sourced troubleshooting pages for this device ──────
function ConfluenceDevicePages({ device }: { device: Device }) {
  const [results, setResults] = useState<DeviceSearchHit[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [openPageId, setOpenPageId] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    setError(null);
    const r = await fetchDevicePages(device, MOBILITY_ROOT_ID);
    if (r.error) setError(r.error);
    else setResults(r.results);
    setLoading(false);
  };

  useEffect(() => {
    load();
    // Refresh every 15 sec (server-cached, fast)
    const id = setInterval(load, 15 * 1000);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [device]);

  return (
    <div className="card">
      <div className="flex items-center gap-2 mb-3 flex-wrap">
        <Database className="w-4 h-4 text-violet-500" />
        <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
          Live from Confluence
        </h3>
        <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-violet-100 dark:bg-violet-500/20 text-violet-700 dark:text-violet-300 font-medium">
          {loading ? '...' : results.length} {results.length === 1 ? 'page' : 'pages'}
        </span>
        <span className="text-[10px] text-slate-400">auto-refreshing · 15s</span>
        <button
          onClick={load}
          className="ml-auto p-1 rounded hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-500"
          title="Refresh"
        >
          <RefreshCw className={`w-3 h-3 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {error && <p className="text-xs text-red-600">{error}</p>}

      {loading && results.length === 0 ? (
        <div className="flex items-center gap-2 text-xs text-slate-500">
          <Loader2 className="w-3 h-3 animate-spin" /> Searching Confluence…
        </div>
      ) : results.length === 0 ? (
        <p className="text-xs text-slate-500 italic">No Confluence pages found for this device.</p>
      ) : (
        <div className="space-y-1.5">
          {results.slice(0, 8).map((r) => (
            <div key={r.id} className="flex items-start gap-2 p-2 rounded-md hover:bg-slate-50 dark:hover:bg-slate-800/60 border border-slate-100 dark:border-slate-700/50">
              <BookOpen className="w-3.5 h-3.5 text-violet-500 flex-shrink-0 mt-0.5" />
              <div className="min-w-0 flex-1">
                <p className="text-xs font-semibold text-slate-900 dark:text-white">{r.title}</p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2">{r.snippet}</p>
              </div>
              <button
                onClick={() => setOpenPageId(openPageId === r.id ? null : r.id)}
                className="inline-flex items-center gap-1 px-2 py-1 text-[10px] font-medium rounded bg-primary-500 hover:bg-primary-600 text-white flex-shrink-0"
              >
                {openPageId === r.id ? 'Close' : 'View'}
              </button>
              <a
                href={r.url}
                target="_blank"
                rel="noopener noreferrer"
                className="p-1 rounded hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-400 flex-shrink-0"
                title="Open in Confluence"
              >
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          ))}
          {results.length > 8 && (
            <p className="text-[10px] text-slate-400 italic mt-1">+ {results.length - 8} more results in Confluence</p>
          )}
        </div>
      )}

      {/* Inline preview when a page is selected */}
      {openPageId && (
        <div className="mt-3 pt-3 border-t border-slate-200 dark:border-slate-700">
          <ConfluencePageRenderer pageId={openPageId} />
        </div>
      )}
    </div>
  );
}

