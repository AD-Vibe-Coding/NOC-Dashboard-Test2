import { useState } from 'react';
import { ExternalLink, BookOpen, Loader2, RefreshCw, Sparkles } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import type { ConfluencePageRef } from '../../lib/mobility/confluence-pages';
import { fetchConfluencePageContent } from '../../lib/mobility/refresh';

interface Props {
  page: ConfluencePageRef;
}

export function ConfluencePageView({ page }: Props) {
  const [content, setContent] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [expanded, setExpanded] = useState(false);
  const [fetchedAt, setFetchedAt] = useState<Date | null>(null);

  const load = async () => {
    setLoading(true);
    setError(null);
    const res = await fetchConfluencePageContent(page.id, page.title);
    if (res.error) setError(res.error);
    else {
      setContent(res.content);
      setFetchedAt(new Date());
    }
    setLoading(false);
    setExpanded(true);
  };

  const catColor =
    page.category === 'activation'
      ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-300'
      : page.category === 'troubleshooting'
        ? 'bg-amber-100 text-amber-700 dark:bg-amber-500/20 dark:text-amber-300'
        : 'bg-primary-100 text-primary-700 dark:bg-primary-500/20 dark:text-primary-300';

  return (
    <div className="card">
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 rounded-lg bg-primary-100 dark:bg-primary-500/10 flex items-center justify-center flex-shrink-0">
          <BookOpen className="w-5 h-5 text-primary-500" />
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-start justify-between gap-2 mb-1">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white">{page.title}</h3>
            <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium flex-shrink-0 ${catColor}`}>
              {page.category}
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed mb-3">
            {page.description}
          </p>

          <div className="flex items-center gap-2 flex-wrap">
            {!content && !loading && (
              <button
                onClick={load}
                className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-md bg-primary-500 hover:bg-primary-600 text-white transition-colors"
              >
                <Sparkles className="w-3 h-3" /> Load from Confluence
              </button>
            )}
            {loading && (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs text-slate-500 dark:text-slate-400">
                <Loader2 className="w-3 h-3 animate-spin" /> Fetching via AI agent...
              </span>
            )}
            {content && (
              <>
                <button
                  onClick={() => setExpanded((e) => !e)}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-md bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 transition-colors"
                >
                  {expanded ? 'Hide' : 'Show'} content
                </button>
                <button
                  onClick={load}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-md hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-500 dark:text-slate-400 transition-colors"
                  title="Refresh content"
                >
                  <RefreshCw className="w-3 h-3" />
                </button>
              </>
            )}
            <a
              href={page.url}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-md hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 transition-colors"
            >
              Open in Confluence <ExternalLink className="w-3 h-3" />
            </a>
            {fetchedAt && (
              <span className="text-[10px] text-slate-400 dark:text-slate-500 ml-auto">
                Loaded {fetchedAt.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
              </span>
            )}
          </div>

          {error && (
            <div className="mt-3 px-3 py-2 rounded-lg bg-red-50 dark:bg-red-900/10 border border-red-200 dark:border-red-800/30 text-xs text-red-700 dark:text-red-400">
              {error}
            </div>
          )}

          {expanded && content && (
            <div className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-700">
              <div className="prose prose-sm dark:prose-invert max-w-none prose-p:my-1 prose-headings:my-2 prose-ul:my-1 prose-li:my-0 prose-h2:text-base prose-h3:text-sm prose-h2:font-semibold prose-h3:font-semibold prose-strong:text-slate-900 dark:prose-strong:text-white">
                <ReactMarkdown>{content}</ReactMarkdown>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
