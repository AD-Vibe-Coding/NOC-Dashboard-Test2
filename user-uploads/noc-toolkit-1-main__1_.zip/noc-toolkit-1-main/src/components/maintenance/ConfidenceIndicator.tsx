import { CheckCircle, AlertTriangle, XCircle } from 'lucide-react';
import type { ConfidenceLevel } from '../../types';

interface ConfidenceIndicatorProps {
  level: ConfidenceLevel;
  className?: string;
}

export function ConfidenceIndicator({ level, className = '' }: ConfidenceIndicatorProps) {
  switch (level) {
    case 'found':
      return <span title="Auto-detected"><CheckCircle className={`w-4 h-4 text-emerald-500 ${className}`} /></span>;
    case 'guessed':
      return <span title="Best guess — please verify"><AlertTriangle className={`w-4 h-4 text-amber-500 ${className}`} /></span>;
    case 'not_found':
      return <span title="Not found — manual entry needed"><XCircle className={`w-4 h-4 text-red-500 ${className}`} /></span>;
  }
}
