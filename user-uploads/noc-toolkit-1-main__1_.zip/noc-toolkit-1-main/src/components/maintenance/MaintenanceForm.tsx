import { useState } from 'react';
import { Wrench, Zap, FileText, AlertTriangle, Radio } from 'lucide-react';
import { Toggle } from '../ui/Toggle';
import { Textarea } from '../ui/Textarea';
import { Button } from '../ui/Button';
import { SUPPORTED_CARRIERS } from '../../utils/maintenanceParser';
import type { MaintenanceType } from '../../types';

interface MaintenanceFormProps {
  onGenerate: (rawEmail: string, type: MaintenanceType) => void;
}

export function MaintenanceForm({ onGenerate }: MaintenanceFormProps) {
  const [rawEmail, setRawEmail] = useState('');
  const [isEmergency, setIsEmergency] = useState(false);
  const [showCarriers, setShowCarriers] = useState(false);

  const handleGenerate = () => {
    if (!rawEmail.trim()) return;
    onGenerate(rawEmail, isEmergency ? 'emergency' : 'scheduled');
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <Toggle
          checked={isEmergency}
          onChange={setIsEmergency}
          labelLeft="Scheduled Maintenance"
          labelRight="Emergency Maintenance"
        />
        <div className="flex items-center gap-2">
          {isEmergency ? (
            <span className="badge-danger flex items-center gap-1.5 text-sm px-3 py-1">
              <Zap className="w-3.5 h-3.5" /> Emergency
            </span>
          ) : (
            <span className="badge-success flex items-center gap-1.5 text-sm px-3 py-1">
              <Wrench className="w-3.5 h-3.5" /> Scheduled
            </span>
          )}
        </div>
      </div>

      {/* Supported Carriers Badge */}
      <button
        onClick={() => setShowCarriers(!showCarriers)}
        className="flex items-center gap-2 px-3 py-2 rounded-lg bg-primary-50 dark:bg-primary-500/10 border border-primary-200 dark:border-primary-500/20 hover:bg-primary-100 dark:hover:bg-primary-500/15 transition-colors w-full text-left"
      >
        <Radio className="w-4 h-4 text-primary-500" />
        <span className="text-sm font-medium text-primary-700 dark:text-primary-300">
          {SUPPORTED_CARRIERS.length} Supported Carrier Formats
        </span>
        <span className="text-xs text-primary-500 ml-auto">{showCarriers ? 'Hide' : 'Show'}</span>
      </button>

      {showCarriers && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 animate-fade-in">
          {SUPPORTED_CARRIERS.map((c) => (
            <div key={c.name} className="flex items-start gap-2 px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
              <span className="text-xs font-semibold text-slate-900 dark:text-slate-100 whitespace-nowrap">{c.name}</span>
              <span className="text-xs text-slate-400 dark:text-slate-500">— {c.format}</span>
            </div>
          ))}
        </div>
      )}

      <Textarea
        label="Paste Carrier Maintenance Email Here"
        placeholder={`Paste the raw carrier maintenance email here...

Supported formats:
• AT&T: "Dear AT&T IP Services Customer..."
• Spectrum: "Spectrum Business Maintenance Notifications..."
• Windstream: "Emergency/Scheduled Maintenance Notification..."
• Nitel: "Ticket #XXXXXXX has been opened..."
• Uniti Fiber: "Uniti Fiber Maintenance Notification: NCC-..."
• Expereo: "New Planned Maintenance Notification..."
• Lumen, Comcast, Frontier, Zayo, Cogent, and more...`}
        value={rawEmail}
        onChange={(e) => setRawEmail(e.target.value)}
        className="min-h-[220px] font-mono text-sm"
      />

      <div className="flex items-center gap-3">
        <Button onClick={handleGenerate} disabled={!rawEmail.trim()}>
          <FileText className="w-4 h-4" />
          Generate vCom Note
        </Button>
        {rawEmail.trim() && (
          <Button variant="ghost" onClick={() => setRawEmail('')}>
            Clear
          </Button>
        )}
      </div>

      <div className="flex items-start gap-2 p-3 bg-amber-50 dark:bg-amber-900/10 rounded-lg border border-amber-200 dark:border-amber-800/30">
        <AlertTriangle className="w-4 h-4 text-amber-500 mt-0.5 flex-shrink-0" />
        <p className="text-sm text-amber-700 dark:text-amber-400">
          Always review the generated note before sending to customers. The parser auto-detects carrier, circuit ID, location, times, timezone (with DST awareness), and duration.
        </p>
      </div>
    </div>
  );
}
