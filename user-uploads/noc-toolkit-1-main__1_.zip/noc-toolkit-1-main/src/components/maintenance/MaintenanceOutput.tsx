import React, { useState } from 'react';
import { Copy, Check, AlertTriangle, FileText, Mail, Activity, CheckCircle2, NotebookPen } from 'lucide-react';
import toast from 'react-hot-toast';
import { Button } from '../ui/Button';
import { ConfidenceIndicator } from './ConfidenceIndicator';
import { copyRichAndPlain, copyPlainOnly } from '../../lib/clipboard-rich';
import type { MaintenanceData, MaintenanceType } from '../../types';

type Variant = 'notice' | 'update' | 'complete' | 'internal';

const VARIANTS: { key: Variant; label: string; icon: typeof Mail; blurb: string }[] = [
  { key: 'notice',   label: 'Notification',          icon: Mail,         blurb: 'Initial customer-facing notice (before maintenance starts).' },
  { key: 'update',   label: 'In-progress update',    icon: Activity,     blurb: 'Mid-maintenance status update to the customer.' },
  { key: 'complete', label: 'Completion notice',     icon: CheckCircle2, blurb: 'Sent after maintenance has ended and service is restored.' },
  { key: 'internal', label: 'Internal handover',     icon: NotebookPen,  blurb: 'Short internal note for the next shift / Slack channel.' },
];

interface MaintenanceOutputProps {
  data: MaintenanceData;
  type: MaintenanceType;
}

function esc(str: string) {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

export function MaintenanceOutput({ data, type }: MaintenanceOutputProps) {
  const [copied, setCopied] = useState<string | null>(null);
  const [variant, setVariant] = useState<Variant>('notice');

  const flashCopied = (kind: string) => {
    setCopied(kind);
    window.setTimeout(() => setCopied((k) => (k === kind ? null : k)), 1800);
  };

  const hasWarnings = Object.values(data).some(
    (f) => f.confidence === 'not_found' || f.confidence === 'guessed'
  );

  const fields = [
    { label: 'Carrier', field: data.carrier },
    { label: 'Circuit ID', field: data.circuitId },
    { label: 'Location', field: data.address },
    { label: 'Start Time', field: data.startTime },
    { label: 'End Time', field: data.endTime },
    { label: 'Duration', field: data.duration },
    { label: 'Reason', field: data.reason },
    { label: 'Timezone', field: data.timezone },
  ];

  const carrier = data.carrier.value;
  const typeLabel = type === 'emergency' ? 'emergency' : 'scheduled';
  const address = data.address.value;
  const circuitId = data.circuitId.value;
  const duration = data.duration.value.includes('Not Found') ? '[TIME LENGTH]' : data.duration.value;
  const reason = data.reason.value.includes('Not Found') ? '[REASON]' : data.reason.value;
  const startTime = data.startTime.value.includes('Not Found') ? '[DATE/TIME]' : data.startTime.value;
  const endTime = data.endTime.value.includes('Not Found') ? '[DATE/TIME]' : data.endTime.value;

  // ── Subject line (handy when sending the note as an email) ──
  const subject =
    variant === 'notice'   ? `${type === 'emergency' ? '[EMERGENCY] ' : ''}${typeLabel.charAt(0).toUpperCase()+typeLabel.slice(1)} Maintenance — ${carrier} — ${circuitId} — ${startTime}`
  : variant === 'update'   ? `[UPDATE] ${carrier} maintenance in progress — ${circuitId}`
  : variant === 'complete' ? `[RESOLVED] ${carrier} maintenance complete — ${circuitId}`
  :                          `Internal handover — ${carrier} ${typeLabel} maintenance — ${circuitId}`;

  // ── Variant bodies ──
  // FORMATTING PHILOSOPHY — match what ChatGPT does:
  //
  //   1.  Bare HTML only — <p>, <ul>, <li>, <strong>. NO inline styles.
  //         The destination editor (Outlook, Gmail, Slack, Word, ServiceNow,
  //         the customer ticket portal, etc.) supplies its own default
  //         paragraph margins and list bullets. Imposing inline styles from
  //         this side fights the destination and changes the font/spacing.
  //
  //   2.  Start time / End time use a real <ul><li> bullet list. Outlook
  //         renders this with its native bullet styling — round disc, indent,
  //         tight line spacing — exactly like the target ChatGPT output.
  //
  //   3.  NO signatures anywhere — the team uses their Outlook signature.
  //
  //   4.  The clipboard sanitizer (clipboard-rich.ts) strips colors, fonts,
  //         backgrounds. It does NOT inject any margins/padding. The
  //         destination editor's defaults take over cleanly.
  const P  = (body: string) => `<p>${body}</p>`;
  const UL = (items: string[]) =>
    `<ul>${items.map((it) => `<li>${it}</li>`).join('')}</ul>`;

  const NOTICE_HTML = `<div>
${P('Hello Team,')}
${P(`Please be advised, <strong>${esc(carrier)}</strong> will be performing <strong>${esc(typeLabel)}</strong> maintenance that will impact your service at location <strong>${esc(address)}</strong>.`)}
${P(`Your vCom provided circuit <strong>${esc(circuitId)}</strong> will be subject to an outage lasting <strong>${esc(duration)}</strong> during this maintenance window (Please note this is an estimate and no guarantee of actual impact). This maintenance is for <strong>${esc(reason)}</strong>.`)}
${UL([
   `<strong>Start time:</strong> ${esc(startTime)}`,
   `<strong>End time:</strong> ${esc(endTime)}`,
 ])}
${P(`If you experience service issues after that window, you may need to reboot your equipment. If you continue to have any problems, call our toll-free Technical Support number <strong>800-804-8266 opt 3</strong>, and refer to this ticket for further assistance.`)}
</div>`;

  const NOTICE_TEXT = `Hello Team,

Please be advised, ${carrier} will be performing ${typeLabel} maintenance that will impact your service at location ${address}.

Your vCom provided circuit ${circuitId} will be subject to an outage lasting ${duration} during this maintenance window (Please note this is an estimate and no guarantee of actual impact). This maintenance is for ${reason}.

• Start time: ${startTime}
• End time: ${endTime}

If you experience service issues after that window, you may need to reboot your equipment. If you continue to have any problems, call our toll-free Technical Support number 800-804-8266 opt 3, and refer to this ticket for further assistance.`;

  const UPDATE_HTML = `<div>
${P('Hello Team,')}
${P(`This is a status update on the <strong>${esc(typeLabel)}</strong> maintenance currently being performed by <strong>${esc(carrier)}</strong> at <strong>${esc(address)}</strong>.`)}
${UL([
   `<strong>Circuit:</strong> ${esc(circuitId)}`,
   `<strong>Maintenance window:</strong> ${esc(startTime)} &rarr; ${esc(endTime)} (${esc(duration)})`,
   `<strong>Reason:</strong> ${esc(reason)}`,
   `<strong>Current status:</strong> [in progress / extended / awaiting carrier confirmation]`,
   `<strong>Next update expected:</strong> [time]`,
 ])}
${P(`We will continue to monitor the work and notify you as soon as the maintenance is complete. If you experience any urgent issue in the meantime, please call <strong>800-804-8266 opt 3</strong>.`)}
</div>`;

  const UPDATE_TEXT = `Hello Team,

This is a status update on the ${typeLabel} maintenance currently being performed by ${carrier} at ${address}.

• Circuit: ${circuitId}
• Maintenance window: ${startTime} → ${endTime} (${duration})
• Reason: ${reason}
• Current status: [in progress / extended / awaiting carrier confirmation]
• Next update expected: [time]

We will continue to monitor the work and notify you as soon as the maintenance is complete. If you experience any urgent issue in the meantime, please call 800-804-8266 opt 3.`;

  const COMPLETE_HTML = `<div>
${P('Hello Team,')}
${P(`The <strong>${esc(typeLabel)}</strong> maintenance performed by <strong>${esc(carrier)}</strong> at <strong>${esc(address)}</strong> is now <strong>complete</strong>.`)}
${UL([
   `<strong>Circuit:</strong> ${esc(circuitId)}`,
   `<strong>Maintenance window:</strong> ${esc(startTime)} &rarr; ${esc(endTime)}`,
   `<strong>Reason:</strong> ${esc(reason)}`,
   `<strong>Service status:</strong> Restored &mdash; vCom has verified the circuit is operational.`,
 ])}
${P(`If you continue to experience any issue with this service, please reboot your equipment first. If the problem persists, call our toll-free Technical Support number <strong>800-804-8266 opt 3</strong> and reference this ticket.`)}
${P('Thank you for your patience during this maintenance window.')}
</div>`;

  const COMPLETE_TEXT = `Hello Team,

The ${typeLabel} maintenance performed by ${carrier} at ${address} is now complete.

• Circuit: ${circuitId}
• Maintenance window: ${startTime} → ${endTime}
• Reason: ${reason}
• Service status: Restored — vCom has verified the circuit is operational.

If you continue to experience any issue with this service, please reboot your equipment first. If the problem persists, call our toll-free Technical Support number 800-804-8266 opt 3 and reference this ticket.

Thank you for your patience during this maintenance window.`;

  // Internal handover — bullet list for fields, no signature
  const INTERNAL_HTML = `<div>
${P(`<strong>Maintenance handover &mdash; ${esc(carrier)}</strong>`)}
${UL([
   `<strong>Type:</strong> ${esc(typeLabel)}${type === 'emergency' ? ' &#9888;&#65039;' : ''}`,
   `<strong>Circuit:</strong> ${esc(circuitId)}`,
   `<strong>Site:</strong> ${esc(address)}`,
   `<strong>Window:</strong> ${esc(startTime)} &rarr; ${esc(endTime)} (${esc(duration)})`,
   `<strong>Reason:</strong> ${esc(reason)}`,
   `<strong>Customer notified:</strong> [Y/N &mdash; who, when]`,
   `<strong>Action for next shift:</strong> [confirm completion / send update at HH:MM / escalate to L2 if not restored by HH:MM]`,
 ])}
</div>`;

  const INTERNAL_TEXT = `Maintenance handover — ${carrier}

• Type: ${typeLabel}${type === 'emergency' ? ' ⚠️' : ''}
• Circuit: ${circuitId}
• Site: ${address}
• Window: ${startTime} → ${endTime} (${duration})
• Reason: ${reason}
• Customer notified: [Y/N — who, when]
• Action for next shift: [confirm completion / send update at HH:MM / escalate to L2 if not restored by HH:MM]`;

  const richHtml  = variant === 'notice' ? NOTICE_HTML   : variant === 'update' ? UPDATE_HTML   : variant === 'complete' ? COMPLETE_HTML   : INTERNAL_HTML;
  const plainText = variant === 'notice' ? NOTICE_TEXT   : variant === 'update' ? UPDATE_TEXT   : variant === 'complete' ? COMPLETE_TEXT   : INTERNAL_TEXT;

  const copyRichNote = async () => {
    const ok = await copyRichAndPlain(richHtml, plainText);
    if (ok) {
      flashCopied('rich');
      toast.success('Copied — paragraph spacing + bold preserved in Outlook/Gmail/Slack', {
        duration: 2400,
      });
    } else {
      toast.error(
        'Clipboard blocked. Select the note text below and press Ctrl/Cmd+C to copy manually.',
        { duration: 4500 },
      );
    }
  };

  const copyPlainNote = async () => {
    const ok = await copyPlainOnly(plainText);
    if (ok) {
      flashCopied('plain');
      toast.success('Copied as plain text', { duration: 1800 });
    } else {
      toast.error('Clipboard blocked. Select the text below and press Ctrl/Cmd+C.', {
        duration: 4500,
      });
    }
  };

  return (
    <div className="space-y-5 animate-fade-in">
      {hasWarnings && (
        <div className="flex items-start gap-2 p-3 bg-amber-50 dark:bg-amber-900/10 rounded-lg border border-amber-200 dark:border-amber-800/30">
          <AlertTriangle className="w-4 h-4 text-amber-500 mt-0.5 flex-shrink-0" />
          <p className="text-sm text-amber-700 dark:text-amber-400">
            Some fields could not be auto-detected. Please review and fill in manually before sending.
          </p>
        </div>
      )}

      <div className="card">
        <h3 className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-3">Parsed Fields</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {fields.map(({ label, field }) => (
            <div key={label} className="flex items-center justify-between gap-2 px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-700/50">
              <div className="flex-1 min-w-0">
                <span className="text-xs text-slate-500 dark:text-slate-400">{label}</span>
                <p className="text-sm font-medium text-slate-900 dark:text-slate-100 truncate">{field.value}</p>
              </div>
              <ConfidenceIndicator level={field.confidence} />
            </div>
          ))}
        </div>
      </div>

      <div className="card">
        {/* Variant selector — Notification / Update / Complete / Internal */}
        <div className="flex items-center gap-1.5 mb-3 flex-wrap">
          {VARIANTS.map((v) => {
            const Icon = v.icon;
            const isActive = variant === v.key;
            return (
              <button
                key={v.key}
                onClick={() => setVariant(v.key)}
                className={`inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-md transition-colors ${
                  isActive
                    ? 'bg-primary-100 dark:bg-primary-500/20 text-primary-700 dark:text-primary-300 ring-1 ring-primary-300 dark:ring-primary-500/40'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
                title={v.blurb}
              >
                <Icon className="w-3 h-3" />
                {v.label}
              </button>
            );
          })}
        </div>
        <p className="text-[11px] text-slate-500 dark:text-slate-400 mb-3">
          {VARIANTS.find((v) => v.key === variant)!.blurb}
        </p>

        {/* Subject line — one-click copy */}
        <div className="mb-3 flex items-center gap-2 px-3 py-2 rounded-md bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700">
          <span className="text-[10px] uppercase tracking-wide font-semibold text-slate-500 dark:text-slate-400 flex-shrink-0">Subject</span>
          <p className="flex-1 min-w-0 text-xs font-mono text-slate-700 dark:text-slate-200 truncate" title={subject}>{subject}</p>
          <button
            onClick={async () => {
              const ok = await copyPlainOnly(subject);
              if (ok) { flashCopied('subject'); toast.success('Subject copied'); }
              else toast.error('Copy failed');
            }}
            className="flex-shrink-0 inline-flex items-center gap-1 px-2 py-0.5 text-[11px] font-medium rounded bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200"
            title="Copy subject line"
          >
            {copied === 'subject' ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
            Copy
          </button>
        </div>

        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold text-slate-700 dark:text-slate-300">
            {type === 'emergency' ? '⚠️ Emergency' : '📋 Scheduled'} · {VARIANTS.find((v) => v.key === variant)!.label}
          </h3>
          <div className="flex items-center gap-2">
            <Button variant="secondary" size="sm" onClick={copyRichNote}>
              {copied === 'rich' ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-500" />
                  Copied
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  Copy
                </>
              )}
            </Button>
            <Button variant="ghost" size="sm" onClick={copyPlainNote} title="Copy as plain text (no formatting)">
              {copied === 'plain' ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-500" />
                  Copied
                </>
              ) : (
                <>
                  <FileText className="w-3.5 h-3.5" />
                  Plain
                </>
              )}
            </Button>
          </div>
        </div>

        {/* Preview — respects the EXACT inline margin styles in the HTML
            (no Tailwind 'prose' overrides) so what you see is what you paste. */}
        <div
          className="bg-slate-50 dark:bg-slate-900 rounded-lg p-5 border border-slate-200 dark:border-slate-700 text-sm leading-relaxed text-slate-800 dark:text-slate-200 maintenance-preview"
          dangerouslySetInnerHTML={{ __html: richHtml }}
        />
        <style dangerouslySetInnerHTML={{ __html: `
          .maintenance-preview strong { color: inherit; font-weight: 700; }
          .maintenance-preview p { line-height: 1.5; }
        ` }} />

        <p className="mt-3 text-xs text-slate-400 dark:text-slate-500 leading-relaxed">
          <strong>Copy</strong> pastes as a real email — bold, bullet points, and paragraph spacing all survive in Outlook, Gmail, Slack, Word, ServiceNow, and Confluence. <strong>No signature line is appended</strong> (your Outlook signature handles that).{' '}
          <strong>Plain</strong> copies just the text, no formatting.{' '}
          <strong>Subject</strong> copies just the email subject line.{' '}
          You can also <strong>select any text anywhere on this site</strong> and press Ctrl/Cmd+C — the paste will keep its bold/bullets/spacing but the colors will adapt to the destination.
        </p>
      </div>
    </div>
  );
}
