import { useRef } from 'react';
import { User } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { MessageActions } from './MessageActions';
import { AIBadge } from './AIBadge';
import type { ChatMessage as ChatMessageType } from '../../types';

interface ChatMessageProps {
  message: ChatMessageType;
  isStreaming?: boolean;
  onRegenerate?: () => void;
  canRegenerate?: boolean;
}

export function ChatMessage({
  message,
  isStreaming,
  onRegenerate,
  canRegenerate,
}: ChatMessageProps) {
  const isUser = message.role === 'user';
  const renderedRef = useRef<HTMLDivElement>(null);

  // ── User message: right-aligned subtle bubble (ChatGPT style) ─────
  if (isUser) {
    return (
      <div className="flex justify-end animate-fade-in">
        <div className="max-w-[85%] rounded-2xl px-4 py-2.5 bg-slate-200/80 dark:bg-slate-700/60 text-slate-900 dark:text-slate-100">
          <div className="text-[15px] leading-relaxed whitespace-pre-wrap break-words">
            {message.content}
          </div>
        </div>
      </div>
    );
  }

  // ── Assistant message: full-width, no bubble, with avatar + actions ─
  return (
    <div className="flex gap-3 animate-fade-in group">
      <div className="flex-shrink-0 mt-0.5">
        <AIBadge size="sm" />
      </div>

      <div className="flex-1 min-w-0">
        <div
          ref={renderedRef}
          className="prose prose-slate dark:prose-invert max-w-none text-[15px] leading-relaxed
            prose-p:my-2
            prose-headings:mt-4 prose-headings:mb-2 prose-headings:font-semibold
            prose-h1:text-xl prose-h2:text-lg prose-h3:text-base
            prose-ul:my-2 prose-ol:my-2 prose-li:my-0.5
            prose-pre:my-3 prose-pre:bg-slate-900 prose-pre:text-slate-100 prose-pre:rounded-lg prose-pre:p-3
            prose-code:bg-slate-100 dark:prose-code:bg-slate-800 prose-code:px-1.5 prose-code:py-0.5 prose-code:rounded prose-code:before:hidden prose-code:after:hidden prose-code:text-[0.9em] prose-code:font-mono
            prose-a:text-primary-600 dark:prose-a:text-primary-400 hover:prose-a:underline
            prose-strong:text-slate-900 dark:prose-strong:text-slate-100 prose-strong:font-semibold
            prose-blockquote:border-l-2 prose-blockquote:border-slate-300 dark:prose-blockquote:border-slate-600 prose-blockquote:pl-3 prose-blockquote:italic prose-blockquote:text-slate-600 dark:prose-blockquote:text-slate-400
            break-words"
        >
          <ReactMarkdown
            components={{
              a: ({ node: _node, ...props }) => (
                <a {...props} target="_blank" rel="noreferrer" />
              ),
            }}
          >
            {message.content || (isStreaming ? '…' : '')}
          </ReactMarkdown>
        </div>

        {/* Action toolbar — only after stream completes & content exists */}
        {!isStreaming && message.content && (
          <MessageActions
            renderedRef={renderedRef}
            rawMarkdown={message.content}
            onRegenerate={onRegenerate}
            canRegenerate={canRegenerate}
          />
        )}

        {/* Cursor while streaming */}
        {isStreaming && message.content && (
          <span className="inline-block w-1.5 h-4 bg-slate-400 dark:bg-slate-500 animate-pulse ml-0.5 align-middle" />
        )}
      </div>

      {/* Hidden spacer to balance user avatar style on user messages — keeps grid */}
      <div className="hidden">
        <User />
      </div>
    </div>
  );
}
