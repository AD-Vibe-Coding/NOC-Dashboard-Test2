import { useState } from 'react';
import { Copy, Check, RefreshCw } from 'lucide-react';
import toast from 'react-hot-toast';
import {
  copyRichAndPlain,
  copyPlainOnly,
  cleanRenderedHtml,
  renderedNodeToPlain,
} from '../../lib/clipboard-rich';

interface Props {
  renderedRef: React.RefObject<HTMLDivElement>;
  /** Raw markdown source — used as the plain-text fallback if DOM walk fails. */
  rawMarkdown: string;
  onRegenerate?: () => void;
  canRegenerate?: boolean;
}

export function MessageActions({
  renderedRef,
  rawMarkdown,
  onRegenerate,
  canRegenerate,
}: Props) {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const flash = (key: string) => {
    setCopiedKey(key);
    setTimeout(() => setCopiedKey((k) => (k === key ? null : k)), 1500);
  };

  const copyFormatted = async () => {
    const html = cleanRenderedHtml(renderedRef.current);
    const plain = renderedNodeToPlain(renderedRef.current) || rawMarkdown;
    const ok = await copyRichAndPlain(html, plain);
    if (ok) {
      flash('rich');
      toast.success('Copied (rich + plain)', { duration: 1500 });
    } else {
      toast.error('Copy failed');
    }
  };

  const copyPlain = async () => {
    const plain = renderedNodeToPlain(renderedRef.current) || rawMarkdown;
    const ok = await copyPlainOnly(plain);
    if (ok) {
      flash('plain');
      toast.success('Copied plain text', { duration: 1500 });
    } else {
      toast.error('Copy failed');
    }
  };

  return (
    <div className="flex items-center gap-1 mt-1.5 -ml-1.5 opacity-0 group-hover:opacity-100 focus-within:opacity-100 transition-opacity">
      <button
        onClick={copyFormatted}
        className="flex items-center gap-1 px-2 py-1 rounded-md text-[11px] font-medium text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700/60 hover:text-slate-700 dark:hover:text-slate-200 transition-colors"
        title="Copy with formatting (bold, bullets, links) — paste into Outlook, Slack, Word, ServiceNow, Confluence"
      >
        {copiedKey === 'rich' ? (
          <Check className="w-3.5 h-3.5 text-emerald-500" />
        ) : (
          <Copy className="w-3.5 h-3.5" />
        )}
        Copy
      </button>
      <button
        onClick={copyPlain}
        className="flex items-center gap-1 px-2 py-1 rounded-md text-[11px] font-medium text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700/60 hover:text-slate-700 dark:hover:text-slate-200 transition-colors"
        title="Copy as plain text only (no formatting)"
      >
        {copiedKey === 'plain' ? (
          <Check className="w-3.5 h-3.5 text-emerald-500" />
        ) : (
          <Copy className="w-3.5 h-3.5" />
        )}
        Plain
      </button>
      {onRegenerate && canRegenerate && (
        <button
          onClick={onRegenerate}
          className="flex items-center gap-1 px-2 py-1 rounded-md text-[11px] font-medium text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700/60 hover:text-slate-700 dark:hover:text-slate-200 transition-colors"
          title="Regenerate response"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          Regenerate
        </button>
      )}
    </div>
  );
}
