import { useState, useRef, useCallback } from 'react';
import { Upload, FileText, Loader2, X, AlertCircle, Zap } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { sendMessage, type AIMessage } from '../../lib/devs-ai/client';

const PCAP_SYSTEM_PROMPT = `You are a senior NOC network analyst and Wireshark expert. You will analyze PCAP/packet capture metadata and hex dumps to produce professional NOC reports.

When given PCAP data, always respond in this exact structure:

## 📋 Summary
Brief 2-3 sentence overview of what the capture shows.

## 🔍 Issues Detected
List each issue found with severity (Critical / Warning / Info):
- **[SEVERITY]** Issue description

## 📊 Notable Patterns
Key observations about traffic patterns, protocols, timing, endpoints.

## ✅ NOC Action Items
Numbered list of specific actions the NOC engineer should take.

## 🔗 Sources
Any relevant documentation or escalation paths.

Be specific with IPs, ports, protocols, timing, error codes. If you identify carrier-related issues (BGP, circuit, latency), reference standard NOC procedures.`;

interface AnalysisState {
  status: 'idle' | 'reading' | 'analyzing' | 'done' | 'error';
  fileName: string;
  fileSize: number;
  result: string;
  error: string | null;
}

function formatBytes(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 / 1024).toFixed(2)} MB`;
}

// Convert first N bytes of ArrayBuffer to hex string for AI analysis
function toHexDump(buf: ArrayBuffer, maxBytes = 4096): string {
  const bytes = new Uint8Array(buf.slice(0, maxBytes));
  const lines: string[] = [];
  for (let i = 0; i < bytes.length; i += 16) {
    const slice = bytes.slice(i, i + 16);
    const hex = Array.from(slice).map(b => b.toString(16).padStart(2, '0')).join(' ');
    const ascii = Array.from(slice).map(b => (b >= 32 && b < 127 ? String.fromCharCode(b) : '.')).join('');
    lines.push(`${i.toString(16).padStart(6, '0')}  ${hex.padEnd(47)}  |${ascii}|`);
    if (lines.length >= 64) { lines.push('... (truncated)'); break; }
  }
  return lines.join('\n');
}

// Parse PCAP global header to extract basic metadata
function parsePcapHeader(buf: ArrayBuffer): { linkType: string; snapLen: number; bigEndian: boolean } | null {
  if (buf.byteLength < 24) return null;
  const view = new DataView(buf);
  const magic = view.getUint32(0, true);
  const bigEndian = magic === 0xa1b2c3d4 ? false : magic === 0xd4c3b2a1 ? true : null;
  if (bigEndian === null) return null;
  const le = !bigEndian;
  const snapLen = view.getUint32(16, le);
  const linkType = view.getUint32(20, le);
  const linkNames: Record<number, string> = { 1: 'Ethernet', 6: 'Ethernet 802.3', 101: 'Raw IP', 105: 'IEEE 802.11 WiFi', 113: 'Linux SLL', 127: 'IEEE 802.11 Radiotap' };
  return { linkType: linkNames[linkType] ?? `Link type ${linkType}`, snapLen, bigEndian };
}

export function PCAPAnalyzer() {
  const [state, setState] = useState<AnalysisState>({
    status: 'idle', fileName: '', fileSize: 0, result: '', error: null,
  });
  const [dragging, setDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const abortRef = useRef<AbortController | null>(null);

  const analyze = useCallback(async (file: File) => {
    setState({ status: 'reading', fileName: file.name, fileSize: file.size, result: '', error: null });

    let buf: ArrayBuffer;
    try {
      buf = await file.arrayBuffer();
    } catch (e) {
      setState(s => ({ ...s, status: 'error', error: 'Failed to read file: ' + (e as Error).message }));
      return;
    }

    const pcapMeta = parsePcapHeader(buf);
    const hexDump = toHexDump(buf, 4096);
    const isPcapNg = buf.byteLength >= 4 && new DataView(buf).getUint32(0, true) === 0x0A0D0D0A;

    const prompt = `Analyze this PCAP packet capture file and provide a professional NOC report.

**File Details:**
- Name: ${file.name}
- Size: ${formatBytes(file.size)}
- Format: ${isPcapNg ? 'PCAP-NG' : pcapMeta ? 'PCAP (libpcap)' : 'Unknown/Binary'}
${pcapMeta ? `- Link Type: ${pcapMeta.linkType}\n- Snap Length: ${pcapMeta.snapLen} bytes\n- Byte Order: ${pcapMeta.bigEndian ? 'Big-endian' : 'Little-endian'}` : ''}

**First ${Math.min(buf.byteLength, 4096)} bytes (hex dump):**
\`\`\`
${hexDump}
\`\`\`

Based on the hex dump and file metadata above, provide a detailed NOC analysis report.
Identify: protocols visible, source/destination IPs if visible, any error patterns, timing issues, and specific NOC action items.`;

    setState(s => ({ ...s, status: 'analyzing' }));

    const messages: AIMessage[] = [
      { role: 'system', content: PCAP_SYSTEM_PROMPT },
      { role: 'user', content: prompt },
    ];

    abortRef.current = new AbortController();
    let assembled = '';

    await sendMessage(
      messages,
      delta => {
        assembled += delta;
        setState(s => ({ ...s, result: assembled }));
      },
      () => setState(s => ({ ...s, status: 'done' })),
      err => setState(s => ({ ...s, status: 'error', error: err })),
      { signal: abortRef.current.signal },
    );
  }, []);

  const handleFile = (file: File) => {
    if (!/\.(pcap|pcapng|cap)$/i.test(file.name)) {
      setState(s => ({ ...s, status: 'error', error: 'Please upload a .pcap, .pcapng, or .cap file', fileName: file.name, fileSize: file.size }));
      return;
    }
    analyze(file);
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  };

  const reset = () => {
    abortRef.current?.abort();
    setState({ status: 'idle', fileName: '', fileSize: 0, result: '', error: null });
  };

  return (
    <div className="flex flex-col h-full p-4 space-y-4 overflow-y-auto">
      {/* Drop zone */}
      {state.status === 'idle' || state.status === 'error' ? (
        <div>
          <div
            onDragOver={e => { e.preventDefault(); setDragging(true); }}
            onDragLeave={() => setDragging(false)}
            onDrop={onDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-xl p-10 text-center cursor-pointer transition-all ${
              dragging
                ? 'border-primary-500 bg-primary-50 dark:bg-primary-500/10'
                : 'border-slate-300 dark:border-slate-600 hover:border-primary-400 dark:hover:border-primary-500/50 hover:bg-slate-50 dark:hover:bg-slate-800/50'
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".pcap,.pcapng,.cap"
              className="hidden"
              onChange={e => { const f = e.target.files?.[0]; if (f) handleFile(f); }}
            />
            <Upload className="w-10 h-10 mx-auto mb-3 text-slate-400" />
            <p className="text-sm font-medium text-slate-700 dark:text-slate-300">
              Drop a PCAP file here or click to browse
            </p>
            <p className="text-xs text-slate-400 mt-1">Supports .pcap · .pcapng · .cap</p>
            <p className="text-[11px] text-slate-400 mt-2">
              The AI analyzes the packet capture hex dump and produces a structured NOC report
            </p>
          </div>

          {state.status === 'error' && (
            <div className="mt-3 flex items-start gap-2 p-3 rounded-lg bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20">
              <AlertCircle className="w-4 h-4 text-red-500 flex-shrink-0 mt-0.5" />
              <p className="text-xs text-red-700 dark:text-red-300">{state.error}</p>
            </div>
          )}
        </div>
      ) : (
        /* Analysis in progress or done */
        <div className="space-y-4">
          {/* File info bar */}
          <div className="flex items-center gap-3 p-3 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
            <FileText className="w-5 h-5 text-primary-500 flex-shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-slate-900 dark:text-white truncate">{state.fileName}</p>
              <p className="text-xs text-slate-500">{formatBytes(state.fileSize)}</p>
            </div>
            <div className="flex items-center gap-2">
              {state.status === 'reading' && (
                <span className="text-xs text-slate-500 flex items-center gap-1">
                  <Loader2 className="w-3 h-3 animate-spin" /> Reading…
                </span>
              )}
              {state.status === 'analyzing' && (
                <span className="text-xs text-primary-600 dark:text-primary-400 flex items-center gap-1">
                  <Zap className="w-3 h-3 animate-pulse" /> Analyzing…
                </span>
              )}
              {state.status === 'done' && (
                <span className="text-xs text-emerald-600 dark:text-emerald-400 font-medium">✓ Done</span>
              )}
              <button onClick={reset} className="p-1 rounded text-slate-400 hover:text-slate-600 dark:hover:text-slate-300">
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Streaming result */}
          {state.result && (
            <div className="card prose prose-sm dark:prose-invert max-w-none overflow-x-hidden
                            prose-headings:font-semibold prose-h2:text-base prose-h2:mt-4
                            prose-strong:text-slate-900 dark:prose-strong:text-white
                            prose-code:text-xs prose-pre:text-xs prose-pre:overflow-x-auto">
              <ReactMarkdown>{state.result}</ReactMarkdown>
              {state.status === 'analyzing' && (
                <span className="inline-block w-2 h-4 bg-primary-500 animate-pulse ml-0.5 align-bottom" />
              )}
            </div>
          )}
        </div>
      )}

      {/* Info footer */}
      {state.status === 'idle' && (
        <div className="text-[11px] text-slate-400 dark:text-slate-500 space-y-1 px-1">
          <p className="font-medium text-slate-500 dark:text-slate-400">What the analyzer does:</p>
          <p>• Parses PCAP global header (link type, byte order, snap length)</p>
          <p>• Extracts first 4 KB hex dump for protocol identification</p>
          <p>• AI generates: Summary → Issues Detected → Notable Patterns → NOC Action Items</p>
          <p>• For full deep analysis, export to text with <code className="bg-slate-100 dark:bg-slate-800 px-1 rounded">tshark -r file.pcap -T text</code> and paste into AI Chat</p>
        </div>
      )}
    </div>
  );
}
