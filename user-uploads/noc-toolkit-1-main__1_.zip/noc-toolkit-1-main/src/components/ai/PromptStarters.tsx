import {
  Smartphone,
  Zap,
  Wrench,
  CheckSquare,
  BookOpen,
  Network,
  AlertTriangle,
  Phone,
} from 'lucide-react';

export interface Starter {
  icon: typeof Smartphone;
  label: string;
  prompt: string;
}

/**
 * Starter prompts shown when the chat is empty. All starters route the user
 * toward NOC + Mobility + Network + Carrier workflows that the agent is
 * auto-grounded against (server-side Confluence search injects context).
 */
export const STARTERS: Starter[] = [
  {
    icon: Smartphone,
    label: 'Mobility troubleshooting',
    prompt:
      'Help me troubleshoot a Mobility issue. Walk me through the right diagnostic flow based on what I describe.\n\n--- THE ISSUE ---\n[describe device, carrier, symptoms]',
  },
  {
    icon: Zap,
    label: 'Ticket fault types',
    prompt:
      'What does iPath fault type "Unreachable from 2+ global site monitors" mean and how should the NOC respond? Cite the relevant Confluence page if available.',
  },
  {
    icon: Smartphone,
    label: 'iPhone activation issues',
    prompt:
      'A user reports their iPhone is stuck on the activation screen on our corporate plan. Walk me through the most-likely-first checklist and the escalation triggers.',
  },
  {
    icon: CheckSquare,
    label: 'Activation assistance',
    prompt:
      'I need to activate a new line. Walk me through the activation steps for the carrier I specify (Telispire / Quantum Shift / Verizon / AT&T), and cite the Confluence task template.\n\n--- DETAILS ---\nCarrier: \nDevice IMEI: \nSIM ICCID:',
  },
  {
    icon: BookOpen,
    label: 'Ask the vCom wiki',
    prompt:
      'Search the vCom Confluence wiki for: [your question or page title here]. Summarize the most relevant pages and cite them.',
  },
  {
    icon: Network,
    label: 'Network troubleshooting',
    prompt:
      'Network troubleshooting — a circuit is down with no ping. Walk me through the NOC diagnostic order (carrier-side vs CPE-side) and when to escalate.',
  },
  {
    icon: AlertTriangle,
    label: 'Carrier escalation — when & who',
    prompt:
      'When should I escalate to a carrier, and who do I call? For [Carrier], give me the L1 → L5 escalation matrix with the criteria for each level. Cite the Confluence escalation page.',
  },
  {
    icon: Phone,
    label: 'Find a support phone number',
    prompt:
      'Find me the current NOC support phone number and email for [Carrier]. Cite the Confluence page where it lives.',
  },
];
