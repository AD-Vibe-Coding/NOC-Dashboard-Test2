/**
 * AIBadge — custom SVG mark used as the AI/assistant identity icon across
 * the app (chat avatar, sidebar nav, header, dashboard tile, empty state).
 *
 * Self-contained SVG (no extra deps). Works on light + dark backgrounds.
 * Includes:
 *   - gradient orb body
 *   - inner "core" + 3 circuit-style nodes connected by faint lines
 *   - subtle highlight for depth
 */

import { useId, type CSSProperties } from 'react';

export type AIBadgeSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl';

const SIZE_PX: Record<AIBadgeSize, number> = {
  xs: 18,
  sm: 28,
  md: 36,
  lg: 64,
  xl: 96,
};

interface AIBadgeProps {
  size?: AIBadgeSize;
  className?: string;
  style?: CSSProperties;
  /** Override numeric pixel size (takes precedence over `size`). */
  px?: number;
  title?: string;
}

export function AIBadge({
  size = 'md',
  className = '',
  style,
  px,
  title = 'AI Assistant',
}: AIBadgeProps) {
  const dim = px ?? SIZE_PX[size];
  // Stable, unique gradient ids per mounted instance so duplicate <svg>s
  // don't collide on their defs.
  const idSuffix = useId().replace(/:/g, '');

  return (
    <svg
      width={dim}
      height={dim}
      viewBox="0 0 64 64"
      xmlns="http://www.w3.org/2000/svg"
      role="img"
      aria-label={title}
      className={className}
      style={style}
    >
      <defs>
        <linearGradient
          id={`aibadge-body-${idSuffix}`}
          x1="0%"
          y1="0%"
          x2="100%"
          y2="100%"
        >
          <stop offset="0%" stopColor="#6366F1" />
          <stop offset="55%" stopColor="#8B5CF6" />
          <stop offset="100%" stopColor="#22D3EE" />
        </linearGradient>
        <radialGradient
          id={`aibadge-glow-${idSuffix}`}
          cx="50%"
          cy="38%"
          r="60%"
        >
          <stop offset="0%" stopColor="#ffffff" stopOpacity="0.55" />
          <stop offset="100%" stopColor="#ffffff" stopOpacity="0" />
        </radialGradient>
        <linearGradient
          id={`aibadge-core-${idSuffix}`}
          x1="0%"
          y1="0%"
          x2="100%"
          y2="100%"
        >
          <stop offset="0%" stopColor="#ffffff" stopOpacity="0.95" />
          <stop offset="100%" stopColor="#E0E7FF" stopOpacity="0.85" />
        </linearGradient>
      </defs>

      {/* Outer rounded squircle body */}
      <rect
        x="2"
        y="2"
        width="60"
        height="60"
        rx="16"
        fill={`url(#aibadge-body-${idSuffix})`}
      />

      {/* Soft highlight */}
      <rect
        x="2"
        y="2"
        width="60"
        height="60"
        rx="16"
        fill={`url(#aibadge-glow-${idSuffix})`}
      />

      {/* Circuit lines connecting outer nodes to core */}
      <g
        stroke="#ffffff"
        strokeOpacity="0.55"
        strokeWidth="1.5"
        strokeLinecap="round"
        fill="none"
      >
        <line x1="32" y1="32" x2="14" y2="14" />
        <line x1="32" y1="32" x2="50" y2="14" />
        <line x1="32" y1="32" x2="14" y2="50" />
        <line x1="32" y1="32" x2="50" y2="50" />
      </g>

      {/* Outer nodes */}
      <g fill="#ffffff">
        <circle cx="14" cy="14" r="3" />
        <circle cx="50" cy="14" r="3" />
        <circle cx="14" cy="50" r="3" />
        <circle cx="50" cy="50" r="3" />
      </g>

      {/* Core orb */}
      <circle
        cx="32"
        cy="32"
        r="9"
        fill={`url(#aibadge-core-${idSuffix})`}
        stroke="#ffffff"
        strokeOpacity="0.4"
        strokeWidth="1"
      />
      {/* Core inner sparkle */}
      <circle cx="29" cy="29" r="2.2" fill="#ffffff" fillOpacity="0.9" />
    </svg>
  );
}

