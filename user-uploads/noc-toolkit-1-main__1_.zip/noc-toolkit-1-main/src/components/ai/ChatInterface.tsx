import { useState, useRef, useEffect, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  Send, Square, Loader2, AlertCircle, BookOpen,
  Plus, X, FileText, Image as ImageIcon, Upload, History,
  MessageSquare, Sparkles, Mail, FileEdit, Trash2,
  ClipboardList, AlertTriangle, Smartphone, Network, PenLine,
  Copy, Check, PanelRightOpen, PanelRightClose,
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { ChatMessage } from './ChatMessage';
import { STARTERS } from './PromptStarters';
import { AIBadge } from './AIBadge';
import { DevsAiBadge, CompanyBadge } from '../ui/Brand';
import { sendMessage, type AIMessage } from '../../lib/devs-ai/client';
import { searchConfluence, formatConfluenceContext } from '../../lib/confluence/client';
import { useAISettings } from '../../hooks/useAISettings';
import { useAuth } from '../../hooks/useAuth';
import { getChatHistory, saveChat, deleteChat as deleteChatDB, chatTitle, type SavedChat } from '../../lib/chats/db';
import type { ChatMessage as ChatMessageType } from '../../types';

// ─── System prompt — open, helpful, NOC-first ──────────────────────────────
const NOC_SYSTEM_PROMPT = `You are the NOC AI Assistant for AppDirect / vCom BU — your team's all-in-one helper for network operations, mobility, carriers, Wireshark, and everything in between. You are friendly, helpful, and technically deep.

KNOWLEDGE PRIORITY ORDER:
1. FIRST — Any Confluence/wiki pages provided → these are your ground truth for company-specific SOPs, contacts, procedures, device configs, escalation paths. Cite them as [1], [2] inline.
2. SECOND — Your deep technical knowledge: networking, NOC operations, mobility (iOS/Android/SIM/eSIM), Wireshark/packet analysis, Cisco/Fortinet/Meraki/SD-WAN/Juniper/Palo Alto, LogicMonitor, carrier management.
3. THIRD — General knowledge for anything else.

WHAT YOU DO (answer all of these deeply):
✓ Network troubleshooting — any vendor, any protocol, exact CLI commands always
✓ Wireshark / tshark / tcpdump / PCAP analysis → structured NOC reports
✓ Carrier escalations, maintenance notifications, customer update drafts
✓ Mobility: iPhone/iPad/Android, SIM/eSIM, APN, carrier provisioning
✓ Email summarization, note rewriting, shift handoffs, RCA drafts
✓ LogicMonitor/PRTG/SolarWinds alert interpretation and action steps
✓ IP/subnet math, CIDR, BGP, OSPF, VLANs, NAT, DNS, DHCP
✓ File analysis: uploaded logs, configs, Wireshark exports, error reports
✓ Fun questions, jokes, general knowledge — yes, answer these too! You are a team member, not a gatekeeper.

RESPONSE STYLE:
- Lead with the answer. Never start with "Great question!" or "Sure, I'd be happy to…"
- Numbered steps for procedures. Most-likely cause first for troubleshooting.
- Bold key values: IPs, port numbers, ticket numbers, circuit IDs, times.
- Inline code for CLI commands. Fenced blocks for multi-line configs or logs.
- Wireshark/PCAP analysis format: ## Summary → ## Issues Detected → ## Notable Patterns → ## NOC Action Items
- Operational writing: clean markdown ready to paste into ServiceNow / Outlook / Slack / Confluence
- End troubleshooting answers with: "**When to escalate:** ..."
- For Confluence citations: cite inline as [1], [2] with a Sources section at end.
- For fun/off-topic questions: answer briefly and helpfully.`;

// ─── Types ─────────────────────────────────────────────────────────────────
interface Attachment {
  id: string;
  name: string;
  type: string;
  size: number;
  content: string;   // text content or description for non-text files
  isText: boolean;
  preview?: string;  // data URL for images
}

// ─── Quick action templates ─────────────────────────────────────────────────
const QUICK_ACTIONS = [
  { icon: Mail,         label: 'Summarize Email',          prompt: 'Summarize this email with a TL;DR, key action items, and a suggested reply:\n\n[PASTE EMAIL HERE]' },
  { icon: FileEdit,     label: 'Rewrite for Customer',     prompt: 'Rewrite these notes into a professional, customer-facing update:\n\n[PASTE NOTES HERE]' },
  { icon: ClipboardList,label: 'Shift Handoff',            prompt: 'Create a structured shift handoff summary from these notes:\n\n[PASTE SHIFT NOTES HERE]' },
  { icon: AlertTriangle,label: 'Carrier Escalation',       prompt: 'Write a carrier escalation script for:\nCarrier: [CARRIER NAME]\nCircuit ID: [CIRCUIT ID]\nIssue: [DESCRIBE ISSUE]\nTicket #: [TICKET]' },
  { icon: PenLine,      label: 'Maintenance Notification', prompt: 'Write a customer maintenance notification:\nCarrier: [CARRIER]\nCircuit: [CIRCUIT ID]\nStart: [DATE/TIME]\nEnd: [DATE/TIME]\nImpact: [IMPACT DESCRIPTION]' },
  { icon: FileText,     label: 'RCA Draft',                prompt: 'Help me write a Root Cause Analysis:\nIncident: [DESCRIBE INCIDENT]\nStart: [TIME]\nResolved: [TIME]\nImpact: [WHAT WAS AFFECTED]' },
  { icon: Smartphone,   label: 'Mobility Flow',            prompt: 'Walk me through a Mobility troubleshooting flow for:\nDevice: [DEVICE TYPE]\nCarrier: [CARRIER]\nIssue: [DESCRIBE ISSUE]' },
  { icon: Network,      label: 'Network Diagnostic',       prompt: 'Give me a structured network diagnostic checklist for:\nDevice: [DEVICE/HOSTNAME]\nSymptom: [DESCRIBE SYMPTOM]\nCircuit Type: [FIBER/CABLE/DSL/LTE]' },
];

// ─── Helpers ───────────────────────────────────────────────────────────────
function createId() { return Date.now().toString(36) + Math.random().toString(36).substring(2, 7); }
function timeAgo(iso: string): string {
  const diff = Math.floor((Date.now() - new Date(iso).getTime()) / 1000);
  if (diff < 60) return 'just now';
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  return `${Math.floor(diff / 86400)}d ago`;
}
const ACCEPTED_TYPES = '.txt,.log,.csv,.json,.md,.pcap,.pcapng,.cap,.pdf,.doc,.docx,.xlsx,.xls,.png,.jpg,.jpeg,.gif,.webp';

// ─── Component ─────────────────────────────────────────────────────────────
export function ChatInterface() {
  const { user } = useAuth();
  const [messages, setMessages] = useState<ChatMessageType[]>([]);
  const [currentChatId, setCurrentChatId] = useState<string>(() => createId());
  const [chatHistory, setChatHistory] = useState<SavedChat[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [input, setInput] = useState('');
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [confluenceStatus, setConfluenceStatus] = useState<string | null>(null);
  const [showHistory, setShowHistory] = useState(false);
  const [showQuickActions, setShowQuickActions] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const saveTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef    = useRef<HTMLTextAreaElement>(null);
  const fileInputRef   = useRef<HTMLInputElement>(null);
  const abortRef       = useRef<AbortController | null>(null);
  const [searchParams, setSearchParams] = useSearchParams();

  const { modelOverride, confluence, confluenceReady } = useAISettings();

  // Load chat history from Supabase on mount
  useEffect(() => {
    if (!user) return;
    setHistoryLoading(true);
    getChatHistory(user.id).then(h => { setChatHistory(h); setHistoryLoading(false); });
  }, [user?.id]);

  useEffect(() => { messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  // Pick up prefill prompt from URL
  useEffect(() => {
    const prompt = searchParams.get('prompt');
    if (prompt) {
      setInput(prompt);
      searchParams.delete('prompt');
      setSearchParams(searchParams, { replace: true });
      setTimeout(() => textareaRef.current?.focus(), 50);
    }
  }, []);

  // Auto-save to Supabase — debounced, fires when AI finishes responding
  useEffect(() => {
    if (!user || messages.length < 2) return;
    const lastMsg = messages[messages.length - 1];
    if (lastMsg.role !== 'assistant' || !lastMsg.content) return;

    // Debounce 1.5s so we don't write on every streaming token
    if (saveTimerRef.current) clearTimeout(saveTimerRef.current);
    saveTimerRef.current = setTimeout(async () => {
      await saveChat(currentChatId, user.id, messages);
      // Refresh history list
      const h = await getChatHistory(user.id);
      setChatHistory(h);
    }, 1500);

    return () => { if (saveTimerRef.current) clearTimeout(saveTimerRef.current); };
  }, [messages, currentChatId, user?.id]);

  // File upload handler
  const handleFileUpload = useCallback(async (files: FileList | null) => {
    if (!files?.length) return;
    const newAtts: Attachment[] = [];
    for (const file of Array.from(files)) {
      const id = createId();
      const isImage = file.type.startsWith('image/');
      const isText = file.type.startsWith('text/') ||
        /\.(txt|log|csv|json|md|pcap|pcapng|cap|xml|yml|yaml|conf|config|syslog)$/i.test(file.name);
      const isPcap = /\.(pcap|pcapng|cap)$/i.test(file.name);

      if (isImage) {
        const dataUrl = await new Promise<string>(res => {
          const reader = new FileReader();
          reader.onload = e => res(e.target?.result as string);
          reader.readAsDataURL(file);
        });
        newAtts.push({ id, name: file.name, type: file.type, size: file.size,
          content: `[Image: ${file.name}]`, isText: false, preview: dataUrl });
      } else if (isPcap) {
        newAtts.push({ id, name: file.name, type: file.type, size: file.size,
          content: `[PCAP file: ${file.name} (${(file.size/1024).toFixed(1)} KB) — binary capture file. If you have tshark installed, run: tshark -r "${file.name}" -T text to get text output for analysis.]`,
          isText: false });
      } else if (isText || file.size < 500_000) {
        const text = await file.text();
        newAtts.push({ id, name: file.name, type: file.type, size: file.size,
          content: text.slice(0, 50_000) + (text.length > 50_000 ? '\n...[truncated]' : ''),
          isText: true });
      } else {
        newAtts.push({ id, name: file.name, type: file.type, size: file.size,
          content: `[File: ${file.name} (${(file.size/1024/1024).toFixed(1)} MB) — binary file, text content not extracted]`,
          isText: false });
      }
    }
    setAttachments(prev => [...prev, ...newAtts]);
    setShowQuickActions(false);
  }, []);

  // Core send
  const runSend = useCallback(async (userText: string, replaceLast = false) => {
    setError(null);
    setConfluenceStatus(null);

    // Build attachment context
    const attContext = attachments.length > 0
      ? '\n\n---\n**Attached files:**\n' + attachments.map(a =>
          a.isText
            ? `\n**${a.name}:**\n\`\`\`\n${a.content}\n\`\`\``
            : `\n${a.content}`
        ).join('\n')
      : '';

    const fullText = userText + attContext;

    let workingMessages: ChatMessageType[];
    if (replaceLast) {
      workingMessages = (() => {
        const arr = [...messages];
        if (arr.length && arr[arr.length - 1].role === 'assistant') arr.pop();
        return arr;
      })();
    } else {
      workingMessages = [...messages, { id: createId(), role: 'user', content: fullText, timestamp: new Date() }];
    }

    setMessages([...workingMessages, { id: createId(), role: 'assistant', content: '', timestamp: new Date() }]);
    setIsLoading(true);
    setAttachments([]);
    const abort = new AbortController();
    abortRef.current = abort;

    try {
      // Confluence lookup
      let confluenceBlock = '';
      if (confluenceReady) {
        setConfluenceStatus('Searching Confluence…');
        const res = await searchConfluence(confluence, userText, 6);
        if (res.error) {
          setConfluenceStatus(`Confluence: ${res.error}`);
        } else if (res.results.length) {
          confluenceBlock = formatConfluenceContext(res.results);
          setConfluenceStatus(`Grounded with ${res.results.length} Confluence page(s)`);
        } else {
          setConfluenceStatus('Confluence: no matching pages');
        }
      }

      const history: AIMessage[] = [
        { role: 'system', content: NOC_SYSTEM_PROMPT },
        ...workingMessages.filter(m => m.role !== 'system' && m.content).map((m, idx, arr) => {
          const isLastUser = m.role === 'user' && arr.slice(idx + 1).every(x => x.role !== 'user');
          if (isLastUser && confluenceBlock) {
            return { role: 'user' as const, content: `${confluenceBlock}\n\n---\nUser: ${m.content}` };
          }
          return { role: m.role as AIMessage['role'], content: m.content };
        }),
      ];

      const model = modelOverride || undefined;
      let assembled = '';
      await sendMessage(history,
        delta => {
          assembled += delta;
          setMessages(prev => {
            const updated = [...prev];
            updated[updated.length - 1] = { ...updated[updated.length - 1], content: assembled };
            return updated;
          });
        },
        () => setIsLoading(false),
        err => { setError(err); setIsLoading(false); },
        { signal: abort.signal, ...(model ? { model } : {}) },
      );
    } catch (err: any) {
      if (err?.name !== 'AbortError') setError(err?.message ?? 'Request failed');
      setIsLoading(false);
    }
  }, [messages, attachments, confluenceReady, confluence, modelOverride]);

  const handleSend = async () => {
    if ((!input.trim() && !attachments.length) || isLoading) return;
    const text = input.trim() || (attachments.length ? 'Please analyze the attached file(s).' : '');
    setInput('');
    await runSend(text);
  };

  const handleStop = () => { abortRef.current?.abort(); setIsLoading(false); };

  const handleRegenerate = async () => {
    if (isLoading) return;
    const lastUser = [...messages].reverse().find(m => m.role === 'user');
    if (lastUser) await runSend(lastUser.content, true);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); }
  };

  const handleClear = () => {
    if (isLoading) handleStop();
    setMessages([]); setError(null); setConfluenceStatus(null); setAttachments([]);
    setCurrentChatId(createId());
  };

  const loadChat = (chat: SavedChat) => {
    setMessages(chat.messages.map(m => ({
      ...m,
      timestamp: m.timestamp ? new Date(m.timestamp as any) : new Date(),
    })));
    setCurrentChatId(chat.id);
    setError(null); setConfluenceStatus(null); setAttachments([]);
    setShowHistory(false);
  };

  const deleteChat = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    await deleteChatDB(id);
    setChatHistory(prev => prev.filter(c => c.id !== id));
    if (id === currentChatId) handleClear();
  };

  const newChat = async () => {
    // Save current chat to Supabase before starting new
    if (user && messages.length >= 2) {
      await saveChat(currentChatId, user.id, messages);
      const h = await getChatHistory(user.id);
      setChatHistory(h);
    }
    setMessages([]); setError(null); setConfluenceStatus(null); setAttachments([]);
    setCurrentChatId(createId());
  };

  const copyMessage = (id: string, content: string) => {
    navigator.clipboard.writeText(content).then(() => {
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    });
  };

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = Math.min(textareaRef.current.scrollHeight, 200) + 'px';
    }
  }, [input]);

  const isEmpty = messages.length === 0;
  const lastAssistantIdx = (() => {
    for (let i = messages.length - 1; i >= 0; i--)
      if (messages[i].role === 'assistant') return i;
    return -1;
  })();

  return (
    <div className="flex h-full overflow-hidden">
      {/* ── History Panel ─────────────────────────────────────── */}
      {showHistory && (
        <div className="w-64 flex-shrink-0 border-r border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 flex flex-col">
          <div className="flex items-center justify-between px-3 py-2.5 border-b border-slate-200 dark:border-slate-700">
            <span className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <History className="w-3.5 h-3.5" /> Chat History
            </span>
            <button onClick={() => setShowHistory(false)} className="p-1 rounded hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-400">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
          <button onClick={newChat}
            className="mx-3 mt-2 mb-1 flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium bg-primary-500 hover:bg-primary-600 text-white transition-colors">
            <Plus className="w-3.5 h-3.5" /> New Chat
          </button>
          <div className="flex-1 overflow-y-auto py-1 px-2 space-y-0.5">
            {historyLoading && (
              <div className="flex items-center justify-center py-6 gap-2 text-slate-400 text-xs">
                <Loader2 className="w-3.5 h-3.5 animate-spin" /> Loading…
              </div>
            )}
            {!historyLoading && chatHistory.length === 0 && (
              <p className="text-[11px] text-slate-400 dark:text-slate-500 text-center py-6 px-3">No saved chats yet. Start chatting!</p>
            )}
            {chatHistory.map(chat => (
              <div key={chat.id}
                onClick={() => loadChat(chat)}
                className={`group flex items-start justify-between gap-1 px-2 py-2 rounded-lg cursor-pointer transition-colors ${
                  chat.id === currentChatId
                    ? 'bg-primary-100 dark:bg-primary-500/20 text-primary-700 dark:text-primary-300'
                    : 'hover:bg-slate-200 dark:hover:bg-slate-700/60 text-slate-700 dark:text-slate-300'
                }`}>
                <div className="flex-1 min-w-0">
                  <p className="text-[11px] font-medium truncate leading-snug">{chat.title}</p>
                  <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-0.5">{timeAgo(chat.updatedAt)} · {chat.messages.length} msgs</p>
                </div>
                <button onClick={e => deleteChat(chat.id, e)}
                  className="opacity-0 group-hover:opacity-100 p-0.5 rounded hover:bg-red-100 dark:hover:bg-red-500/20 text-slate-400 hover:text-red-500 transition-all flex-shrink-0 mt-0.5">
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ── Main Chat ─────────────────────────────────────────── */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top toolbar */}
        <div className="flex items-center gap-2 px-4 py-2 border-b border-slate-200 dark:border-slate-700/60 bg-white dark:bg-slate-900">
          <button onClick={() => setShowHistory(v => !v)}
            className={`p-1.5 rounded-lg transition-colors ${showHistory ? 'bg-primary-100 dark:bg-primary-500/20 text-primary-600 dark:text-primary-400' : 'hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500'}`}
            title="Toggle chat history">
            {showHistory ? <PanelRightClose className="w-4 h-4" /> : <PanelRightOpen className="w-4 h-4" />}
          </button>
          <button onClick={newChat}
            className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 transition-colors"
            title="New chat">
            <MessageSquare className="w-4 h-4" />
          </button>
          <span className="flex-1" />
          {confluenceReady
            ? <span className="text-[10px] flex items-center gap-1 text-emerald-600 dark:text-emerald-400"><BookOpen className="w-3 h-3" /> Confluence ON</span>
            : <span className="text-[10px] text-slate-400">Confluence OFF</span>
          }
        </div>

        {/* Scrollable messages */}
        <div className="flex-1 overflow-y-auto">
          <div className="max-w-3xl mx-auto px-4 py-6">
            {isEmpty ? (
              <EmptyState confluenceReady={confluenceReady} onPick={p => { setInput(p); setTimeout(() => textareaRef.current?.focus(), 30); }} />
            ) : (
              <div className="space-y-6">
                {messages.map((msg, idx) => {
                  const isLastAssistant = msg.role === 'assistant' && idx === lastAssistantIdx;
                  return (
                    <div key={msg.id} className="group relative">
                      <ChatMessage
                        message={msg}
                        isStreaming={isLoading && isLastAssistant}
                        onRegenerate={handleRegenerate}
                        canRegenerate={isLastAssistant && !isLoading}
                      />
                      {msg.role === 'assistant' && msg.content && (
                        <button
                          onClick={() => copyMessage(msg.id, msg.content)}
                          className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 p-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition-all shadow-sm"
                          title="Copy response"
                        >
                          {copiedId === msg.id ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                        </button>
                      )}
                    </div>
                  );
                })}
                {isLoading && messages[messages.length - 1]?.content === '' && (
                  <div className="flex items-center gap-3 pl-10 text-sm text-slate-500 dark:text-slate-400">
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>{confluenceStatus || 'Thinking…'}</span>
                  </div>
                )}
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        </div>

        {/* Composer */}
        <div className="border-t border-slate-200 dark:border-slate-700/60 bg-white dark:bg-slate-900">
          <div className="max-w-3xl mx-auto px-4 py-3 space-y-2">
            {/* Confluence status */}
            {!isLoading && confluenceStatus && messages.length > 0 && (
              <div className="flex items-center gap-1.5 text-[11px] text-purple-600 dark:text-purple-300">
                <BookOpen className="w-3 h-3" /> {confluenceStatus}
              </div>
            )}

            {/* Attachments preview */}
            {attachments.length > 0 && (
              <div className="flex flex-wrap gap-1.5">
                {attachments.map(att => (
                  <div key={att.id} className="flex items-center gap-1.5 px-2 py-1 rounded-lg bg-primary-50 dark:bg-primary-500/10 border border-primary-200 dark:border-primary-500/30 text-xs text-primary-700 dark:text-primary-300 max-w-48">
                    {att.preview
                      ? <img src={att.preview} className="w-5 h-5 rounded object-cover flex-shrink-0" alt="" />
                      : <FileText className="w-3.5 h-3.5 flex-shrink-0" />
                    }
                    <span className="truncate flex-1">{att.name}</span>
                    <button onClick={() => setAttachments(p => p.filter(a => a.id !== att.id))} className="flex-shrink-0 text-primary-400 hover:text-red-500">
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Error */}
            {error && (
              <div className="flex items-start gap-2 p-2.5 bg-red-50 dark:bg-red-500/10 rounded-lg border border-red-200 dark:border-red-500/30">
                <AlertCircle className="w-4 h-4 text-red-500 mt-0.5 flex-shrink-0" />
                <p className="text-sm text-red-700 dark:text-red-400 flex-1">{error}</p>
                <button onClick={() => setError(null)} className="text-red-400 hover:text-red-500"><X className="w-3.5 h-3.5" /></button>
              </div>
            )}

            {/* Quick actions menu */}
            {showQuickActions && (
              <div className="rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 shadow-xl overflow-hidden">
                <div className="px-3 py-2 border-b border-slate-100 dark:border-slate-700 flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-violet-500" /> Quick Actions
                  </span>
                  <button onClick={() => setShowQuickActions(false)} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300">
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
                <div className="grid grid-cols-2 gap-0 p-1.5">
                  {QUICK_ACTIONS.map(action => (
                    <button key={action.label}
                      onClick={() => { setInput(action.prompt); setShowQuickActions(false); setTimeout(() => textareaRef.current?.focus(), 30); }}
                      className="flex items-center gap-2 px-2.5 py-2 rounded-lg text-xs text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors text-left">
                      <action.icon className="w-3.5 h-3.5 text-violet-500 flex-shrink-0" />
                      <span>{action.label}</span>
                    </button>
                  ))}
                  <button
                    onClick={() => { fileInputRef.current?.click(); setShowQuickActions(false); }}
                    className="flex items-center gap-2 px-2.5 py-2 rounded-lg text-xs text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors text-left">
                    <Upload className="w-3.5 h-3.5 text-emerald-500 flex-shrink-0" />
                    <span>Upload File</span>
                  </button>
                  <button
                    onClick={() => { fileInputRef.current?.click(); setShowQuickActions(false); }}
                    className="flex items-center gap-2 px-2.5 py-2 rounded-lg text-xs text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors text-left">
                    <ImageIcon className="w-3.5 h-3.5 text-blue-500 flex-shrink-0" />
                    <span>Upload Image</span>
                  </button>
                </div>
              </div>
            )}

            {/* Input row */}
            <div className="relative flex items-end gap-2 rounded-2xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 focus-within:border-primary-500 dark:focus-within:border-primary-500 focus-within:ring-2 focus-within:ring-primary-500/20 transition-all shadow-sm">
              {/* + button */}
              <button
                onClick={() => setShowQuickActions(v => !v)}
                className={`flex-shrink-0 ml-2 mb-2 p-1.5 rounded-lg transition-colors ${showQuickActions ? 'bg-violet-100 dark:bg-violet-500/20 text-violet-600 dark:text-violet-400' : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'}`}
                title="Quick actions & file upload"
              >
                <Plus className="w-4 h-4" />
              </button>

              <textarea
                ref={textareaRef}
                rows={1}
                className="flex-1 bg-transparent resize-none py-3 text-[15px] text-slate-900 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none max-h-[200px]"
                placeholder="Ask anything — NOC, Wireshark, mobility, carriers, or just chat…  (Shift+Enter for new line)"
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
              />
              <div className="flex items-center gap-1 pr-2 pb-2">
                {messages.length > 0 && !isLoading && (
                  <button onClick={handleClear} className="p-2 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors" title="Clear conversation">
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
                {isLoading ? (
                  <button onClick={handleStop} className="p-2 rounded-lg bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 hover:opacity-90 transition-opacity" title="Stop">
                    <Square className="w-4 h-4 fill-current" />
                  </button>
                ) : (
                  <button onClick={handleSend} disabled={!input.trim() && !attachments.length}
                    className="p-2 rounded-lg bg-primary-500 hover:bg-primary-600 disabled:bg-slate-300 dark:disabled:bg-slate-700 disabled:cursor-not-allowed text-white transition-colors" title="Send">
                    <Send className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>

            <div className="flex items-center justify-between text-[11px] text-slate-400 dark:text-slate-500 px-1">
              <span className="flex items-center gap-2">
                <button onClick={() => fileInputRef.current?.click()} className="hover:text-primary-500 transition-colors flex items-center gap-1">
                  <Upload className="w-3 h-3" /> Attach file
                </button>
                <span>·</span>
                <span>{confluenceReady ? '📚 Confluence grounding ON' : 'Confluence OFF'}</span>
              </span>
              <span>Enter to send · Shift+Enter for newline</span>
            </div>
          </div>
        </div>

        {/* Hidden file input */}
        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept={ACCEPTED_TYPES}
          className="hidden"
          onChange={e => handleFileUpload(e.target.files)}
          onClick={e => { (e.target as HTMLInputElement).value = ''; }}
        />
      </div>
    </div>
  );
}

// ─── Empty state ────────────────────────────────────────────────────────────
function EmptyState({ confluenceReady, onPick }: { confluenceReady: boolean; onPick: (p: string) => void }) {
  return (
    <div className="flex flex-col items-center justify-center py-12 text-center">
      <div className="mb-5"><AIBadge size="lg" /></div>
      <h2 className="text-2xl font-semibold text-slate-900 dark:text-white mb-1.5">
        How can I help with your NOC shift?
      </h2>
      <p className="text-sm text-slate-500 dark:text-slate-400 max-w-md mb-3">
        Ask about troubleshooting, carriers, packet analysis, mobility, or paste emails/notes to rewrite.
        {confluenceReady && <> Your <span className="font-medium">Confluence wiki</span> is connected — I'll search it first.</>}
        {' '}You can also upload logs, configs, and Wireshark exports using the <strong>+</strong> button.
      </p>
      <div className="flex items-center gap-2 flex-wrap justify-center mb-7">
        <DevsAiBadge size="xs" />
        <CompanyBadge size="xs" />
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 w-full max-w-2xl">
        {STARTERS.map(s => (
          <button key={s.label} onClick={() => onPick(s.prompt)}
            className="flex items-start gap-3 p-3 text-left rounded-xl border border-slate-200 dark:border-slate-700 hover:border-primary-400 dark:hover:border-primary-500 hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-all group">
            <div className="w-8 h-8 rounded-lg bg-slate-100 dark:bg-slate-800 flex items-center justify-center flex-shrink-0 group-hover:bg-primary-50 dark:group-hover:bg-primary-500/10 transition-colors">
              <s.icon className="w-4 h-4 text-slate-600 dark:text-slate-400 group-hover:text-primary-500" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium text-slate-800 dark:text-slate-200">{s.label}</div>
              <div className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-1">{s.prompt.split('\n')[0]}</div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
