import { useState, type RefObject } from 'react';
import { Copy, Check, FileText } from 'lucide-react';
import toast from 'react-hot-toast';
import {
  copyRichAndPlain,
  copyPlainOnly,
  cleanRenderedHtml,
  renderedNodeToPlain,
} from '../../lib/clipboard-rich';

interface Props {
  /** A ref to the DOM node whose visible content should be copied. */
  targetRef: RefObject<HTMLElement>;
  /** Optional human-readable label for the toast message. */
  label?: string;
  /** Render compact (icon only) version. */
  compact?: boolean;
  className?: string;
}

/**
 * Drop-in "Copy this section" button.
 *
 * - "Copy"   — preserves bold, bullets, headings, links. Background colour
 *              and explicit text colour are STRIPPED so the paste-side
 *              adapts to its own theme (Outlook, Slack, Word, ServiceNow,
 *              Confluence, Google Docs all read the same clean HTML).
 * - "Plain"  — strips all formatting; useful for terminals or strict
 *              plain-text fields.
 *
 * Drop it on top of any rendered region:
 *
 *     const ref = useRef<HTMLDivElement>(null);
 *     <div ref={ref}> …rendered content… </div>
 *     <CopySectionButton targetRef={ref} label="Carrier card" />
 */
export function CopySectionButton({ targetRef, label, compact, className }: Props) {
  const [copied, setCopied] = useState<'rich' | 'plain' | null>(null);

  const flash = (k: 'rich' | 'plain') => {
    setCopied(k);
    window.setTimeout(() => setCopied((cur) => (cur === k ? null : cur)), 1500);
  };

  const copyRich = async () => {
    const node = targetRef.current;
    if (!node) { toast.error('Nothing to copy'); return; }
    const html  = cleanRenderedHtml(node);
    const plain = renderedNodeToPlain(node);
    const ok = await copyRichAndPlain(html, plain);
    if (ok) {
      flash('rich');
      toast.success(`${label ?? 'Section'} copied — paste-side will adapt to its own theme`, { duration: 1900 });
    } else {
      toast.error('Copy blocked by the browser');
    }
  };

  const copyPlain = async () => {
    const node = targetRef.current;
    if (!node) { toast.error('Nothing to copy'); return; }
    const plain = renderedNodeToPlain(node) || (node.textContent ?? '');
    const ok = await copyPlainOnly(plain);
    if (ok) {
      flash('plain');
      toast.success(`${label ?? 'Section'} copied (plain text)`, { duration: 1500 });
    } else {
      toast.error('Copy blocked by the browser');
    }
  };

  return (
    <div className={`inline-flex items-center gap-1 ${className ?? ''}`}>
      <button
        onClick={copyRich}
        className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium rounded-md bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 transition-colors"
        title="Copy with formatting — paste-side adapts to its own theme"
      >
        {copied === 'rich' ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
        {!compact && <span>Copy</span>}
      </button>
      <button
        onClick={copyPlain}
        className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium rounded-md bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 transition-colors"
        title="Copy as plain text only"
      >
        {copied === 'plain' ? <Check className="w-3 h-3 text-emerald-500" /> : <FileText className="w-3 h-3" />}
        {!compact && <span>Plain</span>}
      </button>
    </div>
  );
}
