import React from 'react';
import { CheckCircle, AlertTriangle, XCircle } from 'lucide-react';
import type { ConfidenceLevel } from '../../types';

interface BadgeProps {
  variant?: 'success' | 'warning' | 'danger';
  children: React.ReactNode;
  className?: string;
}

export function Badge({ variant = 'success', children, className = '' }: BadgeProps) {
  const classes = {
    success: 'badge-success',
    warning: 'badge-warning',
    danger: 'badge-danger',
  };

  return (
    <span className={`${classes[variant]} ${className}`}>
      {children}
    </span>
  );
}

interface ConfidenceBadgeProps {
  level: ConfidenceLevel;
}

export function ConfidenceBadge({ level }: ConfidenceBadgeProps) {
  switch (level) {
    case 'found':
      return (
        <Badge variant="success">
          <CheckCircle className="w-3 h-3" /> Found
        </Badge>
      );
    case 'guessed':
      return (
        <Badge variant="warning">
          <AlertTriangle className="w-3 h-3" /> Guessed
        </Badge>
      );
    case 'not_found':
      return (
        <Badge variant="danger">
          <XCircle className="w-3 h-3" /> Not Found
        </Badge>
      );
  }
}
