import { useState, useEffect } from 'react';
import { Clock } from 'lucide-react';

/**
 * Live clock locked to US Pacific (California) timezone.
 * Updates every second. Shows time + date + PT/PST/PDT label.
 */
export function LiveClock({ className = '' }: { className?: string }) {
  const [now, setNow] = useState(() => new Date());

  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  // Format in Pacific time
  const timeStr = now.toLocaleTimeString('en-US', {
    timeZone: 'America/Los_Angeles',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true,
  });

  const dateStr = now.toLocaleDateString('en-US', {
    timeZone: 'America/Los_Angeles',
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  });

  // Get timezone abbreviation (PST or PDT)
  const tzAbbr = now
    .toLocaleString('en-US', { timeZone: 'America/Los_Angeles', timeZoneName: 'short' })
    .split(' ')
    .pop();

  return (
    <div className={`flex items-center gap-1.5 ${className}`}>
      <Clock className="w-3.5 h-3.5 text-primary-500 flex-shrink-0" />
      <div className="flex items-center gap-1.5 text-[11px] font-mono tabular-nums">
        <span className="text-slate-700 dark:text-slate-200 font-semibold">{timeStr}</span>
        <span className="text-slate-400 dark:text-slate-500">{tzAbbr}</span>
        <span className="text-slate-400 dark:text-slate-500 hidden sm:inline">· {dateStr}</span>
      </div>
    </div>
  );
}
