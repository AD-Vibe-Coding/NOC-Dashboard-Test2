import { Shield, Sparkles } from 'lucide-react';

type Size = 'xs' | 'sm' | 'md';

const SIZES: Record<Size, { wrap: string; icon: string; text: string }> = {
  xs: { wrap: 'px-1.5 py-0.5 gap-1 rounded',     icon: 'w-2.5 h-2.5', text: 'text-[10px]' },
  sm: { wrap: 'px-2 py-0.5 gap-1.5 rounded-md',  icon: 'w-3 h-3',     text: 'text-[11px]' },
  md: { wrap: 'px-2.5 py-1 gap-1.5 rounded-md',  icon: 'w-3.5 h-3.5', text: 'text-xs' },
};

/**
 * Company attribution chip — shows AppDirect with vCom BU as the business unit.
 * Used in: Navbar, Footer, Dashboard hero, AI Settings modal, AI Assistant empty
 * state. Renders correctly in light and dark mode and respects the existing
 * primary color palette.
 */
export function CompanyBadge({
  size = 'sm',
  className = '',
}: {
  size?: Size;
  className?: string;
}) {
  const s = SIZES[size];
  return (
    <span
      className={`inline-flex items-center font-medium border border-primary-200 dark:border-primary-500/30 bg-primary-50 dark:bg-primary-500/10 text-primary-700 dark:text-primary-300 ${s.wrap} ${s.text} ${className}`}
      title="AppDirect — vCom Business Unit"
      aria-label="AppDirect, vCom Business Unit"
    >
      <Shield className={`${s.icon} flex-shrink-0`} />
      <span className="font-semibold tracking-tight">AppDirect</span>
      <span className="text-primary-400 dark:text-primary-500/70 font-normal">·</span>
      <span className="font-medium">vCom BU</span>
    </span>
  );
}

/**
 * Devs.ai attribution chip — shows the AI is powered by the Devs.ai platform.
 * Optionally renders the active model id / agent name inline.
 */
export function DevsAiBadge({
  size = 'sm',
  model,
  className = '',
}: {
  size?: Size;
  model?: string;
  className?: string;
}) {
  const s = SIZES[size];
  return (
    <span
      className={`inline-flex items-center font-medium border border-violet-200 dark:border-violet-500/30 bg-violet-50 dark:bg-violet-500/10 text-violet-700 dark:text-violet-300 ${s.wrap} ${s.text} ${className}`}
      title={model ? `Powered by Devs.ai · ${model}` : 'Powered by Devs.ai'}
      aria-label={model ? `Powered by Devs.ai, model ${model}` : 'Powered by Devs.ai'}
    >
      <Sparkles className={`${s.icon} flex-shrink-0`} />
      <span className="font-semibold tracking-tight">Devs.ai</span>
      {model && (
        <>
          <span className="text-violet-400 dark:text-violet-500/70 font-normal">·</span>
          <span className="font-mono truncate max-w-[120px]">{model}</span>
        </>
      )}
    </span>
  );
}
