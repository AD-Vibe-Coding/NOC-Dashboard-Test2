import { useState } from 'react';
import { Copy, Check, ChevronDown, ChevronRight, Pencil, Trash2, Pin } from 'lucide-react';
import toast from 'react-hot-toast';
import type { Runbook } from '../../lib/runbooks/db';
import { CATEGORY_META } from '../../lib/runbooks/db';

interface Props {
  runbook: Runbook;
  isAdmin: boolean;
  onEdit?: (rb: Runbook) => void;
  onDelete?: (id: string) => void;
}

export function RunbookCard({ runbook, isAdmin, onEdit, onDelete }: Props) {
  const [open, setOpen] = useState(false);
  const [copied, setCopied] = useState<'rich' | 'plain' | null>(null);
  const meta = CATEGORY_META[runbook.category] ?? CATEGORY_META.general;

  const copyRich = async () => {
    try {
      const blob = new Blob([runbook.content], { type: 'text/html' });
      const plain = new Blob([runbook.plainText || runbook.content.replace(/<[^>]+>/g, ' ')], { type: 'text/plain' });
      await navigator.clipboard.write([new ClipboardItem({ 'text/html': blob, 'text/plain': plain })]);
      setCopied('rich'); setTimeout(() => setCopied(null), 2000);
      toast.success('Copied (rich)');
    } catch {
      copyPlain();
    }
  };

  const copyPlain = async () => {
    const text = runbook.plainText || runbook.content.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
    await navigator.clipboard.writeText(text);
    setCopied('plain'); setTimeout(() => setCopied(null), 2000);
    toast.success('Copied (plain)');
  };

  return (
    <div className={`card overflow-hidden transition-all ${runbook.isPinned ? 'border-l-4 border-l-primary-500' : ''}`}>
      {/* Header row */}
      <div className="flex items-start gap-2">
        <button
          onClick={() => setOpen(v => !v)}
          className="flex items-center gap-2 flex-1 min-w-0 text-left"
        >
          {open
            ? <ChevronDown className="w-4 h-4 text-slate-400 flex-shrink-0 mt-0.5" />
            : <ChevronRight className="w-4 h-4 text-slate-400 flex-shrink-0 mt-0.5" />}
          <span className="text-sm font-medium text-slate-900 dark:text-white truncate">{runbook.title}</span>
          {runbook.isPinned && <Pin className="w-3 h-3 text-primary-500 flex-shrink-0" />}
        </button>
        <span className={`flex-shrink-0 text-[10px] px-2 py-0.5 rounded-full font-medium ${meta.color}`}>
          {meta.label}
        </span>

        {/* Action buttons */}
        <div className="flex items-center gap-1 flex-shrink-0">
          <button
            onClick={copyRich}
            className="p-1.5 rounded-md hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-500 dark:text-slate-400 transition-colors"
            title="Copy rich"
          >
            {copied === 'rich' ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
          </button>
          <button
            onClick={copyPlain}
            className="p-1.5 rounded-md hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-500 dark:text-slate-400 transition-colors text-[10px] font-medium px-2"
            title="Copy plain text"
          >
            {copied === 'plain' ? <Check className="w-3 h-3 text-emerald-500" /> : 'Plain'}
          </button>
          {isAdmin && (
            <>
              <button
                onClick={() => onEdit?.(runbook)}
                className="p-1.5 rounded-md hover:bg-blue-50 dark:hover:bg-blue-500/10 text-slate-500 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
                title="Edit"
              >
                <Pencil className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => {
                  if (confirm(`Delete "${runbook.title}"?`)) onDelete?.(runbook.id);
                }}
                className="p-1.5 rounded-md hover:bg-red-50 dark:hover:bg-red-500/10 text-slate-500 dark:text-slate-400 hover:text-red-600 dark:hover:text-red-400 transition-colors"
                title="Delete"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </>
          )}
        </div>
      </div>

      {/* Expanded content */}
      {open && (
        <div
          className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-700/50 prose prose-sm dark:prose-invert max-w-none
                     prose-p:my-1 prose-ul:my-1 prose-li:my-0 prose-strong:text-slate-900 dark:prose-strong:text-white"
          dangerouslySetInnerHTML={{ __html: runbook.content }}
        />
      )}
    </div>
  );
}
