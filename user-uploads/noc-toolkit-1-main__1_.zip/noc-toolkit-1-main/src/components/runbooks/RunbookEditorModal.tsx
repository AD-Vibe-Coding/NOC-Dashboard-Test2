import { useState, useEffect } from 'react';
import { X, Save, Eye, Code } from 'lucide-react';
import toast from 'react-hot-toast';
import type { Runbook, RunbookCategory } from '../../lib/runbooks/db';
import { CATEGORY_META } from '../../lib/runbooks/db';

interface Props {
  runbook?: Runbook | null; // null = create new
  onSave: (data: { title: string; category: RunbookCategory; content: string; plainText: string }) => Promise<void>;
  onClose: () => void;
}

export function RunbookEditorModal({ runbook, onSave, onClose }: Props) {
  const [title, setTitle] = useState(runbook?.title ?? '');
  const [category, setCategory] = useState<RunbookCategory>(runbook?.category ?? 'ticket-scripts');
  const [content, setContent] = useState(runbook?.content ?? '');
  const [plainText, setPlainText] = useState(runbook?.plainText ?? '');
  const [preview, setPreview] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (runbook) {
      setTitle(runbook.title);
      setCategory(runbook.category);
      setContent(runbook.content);
      setPlainText(runbook.plainText);
    }
  }, [runbook?.id]);

  const handleSave = async () => {
    if (!title.trim()) { toast.error('Title is required'); return; }
    if (!content.trim()) { toast.error('Content is required'); return; }
    setSaving(true);
    await onSave({ title: title.trim(), category, content, plainText });
    setSaving(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="w-full max-w-2xl max-h-[90vh] bg-white dark:bg-slate-800 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-700 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-200 dark:border-slate-700 flex-shrink-0">
          <h2 className="text-sm font-semibold text-slate-900 dark:text-white">
            {runbook ? 'Edit Runbook' : 'New Runbook'}
          </h2>
          <button onClick={onClose} className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
          {/* Title */}
          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Title *</label>
            <input
              type="text"
              value={title}
              onChange={e => setTitle(e.target.value)}
              placeholder="e.g. Circuit Down – No Outage Confirmed"
              className="input-base w-full"
            />
          </div>

          {/* Category */}
          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Category</label>
            <div className="grid grid-cols-3 gap-2">
              {(Object.keys(CATEGORY_META) as RunbookCategory[]).map(cat => (
                <button
                  key={cat}
                  onClick={() => setCategory(cat)}
                  className={`px-2 py-1.5 rounded-lg text-[11px] font-medium border transition-all ${
                    category === cat
                      ? 'border-primary-500 bg-primary-50 dark:bg-primary-500/10 text-primary-700 dark:text-primary-300'
                      : 'border-slate-200 dark:border-slate-600 text-slate-600 dark:text-slate-400 hover:border-slate-300 dark:hover:border-slate-500'
                  }`}
                >
                  {CATEGORY_META[cat].label}
                </button>
              ))}
            </div>
          </div>

          {/* Content (HTML) */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-medium text-slate-600 dark:text-slate-400">Content (HTML) *</label>
              <button
                onClick={() => setPreview(v => !v)}
                className="inline-flex items-center gap-1 text-[11px] text-primary-600 dark:text-primary-400 hover:underline"
              >
                {preview ? <><Code className="w-3 h-3" /> Edit</> : <><Eye className="w-3 h-3" /> Preview</>}
              </button>
            </div>
            {preview ? (
              <div
                className="min-h-[200px] p-3 rounded-lg border border-slate-200 dark:border-slate-600 bg-white dark:bg-slate-900 prose prose-sm dark:prose-invert max-w-none overflow-auto"
                dangerouslySetInnerHTML={{ __html: content }}
              />
            ) : (
              <textarea
                value={content}
                onChange={e => setContent(e.target.value)}
                rows={8}
                placeholder="<p>Hello Team,</p><p>...</p>"
                className="input-base w-full font-mono text-xs resize-y"
              />
            )}
            <p className="text-[10px] text-slate-400 mt-1">Use HTML tags: &lt;p&gt;, &lt;strong&gt;, &lt;ul&gt;, &lt;li&gt;, &lt;ol&gt;</p>
          </div>

          {/* Plain text */}
          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Plain text (for "Copy plain" button)</label>
            <textarea
              value={plainText}
              onChange={e => setPlainText(e.target.value)}
              rows={4}
              placeholder="Plain text version without HTML tags..."
              className="input-base w-full text-xs resize-y"
            />
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-2 px-5 py-3 border-t border-slate-200 dark:border-slate-700 flex-shrink-0">
          <button onClick={onClose} className="px-4 py-2 rounded-lg text-sm font-medium text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-600 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors">
            Cancel
          </button>
          <button onClick={handleSave} disabled={saving} className="btn-primary">
            {saving ? <span className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Save className="w-3.5 h-3.5" />}
            {runbook ? 'Save Changes' : 'Create Runbook'}
          </button>
        </div>
      </div>
    </div>
  );
}
