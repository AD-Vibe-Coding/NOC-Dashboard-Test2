import { Search, Sparkles, X, BookOpen } from 'lucide-react';

interface Props {
  query: string;
  onQueryChange: (q: string) => void;
  aiMode: boolean;
  onAiToggle: () => void;
  onAiSubmit: () => void;
  /** True when Confluence is enabled+configured — surfaces a hint in the UI. */
  confluenceActive: boolean;
}

export function CarrierSearchBar({
  query,
  onQueryChange,
  aiMode,
  onAiToggle,
  onAiSubmit,
  confluenceActive,
}: Props) {
  const placeholder = aiMode
    ? 'Ask AI: "Who do I call for AT&T MPLS?" or "Comcast NOC email"'
    : 'Search by carrier, phone, email, or service type…';

  return (
    <div className="space-y-2">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
        <input
          type="text"
          value={query}
          onChange={(e) => onQueryChange(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && aiMode && query.trim()) onAiSubmit();
          }}
          placeholder={placeholder}
          className="input-base !pl-10 !pr-28 text-sm"
        />
        <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
          {query && (
            <button
              onClick={() => onQueryChange('')}
              className="p-1 rounded hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-400"
              aria-label="Clear search"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
          <button
            onClick={onAiToggle}
            className={`flex items-center gap-1 px-2 py-1 rounded-md text-[11px] font-medium transition-colors ${
              aiMode
                ? 'bg-purple-500 text-white'
                : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600'
            }`}
            title="Toggle AI search (powered by Devs.ai)"
          >
            <Sparkles className="w-3 h-3" />
            AI
          </button>
          {aiMode && query.trim() && (
            <button
              onClick={onAiSubmit}
              className="px-2 py-1 rounded-md text-[11px] font-medium bg-primary-500 hover:bg-primary-600 text-white"
            >
              Ask
            </button>
          )}
        </div>
      </div>
      {aiMode && (
        <p className="text-[11px] text-slate-500 dark:text-slate-400 px-1 flex items-center gap-1.5 flex-wrap">
          <Sparkles className="w-3 h-3 text-purple-500" />
          AI search uses the local carrier directory + general carrier
          knowledge.
          {confluenceActive && (
            <>
              <span className="text-slate-400">·</span>
              <BookOpen className="w-3 h-3 text-purple-500" />
              <span className="text-purple-600 dark:text-purple-400">
                Grounded with your Confluence wiki
              </span>
            </>
          )}
          <span className="text-slate-400">·</span>
          Cannot fetch live outage data — click an Outage Map button for that.
        </p>
      )}
    </div>
  );
}
