import { ExternalLink, Activity } from 'lucide-react';
import { getOutageMap } from '../../data/outageMaps';

interface Props {
  carrierName: string;
}

export function OutageMapButton({ carrierName }: Props) {
  const map = getOutageMap(carrierName);
  const isOfficial = map.source === 'official';

  return (
    <a
      href={map.url}
      target="_blank"
      rel="noopener noreferrer"
      className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
        isOfficial
          ? 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-100 dark:hover:bg-emerald-500/20 border border-emerald-200 dark:border-emerald-500/30'
          : 'bg-slate-100 dark:bg-slate-700/50 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-600'
      }`}
      title={isOfficial ? 'Official carrier outage page' : 'No official outage map — DownDetector fallback'}
    >
      <Activity className="w-3.5 h-3.5" />
      <span>{map.label}</span>
      <ExternalLink className="w-3 h-3 opacity-70" />
    </a>
  );
}
