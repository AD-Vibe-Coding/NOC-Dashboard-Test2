import type { CarrierCategory } from '../../types';

interface Props {
  category: CarrierCategory | 'All';
  onCategoryChange: (c: CarrierCategory | 'All') => void;
  serviceType: string | 'All';
  onServiceTypeChange: (s: string | 'All') => void;
  serviceTypes: string[];
  totalCount: number;
  filteredCount: number;
}

export function CarrierFilters({
  category,
  onCategoryChange,
  serviceType,
  onServiceTypeChange,
  serviceTypes,
  totalCount,
  filteredCount,
}: Props) {
  const categories: Array<CarrierCategory | 'All'> = ['All', 'Business', 'Residential', 'Both'];

  return (
    <div className="flex flex-wrap items-center gap-3 px-1">
      <div className="flex flex-wrap items-center gap-1 bg-slate-100 dark:bg-slate-800 rounded-lg p-1">
        {categories.map((c) => (
          <button
            key={c}
            onClick={() => onCategoryChange(c)}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              category === c
                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      <select
        value={serviceType}
        onChange={(e) => onServiceTypeChange(e.target.value)}
        className="input-base !py-1.5 !px-3 !w-auto text-sm max-w-[220px]"
        aria-label="Filter by service type"
      >
        <option value="All">All Services</option>
        {serviceTypes.map((s) => (
          <option key={s} value={s}>{s}</option>
        ))}
      </select>

      <span className="ml-auto text-xs text-slate-500 dark:text-slate-400">
        Showing <span className="font-semibold text-slate-700 dark:text-slate-200">{filteredCount}</span> of {totalCount} carriers
      </span>
    </div>
  );
}
