import { Sparkles, Loader2, AlertCircle } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

interface Props {
  loading: boolean;
  error: string | null;
  answer: string;
  onClear: () => void;
}

export function AICarrierResults({ loading, error, answer, onClear }: Props) {
  if (!loading && !error && !answer) return null;

  return (
    <div className="card !p-4 border-purple-200 dark:border-purple-500/30 bg-purple-50/40 dark:bg-purple-500/5 animate-fade-in">
      <div className="flex items-center justify-between mb-2">
        <h3 className="flex items-center gap-2 text-sm font-semibold text-purple-700 dark:text-purple-300">
          <Sparkles className="w-4 h-4" />
          AI Answer
        </h3>
        {(answer || error) && !loading && (
          <button
            onClick={onClear}
            className="text-xs text-slate-500 hover:text-slate-700 dark:hover:text-slate-200"
          >
            Clear
          </button>
        )}
      </div>

      {loading && !answer && (
        <div className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-300">
          <Loader2 className="w-4 h-4 animate-spin" />
          Thinking…
        </div>
      )}

      {error && (
        <div className="flex items-start gap-2 text-sm text-red-600 dark:text-red-400">
          <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {!error && answer && (
        <div className="prose prose-sm dark:prose-invert max-w-none prose-p:my-1 prose-headings:my-2 prose-ul:my-1 prose-ol:my-1 prose-li:my-0 prose-pre:my-2 prose-code:before:hidden prose-code:after:hidden">
          <ReactMarkdown
            components={{
              a: ({ node: _node, ...props }) => (
                <a {...props} target="_blank" rel="noreferrer" />
              ),
            }}
          >
            {answer}
          </ReactMarkdown>
        </div>
      )}
    </div>
  );
}
