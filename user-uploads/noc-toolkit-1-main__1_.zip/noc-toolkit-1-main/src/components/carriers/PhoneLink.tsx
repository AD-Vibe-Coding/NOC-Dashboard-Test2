import { Phone } from 'lucide-react';

interface Props {
  phone: string;          // "1-800-444-1111"
  className?: string;
}

export function PhoneLink({ phone, className = '' }: Props) {
  const tel = phone.replace(/[^0-9]/g, '');
  return (
    <a
      href={`tel:+${tel}`}
      className={`inline-flex items-center gap-1.5 text-sm font-mono text-primary-600 dark:text-primary-400 hover:underline ${className}`}
      title="Click to call"
    >
      <Phone className="w-3.5 h-3.5 flex-shrink-0" />
      <span>{phone}</span>
    </a>
  );
}
