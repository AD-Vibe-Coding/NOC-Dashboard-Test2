import { useState } from 'react';
import { ChevronDown, ExternalLink, Briefcase, Home, Layers, FileText } from 'lucide-react';
import type { Carrier, EscalationContact } from '../../types';
import { PhoneLink } from './PhoneLink';
import { EmailLink } from './EmailLink';
import { OutageMapButton } from './OutageMapButton';
import { EscalationTierTable } from './EscalationTierTable';

interface Props {
  carrier: Carrier;
  buyersClub: EscalationContact[];
  brokerage: EscalationContact[];
}

export function CarrierCard({ carrier, buyersClub, brokerage }: Props) {
  const [allServicesOpen, setAllServicesOpen] = useState(false);
  const visibleServices = allServicesOpen ? carrier.services : carrier.services.slice(0, 3);

  const categoryStyle =
    carrier.category === 'Business'
      ? 'bg-blue-50 dark:bg-blue-500/10 text-blue-700 dark:text-blue-300 border-blue-200 dark:border-blue-500/30'
      : carrier.category === 'Residential'
      ? 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-500/30'
      : 'bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-600';

  const CategoryIcon = carrier.category === 'Business' ? Briefcase : carrier.category === 'Residential' ? Home : Layers;

  return (
    <div className="card !p-4">
      <div className="flex flex-wrap items-start gap-3 mb-3">
        <div className="flex-1 min-w-0">
          <h3 className="text-base font-semibold text-slate-900 dark:text-white truncate">{carrier.name}</h3>
          <div className="flex flex-wrap items-center gap-2 mt-1">
            <span className={`inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-medium rounded-full border ${categoryStyle}`}>
              <CategoryIcon className="w-3 h-3" />
              {carrier.category}
              {carrier.category === 'Both' && <span className="text-slate-400">· Business + Residential</span>}
            </span>
            <span className="text-[10px] text-slate-400 dark:text-slate-500">
              {carrier.services.length} service{carrier.services.length === 1 ? '' : 's'}
            </span>
          </div>
        </div>
        <OutageMapButton carrierName={carrier.name} />
      </div>

      {/* Services list */}
      <div className="space-y-2">
        {visibleServices.map((s, idx) => (
          <div key={idx} className="px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-800/50 border border-slate-200/60 dark:border-slate-700/60">
            <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
              <span className="text-sm font-medium text-slate-800 dark:text-slate-200 min-w-[120px]">
                {s.service}
              </span>
              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 flex-1">
                {s.phones.map((p) => (
                  <PhoneLink key={p} phone={p} />
                ))}
                {s.emails.map((e) => (
                  <EmailLink key={e} email={e} />
                ))}
                {s.urls.map((u) => (
                  <a
                    key={u}
                    href={u}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-xs text-primary-600 dark:text-primary-400 hover:underline break-all"
                  >
                    <ExternalLink className="w-3 h-3 flex-shrink-0" />
                    Portal
                  </a>
                ))}
              </div>
            </div>
            {s.notes && (
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400 flex items-start gap-1">
                <FileText className="w-3 h-3 mt-0.5 flex-shrink-0 opacity-60" />
                <span>{s.notes}</span>
              </p>
            )}
          </div>
        ))}
        {carrier.services.length > 3 && (
          <button
            onClick={() => setAllServicesOpen(!allServicesOpen)}
            className="w-full inline-flex items-center justify-center gap-1 px-3 py-1.5 text-xs font-medium text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition-colors"
          >
            {allServicesOpen ? 'Show fewer' : `Show all ${carrier.services.length} services`}
            <ChevronDown className={`w-3.5 h-3.5 transition-transform ${allServicesOpen ? 'rotate-180' : ''}`} />
          </button>
        )}
      </div>

      <EscalationTierTable carrierName={carrier.name} buyersClub={buyersClub} brokerage={brokerage} />
    </div>
  );
}
