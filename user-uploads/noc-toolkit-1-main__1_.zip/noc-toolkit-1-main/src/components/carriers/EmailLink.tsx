import { Mail } from 'lucide-react';

interface Props {
  email: string;
  className?: string;
}

export function EmailLink({ email, className = '' }: Props) {
  return (
    <a
      href={`mailto:${email}`}
      className={`inline-flex items-center gap-1.5 text-sm text-primary-600 dark:text-primary-400 hover:underline break-all ${className}`}
      title="Send email"
    >
      <Mail className="w-3.5 h-3.5 flex-shrink-0" />
      <span>{email}</span>
    </a>
  );
}
