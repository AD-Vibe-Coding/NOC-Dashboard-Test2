import { useState } from 'react';
import { ChevronDown, TrendingUp } from 'lucide-react';
import type { EscalationContact } from '../../types';
import { PhoneLink } from './PhoneLink';
import { EmailLink } from './EmailLink';

interface Props {
  carrierName: string;
  buyersClub: EscalationContact[];
  brokerage: EscalationContact[];
}

type Channel = 'Buyers Club' | 'Brokerage';

export function EscalationTierTable({ carrierName, buyersClub, brokerage }: Props) {
  const hasBC = buyersClub.length > 0;
  const hasBR = brokerage.length > 0;

  const [open, setOpen] = useState(false);
  const [tab, setTab] = useState<Channel>(hasBC ? 'Buyers Club' : 'Brokerage');

  if (!hasBC && !hasBR) return null;

  const contacts = tab === 'Buyers Club' ? buyersClub : brokerage;

  return (
    <div className="border border-slate-200 dark:border-slate-700 rounded-lg overflow-hidden mt-3">
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between px-3 py-2 text-left bg-slate-50 dark:bg-slate-800/60 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
        aria-expanded={open}
      >
        <span className="flex items-center gap-2 text-xs font-semibold text-slate-700 dark:text-slate-200">
          <TrendingUp className="w-3.5 h-3.5 text-amber-500" />
          Escalation Tiers ({carrierName})
          <span className="text-slate-400 font-normal">
            · {hasBC ? `${buyersClub.length} BC` : ''}{hasBC && hasBR ? ' / ' : ''}{hasBR ? `${brokerage.length} BR` : ''}
          </span>
        </span>
        <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>

      {open && (
        <div className="p-3 space-y-3">
          {/* Channel tabs */}
          {(hasBC && hasBR) && (
            <div className="flex gap-1 bg-slate-100 dark:bg-slate-900 rounded-lg p-1 w-fit">
              {(['Buyers Club', 'Brokerage'] as Channel[]).map((ch) => (
                <button
                  key={ch}
                  onClick={() => setTab(ch)}
                  className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                    tab === ch
                      ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm'
                      : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'
                  }`}
                >
                  {ch}
                </button>
              ))}
            </div>
          )}

          {/* Contacts */}
          <div className="space-y-2">
            {contacts.map((c, i) => (
              <div
                key={i}
                className="flex flex-col sm:flex-row sm:items-start gap-2 p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/60"
              >
                <div className="flex items-center gap-2 sm:w-20 flex-shrink-0">
                  <span className="inline-flex items-center justify-center w-7 h-7 rounded-full bg-primary-100 dark:bg-primary-500/15 text-primary-700 dark:text-primary-300 text-xs font-bold">
                    T{c.tier || '-'}
                  </span>
                </div>
                <div className="flex-1 min-w-0 space-y-1">
                  {(c.name || c.title) && (
                    <div className="text-sm">
                      {c.name && <span className="font-semibold text-slate-900 dark:text-slate-100">{c.name}</span>}
                      {c.title && c.title !== c.name && (
                        <span className="text-slate-500 dark:text-slate-400"> — {c.title}</span>
                      )}
                    </div>
                  )}
                  <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
                    {c.phones.map((p) => (
                      <PhoneLink key={p} phone={p} />
                    ))}
                    {c.emails.map((e) => (
                      <EmailLink key={e} email={e} />
                    ))}
                  </div>
                  {c.notes && (
                    <p className="text-xs text-slate-500 dark:text-slate-400 italic">{c.notes}</p>
                  )}
                </div>
              </div>
            ))}
            {contacts.length === 0 && (
              <p className="text-xs text-slate-400 italic">No contacts on file for this channel.</p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
