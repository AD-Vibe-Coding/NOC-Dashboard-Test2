import { User as UserIcon, Mail, AtSign } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { RoleBadge } from '../auth/RoleBadge';

export function ProfileTab() {
  const { user, isSuperAdmin } = useAuth();
  if (!user) return null;
  const fields = [
    { icon: UserIcon, label: 'Full Name', value: `${user.firstName} ${user.lastName}` },
    { icon: AtSign, label: 'Username', value: user.username },
    { icon: Mail, label: 'Email', value: user.email },
  ];
  return (
    <div className="space-y-4">
      {isSuperAdmin && (
        <div className="flex items-center gap-2 mb-2">
          <span className="text-xs text-slate-500 dark:text-slate-400">Role:</span>
          <RoleBadge role={user.role} />
        </div>
      )}
      {fields.map((f) => (
        <div key={f.label} className="flex items-center gap-3 px-4 py-3 rounded-lg bg-slate-50 dark:bg-slate-700/50">
          <f.icon className="w-4 h-4 text-slate-400 flex-shrink-0" />
          <div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">{f.label}</p>
            <p className="text-sm font-medium text-slate-900 dark:text-white">{f.value}</p>
          </div>
        </div>
      ))}
      <p className="text-xs text-slate-400 dark:text-slate-500">Profile fields are read-only. Contact a Super Admin to make changes.</p>
    </div>
  );
}
