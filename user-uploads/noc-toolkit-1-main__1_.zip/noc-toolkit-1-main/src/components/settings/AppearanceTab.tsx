import { Sun, Moon } from 'lucide-react';
import { useThemeContext } from '../../context/ThemeContext';

export function AppearanceTab() {
  const { theme, toggleTheme } = useThemeContext();
  const options = [
    { key: 'light' as const, icon: Sun, label: 'Light', desc: 'Clean white background' },
    { key: 'dark' as const, icon: Moon, label: 'Dark', desc: 'Easy on the eyes for night shifts' },
  ];
  return (
    <div className="space-y-4">
      <p className="text-sm text-slate-500 dark:text-slate-400">Choose your preferred theme.</p>
      <div className="grid grid-cols-2 gap-3">
        {options.map((o) => (
          <button key={o.key} onClick={() => { if (theme !== o.key) toggleTheme(); }}
            className={`card text-left transition-all ${theme === o.key ? 'ring-2 ring-primary-500 border-primary-500 dark:border-primary-500' : 'hover:border-slate-300 dark:hover:border-slate-600'}`}>
            <div className="flex items-center gap-2 mb-2">
              <o.icon className="w-5 h-5 text-primary-500" />
              <span className="text-sm font-semibold text-slate-900 dark:text-white">{o.label}</span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">{o.desc}</p>
          </button>
        ))}
      </div>
    </div>
  );
}
