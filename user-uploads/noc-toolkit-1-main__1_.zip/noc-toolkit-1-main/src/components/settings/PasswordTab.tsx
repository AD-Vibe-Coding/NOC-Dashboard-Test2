import { useState } from 'react';
import { Eye, EyeOff, Check, X, LogIn, Info } from 'lucide-react';
import toast from 'react-hot-toast';
import { useAuth } from '../../hooks/useAuth';
import { PasswordStrengthMeter } from '../auth/PasswordStrengthMeter';
import { checkPasswordStrength } from '../../lib/auth/passwordStrength';

export function PasswordTab() {
  const { updatePassword } = useAuth();
  const [current, setCurrent] = useState('');
  const [newPw, setNewPw] = useState('');
  const [confirm, setConfirm] = useState('');
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [loading, setLoading] = useState(false);

  const strength = checkPasswordStrength(newPw);
  const canSubmit = !loading && !!current && !!newPw && !!confirm && newPw === confirm && strength.isAcceptable;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!strength.isAcceptable) {
      toast.error(strength.isDefault ? 'Cannot use a default password' : 'Password does not meet strength requirements');
      return;
    }
    if (newPw !== confirm) { toast.error('Passwords do not match'); return; }
    setLoading(true);
    const err = await updatePassword(current, newPw);
    setLoading(false);
    if (err) { toast.error(err); return; }
    // updatePassword clears session — user will be redirected to login
    toast.success('✅ Password changed! Logging you out to re-authenticate…', { duration: 3000 });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 max-w-md">
      {/* Info banner */}
      <div className="flex items-start gap-2 p-3 rounded-lg bg-blue-50 dark:bg-blue-500/10 border border-blue-200 dark:border-blue-500/20">
        <Info className="w-4 h-4 text-blue-500 mt-0.5 flex-shrink-0" />
        <p className="text-xs text-blue-700 dark:text-blue-300 leading-relaxed">
          After changing your password you will be logged out and redirected to sign in again with the new password.
        </p>
      </div>

      {/* Current password */}
      <div>
        <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">Current Password</label>
        <div className="relative">
          <input
            type={showCurrent ? 'text' : 'password'}
            value={current}
            onChange={e => setCurrent(e.target.value)}
            className="input-base pr-10"
            autoComplete="current-password"
          />
          <button type="button" onClick={() => setShowCurrent(v => !v)}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300">
            {showCurrent ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* New password + strength meter */}
      <div>
        <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">New Password</label>
        <div className="relative">
          <input
            type={showNew ? 'text' : 'password'}
            value={newPw}
            onChange={e => setNewPw(e.target.value)}
            placeholder="Min. 8 chars, uppercase, number, symbol"
            className="input-base pr-10"
            autoComplete="new-password"
          />
          <button type="button" onClick={() => setShowNew(v => !v)}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300">
            {showNew ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
          </button>
        </div>
        <PasswordStrengthMeter password={newPw} />
      </div>

      {/* Confirm */}
      <div>
        <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">Confirm New Password</label>
        <div className="relative">
          <input
            type={showNew ? 'text' : 'password'}
            value={confirm}
            onChange={e => setConfirm(e.target.value)}
            className={`input-base pr-10 ${confirm && newPw !== confirm ? 'border-red-400 dark:border-red-500' : ''}`}
            autoComplete="new-password"
          />
          {confirm && (
            <span className="absolute right-3 top-1/2 -translate-y-1/2">
              {newPw === confirm
                ? <Check className="w-4 h-4 text-emerald-500" />
                : <X className="w-4 h-4 text-red-500" />}
            </span>
          )}
        </div>
        {confirm && newPw !== confirm && (
          <p className="text-[11px] text-red-500 mt-1">Passwords do not match</p>
        )}
      </div>

      <button type="submit" disabled={!canSubmit} className="btn-primary">
        {loading
          ? <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
          : <LogIn className="w-4 h-4" />}
        Change Password & Re-login
      </button>
    </form>
  );
}
