import { useState, useEffect } from 'react';
import { Key, Clock, CheckCircle, Send } from 'lucide-react';
import toast from 'react-hot-toast';
import { useAuth } from '../../hooks/useAuth';
import { createResetRequest, hasActivePendingRequest } from '../../lib/auth/resetRequests';
import { getAllUsers } from '../../lib/auth/db';
import { createNotification } from '../../lib/notifications/db';

export function ResetRequestTab() {
  const { user } = useAuth();
  const [hasPending, setHasPending] = useState(false);
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    if (user) hasActivePendingRequest(user.id).then(setHasPending);
  }, [user]);

  if (!user) return null;

  const handleRequest = async () => {
    setLoading(true);
    await createResetRequest(user.id, `${user.firstName} ${user.lastName}`, user.email);

    // Notify ALL admins and super admins so they see it in their bell immediately
    try {
      const allUsers = await getAllUsers();
      const admins = allUsers.filter(u => u.role === 'admin' || u.role === 'super_admin');
      await Promise.all(admins.map(admin =>
        createNotification(
          admin.id,
          '🔑 Password Reset Request',
          `${user.firstName} ${user.lastName} (${user.email}) has requested a password reset. Click to review.`,
          'warning',
          { link: '/admin?tab=requests', createdBy: user.id, createdByName: `${user.firstName} ${user.lastName}` }
        )
      ));
    } catch { /* non-fatal */ }

    setHasPending(true);
    setSubmitted(true);
    setLoading(false);
    toast.success('Password reset request submitted — an admin will approve shortly.');
  };

  return (
    <div className="space-y-4 max-w-md">
      <div className="flex items-start gap-3 p-4 rounded-xl bg-blue-50 dark:bg-blue-500/10 border border-blue-200 dark:border-blue-500/20">
        <Key className="w-5 h-5 text-blue-500 flex-shrink-0 mt-0.5" />
        <div>
          <p className="text-sm font-medium text-blue-800 dark:text-blue-200 mb-1">Forgot your password?</p>
          <p className="text-xs text-blue-700 dark:text-blue-300 leading-relaxed">
            If you've forgotten your password and can't log in, submit a request here.
            An Admin or Super Admin will review and set a temporary password for you.
            You'll be required to change it on your next login.
          </p>
        </div>
      </div>

      {hasPending || submitted ? (
        <div className="flex items-start gap-3 p-4 rounded-xl bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-200 dark:border-emerald-500/20">
          <CheckCircle className="w-5 h-5 text-emerald-500 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-medium text-emerald-800 dark:text-emerald-200">Request submitted</p>
            <p className="text-xs text-emerald-700 dark:text-emerald-300 mt-1">
              Your request is pending admin approval. An admin will set a temporary password and share it with you.
              Check back here or ask your admin directly.
            </p>
            <div className="flex items-center gap-1 mt-2 text-[11px] text-emerald-600 dark:text-emerald-400">
              <Clock className="w-3 h-3" />
              Typically approved within one shift
            </div>
          </div>
        </div>
      ) : (
        <button
          onClick={handleRequest}
          disabled={loading}
          className="btn-primary w-full justify-center"
        >
          {loading
            ? <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            : <Send className="w-4 h-4" />}
          Submit Password Reset Request
        </button>
      )}

      <p className="text-xs text-slate-400 dark:text-slate-500">
        Admins: Sriram Parisa, Anirudh Kukudala, Matt Marquez, Perry Cox, Otukho Olembo, Zubair Mohammed, Karthik Radhakrishnan
      </p>
    </div>
  );
}
