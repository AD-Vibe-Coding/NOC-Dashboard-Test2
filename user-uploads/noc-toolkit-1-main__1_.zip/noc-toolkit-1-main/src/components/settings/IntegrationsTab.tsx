import { useState, useEffect } from 'react';
import { MessageSquare, Mail, Calendar, Check, X, AlertTriangle, Loader2 } from 'lucide-react';
import toast from 'react-hot-toast';
import { useAuth } from '../../hooks/useAuth';
import { getUserIntegrations, connectIntegration, disconnectIntegration } from '../../lib/integrations/db';
import type { IntegrationKind, UserIntegrations } from '../../types/auth';

const SERVICES = [
  { kind: 'slack' as IntegrationKind, label: 'Slack', icon: MessageSquare, color: 'bg-purple-100 dark:bg-purple-500/10 text-purple-600 dark:text-purple-400', desc: 'Get NOC alerts and ticket updates in your Slack workspace.' },
  { kind: 'gmail' as IntegrationKind, label: 'Gmail', icon: Mail, color: 'bg-red-100 dark:bg-red-500/10 text-red-600 dark:text-red-400', desc: 'Send maintenance notes and carrier updates directly from Gmail.' },
  { kind: 'gcal' as IntegrationKind, label: 'Google Calendar', icon: Calendar, color: 'bg-blue-100 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400', desc: 'Sync scheduled maintenance windows to your calendar automatically.' },
];

export function IntegrationsTab() {
  const { user } = useAuth();
  const [integrations, setIntegrations] = useState<UserIntegrations | null>(null);
  const [loading, setLoading] = useState<IntegrationKind | null>(null);

  useEffect(() => { if (user) void getUserIntegrations(user.id).then(v => setIntegrations(v)); }, [user]);

  if (!user || !integrations) return null;

  const handleConnect = async (kind: IntegrationKind, label: string) => {
    setLoading(kind);
    // Simulate OAuth round-trip
    await new Promise((r) => setTimeout(r, 700));
    const email = user.email;
    const updated = await connectIntegration(user.id, kind, email);
    setIntegrations(updated);
    setLoading(null);
    toast.success(`${label} connected`);
  };

  const handleDisconnect = async (kind: IntegrationKind, label: string) => {
    setLoading(kind);
    await new Promise((r) => setTimeout(r, 400));
    const updated = await disconnectIntegration(user.id, kind);
    setIntegrations(updated);
    setLoading(null);
    toast.success(`${label} disconnected`);
  };

  return (
    <div className="space-y-5">
      <div className="flex items-start gap-2 p-3 bg-amber-50 dark:bg-amber-900/10 rounded-lg border border-amber-200 dark:border-amber-800/30">
        <AlertTriangle className="w-4 h-4 text-amber-500 mt-0.5 flex-shrink-0" />
        <p className="text-xs text-amber-700 dark:text-amber-400">
          <strong>Demo mode:</strong> These "Connect" buttons simulate an OAuth flow. Real integration requires a backend callback URL + secure token storage (planned for production with Supabase).
        </p>
      </div>

      <div className="space-y-3">
        {SERVICES.map((s) => {
          const connected = integrations[s.kind];
          const isLoading = loading === s.kind;
          return (
            <div key={s.kind} className="card flex items-center gap-4">
              <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${s.color}`}>
                <s.icon className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold text-slate-900 dark:text-white">{s.label}</span>
                  {connected && <span className="badge-success"><Check className="w-3 h-3" /> Connected</span>}
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{s.desc}</p>
                {connected && <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-1 font-mono">{connected.accountLabel}</p>}
              </div>
              <div className="flex-shrink-0">
                {connected ? (
                  <button onClick={() => handleDisconnect(s.kind, s.label)} disabled={isLoading} className="btn-ghost text-xs px-3 py-1.5 text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10">
                    {isLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <X className="w-3.5 h-3.5" />} Disconnect
                  </button>
                ) : (
                  <button onClick={() => handleConnect(s.kind, s.label)} disabled={isLoading} className="btn-primary text-xs px-4 py-1.5">
                    {isLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : null} Connect
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
