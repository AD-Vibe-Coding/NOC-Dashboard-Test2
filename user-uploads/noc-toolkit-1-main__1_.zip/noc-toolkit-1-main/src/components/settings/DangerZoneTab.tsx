import { useState } from 'react';
import { AlertTriangle, Trash2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { useAuth } from '../../hooks/useAuth';

export function DangerZoneTab() {
  const { resetDatabaseAndLogout } = useAuth();
  const navigate = useNavigate();
  const [confirmText, setConfirmText] = useState('');
  const [showModal, setShowModal] = useState(false);

  const handleReset = () => {
    if (confirmText !== 'RESET DATABASE') return;
    resetDatabaseAndLogout();
    toast.success('Database reset. All users re-seeded with default password.');
    navigate('/login', { replace: true });
  };

  return (
    <div className="space-y-4">
      <div className="border-2 border-red-200 dark:border-red-500/30 rounded-xl p-5">
        <div className="flex items-center gap-2 mb-3">
          <AlertTriangle className="w-5 h-5 text-red-500" />
          <h3 className="text-sm font-semibold text-red-600 dark:text-red-400">Danger Zone</h3>
        </div>
        <p className="text-sm text-slate-600 dark:text-slate-400 mb-4">
          This will <strong>delete all user data</strong> (passwords, integrations) and re-seed the 17 team members with the default password <code className="font-mono text-xs">123456</code>. All sessions will be logged out.
        </p>
        <button onClick={() => setShowModal(true)} className="btn-danger text-sm">
          <Trash2 className="w-4 h-4" /> Reset Database
        </button>
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 px-4" onClick={() => setShowModal(false)}>
          <div className="bg-white dark:bg-slate-800 rounded-xl shadow-xl max-w-sm w-full p-6 space-y-4" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-red-500" />
              <h3 className="text-lg font-semibold text-slate-900 dark:text-white">Confirm Reset</h3>
            </div>
            <p className="text-sm text-slate-600 dark:text-slate-400">
              Type <code className="font-mono text-xs bg-slate-100 dark:bg-slate-700 px-1.5 py-0.5 rounded">RESET DATABASE</code> to confirm.
            </p>
            <input value={confirmText} onChange={(e) => setConfirmText(e.target.value)} placeholder="Type RESET DATABASE" className="input-base font-mono" autoFocus />
            <div className="flex items-center gap-3 justify-end">
              <button onClick={() => { setShowModal(false); setConfirmText(''); }} className="btn-ghost text-sm">Cancel</button>
              <button onClick={handleReset} disabled={confirmText !== 'RESET DATABASE'} className="btn-danger text-sm">
                <Trash2 className="w-4 h-4" /> Reset Now
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
