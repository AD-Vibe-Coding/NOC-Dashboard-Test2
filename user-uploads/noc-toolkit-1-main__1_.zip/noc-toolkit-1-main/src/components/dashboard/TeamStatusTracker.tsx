import { useState, useEffect, useMemo, useCallback } from 'react';
import { Users, CircleDot, Calendar, RefreshCw } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { getAllUsers } from '../../lib/auth/db';
import { fetchRoster, rosterNameMatches, type ActiveMember, type TodayShift } from '../../lib/roster/client';
import type { User } from '../../types/auth';

// Excluded from team status display
const EXCLUDED_USERNAMES = ['matt.marquez', 'perry.cox', 'anirudh.kukudala'];
const ROSTER_REFRESH_MS = 30 * 60 * 1000; // 30 minutes

interface RosterInfo {
  active: ActiveMember[];
  todayAll: TodayShift[];
  pacificTime: string;
}

const COLORS = [
  'bg-blue-500', 'bg-emerald-500', 'bg-amber-500', 'bg-rose-500',
  'bg-violet-500', 'bg-cyan-500', 'bg-indigo-500', 'bg-orange-500',
  'bg-teal-500', 'bg-pink-500', 'bg-lime-500', 'bg-sky-500',
  'bg-fuchsia-500', 'bg-yellow-500',
];

function getInitials(u: User) {
  return `${u.firstName[0] ?? ''}${u.lastName[0] ?? ''}`.toUpperCase();
}

type RosterStatus = 'on_shift' | 'scheduled' | 'on_leave' | 'week_off' | 'unscheduled';

interface RosterStatusInfo {
  kind: RosterStatus;
  label: string;
  shortLabel: string;
  ringClass: string;       // border ring around the card
  dotClass: string;        // status dot on the avatar
  textClass: string;       // for the rosterLabel text
  badgeClass: string;      // small pill near the top-right of the card
}

function classifyRosterStatus(
  rosterShift: TodayShift | null,
  isOnShift: boolean,
): RosterStatusInfo {
  // 🟢 GREEN — currently on shift
  if (isOnShift) {
    return {
      kind: 'on_shift',
      label: 'On shift',
      shortLabel: 'On shift',
      ringClass: 'border-emerald-300 dark:border-emerald-500/60 shadow-emerald-100 dark:shadow-emerald-900/20',
      dotClass: 'bg-emerald-500 animate-pulse',
      textClass: 'text-emerald-700 dark:text-emerald-400 font-mono',
      badgeClass: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-300',
    };
  }
  if (rosterShift) {
    const c = rosterShift.cell.toLowerCase();
    // 🔴 RED — on leave (PTO/Sick/Emergency/Holiday)
    if (c.includes('pto') || c.includes('leave') || c.includes('sick') || c.includes('emergency') || c.includes('holiday')) {
      return {
        kind: 'on_leave',
        label: rosterShift.cell, // show the exact leave type
        shortLabel: 'On leave',
        ringClass: 'border-red-300 dark:border-red-500/60',
        dotClass: 'bg-red-500',
        textClass: 'text-red-600 dark:text-red-400 font-semibold',
        badgeClass: 'bg-red-100 text-red-700 dark:bg-red-500/20 dark:text-red-300',
      };
    }
    // 🔵 BLUE — week off (WO)
    if (/^\s*wo\s*$/i.test(rosterShift.cell)) {
      return {
        kind: 'week_off',
        label: 'Week off',
        shortLabel: 'Week off',
        ringClass: 'border-sky-300 dark:border-sky-500/40',
        dotClass: 'bg-sky-500',
        textClass: 'text-sky-600 dark:text-sky-400',
        badgeClass: 'bg-sky-100 text-sky-700 dark:bg-sky-500/20 dark:text-sky-300',
      };
    }
    // 🟠 ORANGE — scheduled today but not yet logged on (shift hasn't started or has ended)
    if (/\d/.test(rosterShift.cell)) {
      return {
        kind: 'scheduled',
        label: rosterShift.cell,
        shortLabel: 'Off duty',
        ringClass: 'border-amber-300 dark:border-amber-500/50',
        dotClass: 'bg-amber-500',
        textClass: 'text-amber-700 dark:text-amber-400 font-mono',
        badgeClass: 'bg-amber-100 text-amber-700 dark:bg-amber-500/20 dark:text-amber-300',
      };
    }
    // Fallback for any other cell value
    return {
      kind: 'unscheduled',
      label: rosterShift.cell,
      shortLabel: rosterShift.cell,
      ringClass: 'border-slate-200 dark:border-slate-700',
      dotClass: 'bg-slate-400',
      textClass: 'text-slate-500 dark:text-slate-400',
      badgeClass: 'bg-slate-100 text-slate-600 dark:bg-slate-700 dark:text-slate-300',
    };
  }
  // ⚪ GRAY — not on roster at all
  return {
    kind: 'unscheduled',
    label: 'Not on roster',
    shortLabel: 'Not scheduled',
    ringClass: 'border-slate-200 dark:border-slate-700',
    dotClass: 'bg-slate-400',
    textClass: 'text-slate-500 dark:text-slate-400',
    badgeClass: 'bg-slate-100 text-slate-600 dark:bg-slate-700 dark:text-slate-300',
  };
}

interface MemberCardProps {
  teammate: User;
  currentUserId: string;
  rosterShift?: TodayShift | null;
  isOnShift: boolean;
  activeShift?: ActiveMember | null;
}

function MemberCard({ teammate, currentUserId, rosterShift, isOnShift, activeShift }: MemberCardProps) {
  const colorIdx = (teammate.firstName.charCodeAt(0) + teammate.lastName.charCodeAt(0)) % COLORS.length;
  const isMe = teammate.id === currentUserId;
  const roster = classifyRosterStatus(rosterShift ?? null, isOnShift);

  // Shift time label — show exact times if on shift, otherwise roster cell
  const shiftLabel = isOnShift && activeShift
    ? `${activeShift.start} → ${activeShift.end}`
    : roster.label;

  // Status pill — purely from roster
  const statusPill = isOnShift
    ? { label: 'On Shift', className: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-300', dot: 'bg-emerald-500 animate-pulse' }
    : roster.kind === 'on_leave'
    ? { label: 'On Leave', className: 'bg-red-100 text-red-700 dark:bg-red-500/20 dark:text-red-300', dot: 'bg-red-500' }
    : roster.kind === 'week_off'
    ? { label: 'Week Off', className: 'bg-sky-100 text-sky-700 dark:bg-sky-500/20 dark:text-sky-300', dot: 'bg-sky-500' }
    : roster.kind === 'scheduled'
    ? { label: 'Off Duty', className: 'bg-amber-100 text-amber-700 dark:bg-amber-500/20 dark:text-amber-300', dot: 'bg-amber-500' }
    : { label: 'Offline', className: 'bg-slate-100 text-slate-500 dark:bg-slate-700/60 dark:text-slate-400', dot: 'bg-slate-400' };

  const cardBorder = isOnShift
    ? 'border-emerald-300 dark:border-emerald-500/60'
    : roster.kind === 'on_leave'
    ? 'border-red-300 dark:border-red-500/40 opacity-70'
    : roster.kind === 'week_off'
    ? 'border-sky-300 dark:border-sky-500/40 opacity-70'
    : roster.kind === 'scheduled'
    ? 'border-amber-300 dark:border-amber-500/40 opacity-80'
    : 'border-slate-200 dark:border-slate-700 opacity-60';

  return (
    <div className={`card relative border-2 transition-shadow ${cardBorder} ${isMe ? 'ring-2 ring-primary-500 ring-offset-1 dark:ring-offset-slate-900' : ''}`}>
      {/* Roster status badge top-right */}
      <span className={`absolute top-2 right-2 inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[9px] font-semibold uppercase tracking-wide ${statusPill.className}`}>
        <span className={`w-1.5 h-1.5 rounded-full ${statusPill.dot}`} />
        {statusPill.label}
      </span>

      {/* Avatar + name */}
      <div className="flex items-center gap-2 mb-2 mt-3">
        <div className="relative flex-shrink-0">
          <div className={`w-10 h-10 rounded-full ${COLORS[colorIdx]} flex items-center justify-center text-white font-semibold text-sm`}>
            {getInitials(teammate)}
          </div>
          <span className={`absolute -top-0.5 -right-0.5 w-3 h-3 rounded-full ${statusPill.dot} border-2 border-white dark:border-slate-800`} />
        </div>
        <div className="min-w-0">
          <p className="text-sm font-semibold text-slate-900 dark:text-white leading-tight truncate">
            {teammate.firstName} {teammate.lastName}
          </p>
          {isMe && <p className="text-[10px] text-primary-600 dark:text-primary-400">You</p>}
        </div>
      </div>

      {/* Shift time from roster */}
      <div className="flex items-center gap-1 text-[11px] px-1">
        <Calendar className="w-3 h-3 text-slate-400 flex-shrink-0" />
        <span className={`truncate font-mono ${roster.textClass}`}>{shiftLabel}</span>
      </div>
    </div>
  );
}



type Filter = 'on_shift' | 'today' | 'on_leave' | 'all';

const LEGEND: Array<{ dot: string; label: string }> = [
  { dot: 'bg-emerald-500', label: 'On shift' },
  { dot: 'bg-amber-500', label: 'Scheduled (off duty)' },
  { dot: 'bg-red-500', label: 'On leave' },
  { dot: 'bg-sky-500', label: 'Week off' },
];

export function TeamStatusTracker() {
  const { user } = useAuth();
  const [filter, setFilter] = useState<Filter>('on_shift');
  const [roster, setRoster] = useState<RosterInfo | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  const [allUsers, setAllUsers] = useState<User[]>([]);
  useEffect(() => { getAllUsers().then(u => setAllUsers(u)); }, []);

  const teammates = useMemo(() => {
    return allUsers.filter((u) => !EXCLUDED_USERNAMES.includes(u.username));
  }, [allUsers]);

  // Fetch roster + auto-refresh every 30 min
  const loadRoster = useCallback(async () => {
    const r = await fetchRoster();
    if (r.error) return;
    setRoster({
      active: r.today.active,
      todayAll: r.today.allShifts,
      pacificTime: r.today.pacificTime,
    });
  }, []);

  useEffect(() => {
    loadRoster();
    const id = setInterval(loadRoster, ROSTER_REFRESH_MS);
    const onFocus = () => loadRoster();
    window.addEventListener('focus', onFocus);
    return () => {
      clearInterval(id);
      window.removeEventListener('focus', onFocus);
    };
  }, [loadRoster]);

  // Map roster names → User entries
  const enrichedTeammates = useMemo(() => {
    return teammates.map((u) => {
      const rosterShift = roster?.todayAll.find((s) => rosterNameMatches(s.name, u.firstName, u.lastName)) || null;
      const activeShift = roster?.active.find((a) => rosterNameMatches(a.name, u.firstName, u.lastName)) || null;
      return { user: u, rosterShift, activeShift, isOnShift: !!activeShift };
    });
  }, [teammates, roster]);

  const isOnLeave = (cell: string) => {
    const c = cell.toLowerCase();
    return c.includes('pto') || c.includes('leave') || c.includes('sick') || c.includes('emergency') || c.includes('holiday');
  };

  const visible = useMemo(() => {
    if (filter === 'on_shift') return enrichedTeammates.filter((t) => t.isOnShift);
    if (filter === 'today')
      return enrichedTeammates.filter(
        (t) => t.rosterShift && /\d/.test(t.rosterShift.cell),
      );
    if (filter === 'on_leave')
      return enrichedTeammates.filter((t) => t.rosterShift && isOnLeave(t.rosterShift.cell));
    return enrichedTeammates;
  }, [enrichedTeammates, filter]);

  const onShiftCount = enrichedTeammates.filter((t) => t.isOnShift).length;
  const scheduledTodayCount = enrichedTeammates.filter(
    (t) => t.rosterShift && /\d/.test(t.rosterShift.cell),
  ).length;
  const onLeaveCount = enrichedTeammates.filter(
    (t) => t.rosterShift && isOnLeave(t.rosterShift.cell),
  ).length;

  if (!user) return null;

  return (
    <div>
      {/* Header */}
      <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
        <div className="flex items-center gap-2 flex-wrap">
          <h2 className="text-lg font-semibold text-slate-900 dark:text-white flex items-center gap-2">
            <Users className="w-4 h-4 text-slate-500" /> Active Now
          </h2>
          {roster && (
            <span className="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-300">
              <CircleDot className="w-2.5 h-2.5 animate-pulse" />
              {onShiftCount} on shift · {roster.pacificTime} PT
            </span>
          )}
        </div>
        <button
          onClick={async () => { setRefreshing(true); await loadRoster(); setRefreshing(false); }}
          disabled={refreshing}
          className="inline-flex items-center gap-1 px-2.5 py-1 text-xs rounded-md bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
        >
          <RefreshCw className={`w-3 h-3 ${refreshing ? 'animate-spin' : ''}`} />
          Refresh roster
        </button>
      </div>

      {/* Legend */}
      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mb-2 text-[10px] text-slate-500 dark:text-slate-400">
        {LEGEND.map((l) => (
          <span key={l.label} className="inline-flex items-center gap-1">
            <span className={`w-2 h-2 rounded-full ${l.dot}`} />
            {l.label}
          </span>
        ))}
      </div>

      {/* Filter pills */}
      <div className="flex flex-wrap items-center gap-2 mb-3">
        {[
          { key: 'on_shift' as Filter, label: `On shift now (${onShiftCount})`, color: 'bg-emerald-500' },
          { key: 'today' as Filter, label: `Scheduled today (${scheduledTodayCount})`, color: 'bg-amber-500' },
          { key: 'on_leave' as Filter, label: `On leave (${onLeaveCount})`, color: 'bg-red-500' },
          { key: 'all' as Filter, label: `All team (${teammates.length})`, color: 'bg-slate-600' },
        ].map((f) => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={`text-xs px-2.5 py-1 rounded-full font-medium transition-colors ${
              filter === f.key
                ? `${f.color} text-white`
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Cards grid */}
      {visible.length > 0 ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
          {visible.map((t) => (
            <MemberCard
              key={t.user.id}
              teammate={t.user}
              currentUserId={user.id}
              rosterShift={t.rosterShift}
              isOnShift={t.isOnShift}
              activeShift={t.activeShift}
            />
          ))}
        </div>
      ) : (
        <div className="card text-center py-8 text-slate-500 dark:text-slate-400">
          <p className="text-sm">
            {filter === 'on_shift' ? 'No one is currently on shift per the roster.'
              : filter === 'today' ? 'No one is scheduled today.'
              : filter === 'on_leave' ? 'No one is on leave today.'
              : 'No teammates to show.'}
          </p>
          <p className="text-xs mt-1 opacity-70">Roster auto-refreshes every 30 minutes.</p>
        </div>
      )}

    </div>
  );
}
