import { useState, useEffect, useCallback } from 'react';
import {
  Calendar,
  RefreshCw,
  ExternalLink,
  AlertCircle,
  Loader2,
  CircleDot,
  CalendarDays,
  Users as UsersIcon,
} from 'lucide-react';
import { fetchRoster, type RosterResponse } from '../../lib/roster/client';

const SHEET_ID =
  (import.meta.env.VITE_ROSTER_SHEET_ID as string | undefined) ?? '';
const SHEET_URL = SHEET_ID
  ? `https://docs.google.com/spreadsheets/d/${SHEET_ID}/edit`
  : '';

const REFRESH_MS = 30 * 60 * 1000; // 30 minutes per user request

// Tag a roster cell value for styling
type CellKind = 'shift' | 'off' | 'leave' | 'holiday' | 'empty';
function classifyCell(val: string): CellKind {
  if (!val) return 'empty';
  const l = val.toLowerCase();
  if (/^\s*wo\s*$/i.test(val)) return 'off';
  if (l.includes('holiday')) return 'holiday';
  if (
    l.includes('pto') ||
    l.includes('leave') ||
    l.includes('sick') ||
    l.includes('emergency')
  )
    return 'leave';
  if (/\d/.test(val)) return 'shift';
  return 'shift';
}
function cellClass(kind: CellKind): string {
  switch (kind) {
    case 'shift':
      return 'text-emerald-700 dark:text-emerald-400 font-mono';
    case 'off':
      return 'text-slate-400 dark:text-slate-500';
    case 'leave':
      return 'text-amber-600 dark:text-amber-400';
    case 'holiday':
      return 'text-violet-600 dark:text-violet-400';
    default:
      return 'text-slate-300 dark:text-slate-600';
  }
}

export function ShiftRoster() {
  const [data, setData] = useState<RosterResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [lastFetch, setLastFetch] = useState<Date | null>(null);
  const [month, setMonth] = useState<string>(''); // empty = current month
  const [view, setView] = useState<'today' | 'date' | 'month'>('today');
  const [selectedDay, setSelectedDay] = useState<string>(''); // e.g. "18-May" — empty = today

  const load = useCallback(async (m?: string) => {
    setLoading(true);
    const res = await fetchRoster(m && m !== '' ? m : undefined);
    setData(res);
    setLastFetch(new Date());
    setLoading(false);
  }, []);

  useEffect(() => {
    load(month);
    // Refresh every 30 minutes
    const id = setInterval(() => load(month), REFRESH_MS);
    // Also refresh when the tab regains focus
    const onFocus = () => load(month);
    window.addEventListener('focus', onFocus);
    return () => {
      clearInterval(id);
      window.removeEventListener('focus', onFocus);
    };
  }, [load, month]);

  return (
    <div className="space-y-4">
      {/* Header row */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <Calendar className="w-5 h-5 text-primary-500" />
          <h2 className="text-lg font-semibold text-slate-900 dark:text-white">
            NOC Shift Roster
          </h2>
          {data && !data.error && data.sheetName && (
            <span className="text-xs px-2 py-0.5 rounded-full bg-primary-100 text-primary-700 dark:bg-primary-500/20 dark:text-primary-300 font-mono">
              {data.sheetName}
            </span>
          )}
          {data && data.today && data.today.pacificTime && (
            <span className="text-[11px] text-slate-500 dark:text-slate-400">
              Pacific · {data.today.pacificTime}
            </span>
          )}
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          {/* Month selector */}
          {data && data.monthTabs && data.monthTabs.length > 0 && (
            <select
              value={month || data.sheetName}
              onChange={(e) => setMonth(e.target.value)}
              className="text-xs font-medium rounded-md bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 px-2 py-1 focus:outline-none focus:ring-2 focus:ring-primary-500"
              title="Select month"
            >
              {data.monthTabs.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          )}
          {/* View toggle: Today / Pick date / Full month */}
          <div className="inline-flex rounded-md bg-slate-100 dark:bg-slate-800 p-0.5">
            <button
              onClick={() => { setView('today'); setSelectedDay(''); }}
              className={`px-2.5 py-1 text-xs font-medium rounded ${
                view === 'today'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'
              }`}
            >
              Today
            </button>
            <button
              onClick={() => setView('date')}
              className={`px-2.5 py-1 text-xs font-medium rounded ${
                view === 'date'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'
              }`}
            >
              Pick date
            </button>
            <button
              onClick={() => setView('month')}
              className={`px-2.5 py-1 text-xs font-medium rounded ${
                view === 'month'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'
              }`}
            >
              Full month
            </button>
          </div>

          {/* Day-of-month selector — only visible in "date" view */}
          {view === 'date' && data?.headerDays && data.headerDays.length > 0 && (
            <select
              value={selectedDay || data.today.label}
              onChange={(e) => setSelectedDay(e.target.value)}
              className="text-xs font-medium rounded-md bg-white dark:bg-slate-900 border border-primary-300 dark:border-primary-500/40 text-primary-700 dark:text-primary-300 px-2 py-1 focus:outline-none focus:ring-2 focus:ring-primary-500"
              title="Pick a day"
            >
              {data.headerDays.map((d) => (
                <option key={d} value={d}>{d}{d === data.today.label ? ' (today)' : ''}</option>
              ))}
            </select>
          )}
          {lastFetch && (
            <span className="text-[11px] text-slate-400 dark:text-slate-500">
              Updated{' '}
              {lastFetch.toLocaleTimeString('en-US', {
                hour: '2-digit',
                minute: '2-digit',
              })}
            </span>
          )}
          <button
            onClick={() => load(month)}
            disabled={loading}
            className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded-md bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 disabled:opacity-50 transition-colors"
          >
            <RefreshCw className={`w-3 h-3 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </button>
          {SHEET_URL && (
            <a
              href={SHEET_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded-md bg-emerald-100 dark:bg-emerald-500/20 hover:bg-emerald-200 dark:hover:bg-emerald-500/30 text-emerald-700 dark:text-emerald-300 transition-colors"
            >
              Open in Sheets <ExternalLink className="w-3 h-3" />
            </a>
          )}
        </div>
      </div>

      {/* Loading / Error states */}
      {loading && !data && (
        <div className="card flex items-center justify-center py-12 text-slate-500 dark:text-slate-400 text-sm">
          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          Loading roster from Google Sheets...
        </div>
      )}

      {data?.error && (
        <div className="card flex items-start gap-2 text-sm">
          <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-red-600 dark:text-red-400">
              Could not load roster
            </p>
            <p className="text-slate-500 dark:text-slate-400 mt-1">{data.error}</p>
            <p className="text-[11px] text-slate-400 mt-2">
              Make sure the Google Sheet is set to "Anyone with the link can
              view".
            </p>
          </div>
        </div>
      )}

      {/* TODAY VIEW: On-Shift Now + Today's Full Roster */}
      {data && !data.error && view === 'today' && (
        <>
          {/* ── On Shift Now ────────────────────────────────────────────── */}
          <div className="card">
            <div className="flex items-center gap-2 mb-3">
              <CircleDot className="w-4 h-4 text-emerald-500 animate-pulse" />
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                On Shift Now
              </h3>
              <span className="text-[11px] text-slate-500 dark:text-slate-400">
                ({data.today.label} · {data.today.pacificTime} PT)
              </span>
              <span className="ml-auto text-xs px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-300 font-semibold">
                {data.today.active.length} active
              </span>
            </div>
            {data.today.active.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                {data.today.active.map((m) => (
                  <div
                    key={m.name}
                    className="flex items-center gap-3 px-3 py-2 rounded-lg bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-200 dark:border-emerald-500/30"
                  >
                    <div className="w-8 h-8 rounded-full bg-emerald-500 text-white flex items-center justify-center text-xs font-semibold flex-shrink-0">
                      {m.name.split(' ').map((n) => n[0]).slice(0, 2).join('')}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                        {m.name}
                      </p>
                      <p className="text-[11px] font-mono text-emerald-700 dark:text-emerald-300">
                        {m.start} → {m.end}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-slate-500 dark:text-slate-400 italic">
                No one currently on shift in the roster.
              </p>
            )}
          </div>

          {/* ── Today's Full Roster ─────────────────────────────────────── */}
          <div className="card">
            <div className="flex items-center gap-2 mb-3">
              <CalendarDays className="w-4 h-4 text-primary-500" />
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                Today's Roster
              </h3>
              <span className="text-[11px] text-slate-500 dark:text-slate-400">
                {data.today.label}
              </span>
              <span className="ml-auto text-xs px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 dark:bg-slate-700/50 dark:text-slate-300">
                <UsersIcon className="w-3 h-3 inline-block mr-1 -mt-0.5" />
                {data.today.allShifts.length}
              </span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-700">
                    <th className="px-3 py-2 text-left font-semibold text-slate-700 dark:text-slate-200">
                      Member
                    </th>
                    <th className="px-3 py-2 text-left font-semibold text-slate-700 dark:text-slate-200">
                      Shift
                    </th>
                    <th className="px-3 py-2 text-left font-semibold text-slate-700 dark:text-slate-200">
                      Status
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {data.today.allShifts.map((m, idx) => {
                    const kind = classifyCell(m.cell);
                    const isActive = data.today.active.some(
                      (a) => a.name === m.name,
                    );
                    return (
                      <tr
                        key={idx}
                        className={`border-b border-slate-100 dark:border-slate-800 ${
                          isActive ? 'bg-emerald-50/50 dark:bg-emerald-500/5' : ''
                        }`}
                      >
                        <td className="px-3 py-2 font-semibold text-slate-900 dark:text-white whitespace-nowrap">
                          {m.name}
                        </td>
                        <td
                          className={`px-3 py-2 whitespace-nowrap ${cellClass(kind)}`}
                        >
                          {m.cell || '—'}
                        </td>
                        <td className="px-3 py-2 whitespace-nowrap">
                          {isActive ? (
                            <span className="inline-flex items-center gap-1 text-[11px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-300 font-semibold">
                              <CircleDot className="w-2.5 h-2.5" />
                              On shift
                            </span>
                          ) : kind === 'off' ? (
                            <span className="text-[11px] text-slate-400">Week Off</span>
                          ) : kind === 'leave' ? (
                            <span className="text-[11px] text-amber-600 dark:text-amber-400">
                              On leave
                            </span>
                          ) : kind === 'holiday' ? (
                            <span className="text-[11px] text-violet-600 dark:text-violet-400">
                              Holiday
                            </span>
                          ) : (
                            <span className="text-[11px] text-slate-400">
                              Scheduled
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}

      {/* DATE VIEW: roster for a specific day */}
      {data && !data.error && view === 'date' && data.members.length > 0 && (() => {
        const day = selectedDay || data.today.label;
        const isToday = day === data.today.label;
        // Build the "all shifts for this day" + "active right now" lists from raw members
        const shifts = data.members.map((m) => ({ name: m.name, cell: m.shifts[day] ?? '' }));
        // "Active now" only makes sense for today; for other days we just classify as "Scheduled"
        const activeNames = new Set(isToday ? data.today.active.map((a) => a.name) : []);
        return (
          <div className="card">
            <div className="flex items-center gap-2 mb-3 flex-wrap">
              <CalendarDays className="w-4 h-4 text-primary-500" />
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                Roster for {day}
              </h3>
              {isToday && (
                <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-emerald-100 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-300 font-semibold">
                  Today
                </span>
              )}
              <span className="ml-auto text-xs px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 dark:bg-slate-700/50 dark:text-slate-300">
                <UsersIcon className="w-3 h-3 inline-block mr-1 -mt-0.5" />
                {shifts.filter((s) => /\d/.test(s.cell)).length} scheduled
              </span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-700">
                    <th className="px-3 py-2 text-left font-semibold text-slate-700 dark:text-slate-200">Member</th>
                    <th className="px-3 py-2 text-left font-semibold text-slate-700 dark:text-slate-200">Shift</th>
                    <th className="px-3 py-2 text-left font-semibold text-slate-700 dark:text-slate-200">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {shifts.map((m, idx) => {
                    const kind = classifyCell(m.cell);
                    const isActive = activeNames.has(m.name);
                    return (
                      <tr
                        key={idx}
                        className={`border-b border-slate-100 dark:border-slate-800 ${
                          isActive ? 'bg-emerald-50/50 dark:bg-emerald-500/5' : ''
                        }`}
                      >
                        <td className="px-3 py-2 font-semibold text-slate-900 dark:text-white whitespace-nowrap">
                          {m.name}
                        </td>
                        <td className={`px-3 py-2 whitespace-nowrap ${cellClass(kind)}`}>
                          {m.cell || '—'}
                        </td>
                        <td className="px-3 py-2 whitespace-nowrap">
                          {isActive ? (
                            <span className="inline-flex items-center gap-1 text-[11px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-300 font-semibold">
                              <CircleDot className="w-2.5 h-2.5" /> On shift
                            </span>
                          ) : kind === 'off' ? (
                            <span className="text-[11px] text-slate-400">Week Off</span>
                          ) : kind === 'leave' ? (
                            <span className="text-[11px] text-amber-600 dark:text-amber-400">On leave</span>
                          ) : kind === 'holiday' ? (
                            <span className="text-[11px] text-violet-600 dark:text-violet-400">Holiday</span>
                          ) : kind === 'shift' ? (
                            <span className="text-[11px] text-slate-500 dark:text-slate-400">Scheduled</span>
                          ) : (
                            <span className="text-[11px] text-slate-400">—</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        );
      })()}

      {/* MONTH VIEW: Full month grid */}
      {data && !data.error && view === 'month' && data.members.length > 0 && (
        <div className="card p-0 overflow-hidden">
          <div className="overflow-x-auto max-h-[500px] overflow-y-auto">
            <table className="w-full text-xs">
              <thead className="sticky top-0 bg-slate-50 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-700 z-10">
                <tr>
                  <th className="px-3 py-2 text-left font-semibold text-slate-700 dark:text-slate-200 whitespace-nowrap sticky left-0 bg-slate-50 dark:bg-slate-900 z-20 border-r border-slate-200 dark:border-slate-700">
                    Name
                  </th>
                  {data.headerDays.map((day) => {
                    const isToday = day === data.today.label;
                    return (
                      <th
                        key={day}
                        className={`px-2 py-2 text-left font-semibold whitespace-nowrap ${
                          isToday
                            ? 'bg-emerald-100 dark:bg-emerald-500/20 text-emerald-700 dark:text-emerald-300'
                            : 'text-slate-700 dark:text-slate-200'
                        }`}
                      >
                        {day}
                      </th>
                    );
                  })}
                </tr>
              </thead>
              <tbody>
                {data.members.map((m, idx) => (
                  <tr
                    key={idx}
                    className="border-b border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50"
                  >
                    <td className="px-3 py-2 font-semibold text-slate-900 dark:text-white whitespace-nowrap sticky left-0 bg-white dark:bg-slate-800 border-r border-slate-200 dark:border-slate-700 z-10">
                      {m.name}
                    </td>
                    {data.headerDays.map((day) => {
                      const v = m.shifts[day] ?? '';
                      const kind = classifyCell(v);
                      const isToday = day === data.today.label;
                      return (
                        <td
                          key={day}
                          className={`px-2 py-2 whitespace-nowrap ${cellClass(kind)} ${
                            isToday
                              ? 'bg-emerald-50/50 dark:bg-emerald-500/10'
                              : ''
                          }`}
                          title={v}
                        >
                          {v || '—'}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
