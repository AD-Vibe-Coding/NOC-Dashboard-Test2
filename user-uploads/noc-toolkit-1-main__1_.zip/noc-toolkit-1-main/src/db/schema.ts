import { pgTable, text, timestamp, boolean, integer } from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: text("id").primaryKey(),
  first_name: text("first_name").notNull(),
  last_name: text("last_name").notNull(),
  username: text("username").notNull(),
  email: text("email").notNull(),
  password_hash: text("password_hash").notNull(),
  role: text("role").notNull(),
  created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const user_statuses = pgTable("user_statuses", {
  user_id: text("user_id").primaryKey(),
  status: text("status").notNull(),
  started_at: timestamp("started_at", { withTimezone: true }).notNull(),
  started_by_user_id: text("started_by_user_id").notNull(),
});

export const status_history = pgTable("status_history", {
  id: text("id").primaryKey(),
  user_id: text("user_id").notNull(),
  from_status: text("from_status"),
  to_status: text("to_status").notNull(),
  changed_at: timestamp("changed_at", { withTimezone: true }).notNull(),
  changed_by_user_id: text("changed_by_user_id").notNull(),
  duration_seconds: text("duration_seconds"),
});

export const user_integrations = pgTable("user_integrations", {
  user_id: text("user_id").primaryKey(),
  slack: text("slack"),
  gmail: text("gmail"),
  gcal: text("gcal"),
});

// ─── Notifications ─────────────────────────────────────────────────────────
// Stores all in-app notifications. target_user_id = specific user id OR 'all'
// for broadcast. Polled every 20s by NotificationContext for cross-browser delivery.
export const notifications = pgTable("notifications", {
  id: text("id").primaryKey(),
  target_user_id: text("target_user_id").notNull(),   // user id OR 'all'
  title: text("title").notNull(),
  message: text("message").notNull(),
  type: text("type").notNull().default("info"),        // info|success|warning|error|system
  read: boolean("read").notNull().default(false),
  link: text("link"),                                  // optional internal path e.g. /settings
  created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  created_by: text("created_by"),                      // sender user id
  created_by_name: text("created_by_name"),            // sender display name
});

// ─── User Preferences ──────────────────────────────────────────────────────
// Stores per-user settings: theme, AI model override, etc.
export const user_preferences = pgTable("user_preferences", {
  user_id: text("user_id").primaryKey(),
  theme: text("theme").notNull().default("dark"),
  ai_model_override: text("ai_model_override").notNull().default(""),
  updated_at: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

// ─── Password Reset Requests ───────────────────────────────────────────────
// Users request password resets; admins approve/reject from Admin → Password Resets tab.
export const password_reset_requests = pgTable("password_reset_requests", {
  id: text("id").primaryKey(),
  user_id: text("user_id").notNull(),
  user_name: text("user_name").notNull(),
  user_email: text("user_email").notNull(),
  requested_at: timestamp("requested_at", { withTimezone: true }).defaultNow().notNull(),
  status: text("status").notNull().default("pending"), // pending|approved|rejected
  approved_by: text("approved_by"),                    // approver display name
  approved_at: timestamp("approved_at", { withTimezone: true }),
});

// ─── User Activity Sessions ────────────────────────────────────────────────
// Heartbeat-based presence tracking: login, heartbeat, logout, inactive events.
export const user_activities = pgTable("user_activities", {
  id: text("id").primaryKey(),
  user_id: text("user_id").notNull(),
  user_name: text("user_name").notNull(),
  event: text("event").notNull(),                      // login|heartbeat|logout|inactive
  tool: text("tool"),                                  // optional: which tool was active
  created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

// ─── AI Chat Histories ─────────────────────────────────────────────────────
// Saves AI assistant chat sessions per user, accessible across browsers/devices.
export const ai_chat_histories = pgTable("ai_chat_histories", {
  id: text("id").primaryKey(),
  user_id: text("user_id").notNull(),
  title: text("title").notNull().default("New Chat"),
  messages: text("messages").notNull().default("[]"), // JSON array stored as text
  message_count: integer("message_count").notNull().default(0),
  created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updated_at: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

