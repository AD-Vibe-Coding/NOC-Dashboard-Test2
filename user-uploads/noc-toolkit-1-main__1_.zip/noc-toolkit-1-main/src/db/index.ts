/**
 * Supabase client — uses SERVICE ROLE KEY so RLS is bypassed entirely.
 * This is correct for an internal app with custom auth (no Supabase Auth).
 * The service role key gives full DB access, which is what we need since
 * there are no Supabase Auth users — our own users table handles auth.
 */
import { createClient } from "@supabase/supabase-js";

const supabaseUrl = (import.meta as any).env?.VITE_SUPABASE_URL as string | undefined;
// Use service role key — bypasses RLS. Safe for internal-only NOC tool.
const supabaseKey =
  (import.meta as any).env?.VITE_SUPABASE_SERVICE_ROLE_KEY as string | undefined ||
  (import.meta as any).env?.VITE_SUPABASE_ANON_KEY as string | undefined;

export const supabase = supabaseUrl && supabaseKey
  ? createClient(supabaseUrl, supabaseKey, {
      auth: { persistSession: false, autoRefreshToken: false },
    })
  : createClient('https://placeholder.supabase.co', 'placeholder-key');