import type { SubnetResult, IPEntry, CIDRReference } from '../types';

export function ipToLong(ip: string): number {
  const parts = ip.split('.').map(Number);
  return ((parts[0] << 24) | (parts[1] << 16) | (parts[2] << 8) | parts[3]) >>> 0;
}

export function longToIp(long: number): string {
  return [
    (long >>> 24) & 0xff,
    (long >>> 16) & 0xff,
    (long >>> 8) & 0xff,
    long & 0xff,
  ].join('.');
}

export function cidrToMask(cidr: number): number {
  if (cidr === 0) return 0;
  return (~0 << (32 - cidr)) >>> 0;
}

export function maskToCidr(mask: number): number {
  let cidr = 0;
  let m = mask;
  while (m & 0x80000000) {
    cidr++;
    m = (m << 1) >>> 0;
  }
  return cidr;
}

export function subnetMaskToString(mask: number): string {
  return longToIp(mask);
}

export function wildcardMask(mask: number): string {
  return longToIp((~mask) >>> 0);
}

export interface ParsedInput {
  ip: string;
  cidr: number;
}

export function parseSubnetInput(input: string): ParsedInput | null {
  // Just CIDR prefix like /29
  const cidrOnly = input.match(/^\/?(\d{1,2})$/);
  if (cidrOnly) {
    const cidr = parseInt(cidrOnly[1]);
    if (cidr >= 0 && cidr <= 32) {
      return { ip: '192.168.1.0', cidr };
    }
    return null;
  }

  // Full CIDR notation like 192.168.1.0/29
  const cidrNotation = input.match(/^(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\/(\d{1,2})$/);
  if (cidrNotation) {
    const cidr = parseInt(cidrNotation[2]);
    if (cidr >= 0 && cidr <= 32 && isValidIp(cidrNotation[1])) {
      return { ip: cidrNotation[1], cidr };
    }
    return null;
  }

  return null;
}

export function parseSubnetWithMask(ip: string, mask: string): ParsedInput | null {
  if (!isValidIp(ip) || !isValidIp(mask)) return null;
  const maskLong = ipToLong(mask);
  const cidr = maskToCidr(maskLong);
  return { ip, cidr };
}

function isValidIp(ip: string): boolean {
  const parts = ip.split('.');
  if (parts.length !== 4) return false;
  return parts.every(p => {
    const n = parseInt(p);
    return !isNaN(n) && n >= 0 && n <= 255;
  });
}

export function calculateSubnet(ip: string, cidr: number): SubnetResult {
  const mask = cidrToMask(cidr);
  const ipLong = ipToLong(ip);
  const networkLong = (ipLong & mask) >>> 0;
  const broadcastLong = (networkLong | (~mask >>> 0)) >>> 0;
  const totalIPs = Math.pow(2, 32 - cidr);

  let usableIPs: number;
  let usableStart: string;
  let usableEnd: string;

  if (cidr === 32) {
    usableIPs = 1;
    usableStart = longToIp(networkLong);
    usableEnd = longToIp(networkLong);
  } else if (cidr === 31) {
    // RFC 3021 - point-to-point
    usableIPs = 2;
    usableStart = longToIp(networkLong);
    usableEnd = longToIp(broadcastLong);
  } else if (cidr >= 30) {
    usableIPs = totalIPs - 2;
    usableStart = longToIp(networkLong + 1);
    usableEnd = longToIp(broadcastLong - 1);
  } else {
    usableIPs = totalIPs - 3; // network, gateway, broadcast
    usableStart = longToIp(networkLong + 2);
    usableEnd = longToIp(broadcastLong - 1);
  }

  // Generate all IPs for visual map (limit to 256 for performance)
  const allIPs: IPEntry[] = [];
  const maxDisplay = Math.min(totalIPs, 256);

  for (let i = 0; i < maxDisplay; i++) {
    const currentLong = networkLong + i;
    const currentIp = longToIp(currentLong);
    let role: IPEntry['role'];
    let label: string;

    if (cidr === 32) {
      role = 'usable';
      label = 'Host Route / Loopback';
    } else if (cidr === 31) {
      role = 'usable';
      label = i === 0 ? 'Point-to-Point (Local)' : 'Point-to-Point (Remote)';
    } else if (i === 0) {
      role = 'network';
      label = 'Network Address (Reserved)';
    } else if (i === 1) {
      role = 'gateway';
      label = 'Gateway / Router (Reserved)';
    } else if (currentLong === broadcastLong) {
      role = 'broadcast';
      label = 'Broadcast Address (Reserved)';
    } else {
      role = 'usable';
      label = 'Usable (Assignable)';
    }

    allIPs.push({ ip: currentIp, role, label });
  }

  return {
    networkAddress: longToIp(networkLong),
    subnetMask: subnetMaskToString(mask),
    wildcardMask: wildcardMask(mask),
    gateway: cidr <= 30 ? longToIp(networkLong + 1) : longToIp(networkLong),
    usableRange: { start: usableStart, end: usableEnd },
    broadcastAddress: longToIp(broadcastLong),
    totalIPs,
    usableIPs,
    cidr,
    allIPs,
  };
}

export function getPlainEnglishExplanation(result: SubnetResult): string {
  const { cidr, totalIPs, usableIPs } = result;

  if (cidr === 32) {
    return `A /32 represents a single host address. This is commonly used for loopback interfaces and host routes in routing tables.`;
  }

  if (cidr === 31) {
    return `A /31 block gives you 2 IP addresses. Under RFC 3021, both addresses are usable for point-to-point links — there's no network or broadcast address. This is commonly used for router-to-router connections.`;
  }

  const reserved = totalIPs - usableIPs;
  let reservedExplanation = '';
  if (cidr <= 30) {
    reservedExplanation = `However, ${reserved} are reserved: 1 for the network address, 1 for the gateway/router, and 1 for broadcast.`;
  }

  return `A /${cidr} block gives you ${totalIPs.toLocaleString()} total IP addresses. ${reservedExplanation} That leaves ${usableIPs.toLocaleString()} usable IP${usableIPs > 1 ? 's' : ''} you can assign to devices.`;
}

export const cidrReferenceTable: CIDRReference[] = [
  { cidr: 32, subnetMask: '255.255.255.255', total: 1, usable: 1, commonUse: 'Host route / Loopback' },
  { cidr: 31, subnetMask: '255.255.255.254', total: 2, usable: '2*', commonUse: 'Point-to-point link' },
  { cidr: 30, subnetMask: '255.255.255.252', total: 4, usable: 2, commonUse: 'Point-to-point link' },
  { cidr: 29, subnetMask: '255.255.255.248', total: 8, usable: 5, commonUse: 'Small client block' },
  { cidr: 28, subnetMask: '255.255.255.240', total: 16, usable: 13, commonUse: 'Medium client block' },
  { cidr: 27, subnetMask: '255.255.255.224', total: 32, usable: 29, commonUse: 'Office network' },
  { cidr: 26, subnetMask: '255.255.255.192', total: 64, usable: 61, commonUse: 'Department network' },
  { cidr: 25, subnetMask: '255.255.255.128', total: 128, usable: 125, commonUse: 'Large subnet' },
  { cidr: 24, subnetMask: '255.255.255.0', total: 256, usable: 253, commonUse: 'Standard LAN' },
  { cidr: 23, subnetMask: '255.255.254.0', total: 512, usable: 509, commonUse: 'Large LAN' },
  { cidr: 22, subnetMask: '255.255.252.0', total: 1024, usable: 1021, commonUse: 'Campus network' },
  { cidr: 21, subnetMask: '255.255.248.0', total: 2048, usable: 2045, commonUse: 'Large campus' },
  { cidr: 20, subnetMask: '255.255.240.0', total: 4096, usable: 4093, commonUse: 'ISP block' },
  { cidr: 16, subnetMask: '255.255.0.0', total: 65536, usable: 65533, commonUse: 'Class B equivalent' },
];
