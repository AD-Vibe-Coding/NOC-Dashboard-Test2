import { copyPlainOnly, copyRichAndPlain } from '../lib/clipboard-rich';

/**
 * Legacy plain-text copy helper — preserved for back-compat.
 * Internally uses the same hardened clipboard pipeline as the rich copy
 * (ClipboardItem API → contenteditable fallback → textarea fallback) so
 * sandboxed iframes, older browsers and Safari all still work.
 */
export async function copyToClipboard(text: string): Promise<boolean> {
  return copyPlainOnly(text);
}

/**
 * Universal rich copy. Pass HTML *and* a plain-text fallback. Bold/bullets/
 * headings/links are preserved, and the paste-side adapts to its own
 * theme — no background colors, font sizes, or text colors are forced.
 *
 *    await copyHtml("<b>hello</b><ul><li>one</li></ul>", "hello\n• one")
 */
export async function copyHtml(html: string, plain: string): Promise<boolean> {
  return copyRichAndPlain(html, plain);
}
