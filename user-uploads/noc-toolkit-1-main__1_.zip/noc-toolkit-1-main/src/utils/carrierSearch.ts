import type { Carrier, CarrierCategory } from '../types';

export interface CarrierFilter {
  query: string;
  category: CarrierCategory | 'All';
  serviceType: string | 'All';   // e.g. 'DIA', 'MPLS', 'Cable'
}

/** All distinct service types across the carrier dataset, sorted A-Z. */
export function getAllServiceTypes(carriers: Carrier[]): string[] {
  const set = new Set<string>();
  for (const c of carriers) {
    for (const s of c.services) {
      if (s.service) set.add(s.service);
    }
  }
  return [...set].sort();
}

/** Lowercase normalize for substring match. */
function norm(s: string | null | undefined): string {
  return (s ?? '').toLowerCase();
}

/** Filter + simple ranking: name match > service match > phone/email match. */
export function filterCarriers(carriers: Carrier[], f: CarrierFilter): Carrier[] {
  const q = norm(f.query.trim());

  const matchesCategory = (c: Carrier) => f.category === 'All' || c.category === f.category;
  const matchesService = (c: Carrier) =>
    f.serviceType === 'All' || c.services.some((s) => s.service === f.serviceType);

  const baseFiltered = carriers.filter((c) => matchesCategory(c) && matchesService(c));

  if (!q) return baseFiltered;

  // Score each carrier
  const scored: Array<{ c: Carrier; score: number }> = [];
  for (const c of baseFiltered) {
    let score = 0;
    const name = norm(c.name);
    if (name === q) score += 100;
    else if (name.startsWith(q)) score += 60;
    else if (name.includes(q)) score += 40;

    for (const s of c.services) {
      if (norm(s.service).includes(q)) score += 10;
      if (s.notes && norm(s.notes).includes(q)) score += 5;
    }
    if (c.allPhones.some((p) => p.includes(q))) score += 25;
    if (c.allEmails.some((e) => e.includes(q))) score += 20;

    if (score > 0) scored.push({ c, score });
  }
  scored.sort((a, b) => b.score - a.score || a.c.name.localeCompare(b.c.name));
  return scored.map((x) => x.c);
}

/** Build a tiny searchable summary for AI context. */
export function summarizeForAI(carriers: Carrier[], maxChars = 12000): string {
  const lines: string[] = [];
  for (const c of carriers) {
    const services = c.services
      .map((s) => `${s.service}${s.phones.length ? ' [' + s.phones.join(', ') + ']' : ''}`)
      .join('; ');
    const emails = c.allEmails.length ? ` Emails: ${c.allEmails.join(', ')}.` : '';
    const line = `- ${c.name} (${c.category}). Services: ${services}.${emails}`;
    if ((lines.join('\n').length + line.length) > maxChars) break;
    lines.push(line);
  }
  return lines.join('\n');
}
