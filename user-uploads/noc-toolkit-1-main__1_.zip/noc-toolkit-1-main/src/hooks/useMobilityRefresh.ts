/**
 * useMobilityRefresh — Zero localStorage.
 * Carrier contacts are refreshed in-memory only (session-scoped).
 * State lives in React — no browser storage needed.
 */
import { useState, useEffect, useRef, useCallback } from 'react';
import { MOBILITY_CARRIERS, type CarrierKey, type MobilityCarrier } from '../lib/mobility/carriers';
import { refreshCarrierContacts } from '../lib/mobility/refresh';

const REFRESH_MS = 60_000; // 60 seconds

export interface UseMobilityRefreshResult {
  carriers: MobilityCarrier[];
  lastUpdated: Date | null;
  isRefreshing: boolean;
  error: string | null;
  refresh: () => Promise<void>;
  stalenessClass: 'fresh' | 'aging' | 'stale';
}

export function useMobilityRefresh(): UseMobilityRefreshResult {
  const [carriers, setCarriers] = useState<MobilityCarrier[]>(MOBILITY_CARRIERS);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  const refresh = useCallback(async () => {
    if (isRefreshing) return;
    abortRef.current?.abort();
    abortRef.current = new AbortController();
    setIsRefreshing(true);
    setError(null);

    try {
      const result = await refreshCarrierContacts(abortRef.current.signal);
      if (result.error) {
        setError(result.error);
      } else {
        // Merge updates into the baseline carrier list
        setCarriers((prev) => {
          const merged = prev.map((c) => {
            const upd = result.updates[c.key as CarrierKey];
            if (!upd) return c;
            return {
              ...c,
              tier1Phone: upd.tier1Phone ?? c.tier1Phone,
              escalationPhone: upd.escalationPhone ?? c.escalationPhone,
              supportEmail: upd.supportEmail ?? c.supportEmail,
              portalUrl: upd.portalUrl ?? c.portalUrl,
              hours: upd.hours ?? c.hours,
              notes: upd.notes ?? c.notes,
              sourcePages: upd.sourcePages ?? c.sourcePages,
              verifiedAt: upd.verifiedAt,
            };
          });
          return merged;
        });
        setLastUpdated(new Date(result.fetchedAt));
      }
    } catch (err) {
      if (err instanceof Error && err.name !== 'AbortError') {
        setError(err.message);
      }
    } finally {
      setIsRefreshing(false);
    }
  }, [isRefreshing]);

  // Auto-refresh every 60 seconds + on tab focus + once on mount (after a 2s delay)
  useEffect(() => {
    const initial = setTimeout(() => void refresh(), 2000);
    const interval = setInterval(() => {
      if (document.visibilityState === 'visible') void refresh();
    }, REFRESH_MS);
    const onVisible = () => {
      if (document.visibilityState === 'visible') void refresh();
    };
    document.addEventListener('visibilitychange', onVisible);
    return () => {
      clearTimeout(initial);
      clearInterval(interval);
      document.removeEventListener('visibilitychange', onVisible);
      abortRef.current?.abort();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Compute staleness for UI badges (turn amber after 3 min, red after 10)
  let stalenessClass: 'fresh' | 'aging' | 'stale' = 'fresh';
  if (lastUpdated) {
    const ageSec = (Date.now() - lastUpdated.getTime()) / 1000;
    if (ageSec > 600) stalenessClass = 'stale';
    else if (ageSec > 180) stalenessClass = 'aging';
  } else {
    stalenessClass = 'stale';
  }

  return { carriers, lastUpdated, isRefreshing, error, refresh, stalenessClass };
}
