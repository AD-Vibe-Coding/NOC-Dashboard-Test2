/**
 * AI SETTINGS — Pure Supabase. Zero localStorage.
 *
 * - modelOverride: loaded from / saved to Supabase user_preferences
 * - confluenceReady: ALWAYS true — server uses .env creds, never browser creds
 * - confluence config: server-side only, not exposed to client at all
 */
import { useCallback, useEffect, useState } from 'react';
import { DEFAULT_CONFLUENCE_CONFIG, type ConfluenceConfig } from '../lib/confluence/client';
import { getUserPreferences, setUserPreferences } from '../lib/preferences/db';
import { useAuth } from './useAuth';

export function useAISettings() {
  const { user } = useAuth();
  const [modelOverride, setModelOverrideState] = useState<string>('');
  const [loaded, setLoaded] = useState(false);

  // Load from Supabase on user change
  useEffect(() => {
    if (!user) { setModelOverrideState(''); setLoaded(false); return; }
    getUserPreferences(user.id).then(prefs => {
      setModelOverrideState(prefs.aiModelOverride ?? '');
      setLoaded(true);
    });
  }, [user?.id]);

  const setModelOverride = useCallback((v: string) => {
    setModelOverrideState(v);
    if (user) void setUserPreferences(user.id, { aiModelOverride: v });
  }, [user?.id]);

  // confluenceReady is always true — server always uses .env CONFLUENCE_TOKEN
  // The browser never needs to hold Confluence credentials
  const confluenceReady = true;

  // Confluence object kept for API compatibility — creds are server-side only
  const confluence: ConfluenceConfig = {
    ...DEFAULT_CONFLUENCE_CONFIG,
    enabled: true,
    token: '', // intentionally empty — token lives in .env on the server
  };

  const setConfluence = useCallback(() => {
    // no-op — Confluence is configured server-side only
  }, []);

  return {
    modelOverride,
    setModelOverride,
    confluence,
    setConfluence,
    confluenceReady,
    loaded,
  };
}

/** Devs.ai is always considered configured — the API key is in server .env. */
export const AI_CONFIGURED = true;

/** The default agent ID baked into the build (safe to expose). */
export const DEFAULT_AGENT_ID =
  (import.meta.env.VITE_AI_AGENT_ID as string | undefined) ?? '';
