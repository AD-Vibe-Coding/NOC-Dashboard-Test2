/**
 * Tracks user activity — login, heartbeat every minute, logout.
 * - Sends events to /api/activity (writes to Supabase user_sessions)
 * - Heartbeat resets on any mouse/keyboard/touch event
 * - After 20 min of no activity → marks session as 'inactive'
 * - On page unload → marks session as 'offline'
 */

import { useEffect, useRef, useCallback } from 'react';
import type { User } from '../types/auth';

const HEARTBEAT_INTERVAL_MS = 60_000;      // send heartbeat every 1 min
const INACTIVE_TIMEOUT_MS   = 20 * 60_000; // mark inactive after 20 min

async function postActivity(
  userId: string,
  userName: string,
  userEmail: string,
  event: 'login' | 'heartbeat' | 'logout' | 'inactive',
  tool?: string,
) {
  try {
    await fetch('/api/activity', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, userName, userEmail, event, tool }),
      keepalive: event === 'logout', // survive page close
    });
  } catch { /* non-critical */ }
}

export function useActivityTracker(user: User | null) {
  const lastActivityRef = useRef<number>(Date.now());
  const inactiveRef     = useRef<boolean>(false);
  const heartbeatRef    = useRef<ReturnType<typeof setInterval> | null>(null);
  const currentToolRef  = useRef<string>('');

  // Update current tool from pathname
  useEffect(() => {
    const updateTool = () => {
      const path = window.location.pathname.replace('/', '') || 'dashboard';
      currentToolRef.current = path;
    };
    updateTool();
    window.addEventListener('popstate', updateTool);
    return () => window.removeEventListener('popstate', updateTool);
  }, []);

  const resetActivity = useCallback(() => {
    lastActivityRef.current = Date.now();
    if (inactiveRef.current && user) {
      inactiveRef.current = false;
      postActivity(user.id, `${user.firstName} ${user.lastName}`, user.email, 'heartbeat', currentToolRef.current);
    }
  }, [user]);

  useEffect(() => {
    if (!user) {
      // Clear heartbeat when no user
      if (heartbeatRef.current) clearInterval(heartbeatRef.current);
      return;
    }

    const userName = `${user.firstName} ${user.lastName}`;

    // Fire login event
    postActivity(user.id, userName, user.email, 'login');

    // Activity event listeners
    const events = ['mousemove', 'keydown', 'click', 'touchstart', 'scroll'] as const;
    events.forEach(e => window.addEventListener(e, resetActivity, { passive: true }));

    // Heartbeat interval
    heartbeatRef.current = setInterval(() => {
      const idleMs = Date.now() - lastActivityRef.current;
      if (idleMs > INACTIVE_TIMEOUT_MS) {
        if (!inactiveRef.current) {
          inactiveRef.current = true;
          // Mark as inactive but keep session alive
          postActivity(user.id, userName, user.email, 'inactive');
        }
      } else {
        inactiveRef.current = false;
        postActivity(user.id, userName, user.email, 'heartbeat', currentToolRef.current);
      }
    }, HEARTBEAT_INTERVAL_MS);

    // Log out on tab/window close
    const handleUnload = () => {
      postActivity(user.id, userName, user.email, 'logout');
    };
    window.addEventListener('beforeunload', handleUnload);

    return () => {
      if (heartbeatRef.current) clearInterval(heartbeatRef.current);
      events.forEach(e => window.removeEventListener(e, resetActivity));
      window.removeEventListener('beforeunload', handleUnload);
    };
  }, [user, resetActivity]);
}
