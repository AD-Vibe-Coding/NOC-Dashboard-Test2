import { useEffect } from 'react';

/**
 * Universal page-wide copy interceptor — ChatGPT-style "paste bare HTML".
 *
 * What it does
 * ------------
 *   When the user selects ANY text anywhere on this site and hits Ctrl/Cmd+C,
 *   we intercept the native `copy` event and write a CLEAN, BARE version of
 *   the selection to the clipboard. The cleaned version:
 *     ✅ Keeps bold, italic, headings, bullets, numbered lists, links
 *     ✅ Has NO inline styles, NO classes, NO data-* attributes
 *     ✅ Uses the destination editor's font + size + paragraph spacing
 *        (Outlook/Gmail/Slack/Word/ServiceNow/Confluence render natural)
 *     ✅ Same output style as ChatGPT's copy button
 *
 *   When the user copies from an <input>, <textarea>, or contenteditable
 *   field, we DON'T intercept — those should keep native copy behavior.
 *
 *   Falls back gracefully: if clipboardData is unavailable, the browser
 *   does its default copy instead.
 *
 * Wired in: src/components/layout/Layout.tsx (so EVERY page benefits)
 */

// Attributes stripped from every element in the cleaned HTML
const NUKE_ATTRS = [
  'style', 'class', 'bgcolor', 'color', 'face', 'background',
  'dir', 'align', 'width', 'height', 'cellpadding', 'cellspacing',
  'border', 'valign', 'nowrap',
];

const DROP_TAGS = new Set(['style', 'script', 'link', 'meta', 'noscript']);
const NEUTRALIZE_TAGS = new Set(['font', 'center']);
const BLOCK_TAGS = new Set([
  'p', 'div', 'ul', 'ol', 'li', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
  'blockquote', 'pre', 'table', 'thead', 'tbody', 'tr',
]);

function cleanFragmentHtml(fragHtml: string): string {
  const doc = new DOMParser().parseFromString(`<div>${fragHtml}</div>`, 'text/html');
  const root = doc.body.firstElementChild as HTMLElement | null;
  if (!root) return fragHtml;

  // Drop disallowed tags entirely
  root.querySelectorAll([...DROP_TAGS].join(',')).forEach((el) => el.remove());

  const walk = (el: Element) => {
    // Replace <font>/<center> with <span>
    if (NEUTRALIZE_TAGS.has(el.tagName.toLowerCase())) {
      const span = el.ownerDocument.createElement('span');
      while (el.firstChild) span.appendChild(el.firstChild);
      el.replaceWith(span);
      return walk(span);
    }

    // Strip every presentational attribute
    for (const a of NUKE_ATTRS) el.removeAttribute(a);
    [...el.attributes].forEach((a) => {
      if (a.name.startsWith('data-') || a.name.startsWith('aria-') ||
          a.name.startsWith('on') || a.name === 'role') {
        el.removeAttribute(a.name);
      }
    });

    // Keep ONLY safe attributes on <a> and <img>
    const tag = el.tagName.toLowerCase();
    if (tag === 'a') {
      const href = el.getAttribute('href');
      [...el.attributes].forEach((a) => {
        if (a.name !== 'href') el.removeAttribute(a.name);
      });
      if (href) el.setAttribute('href', href);
    } else if (tag === 'img') {
      const src = el.getAttribute('src');
      const alt = el.getAttribute('alt') ?? '';
      [...el.attributes].forEach((a) => el.removeAttribute(a.name));
      if (src) el.setAttribute('src', src);
      el.setAttribute('alt', alt);
    }

    for (const child of [...el.children]) walk(child);
  };

  for (const attr of NUKE_ATTRS) root.removeAttribute(attr);
  for (const child of [...root.children]) walk(child);

  return root.innerHTML.trim();
}

/**
 * Convert a DOM range's contents into clean plain text with bullets / line breaks.
 * Block elements get newlines between them; bullets get a "• " prefix.
 */
function rangeToPlainText(range: Range): string {
  const frag = range.cloneContents();
  const lines: string[] = [];
  let cur = '';
  const flush = () => { lines.push(cur.replace(/[ \t]+$/, '')); cur = ''; };

  const walk = (node: Node) => {
    if (node.nodeType === Node.TEXT_NODE) {
      cur += (node.nodeValue ?? '').replace(/\s+/g, ' ');
      return;
    }
    if (node.nodeType !== Node.ELEMENT_NODE) return;
    const el = node as HTMLElement;
    const tag = el.tagName.toLowerCase();

    if (tag === 'br') { flush(); return; }
    if (tag === 'li') {
      flush();
      const parent = (el.parentElement?.tagName ?? '').toLowerCase();
      cur += parent === 'ol' ? '1. ' : '• ';
      for (const c of el.childNodes) walk(c);
      flush();
      return;
    }
    if (BLOCK_TAGS.has(tag)) {
      if (cur.trim()) flush();
      for (const c of el.childNodes) walk(c);
      flush();
      // Add a blank line between top-level blocks (not inside lists)
      if (tag === 'p' || tag === 'div' || tag.startsWith('h')) lines.push('');
      return;
    }
    for (const c of el.childNodes) walk(c);
  };

  for (const c of frag.childNodes) walk(c);
  if (cur.trim()) flush();

  // Collapse runs of >2 blank lines down to 1
  const out: string[] = [];
  let blankRun = 0;
  for (const line of lines) {
    if (line.trim() === '') {
      blankRun++;
      if (blankRun <= 1) out.push('');
    } else {
      blankRun = 0;
      out.push(line);
    }
  }
  return out.join('\n').trim();
}

function isInsideEditable(node: Node | null): boolean {
  let n: Node | null = node;
  while (n && n.nodeType === Node.ELEMENT_NODE) {
    const el = n as HTMLElement;
    const tag = el.tagName?.toLowerCase();
    if (tag === 'input' || tag === 'textarea') return true;
    if (el.isContentEditable) return true;
    n = el.parentElement;
  }
  return false;
}

export function useUniversalCopy() {
  useEffect(() => {
    const onCopy = (e: ClipboardEvent) => {
      try {
        const sel = window.getSelection();
        if (!sel || sel.isCollapsed || sel.rangeCount === 0) return;

        // Skip if user is copying from a form field — let native behavior win
        const anchor = sel.anchorNode;
        if (isInsideEditable(anchor)) return;

        const range = sel.getRangeAt(0);
        const container = document.createElement('div');
        container.appendChild(range.cloneContents());
        const html = cleanFragmentHtml(container.innerHTML);
        const plain = rangeToPlainText(range) || sel.toString();

        if (!e.clipboardData) return; // let native default through
        e.clipboardData.setData('text/html', html);
        e.clipboardData.setData('text/plain', plain);
        e.preventDefault();
      } catch {
        // Never block native copy on error — just let the browser handle it
      }
    };

    document.addEventListener('copy', onCopy);
    return () => document.removeEventListener('copy', onCopy);
  }, []);
}
