import { useState, useCallback } from 'react';
import toast from 'react-hot-toast';
import { copyRichAndPlain, copyPlainOnly } from '../lib/clipboard-rich';

/**
 * Universal clipboard hook.
 *
 * Single-arg call → behaves like the old hook (plain-text copy):
 *   copyToClipboard("hello")
 *
 * With an explicit `{ html, plain }` payload → rich+plain copy.  Bold,
 * bullets, headings and links are preserved; background colours, font
 * families and explicit text colours are STRIPPED so the paste-side
 * adapts to the destination's own theme (Outlook, Slack, Word, ServiceNow,
 * Confluence all read the rich HTML; terminals fall back to plain text).
 *   copyToClipboard({ html: "<b>hello</b>", plain: "hello" }, "Note")
 *
 * Or pass a DOMRef whose rendered content should be copied as-is:
 *   copyToClipboard({ from: ref.current }, "Section")
 */

type RichInput =
  | string
  | { html: string; plain: string }
  | { from: HTMLElement | null; plain?: string };

export function useClipboard() {
  const [copied, setCopied] = useState(false);

  const copyToClipboard = useCallback(async (input: RichInput, label?: string) => {
    try {
      let ok = false;
      if (typeof input === 'string') {
        ok = await copyPlainOnly(input);
      } else if ('from' in input) {
        const node = input.from;
        if (!node) { ok = false; }
        else {
          const { cleanRenderedHtml, renderedNodeToPlain } = await import('../lib/clipboard-rich');
          const html  = cleanRenderedHtml(node);
          const plain = input.plain ?? renderedNodeToPlain(node);
          ok = await copyRichAndPlain(html, plain);
        }
      } else {
        ok = await copyRichAndPlain(input.html, input.plain);
      }

      if (!ok) throw new Error('clipboard rejected');

      setCopied(true);
      toast.success(label ? `${label} copied to clipboard!` : 'Copied — paste-side will adapt to its own theme', {
        duration: 2000,
        style: { background: '#1e293b', color: '#f1f5f9', borderRadius: '8px' },
      });
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error('Failed to copy to clipboard', {
        style: { background: '#1e293b', color: '#f1f5f9', borderRadius: '8px' },
      });
    }
  }, []);

  return { copied, copyToClipboard };
}
