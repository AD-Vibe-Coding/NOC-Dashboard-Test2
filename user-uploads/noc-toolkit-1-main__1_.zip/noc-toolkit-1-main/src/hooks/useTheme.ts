/**
 * Thin re-export from ThemeContext so existing callers of useTheme() still work.
 * Theme is now Supabase-backed via ThemeContext — no localStorage.
 */
export { useThemeContext as useTheme } from '../context/ThemeContext';
