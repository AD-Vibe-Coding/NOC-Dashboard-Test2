/**
 * THEME CONTEXT — Pure Supabase. Zero localStorage.
 * Loads user theme from user_preferences on login, saves on change.
 * Falls back to 'dark' if table missing or user not logged in.
 */
import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { getUserPreferences, setUserPreferences } from '../lib/preferences/db';

interface ThemeContextType {
  theme: 'dark' | 'light';
  toggleTheme: () => void;
  setTheme: (t: 'dark' | 'light') => void;
  loadThemeForUser: (userId: string) => Promise<void>;
}

const ThemeContext = createContext<ThemeContextType>({
  theme: 'dark',
  toggleTheme: () => {},
  setTheme: () => {},
  loadThemeForUser: async () => {},
});

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setThemeState] = useState<'dark' | 'light'>('dark');
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);

  // Apply theme to DOM
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') root.classList.add('dark');
    else root.classList.remove('dark');
  }, [theme]);

  // Called by AuthContext after login — loads user's saved theme
  const loadThemeForUser = useCallback(async (userId: string) => {
    setCurrentUserId(userId);
    const prefs = await getUserPreferences(userId);
    setThemeState(prefs.theme);
  }, []);

  const setTheme = useCallback((t: 'dark' | 'light') => {
    setThemeState(t);
    if (currentUserId) {
      void setUserPreferences(currentUserId, { theme: t });
    }
  }, [currentUserId]);

  const toggleTheme = useCallback(() => {
    setTheme(theme === 'dark' ? 'light' : 'dark');
  }, [theme, setTheme]);

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme, setTheme, loadThemeForUser }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useThemeContext() {
  return useContext(ThemeContext);
}
