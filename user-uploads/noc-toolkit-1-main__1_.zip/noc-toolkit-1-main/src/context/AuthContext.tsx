/**
 * AUTH CONTEXT — Pure Supabase. Session token only in localStorage (unavoidable for client-side).
 */
import React, { createContext, useState, useEffect, useCallback } from 'react';
import type { User } from '../types/auth';
import { getUserById, getUserByEmail, getUserByUsername, updateUser, hasAnyUsers, resetDatabase as resetDB, DEFAULT_PW_HASH } from '../lib/auth/db';
import { seedUsers } from '../lib/auth/seed';
import { hashPassword, verifyPassword } from '../lib/auth/hash';
import { getSessionUserId, setSessionUserId, clearSession, getSessionExpiresAt } from '../lib/auth/session';
import { resetIntegrations } from '../lib/integrations/db';
import { useThemeContext } from './ThemeContext';

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  login: (username: string, password: string) => Promise<string | null>;
  logout: () => void;
  updatePassword: (oldPw: string, newPw: string) => Promise<string | null>;
  resetDatabaseAndLogout: () => void;
  isSuperAdmin: boolean;
  isAdmin: boolean;
  refreshUser: () => Promise<void>;
  mustChangePassword: boolean;
  dismissPasswordWarning: () => void;
  loginWithGoogle: () => Promise<string | null>;
}

export const AuthContext = createContext<AuthContextType>({
  user: null, isLoading: true,
  login: async () => 'Not initialised',
  logout: () => {},
  updatePassword: async () => 'Not initialised',
  resetDatabaseAndLogout: () => {},
  isSuperAdmin: false, isAdmin: false,
  refreshUser: async () => {},
  mustChangePassword: false,
  dismissPasswordWarning: () => {},
  loginWithGoogle: async () => 'Not initialised',
});

const PW_DISMISS_KEY = 'noc_pw_warn_dismissed';

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [pwDismissed, setPwDismissed] = useState(false);
  const { loadThemeForUser } = useThemeContext();

  useEffect(() => {
    (async () => {
      try {
        // 1. Seed if Supabase users table is empty (first ever run)
        const hasUsers = await hasAnyUsers();
        if (!hasUsers) await seedUsers();

        // 2. Restore session from localStorage token
        const sid = getSessionUserId();
        if (sid) {
          const u = await getUserById(sid);
          if (u) {
            setUser(u);
            void loadThemeForUser(u.id);
          } else clearSession();
        }
      } catch (e) {
        console.error('Auth boot error:', e);
      } finally {
        setIsLoading(false);
      }
    })();
  }, []);

  // Auto-logout on session expiry — check every 60s
  useEffect(() => {
    const id = setInterval(() => {
      const exp = getSessionExpiresAt();
      if (user && (!exp || Date.now() > exp)) {
        clearSession();
        setUser(null);
      }
    }, 60_000);
    return () => clearInterval(id);
  }, [user]);

  const login = useCallback(async (username: string, password: string): Promise<string | null> => {
    // Always fetch from Supabase — no cache
    const u = await getUserByUsername(username);
    if (!u) return 'Invalid username or password';

    const ok = await verifyPassword(password, u.passwordHash);
    if (!ok) return 'Invalid username or password';

    setSessionUserId(u.id);
    setUser(u);
    sessionStorage.removeItem(PW_DISMISS_KEY);
    setPwDismissed(false);
    void loadThemeForUser(u.id);
    return null;
  }, []);

  const logout = useCallback(() => {
    clearSession();
    setUser(null);
  }, []);

  const updatePassword = useCallback(async (oldPw: string, newPw: string): Promise<string | null> => {
    if (!user) return 'Not logged in';

    const ok = await verifyPassword(oldPw, user.passwordHash);
    if (!ok) return 'Current password is incorrect';
    if (newPw.length < 8) return 'New password must be at least 8 characters';

    const newHash = await hashPassword(newPw);

    // Prevent user from "changing" back to the default password
    if (newHash === DEFAULT_PW_HASH) return 'Please choose a different password — not the default one';

    // Write new hash to Supabase FIRST
    const updated = await updateUser(user.id, { passwordHash: newHash });
    if (!updated) return 'Failed to save — please try again';

    // Update React state immediately — modal disappears instantly, no re-login needed
    // mustChangePassword is now false because newHash !== DEFAULT_PW_HASH
    setUser({ ...user, passwordHash: newHash, mustChangePassword: false });

    return null;
  }, [user]);

  const resetDatabaseAndLogout = useCallback(() => {
    void resetDB();
    if (user) void resetIntegrations(user.id);
    clearSession();
    setUser(null);
  }, [user]);

  const refreshUser = useCallback(async () => {
    if (!user) return;
    const fresh = await getUserById(user.id);
    if (fresh) setUser(fresh);
  }, [user]);

  const dismissPasswordWarning = useCallback(() => {
    sessionStorage.setItem(PW_DISMISS_KEY, '1');
    setPwDismissed(true);
  }, []);

  // ── Google OAuth → NOC user bridge ──────────────────────────────────────
  // Called after signIn('google') resolves. Fetches /api/auth/me to get the
  // Google profile email, then looks up the NOC user in Supabase by email.
  const loginWithGoogle = useCallback(async (): Promise<string | null> => {
    try {
      const r = await fetch('/api/auth/me', { credentials: 'include' });
      if (!r.ok) return 'Could not verify Google session';
      const data = await r.json() as { user?: { email?: string; authorized?: boolean } };
      const gUser = data.user;
      if (!gUser?.email) return 'No email returned from Google';
      if (!gUser.authorized) return 'Your account is not authorized. Contact Sriram or Anirudh.';

      const u = await getUserByEmail(gUser.email);
      if (!u) return 'Your Google account is not registered in the NOC team. Contact Sriram or Anirudh.';

      setSessionUserId(u.id);
      setUser(u);
      sessionStorage.removeItem(PW_DISMISS_KEY);
      setPwDismissed(false);
      void loadThemeForUser(u.id);
      return null;
    } catch (err) {
      return err instanceof Error ? err.message : 'Google sign-in failed';
    }
  }, [loadThemeForUser]);

  const isSuperAdmin = user?.role === 'super_admin';
  const isAdmin = user?.role === 'admin' || isSuperAdmin;
  const mustChangePassword = !!(user?.mustChangePassword) && !pwDismissed;

  return (
    <AuthContext.Provider value={{ user, isLoading, login, logout, updatePassword, resetDatabaseAndLogout, isSuperAdmin, isAdmin, refreshUser, mustChangePassword, dismissPasswordWarning, loginWithGoogle }}>
      {children}
    </AuthContext.Provider>
  );
}
