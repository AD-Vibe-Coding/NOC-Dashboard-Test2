/**
 * NOTIFICATION CONTEXT — Pure Supabase. Polls every 20s for cross-browser delivery.
 * Zero localStorage.
 */
import React, { createContext, useState, useEffect, useCallback, useContext, useRef } from 'react';
import type { Notification, NotificationType } from '../lib/notifications/db';
import {
  getNotificationsForUser, markAsRead, markAllAsRead,
  createNotification, deleteNotification,
} from '../lib/notifications/db';
import { useAuth } from '../hooks/useAuth';

interface NotificationContextType {
  notifications: Notification[];
  unreadCount: number;
  markRead: (id: string) => Promise<void>;
  markAllRead: () => Promise<void>;
  send: (targetUserId: string, title: string, message: string, type?: NotificationType, options?: { link?: string }) => Promise<Notification | null>;
  remove: (id: string) => Promise<void>;
  refresh: () => Promise<void>;
}

const NotificationContext = createContext<NotificationContextType>({
  notifications: [], unreadCount: 0,
  markRead: async () => {},
  markAllRead: async () => {},
  send: async () => null,
  remove: async () => {},
  refresh: async () => {},
});

// Module-level guard — welcome notification fires once per session per user
const welcomedUsers = new Set<string>();
const POLL_MS = 20_000; // 20 second poll — notifications appear within 20s cross-browser

export function NotificationProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const fetchAndSet = useCallback(async () => {
    if (!user) { setNotifications([]); setUnreadCount(0); return; }
    const notifs = await getNotificationsForUser(user.id);
    setNotifications(notifs);
    setUnreadCount(notifs.filter(n => !n.read).length);
  }, [user?.id]);

  useEffect(() => {
    if (!user) {
      setNotifications([]);
      setUnreadCount(0);
      if (pollRef.current) clearInterval(pollRef.current);
      return;
    }

    // Immediate fetch
    fetchAndSet();

    // Poll Supabase every 20s — this is how cross-browser delivery works
    if (pollRef.current) clearInterval(pollRef.current);
    pollRef.current = setInterval(fetchAndSet, POLL_MS);

    // Welcome notification — once per user ever, checked against Supabase
    // so it doesn't re-fire on every page refresh
    if (!welcomedUsers.has(user.id)) {
      welcomedUsers.add(user.id);
      setTimeout(async () => {
        // Only send if user has ZERO notifications yet (brand new account)
        const existing = await getNotificationsForUser(user.id);
        if (existing.length === 0) {
          await createNotification(
            user.id,
            `Welcome, ${user.firstName}! 👋`,
            user.mustChangePassword
              ? 'You are using the default password. Please change it in Settings → Password.'
              : 'You are logged in to NOC Toolkit. Stay safe on shift!',
            user.mustChangePassword ? 'warning' : 'success',
            { link: user.mustChangePassword ? '/settings' : '/' }
          );
          fetchAndSet();
        }
      }, 1200);
    }

    return () => { if (pollRef.current) clearInterval(pollRef.current); };
  }, [user?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  const markRead = useCallback(async (id: string) => {
    await markAsRead(id);
    await fetchAndSet();
  }, [fetchAndSet]);

  const markAllRead = useCallback(async () => {
    if (!user) return;
    await markAllAsRead(user.id);
    await fetchAndSet();
  }, [user, fetchAndSet]);

  const send = useCallback(async (
    targetUserId: string,
    title: string,
    message: string,
    type: NotificationType = 'info',
    options?: { link?: string }
  ): Promise<Notification | null> => {
    const n = await createNotification(targetUserId, title, message, type, {
      ...options,
      createdBy: user?.id,
      createdByName: user ? `${user.firstName} ${user.lastName}` : 'System',
    });
    await fetchAndSet();
    return n;
  }, [user, fetchAndSet]);

  const remove = useCallback(async (id: string) => {
    await deleteNotification(id);
    await fetchAndSet();
  }, [fetchAndSet]);

  const refresh = useCallback(async () => {
    await fetchAndSet();
  }, [fetchAndSet]);

  return (
    <NotificationContext.Provider value={{ notifications, unreadCount, markRead, markAllRead, send, remove, refresh }}>
      {children}
    </NotificationContext.Provider>
  );
}

export const useNotifications = () => useContext(NotificationContext);
