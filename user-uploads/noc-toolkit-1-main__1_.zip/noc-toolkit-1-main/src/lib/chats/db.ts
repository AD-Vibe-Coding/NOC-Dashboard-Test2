/**
 * AI CHAT HISTORIES — Pure Supabase. Zero localStorage.
 * Chats are saved per-user and accessible on any device/browser.
 */

import { supabase } from '../../db';
import type { ChatMessage } from '../../types';

export interface SavedChat {
  id: string;
  userId: string;
  title: string;
  messages: ChatMessage[];
  messageCount: number;
  createdAt: string;
  updatedAt: string;
}

function fromRow(r: any): SavedChat {
  return {
    id: r.id,
    userId: r.user_id,
    title: r.title ?? 'New Chat',
    messages: Array.isArray(r.messages) ? r.messages : [],
    messageCount: r.message_count ?? 0,
    createdAt: r.created_at,
    updatedAt: r.updated_at,
  };
}

export function chatTitle(messages: ChatMessage[]): string {
  const first = messages.find(m => m.role === 'user');
  if (!first) return 'New Chat';
  const text = first.content.slice(0, 55);
  return text + (first.content.length > 55 ? '…' : '');
}

// ─── Reads ────────────────────────────────────────────────────────────────────

export async function getChatHistory(userId: string): Promise<SavedChat[]> {
  const { data, error } = await supabase
    .from('ai_chat_histories')
    .select('*')
    .eq('user_id', userId)
    .order('updated_at', { ascending: false })
    .limit(50);

  if (error) { console.warn('getChatHistory:', error.message); return []; }
  return (data ?? []).map(fromRow);
}

// ─── Writes ───────────────────────────────────────────────────────────────────

export async function saveChat(
  chatId: string,
  userId: string,
  messages: ChatMessage[],
): Promise<void> {
  if (messages.length === 0) return;
  const title = chatTitle(messages);
  const now = new Date().toISOString();

  const { error } = await supabase
    .from('ai_chat_histories')
    .upsert({
      id: chatId,
      user_id: userId,
      title,
      messages: messages.map(m => ({
        id: m.id,
        role: m.role,
        content: m.content,
        timestamp: m.timestamp instanceof Date ? m.timestamp.toISOString() : m.timestamp,
      })),
      message_count: messages.length,
      updated_at: now,
    }, { onConflict: 'id' });

  if (error) console.warn('saveChat:', error.message);
}

export async function deleteChat(chatId: string): Promise<void> {
  await supabase.from('ai_chat_histories').delete().eq('id', chatId);
}

export async function deleteAllChats(userId: string): Promise<void> {
  await supabase.from('ai_chat_histories').delete().eq('user_id', userId);
}
