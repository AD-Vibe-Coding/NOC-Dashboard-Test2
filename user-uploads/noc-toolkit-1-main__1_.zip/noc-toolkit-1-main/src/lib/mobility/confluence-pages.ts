/**
 * Featured Confluence pages surfaced inside the Mobility tab.
 * The agent fetches full page content on demand and we render it inline.
 */

export interface ConfluencePageRef {
  id: string;
  title: string;
  description: string;
  category: 'activation' | 'troubleshooting' | 'reference';
  url: string;
}

export const FEATURED_PAGES: ConfluencePageRef[] = [
  {
    id: '45583453',
    title: 'Mobility Task Template',
    description: 'Master template for opening any mobility task / ticket — includes required fields, sign-offs, and escalation paths.',
    category: 'reference',
    url: 'https://vikicloud.atlassian.net/wiki/spaces/TS/pages/45583453/Mobility+Task+Template',
  },
  {
    id: '132645262',
    title: 'How to activate a new physical SIM — Telispire',
    description: 'Step-by-step Telispire SIM activation guide via the Telispire portal. Covers SIM-to-device pairing and verification.',
    category: 'activation',
    url: 'https://vikicloud.atlassian.net/wiki/spaces/TS/pages/132645262/How+to+activate+new+physical+SIM+-+Telispire',
  },
  {
    id: '132646820',
    title: 'TLC Classic — Basic Troubleshooting',
    description: 'First-line troubleshooting for TLC Classic devices. Power, SIM, signal, and reset procedures.',
    category: 'troubleshooting',
    url: 'https://vikicloud.atlassian.net/wiki/spaces/TS/pages/132646820/TLC+classic+Basic+Troubleshooting',
  },
  {
    id: '45550318',
    title: 'Android FAQs',
    description: 'Most common Android questions: APN, MMS, eSIM, dual-SIM, profile install, factory reset.',
    category: 'reference',
    url: 'https://vikicloud.atlassian.net/wiki/spaces/TS/pages/45550318/Android+FAQs',
  },
];
