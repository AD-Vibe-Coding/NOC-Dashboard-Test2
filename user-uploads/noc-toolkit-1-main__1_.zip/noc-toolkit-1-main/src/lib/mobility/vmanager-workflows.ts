/**
 * vManager Mobile workflows — extracted from the vCom vManager Mobile
 * Quick Reference Guide. Each workflow lists exact UI navigation steps.
 */

export type WorkflowCategory = 'procurement' | 'line_status' | 'plan_device';

export interface WorkflowStep {
  /** What the user clicks / fills in */
  text: string;
  /** Optional emphasized noun (auto-bolded in UI) */
  emphasis?: string;
}

export interface VManagerWorkflow {
  id: string;
  title: string;
  category: WorkflowCategory;
  blurb: string;
  steps: WorkflowStep[];
  note?: string;
}

export const VMANAGER_WORKFLOWS: VManagerWorkflow[] = [
  // ─── PROCUREMENT ─────────────────────────────────────────────
  {
    id: 'upgrade',
    title: 'Change Device (Upgrade) request',
    category: 'procurement',
    blurb: 'Upgrade a device on an existing line.',
    steps: [
      { text: 'Search for the mobile ID, or hover Operations Management → Assets → Inventory → Mobile tab.' },
      { text: 'Click the mobile-number hyperlink to open the asset.' },
      { text: 'Top-right hamburger icon → select Change Device.' },
      { text: 'Complete required fields → Submit.' },
    ],
    note: 'Also applies to user-owned devices.',
  },
  {
    id: 'new_activation',
    title: 'Ordering a new activation (new or port) + device',
    category: 'procurement',
    blurb: 'Activate a brand-new line or port a number, and order a device.',
    steps: [
      { text: 'Planning & Procurement → Sourcing → My Marketplace / vCom Marketplace → Mobile tab.' },
      { text: 'Choose Order a Service from the dropdown.' },
      { text: 'Select Order a Line with New Number (or Port A Number) and Order a New Device.' },
      { text: 'Pick the Carrier and Account.' },
      { text: 'Fill in the required fields → Submit.' },
    ],
  },
  {
    id: 'tol_in',
    title: 'Transfer of Liability (BAN-to-BAN Transfer) + device',
    category: 'procurement',
    blurb: 'Move a number between accounts and ship a new device.',
    steps: [
      { text: 'Planning & Procurement → Sourcing → Marketplace → Mobile tab.' },
      { text: 'Order a Service → Transfer A Number → Order a New Device.' },
      { text: 'Pick the destination Carrier and Account.' },
      { text: 'Fill in the required fields → Submit.' },
    ],
  },
  {
    id: 'flip_flop',
    title: 'Flip flop devices',
    category: 'procurement',
    blurb: 'Swap a device between two existing lines.',
    steps: [
      { text: 'Operations Management → Assets → Inventory → Mobile tab.' },
      { text: 'Open the mobile number you want to swap.' },
      { text: 'Top-right hamburger icon → Flip Flop Order.' },
      { text: 'Fill in the required fields → Submit.' },
    ],
  },
  {
    id: 'accessories',
    title: 'Ordering accessories',
    category: 'procurement',
    blurb: 'Cases, chargers, screen protectors, etc.',
    steps: [
      { text: 'Not yet available in the vManager Marketplace. Coming soon.' },
    ],
    note: 'For urgent accessory orders, work through your vCom account team.',
  },
  {
    id: 'wearable',
    title: 'Ordering a wearable (paired with a smartphone)',
    category: 'procurement',
    blurb: 'Apple Watch / Galaxy Watch paired to an existing line.',
    steps: [
      { text: 'Operations Management → Assets → Inventory → Mobile tab.' },
      { text: 'Open the parent smartphone line.' },
      { text: 'Top-right hamburger icon → Add Wearable.' },
      { text: 'Complete the procurement flow → Submit.' },
    ],
  },

  // ─── LINE STATUS ─────────────────────────────────────────────
  {
    id: 'suspend',
    title: 'Suspending a wireless line',
    category: 'line_status',
    blurb: 'Lost / stolen / vacation suspend.',
    steps: [
      { text: 'Operations Management → Assets → Inventory → Mobile tab.' },
      { text: 'Open the mobile number.' },
      { text: 'Top-right hamburger icon → Suspend Order.' },
      { text: 'Fill in the required fields → OK.' },
    ],
  },
  {
    id: 'restore',
    title: 'Reactivating a suspended wireless line',
    category: 'line_status',
    blurb: 'Restore service after a suspend.',
    steps: [
      { text: 'Operations Management → Assets → Inventory → Mobile tab.' },
      { text: 'Open the suspended mobile number.' },
      { text: 'Top-right hamburger icon → Restore Order.' },
      { text: 'Fill in the required fields → Save.' },
    ],
  },
  {
    id: 'cancel',
    title: 'Canceling a wireless line',
    category: 'line_status',
    blurb: 'Permanently disconnect a line.',
    steps: [
      { text: 'Operations Management → Assets → Inventory → Mobile tab.' },
      { text: 'Open the mobile number.' },
      { text: 'Top-right hamburger icon → Disconnect Order.' },
      { text: 'Fill in the required fields → Place Disconnect Order.' },
    ],
  },
  {
    id: 'tol_out',
    title: 'Transfer of Liability OUT',
    category: 'line_status',
    blurb: 'Move a number to another company / personal account.',
    steps: [
      { text: 'Operations Management → Assets → Inventory → Mobile tab.' },
      { text: 'Open the mobile number.' },
      { text: 'Top-right hamburger icon → TOL Out Order.' },
      { text: 'Fill in the required fields → Place TOL Out Order.' },
    ],
  },

  // ─── PLAN & DEVICE FEATURES ──────────────────────────────────
  {
    id: 'plan_change',
    title: 'Submitting a plan change',
    category: 'plan_device',
    blurb: 'Change the rate plan on an existing line.',
    steps: [
      { text: 'Operations Management → Assets → Inventory → Mobile tab.' },
      { text: 'Open the mobile number.' },
      { text: 'Top-right hamburger icon → Change Plan.' },
      { text: 'Fill in the required fields → Submit.' },
    ],
  },
  {
    id: 'feature_change',
    title: 'Submitting a feature change / add-on',
    category: 'plan_device',
    blurb: 'International Day Pass, call forwarding, AT&T Passport, MobileWall, etc.',
    steps: [
      { text: 'Operations Management → Assets → Inventory → Mobile tab.' },
      { text: 'Open the mobile number.' },
      { text: 'Top-right hamburger icon → Change Add Ons.' },
      { text: 'Options include: Intl. Day Pass, call forwarding, lock incoming/outgoing, AT&T Passport / data bundle, MobileWall.' },
      { text: 'Fill in the required fields → Submit.' },
    ],
  },
  {
    id: 'trouble_ticket',
    title: 'Open a trouble ticket (device / service help)',
    category: 'plan_device',
    blurb: 'Get device or service troubleshooting from vCom Operations.',
    steps: [
      { text: 'Operations Management → Assets → Inventory → Mobile tab.' },
      { text: 'Open the mobile number.' },
      { text: 'Bottom-right → Open Trouble Ticket.' },
      { text: 'Fill in the required fields → Save.' },
    ],
    note: 'vCom Technical Support: 800-804-VCOM (8266) Option 3.',
  },
  {
    id: 'warranty',
    title: 'Warranty exchange / replacement device',
    category: 'plan_device',
    blurb: 'Defective device → replacement.',
    steps: [
      { text: 'Operations Management → Assets → Inventory → Mobile tab.' },
      { text: 'Open the mobile number.' },
      { text: 'Top-right hamburger icon → Warranty Replacement.' },
      { text: 'Fill in the required fields → OK.' },
      { text: 'IMPORTANT: also open a Trouble Ticket (see workflow above) — both are required.' },
    ],
  },
  {
    id: 'number_change',
    title: 'Change a wireless number',
    category: 'plan_device',
    blurb: 'Issue a new mobile number for an existing line.',
    steps: [
      { text: 'Operations Management → Assets → Inventory → Mobile tab.' },
      { text: 'Open the mobile number.' },
      { text: 'Top-right hamburger icon → Number Change Order.' },
      { text: 'Complete the required fields → OK.' },
    ],
  },
];
