/**
 * Mobility carrier registry — 7 carriers the NOC supports.
 * Phone/email/URL fields are starting baselines; the agent refresh
 * job updates them in-place every 60 seconds from Confluence.
 */

export type CarrierKey =
  | 'att_quantamshift_opus'
  | 'att_retail'
  | 'verizon_quantamshift_telispire'
  | 'verizon_retail'
  | 'tmobile'
  | 'cybereef'
  | 'firstnet'
  | 'granite';

export interface MobilityCarrier {
  key: CarrierKey;
  name: string;
  shortName: string;
  category: 'Business' | 'Retail' | 'Specialty';
  brandColor: string;          // hex
  tier1Phone: string | null;
  escalationPhone: string | null;
  supportEmail: string | null;
  portalUrl: string | null;
  hours: string | null;
  notes: string | null;
  sourcePages?: string[];      // Confluence page titles that backed the data
  verifiedAt?: string;         // ISO timestamp of last successful refresh
}

/**
 * Baseline (placeholder) data shown immediately on page load while the
 * background refresh fetches live data from Confluence. These are public
 * carrier support lines — they will be overwritten when the agent returns.
 */
export const MOBILITY_CARRIERS: MobilityCarrier[] = [
  {
    key: 'att_quantamshift_opus',
    name: 'AT&T Wireless via QuantumShift (OPUS)',
    shortName: 'AT&T QS OPUS',
    category: 'Business',
    brandColor: '#00A8E0',
    tier1Phone: '1-855-288-7867',
    escalationPhone: '1-866-288-7867',
    supportEmail: 'mobility-support@quantumshift.com',
    portalUrl: 'https://opus.quantumshift.com',
    hours: '24/7',
    notes: 'Always include the OPUS Order ID / Ticket ID when contacting QuantumShift. Use OPUS portal for SIM activations.',
  },
  {
    key: 'att_retail',
    name: 'AT&T Wireless (Retail / Direct)',
    shortName: 'AT&T Retail',
    category: 'Retail',
    brandColor: '#00A8E0',
    tier1Phone: '1-800-331-0500',
    escalationPhone: '1-800-331-0500',
    supportEmail: null,
    portalUrl: 'https://www.att.com/wireless/',
    hours: '24/7',
    notes: 'Direct AT&T retail line. Have the BAN and PIN ready before calling.',
  },
  {
    key: 'verizon_quantamshift_telispire',
    name: 'Verizon Wireless via QuantumShift / Telispire',
    shortName: 'Verizon QS/Telispire',
    category: 'Business',
    brandColor: '#CD040B',
    tier1Phone: '1-866-836-9197',
    escalationPhone: '1-855-288-7867',
    supportEmail: 'support@telispire.com',
    portalUrl: 'https://portal.telispire.com',
    hours: '24/7',
    notes: 'Telispire is a Verizon MVNO. Physical SIM activations use the Telispire portal. eSIM activations require a separate flow.',
  },
  {
    key: 'verizon_retail',
    name: 'Verizon Wireless (Retail / Direct)',
    shortName: 'Verizon Retail',
    category: 'Retail',
    brandColor: '#CD040B',
    tier1Phone: '1-800-922-0204',
    escalationPhone: '1-800-922-0204',
    supportEmail: null,
    portalUrl: 'https://www.verizon.com/business/',
    hours: '24/7',
    notes: 'Verizon direct retail line. Use #PMT, #BAL, #DATA shortcodes from the device.',
  },
  {
    key: 'tmobile',
    name: 'T-Mobile for Business',
    shortName: 'T-Mobile',
    category: 'Business',
    brandColor: '#E20074',
    tier1Phone: '1-844-866-2453',
    escalationPhone: '1-877-778-2106',
    supportEmail: null,
    portalUrl: 'https://www.t-mobile.com/business',
    hours: '24/7',
    notes: 'T-Mobile business support. Use the T-Mobile for Business portal for line management.',
  },
  {
    key: 'cybereef',
    name: 'CyberReef Solutions',
    shortName: 'CyberReef',
    category: 'Specialty',
    brandColor: '#0066B3',
    tier1Phone: '1-844-256-1611',
    escalationPhone: '1-844-256-1611',
    supportEmail: 'support@cybereef.com',
    portalUrl: 'https://www.cybereef.com',
    hours: 'Mon–Fri 8 AM – 8 PM CT',
    notes: 'Mobile security / firewall service. Open tickets via portal; phone for P1 incidents only.',
  },
  {
    key: 'firstnet',
    name: 'FirstNet (AT&T Public Safety)',
    shortName: 'FirstNet',
    category: 'Specialty',
    brandColor: '#003F72',
    tier1Phone: '1-800-574-7000',
    escalationPhone: '1-800-574-7000',
    supportEmail: null,
    portalUrl: 'https://www.firstnet.com',
    hours: '24/7',
    notes: 'FirstNet line for first responders & public safety agencies. Always verify the BAN is a FirstNet BAN before calling.',
  },
  {
    key: 'granite',
    name: 'Granite Telecommunications',
    shortName: 'Granite',
    category: 'Business',
    brandColor: '#003B71',
    tier1Phone: '1-866-847-1500',
    escalationPhone: '1-866-847-1500',
    supportEmail: 'noc@granitenet.com',
    portalUrl: 'https://www.granitenet.com',
    hours: '24/7',
    notes: 'Granite manages mobility for many enterprise accounts. Include the Granite Account # and circuit ID when contacting.',
  },
];

export function getCarrier(key: CarrierKey): MobilityCarrier | undefined {
  return MOBILITY_CARRIERS.find((c) => c.key === key);
}
