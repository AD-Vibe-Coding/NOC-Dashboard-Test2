/**
 * Confluence search + page listing through the Devs.ai agent's Confluence
 * connector. Search-based (not ID-based) because that's how connectors
 * actually work — they index page CONTENT, not IDs.
 */

import { complete, extractJSON } from '../devs-ai/complete';

// ────────────────────────────────────────────────────────────────
// Types
// ────────────────────────────────────────────────────────────────

export type PageCategory =
  | 'activation'
  | 'troubleshooting'
  | 'reference'
  | 'carrier'
  | 'general';

export interface SearchHit {
  title: string;
  snippet: string;
  url: string;
  category: PageCategory;
}

export interface PageListEntry {
  title: string;
  url: string;
  description: string;
  category: PageCategory;
}

// ────────────────────────────────────────────────────────────────
// Live search
// ────────────────────────────────────────────────────────────────

/**
 * Search the company Confluence wiki for pages matching a query.
 * Returns up to 8 results with title, snippet, URL, and category.
 */
export async function searchConfluence(
  query: string,
  signal?: AbortSignal,
): Promise<{ results: SearchHit[]; error?: string; raw?: string }> {
  if (!query.trim()) return { results: [] };

  const prompt = `Using your Confluence connector, search the company wiki for pages matching this query: "${query}"

Return ONLY a JSON object with this exact shape (no markdown fences, no explanation):

{
  "results": [
    {
      "title": "Exact page title from Confluence",
      "snippet": "A 1-2 sentence excerpt from the page content that matches the query",
      "url": "https://vikicloud.atlassian.net/wiki/... actual URL from your connector ...",
      "category": "activation" | "troubleshooting" | "reference" | "carrier" | "general"
    }
  ]
}

CRITICAL RULES:
- Maximum 8 results, ordered by relevance.
- Prefer pages in the Tech Support / NOC / Mobility spaces (e.g. space TS).
- The "url" MUST be a real Confluence URL surfaced by your connector — do not invent URLs.
- The "snippet" must be from the page CONTENT (not just a repeat of the title).
- If you cannot find any matching pages, return: {"results": []}
- Return ONLY the JSON, nothing else.`;

  const res = await complete([{ role: 'user', content: prompt }], { signal });
  if (res.error) return { results: [], error: res.error };

  const parsed = extractJSON<{ results: SearchHit[] }>(res.text);
  if (!parsed || !Array.isArray(parsed.results)) {
    return {
      results: [],
      error: 'Could not parse search results from agent',
      raw: res.text.slice(0, 300),
    };
  }
  // Sanitize
  const clean = parsed.results
    .filter((r) => r && typeof r.title === 'string' && r.title.trim().length > 0)
    .map((r) => ({
      title: r.title.trim(),
      snippet: (r.snippet || '').trim(),
      url: (r.url || '').trim(),
      category: (['activation', 'troubleshooting', 'reference', 'carrier', 'general'].includes(r.category)
        ? r.category
        : 'general') as PageCategory,
    }));
  return { results: clean };
}

// ────────────────────────────────────────────────────────────────
// Full page list (cached)
// ────────────────────────────────────────────────────────────────

// In-memory cache — no browser storage needed (5 min TTL, session-scoped)
const PAGE_LIST_TTL_MS = 5 * 60 * 1000;
interface CachedPageList { pages: PageListEntry[]; fetchedAt: string; }
const _pageListCache = new Map<string, { data: CachedPageList; ts: number }>();

function readCache(): CachedPageList | null {
  const entry = _pageListCache.get('mobility_pages');
  if (!entry) return null;
  if (Date.now() - entry.ts > PAGE_LIST_TTL_MS) { _pageListCache.delete('mobility_pages'); return null; }
  return entry.data;
}

function writeCache(pages: PageListEntry[]) {
  _pageListCache.set('mobility_pages', { data: { pages, fetchedAt: new Date().toISOString() }, ts: Date.now() });
}

/**
 * Lists all Mobility-related Confluence pages discoverable by the agent.
 * Cached in memory for 5 minutes.
 */
export async function listMobilityPages(
  options: { force?: boolean; signal?: AbortSignal } = {},
): Promise<{ pages: PageListEntry[]; fetchedAt: string; cached: boolean; error?: string }> {
  if (!options.force) {
    const cached = readCache();
    if (cached) return { pages: cached.pages, fetchedAt: cached.fetchedAt, cached: true };
  }

  const prompt = `Using your Confluence connector, list ALL the pages you can find related to MOBILITY operations in the company wiki — including topics like:
- Wireless carrier support (AT&T, Verizon, T-Mobile, FirstNet, Telispire, QuantumShift, CyberReef, Granite)
- SIM and eSIM activation
- Device troubleshooting (iPhone, Android, tablets, wearables)
- vManager mobile workflows
- Mobility task templates and runbooks
- APN configurations
- Number porting / activation / suspension procedures

Likely concentrated in space TS but include any space if relevant.

Return ONLY a JSON object (no markdown fences, no commentary):

{
  "pages": [
    {
      "title": "Exact page title from Confluence",
      "url": "https://vikicloud.atlassian.net/wiki/... real URL from your search ...",
      "description": "One sentence (max 120 chars) describing what this page covers",
      "category": "activation" | "troubleshooting" | "reference" | "carrier" | "general"
    }
  ]
}

RULES:
- Return up to 50 pages.
- Sort by category, then by title.
- The "url" MUST be a real URL from your Confluence connector — do not invent.
- Categories:
    - "activation"     = SIM / eSIM / new line activation guides
    - "troubleshooting"= device issues, signal, connectivity problems
    - "carrier"        = carrier-specific support contacts and procedures
    - "reference"      = templates, tables, lookup data, APN lists
    - "general"        = anything else mobility-related
- If you find 0 matching pages, return {"pages": []}.
- Return ONLY the JSON.`;

  const res = await complete([{ role: 'user', content: prompt }], { signal: options.signal });
  const fetchedAt = new Date().toISOString();
  if (res.error) return { pages: [], fetchedAt, cached: false, error: res.error };

  const parsed = extractJSON<{ pages: PageListEntry[] }>(res.text);
  if (!parsed || !Array.isArray(parsed.pages)) {
    return {
      pages: [],
      fetchedAt,
      cached: false,
      error: 'Could not parse page list from agent',
    };
  }
  const clean = parsed.pages
    .filter((p) => p && typeof p.title === 'string' && p.title.trim().length > 0)
    .map((p) => ({
      title: p.title.trim(),
      url: (p.url || '').trim(),
      description: (p.description || '').trim(),
      category: (['activation', 'troubleshooting', 'reference', 'carrier', 'general'].includes(p.category)
        ? p.category
        : 'general') as PageCategory,
    }));

  writeCache(clean);
  return { pages: clean, fetchedAt, cached: false };
}

export function clearPageListCache() {
  _pageListCache.delete('mobility_pages');
}

// ────────────────────────────────────────────────────────────────
// Category display helpers
// ────────────────────────────────────────────────────────────────

export const CATEGORY_META: Record<PageCategory, { label: string; emoji: string; className: string }> = {
  activation: {
    label: 'Activation',
    emoji: '🔧',
    className: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-300',
  },
  troubleshooting: {
    label: 'Troubleshooting',
    emoji: '🛠',
    className: 'bg-amber-100 text-amber-700 dark:bg-amber-500/20 dark:text-amber-300',
  },
  reference: {
    label: 'Reference',
    emoji: '📋',
    className: 'bg-primary-100 text-primary-700 dark:bg-primary-500/20 dark:text-primary-300',
  },
  carrier: {
    label: 'Carrier',
    emoji: '📞',
    className: 'bg-violet-100 text-violet-700 dark:bg-violet-500/20 dark:text-violet-300',
  },
  general: {
    label: 'General',
    emoji: '🌐',
    className: 'bg-slate-100 text-slate-700 dark:bg-slate-700 dark:text-slate-300',
  },
};
