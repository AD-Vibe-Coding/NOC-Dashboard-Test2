/**
 * Mobility data refresh — uses the Devs.ai agent (which has the Confluence
 * connector attached) to fetch fresh carrier contact data and individual
 * page content. Pure client-side: zero per-user config required.
 */

import { complete, extractJSON } from '../devs-ai/complete';
import type { CarrierKey, MobilityCarrier } from './carriers';

interface ContactRefreshResponse {
  carriers: Array<{
    key: CarrierKey;
    tier1Phone?: string | null;
    escalationPhone?: string | null;
    supportEmail?: string | null;
    portalUrl?: string | null;
    hours?: string | null;
    notes?: string | null;
    sourcePages?: string[];
  }>;
}

const CARRIER_KEYS_FOR_PROMPT = `
1. att_quantamshift_opus — AT&T Wireless via QuantumShift (OPUS)
2. att_retail — AT&T Wireless retail / direct support
3. verizon_quantamshift_telispire — Verizon Wireless via QuantumShift / Telispire
4. verizon_retail — Verizon Wireless retail / direct support
5. tmobile — T-Mobile for Business
6. cybereef — CyberReef Solutions
7. firstnet — FirstNet (AT&T Public Safety)
8. granite — Granite Telecommunications
`.trim();

const REFRESH_PROMPT = `You have access to the company Confluence wiki via your connector. Search the NOC Mobility documentation (space TS or anywhere Mobility-related) and return the CURRENT support contact information for each of these carriers:

${CARRIER_KEYS_FOR_PROMPT}

Return ONLY a JSON object with this exact shape (no markdown fences, no explanation):

{
  "carriers": [
    {
      "key": "att_quantamshift_opus",
      "tier1Phone": "1-XXX-XXX-XXXX or null",
      "escalationPhone": "1-XXX-XXX-XXXX or null",
      "supportEmail": "email or null",
      "portalUrl": "https://... or null",
      "hours": "24/7 or specific hours, or null",
      "notes": "Any special instructions (BAN format, order ID requirements, etc.) — keep under 200 chars, or null",
      "sourcePages": ["Confluence page title 1", "Confluence page title 2"]
    }
  ]
}

CRITICAL RULES:
- Include all 8 carriers in the output, in the order above.
- If you cannot find a field in Confluence, use null. Do NOT invent or guess phone numbers / emails.
- Normalize phone numbers to "1-XXX-XXX-XXXX" format.
- "sourcePages" should list the titles of Confluence pages you pulled data from for that carrier.
- Return ONLY the JSON, nothing else.`;

export interface RefreshResult {
  updates: Record<CarrierKey, Partial<MobilityCarrier>>;
  fetchedAt: string;
  error?: string;
  rawResponse?: string;
}

export async function refreshCarrierContacts(
  signal?: AbortSignal,
): Promise<RefreshResult> {
  const fetchedAt = new Date().toISOString();
  const res = await complete(
    [{ role: 'user', content: REFRESH_PROMPT }],
    { signal },
  );

  if (res.error) {
    return { updates: {} as Record<CarrierKey, Partial<MobilityCarrier>>, fetchedAt, error: res.error };
  }

  const parsed = extractJSON<ContactRefreshResponse>(res.text);
  if (!parsed?.carriers || !Array.isArray(parsed.carriers)) {
    return {
      updates: {} as Record<CarrierKey, Partial<MobilityCarrier>>,
      fetchedAt,
      error: 'Could not parse JSON from agent response',
      rawResponse: res.text.slice(0, 400),
    };
  }

  const updates = {} as Record<CarrierKey, Partial<MobilityCarrier>>;
  for (const c of parsed.carriers) {
    if (!c.key) continue;
    updates[c.key] = {
      tier1Phone: c.tier1Phone ?? null,
      escalationPhone: c.escalationPhone ?? null,
      supportEmail: c.supportEmail ?? null,
      portalUrl: c.portalUrl ?? null,
      hours: c.hours ?? null,
      notes: c.notes ?? null,
      sourcePages: c.sourcePages ?? [],
      verifiedAt: fetchedAt,
    };
  }

  return { updates, fetchedAt };
}

/**
 * Fetches a single Confluence page's content via the agent.
 * Uses SEARCH (not direct ID lookup) since most connectors index by content,
 * not by page ID. This means the agent can actually find the page.
 */
export async function fetchConfluencePageContent(
  _pageId: string,
  pageTitle: string,
  signal?: AbortSignal,
): Promise<{ content: string; error?: string }> {
  const prompt = `Using your Confluence connector, search for the page titled "${pageTitle}" (or the closest matching page) in the company wiki — likely in space "TS" (Tech Support / NOC space).

Return a well-structured markdown summary of that page's content that preserves:
- All section headings (use ## and ###)
- Step-by-step procedures (numbered lists)
- Phone numbers, emails, account numbers (in **bold**)
- Internal references / link mentions
- Any warning or note callouts (prefix with "> ⚠️" or "> ℹ️")

Be COMPREHENSIVE — include every step, contact, and reference from the page. Do not summarize away details. Do not add commentary outside what the page says.

If the page truly cannot be found AT ALL via search, respond with exactly: "PAGE_NOT_FOUND" followed by what closely-related pages you DO see.`;

  const res = await complete([{ role: 'user', content: prompt }], { signal });
  if (res.error) return { content: '', error: res.error };
  return { content: res.text };
}
