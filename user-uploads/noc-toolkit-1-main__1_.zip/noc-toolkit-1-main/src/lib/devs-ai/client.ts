export type AIRole = 'user' | 'assistant' | 'system';
export interface AIMessage {
  role: AIRole;
  content: string;
}

export interface SendMessageOptions {
  /** Optional override of the agent ID or raw LLM model id (e.g. "gpt-5.4"). */
  model?: string;
  signal?: AbortSignal;
}

/**
 * Stream a chat completion from the Devs.ai platform via our /api/ai/chat
 * server proxy. The API key never reaches the browser.
 *
 * The platform uses NAMED SSE events (not OpenAI's `data: {choices:[]}`
 * format). The parser below handles buffering and partial chunks correctly.
 */
export async function sendMessage(
  messages: AIMessage[],
  onDelta: (text: string) => void,
  onComplete: () => void,
  onError: (err: string) => void,
  opts: SendMessageOptions = {},
) {
  let res: Response;
  try {
    res = await fetch('/api/ai/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ messages, model: opts.model }),
      signal: opts.signal,
    });
  } catch (err) {
    onError(err instanceof Error ? err.message : 'Network error');
    return;
  }

  if (!res.ok || !res.body) {
    let msg = `Request failed: ${res.status}`;
    try {
      const j = await res.json();
      if (j?.error) msg = j.error;
    } catch {
      /* ignore */
    }
    onError(msg);
    return;
  }

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  let currentEvent = '';
  let currentData = '';

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n');
    buffer = lines.pop() ?? '';
    for (const line of lines) {
      if (line.startsWith('event: ')) {
        currentEvent = line.slice(7).trim();
      } else if (line.startsWith('data: ')) {
        currentData = line.slice(6);
      } else if (line.startsWith(':')) {
        // SSE comment (keep-alive), ignore
      } else if (line === '') {
        if (currentEvent && currentData) {
          try {
            const parsed = JSON.parse(currentData);
            if (currentEvent === 'message.delta' && parsed.content?.text) {
              onDelta(parsed.content.text);
            } else if (currentEvent === 'message.complete') {
              onComplete();
            } else if (currentEvent === 'message.error') {
              onError(parsed.error || 'Stream error');
            }
          } catch {
            /* skip malformed JSON */
          }
        }
        currentEvent = '';
        currentData = '';
      }
    }
  }
  onComplete();
}

/**
 * Async-generator wrapper around sendMessage for callers that prefer the
 * `for await (const chunk of ...)` style (matches the old streamChatCompletion
 * signature from the OpenAI client we replaced).
 */
export async function* streamMessage(
  messages: AIMessage[],
  opts: SendMessageOptions = {},
): AsyncGenerator<string> {
  const queue: string[] = [];
  let resolveNext: ((v: IteratorResult<string>) => void) | null = null;
  let finished = false;
  let errorMsg: string | null = null;

  const flush = () => {
    if (!resolveNext) return;
    if (queue.length) {
      const value = queue.shift()!;
      const fn = resolveNext;
      resolveNext = null;
      fn({ value, done: false });
    } else if (finished || errorMsg) {
      const fn = resolveNext;
      resolveNext = null;
      fn({ value: undefined as unknown as string, done: true });
    }
  };

  sendMessage(
    messages,
    (delta) => {
      queue.push(delta);
      flush();
    },
    () => {
      finished = true;
      flush();
    },
    (err) => {
      errorMsg = err;
      finished = true;
      flush();
    },
    opts,
  );

  while (true) {
    if (errorMsg) throw new Error(errorMsg);
    if (queue.length) {
      yield queue.shift()!;
      continue;
    }
    if (finished) return;
    const next = await new Promise<IteratorResult<string>>((r) => {
      resolveNext = r;
    });
    if (next.done) return;
    yield next.value;
  }
}
