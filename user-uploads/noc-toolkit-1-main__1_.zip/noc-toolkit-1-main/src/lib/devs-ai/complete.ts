/**
 * Non-streaming completion helper — sends a prompt to our Devs.ai agent
 * (which has the Confluence connector attached) and returns the FULL
 * aggregated response as text. Used for structured data extractions where
 * streaming UX is unnecessary.
 */

import type { AIMessage } from './client';

export interface CompletionResult {
  text: string;
  model?: string;
  error?: string;
}

export async function complete(
  messages: AIMessage[],
  opts: { model?: string; signal?: AbortSignal } = {},
): Promise<CompletionResult> {
  try {
    const res = await fetch('/api/ai/complete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ messages, model: opts.model }),
      signal: opts.signal,
    });
    const data = await res.json();
    if (!res.ok) return { text: '', error: data?.error ?? `HTTP ${res.status}` };
    return { text: data.text ?? '', model: data.model };
  } catch (err) {
    return {
      text: '',
      error: err instanceof Error ? err.message : 'Network error',
    };
  }
}

/**
 * Attempts to extract a JSON object from the agent's text response.
 * Strips markdown code fences and tries common patterns.
 */
export function extractJSON<T = unknown>(text: string): T | null {
  if (!text) return null;
  // Strip ```json ... ``` or ``` ... ``` fences
  let cleaned = text.trim();
  const fenceMatch = cleaned.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (fenceMatch) cleaned = fenceMatch[1].trim();
  // Find first { and last } (handles agent commentary before/after)
  const start = cleaned.indexOf('{');
  const end = cleaned.lastIndexOf('}');
  if (start === -1 || end === -1 || end < start) return null;
  try {
    return JSON.parse(cleaned.slice(start, end + 1)) as T;
  } catch {
    return null;
  }
}
