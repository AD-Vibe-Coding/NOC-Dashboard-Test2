/**
 * ANALYTICS — Pure Supabase. Zero localStorage.
 */

import { supabase } from '../../db';

export type ToolName =
  | 'maintenance'
  | 'carriers'
  | 'noc_tools_subnet'
  | 'noc_tools_ping'
  | 'noc_tools_whois'
  | 'noc_tools_wireshark'
  | 'ai_assistant'
  | 'mobility'
  | 'network'
  | 'noc_scripts';

export interface UsageEvent {
  id: string;
  userId: string;
  tool: ToolName;
  action: string;
  createdAt: string;
}

export async function trackEvent(userId: string, tool: ToolName, action: string): Promise<void> {
  const id = `ev_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  const { error } = await supabase.from('usage_events').insert({
    id,
    user_id: userId,
    tool,
    action,
    created_at: new Date().toISOString(),
  });
  if (error) console.warn('trackEvent:', error.message);
}

export async function getUsageEvents(limit = 1000): Promise<UsageEvent[]> {
  const { data, error } = await supabase
    .from('usage_events')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(limit);

  if (error) { console.warn('getUsageEvents:', error.message); return []; }
  return (data ?? []).map((r: any) => ({
    id: r.id,
    userId: r.user_id,
    tool: r.tool as ToolName,
    action: r.action,
    createdAt: r.created_at,
  }));
}

export const TOOL_LABELS: Record<ToolName, string> = {
  maintenance:         'Maintenance Notes',
  carriers:            'Carrier Contacts',
  noc_tools_subnet:    'IP / Subnet Calc',
  noc_tools_ping:      'Ping Test',
  noc_tools_whois:     'WHOIS Lookup',
  noc_tools_wireshark: 'AI Wireshark',
  ai_assistant:        'AI Assistant',
  mobility:            'Mobility',
  network:             'Network Hub',
  noc_scripts:         'NOC Scripts',
};

export const AI_TOOLS: ToolName[] = ['noc_tools_wireshark', 'ai_assistant'];
