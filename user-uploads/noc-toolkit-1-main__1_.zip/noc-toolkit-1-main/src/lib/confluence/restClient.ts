/**
 * Typed client for our Confluence REST proxy (server-side auth).
 * Backend endpoints live in vite.config.ts → confluenceRestPlugin().
 */

export interface PageNode {
  id: string;
  title: string;
  url: string;
  parentId: string | null;
  childCount: number;
  hasAttachments?: boolean;
  children?: PageNode[];
}

export interface TreeResponse {
  tree: PageNode;
  cached: boolean;
  fetchedAt: string;
  error?: string;
}

export interface Attachment {
  id: string;
  title: string;
  mediaType: string;
  fileSize: number | null;
  downloadUrl: string;       // /api/confluence/attachment?id=...
  confluenceUrl: string;
  isImage: boolean;
  isPdf: boolean;
}

export interface PageDetail {
  id: string;
  title: string;
  spaceKey: string;
  version: number;
  lastUpdated: string;
  updatedBy: string;
  url: string;
  html: string;
  attachments: Attachment[];
  error?: string;
}

export interface SearchHit {
  id: string | null;
  title: string;
  url: string;
  snippet: string;
  excerpt: string;
}

export interface SearchResponse {
  results: SearchHit[];
  count: number;
  query: string;
  error?: string;
}

export interface RankedHit {
  id: string;
  title: string;
  url: string;
  relevance: number;
  why: string;
}

export interface RerankResult {
  ranked: RankedHit[];
  topMatch: string | null;
  didYouMean: string | null;
  suggestions: string[];
}

// ─── Tree ──────────────────────────────────────────────────────
export async function fetchTree(rootId: string, force = false): Promise<TreeResponse> {
  try {
    const url = `/api/confluence/tree?root=${encodeURIComponent(rootId)}${force ? '&force=1' : ''}`;
    const r = await fetch(url);
    return await r.json();
  } catch (err) {
    return {
      tree: { id: rootId, title: '', url: '', parentId: null, childCount: 0, children: [] },
      cached: false,
      fetchedAt: new Date().toISOString(),
      error: err instanceof Error ? err.message : 'fetch failed',
    };
  }
}

// ─── Page ──────────────────────────────────────────────────────
export async function fetchPage(id: string): Promise<PageDetail> {
  try {
    const r = await fetch(`/api/confluence/page?id=${encodeURIComponent(id)}`);
    return await r.json();
  } catch (err) {
    return {
      id, title: '', spaceKey: '', version: 0, lastUpdated: '', updatedBy: '',
      url: '', html: '', attachments: [],
      error: err instanceof Error ? err.message : 'fetch failed',
    };
  }
}

// ─── Search (CQL) ──────────────────────────────────────────────
export async function searchConfluence(
  query: string,
  opts: { ancestor?: string; limit?: number } = {},
): Promise<SearchResponse> {
  if (!query.trim()) return { results: [], count: 0, query };
  try {
    const params = new URLSearchParams({ q: query.trim() });
    if (opts.ancestor) params.set('ancestor', opts.ancestor);
    if (opts.limit) params.set('limit', String(opts.limit));
    const r = await fetch(`/api/confluence/search?${params.toString()}`);
    return await r.json();
  } catch (err) {
    return { results: [], count: 0, query, error: err instanceof Error ? err.message : 'search failed' };
  }
}

// ─── Smart Search (premium semantic pipeline) ──────────────────
// Intent extraction → targeted CQL → GPT-5 filter & rerank, all server-side.
// Returns a curated short list of HIGH-CONFIDENCE results only (drops < 50%).
export interface CuratedHit extends SearchHit {
  relevance: number;
  why: string;
}

export interface SmartSearchResponse {
  query: string;
  intent: {
    intent: string;
    searchTerms: string[];
    phraseHints: string[];
    queryType: 'lookup' | 'how-to' | 'troubleshooting' | 'reference' | 'contact' | string;
  } | null;
  curated: CuratedHit[];          // ≤5 high-confidence picks (relevance ≥ 50)
  raw: SearchHit[];               // all candidates from CQL
  count: number;                   // curated.length
  rawCount: number;                // raw.length
  topMatch: string | null;
  didYouMean: string | null;
  suggestions: string[];
  model?: string;
  error?: string;
}

export async function smartSearch(
  query: string,
  opts: { ancestor?: string } = {},
): Promise<SmartSearchResponse> {
  const empty: SmartSearchResponse = {
    query, intent: null, curated: [], raw: [], count: 0, rawCount: 0,
    topMatch: null, didYouMean: null, suggestions: [],
  };
  if (!query.trim()) return empty;
  try {
    const r = await fetch('/api/ai/smart-search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query, ancestor: opts.ancestor }),
    });
    const data = await r.json();
    if (!r.ok) return { ...empty, error: data?.error ?? `HTTP ${r.status}` };
    return data as SmartSearchResponse;
  } catch (err) {
    return { ...empty, error: err instanceof Error ? err.message : 'smart-search failed' };
  }
}

// ─── Streaming smart-search (fast, progressive UI) ─────────────
// Emits 3 events progressively so the UI can show results within ~400ms.
export interface StreamEvents {
  onCandidates?: (hits: SearchHit[], partial: boolean, cached?: boolean) => void;
  onIntent?: (intent: SmartSearchResponse['intent']) => void;
  onCurated?: (curated: CuratedHit[], extra: {
    topMatch: string | null;
    didYouMean: string | null;
    suggestions: string[];
    cached?: boolean;
  }) => void;
  onDone?: () => void;
  onError?: (msg: string) => void;
}

// Client-side cache: same query within 5 min returns instantly.
const CLIENT_CACHE = new Map<string, { ts: number; raw: SearchHit[]; intent: any; curated: CuratedHit[]; topMatch: string | null; didYouMean: string | null; suggestions: string[] }>();
const CLIENT_CACHE_TTL = 5 * 60 * 1000;

export async function smartSearchStream(
  query: string,
  opts: { ancestor?: string; premium?: boolean; signal?: AbortSignal } = {},
  events: StreamEvents = {},
): Promise<void> {
  const trimmed = query.trim();
  if (!trimmed) { events.onDone?.(); return; }

  const cacheKey = `${trimmed.toLowerCase()}|${opts.ancestor ?? ''}|${opts.premium ? 'p' : 'f'}`;
  const hit = CLIENT_CACHE.get(cacheKey);
  if (hit && Date.now() - hit.ts < CLIENT_CACHE_TTL) {
    events.onCandidates?.(hit.raw, false, true);
    if (hit.intent) events.onIntent?.(hit.intent);
    events.onCurated?.(hit.curated, {
      topMatch: hit.topMatch,
      didYouMean: hit.didYouMean,
      suggestions: hit.suggestions,
      cached: true,
    });
    events.onDone?.();
    return;
  }

  let res: Response;
  try {
    res = await fetch('/api/ai/smart-search-stream', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query: trimmed, ancestor: opts.ancestor, premium: !!opts.premium }),
      signal: opts.signal,
    });
  } catch (err) {
    events.onError?.(err instanceof Error ? err.message : 'network error');
    events.onDone?.();
    return;
  }

  if (!res.ok || !res.body) {
    events.onError?.(`HTTP ${res.status}`);
    events.onDone?.();
    return;
  }

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buf = '';
  let ev = '';
  let dt = '';

  let cacheAccum: { raw: SearchHit[]; intent: any; curated: CuratedHit[]; topMatch: string | null; didYouMean: string | null; suggestions: string[] } = {
    raw: [], intent: null, curated: [], topMatch: null, didYouMean: null, suggestions: [],
  };

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += decoder.decode(value, { stream: true });
    const lines = buf.split('\n'); buf = lines.pop() ?? '';
    for (const line of lines) {
      if (line.startsWith('event: ')) ev = line.slice(7).trim();
      else if (line.startsWith('data: ')) dt = line.slice(6);
      else if (line === '') {
        if (ev && dt) {
          try {
            const payload = JSON.parse(dt);
            if (ev === 'candidates') {
              const candidates: SearchHit[] = payload.candidates ?? [];
              cacheAccum.raw = candidates;
              events.onCandidates?.(candidates, !!payload.partial, !!payload.cached);
            } else if (ev === 'intent') {
              cacheAccum.intent = payload;
              events.onIntent?.(payload);
            } else if (ev === 'curated') {
              cacheAccum.curated = payload.curated ?? [];
              cacheAccum.topMatch = payload.topMatch ?? null;
              cacheAccum.didYouMean = payload.didYouMean ?? null;
              cacheAccum.suggestions = payload.suggestions ?? [];
              events.onCurated?.(cacheAccum.curated, {
                topMatch: cacheAccum.topMatch,
                didYouMean: cacheAccum.didYouMean,
                suggestions: cacheAccum.suggestions,
                cached: !!payload.cached,
              });
            } else if (ev === 'done') {
              events.onDone?.();
            }
          } catch {/* ignore malformed event */}
        }
        ev = ''; dt = '';
      }
    }
  }

  // Cache the final result
  if (cacheAccum.raw.length > 0 || cacheAccum.curated.length > 0) {
    CLIENT_CACHE.set(cacheKey, { ts: Date.now(), ...cacheAccum });
    if (CLIENT_CACHE.size > 100) {
      const oldest = CLIENT_CACHE.keys().next().value;
      if (oldest) CLIENT_CACHE.delete(oldest);
    }
  }
  events.onDone?.();
}

// ─── XLSX preview ──────────────────────────────────────────────
export interface XlsxSheet {
  name: string;
  headers: string[];
  rows: string[][];
  totalRows: number;
}

export interface XlsxResponse {
  title: string;
  sheets: XlsxSheet[];
  error?: string;
}

export async function fetchXlsx(attachmentId: string): Promise<XlsxResponse> {
  try {
    const r = await fetch(`/api/confluence/xlsx?id=${encodeURIComponent(attachmentId)}`);
    return await r.json();
  } catch (err) {
    return { title: '', sheets: [], error: err instanceof Error ? err.message : 'xlsx fetch failed' };
  }
}

// ─── Device troubleshooting (live Confluence search per category) ──
export interface DeviceSearchHit {
  id: string;
  title: string;
  url: string;
  snippet: string;
  matchedTerm: string;
}

export interface DeviceSearchResponse {
  device: string;
  count: number;
  results: DeviceSearchHit[];
  error?: string;
}

export async function fetchDevicePages(
  device: 'iphone' | 'android-phone' | 'ipad' | 'android-tablet' | 'sim',
  ancestor?: string,
): Promise<DeviceSearchResponse> {
  try {
    const params = new URLSearchParams({ device });
    if (ancestor) params.set('ancestor', ancestor);
    const r = await fetch(`/api/confluence/devices?${params.toString()}`);
    return await r.json();
  } catch (err) {
    return { device, count: 0, results: [], error: err instanceof Error ? err.message : 'devices fetch failed' };
  }
}

// ─── Rerank with GPT-5 ─────────────────────────────────────────
export async function rerankResults(
  query: string,
  results: SearchHit[],
): Promise<RerankResult | null> {
  try {
    const r = await fetch('/api/ai/rerank', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query, results }),
    });
    const data = await r.json();
    if (!data.text) return null;
    // Extract JSON
    let text = data.text.trim();
    const fence = text.match(/```(?:json)?\s*([\s\S]*?)```/);
    if (fence) text = fence[1].trim();
    const s = text.indexOf('{');
    const e = text.lastIndexOf('}');
    if (s === -1 || e === -1) return null;
    return JSON.parse(text.slice(s, e + 1));
  } catch {
    return null;
  }
}

// ─── Tree utilities ────────────────────────────────────────────
export function flattenTree(node: PageNode | null | undefined): PageNode[] {
  if (!node) return [];
  const out: PageNode[] = [node];
  for (const c of node.children ?? []) out.push(...flattenTree(c));
  return out;
}

export function filterTree(node: PageNode, query: string): PageNode | null {
  const q = query.trim().toLowerCase();
  if (!q) return node;
  const titleMatch = node.title.toLowerCase().includes(q);
  const filteredChildren = (node.children ?? [])
    .map((c) => filterTree(c, q))
    .filter((c): c is PageNode => c !== null);
  if (titleMatch || filteredChildren.length > 0) {
    return { ...node, children: filteredChildren };
  }
  return null;
}
