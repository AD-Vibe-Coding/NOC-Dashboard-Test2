export interface ConfluenceConfig {
  baseUrl: string;   // e.g. https://yourorg.atlassian.net/wiki
  email: string;     // Atlassian account email
  token: string;     // Atlassian API token (id.atlassian.com → Security → API tokens)
  spaceKey?: string; // Optional: restrict search to a single space
  enabled: boolean;  // Master on/off — when false, AI calls skip Confluence
}

export const DEFAULT_CONFLUENCE_CONFIG: ConfluenceConfig = {
  baseUrl: (import.meta as any).env?.VITE_CONFLUENCE_URL ?? 'https://vikicloud.atlassian.net/wiki',
  email:   (import.meta as any).env?.VITE_CONFLUENCE_EMAIL ?? 'sparisa@vcomsolutions.com',
  token:   '', // token stays server-side only — never in VITE_ vars
  spaceKey: '',
  enabled: true, // ON by default — Confluence is always available for this org
};

export interface ConfluenceResult {
  title: string;
  space: string | null;
  url: string;
  excerpt: string;
}

export interface ConfluenceSearchResponse {
  results: ConfluenceResult[];
  error?: string;
}

/**
 * Search Confluence for pages matching `query`. Goes through our server
 * proxy at /api/confluence/search to avoid CORS and keep the API token
 * out of the browser's network panel as much as possible (creds still
 * live in localStorage on the user's machine).
 */
export async function searchConfluence(
  cfg: ConfluenceConfig,
  query: string,
  limit = 5,
  signal?: AbortSignal,
): Promise<ConfluenceSearchResponse> {
  if (!cfg.enabled) return { results: [] };
  if (!cfg.baseUrl || !cfg.email || !cfg.token) {
    return { results: [], error: 'Confluence is not fully configured.' };
  }
  if (!query.trim()) return { results: [] };

  try {
    const res = await fetch('/api/confluence/search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        baseUrl: cfg.baseUrl,
        email: cfg.email,
        token: cfg.token,
        spaceKey: cfg.spaceKey || undefined,
        query,
        limit,
      }),
      signal,
    });
    const data = await res.json().catch(() => null);
    if (!res.ok) {
      return {
        results: [],
        error: data?.error || `Confluence search failed (${res.status})`,
      };
    }
    return { results: data?.results ?? [] };
  } catch (err) {
    return {
      results: [],
      error: err instanceof Error ? err.message : 'Confluence request failed',
    };
  }
}

/**
 * Format Confluence hits as a compact, model-friendly context block that
 * gets prepended to the user's question. Keeps it tight: ~600 chars per
 * page, hard-capped total length.
 */
export function formatConfluenceContext(
  results: ConfluenceResult[],
  maxChars = 6000,
): string {
  if (!results.length) return '';
  const lines: string[] = [
    'Relevant Confluence pages (use these as the primary source when answering):',
  ];
  for (let i = 0; i < results.length; i++) {
    const r = results[i];
    const block = [
      ``,
      `[${i + 1}] ${r.title}${r.space ? ` (space: ${r.space})` : ''}`,
      r.url ? `URL: ${r.url}` : '',
      `Excerpt: ${r.excerpt.slice(0, 600)}`,
    ]
      .filter(Boolean)
      .join('\n');
    if (lines.join('\n').length + block.length > maxChars) break;
    lines.push(block);
  }
  lines.push(
    '',
    'When citing a page, reference it by its number like [1] and include the URL once at the end of your answer.',
  );
  return lines.join('\n');
}
