/**
 * Live NOC shift roster client.
 *
 * Backed by /api/roster which parses the Google Sheets XLSX server-side
 * and returns:
 *   - All month tabs (Jan26..Dec26) for selection
 *   - Members + shifts for the requested month
 *   - "Active now" computed from current Pacific Time
 */

export interface RosterMember {
  name: string;
  shifts: Record<string, string>; // "15-May" -> "06:00 AM to 03:00 PM"
}

export interface ActiveMember {
  name: string;
  start: string;       // "06:00 AM"
  end: string;         // "03:00 PM"
  shift: string;       // raw cell value
}

export interface TodayShift {
  name: string;
  cell: string;
}

export interface RosterResponse {
  sheetName: string;
  monthTabs: string[];        // e.g. ["Jan26", "Feb26", ..., "Dec26"]
  allTabs: string[];
  headerDays: string[];       // e.g. ["1-May", "2-May", ...]
  members: RosterMember[];
  today: {
    label: string;            // e.g. "15-May"
    pacificISO: string;
    pacificTime: string;      // e.g. "11:45 PM"
    allShifts: TodayShift[];  // everyone scheduled today
    active: ActiveMember[];   // currently on shift
  };
  error?: string;
}

const EMPTY: RosterResponse = {
  sheetName: '',
  monthTabs: [],
  allTabs: [],
  headerDays: [],
  members: [],
  today: { label: '', pacificISO: '', pacificTime: '', allShifts: [], active: [] },
};

export async function fetchRoster(month?: string): Promise<RosterResponse> {
  try {
    const url = month ? `/api/roster?month=${encodeURIComponent(month)}` : '/api/roster';
    const res = await fetch(url);
    const data = await res.json();
    if (!res.ok) {
      return { ...EMPTY, error: data?.error || `Failed (${res.status})` };
    }
    return data as RosterResponse;
  } catch (err) {
    return { ...EMPTY, error: err instanceof Error ? err.message : 'Network error' };
  }
}

/** Best-effort match between a sheet name (e.g. "Mohammed Ashraf") and a
 *  seeded local user (e.g. "Ashraf Mohammed"). Tolerant of:
 *   - Token order swap (sheet uses Mohammed first, seed uses Mohammed last)
 *   - Middle names in the sheet ("Lokesh Naik Banavath" vs "Lokesh Banavath")
 *   - Minor spelling differences (Benarji vs Benerji, Kartik vs Karthik, Damagalla vs Damaggala)
 *   - First-name-only matches if last name is a known alias ("Akram Ahmed" → "Mohammed Akram") */
export function rosterNameMatches(sheetName: string, firstName: string, lastName: string): boolean {
  const norm = (s: string) => s.toLowerCase().replace(/[^a-z\s]/g, ' ').replace(/\s+/g, ' ').trim();

  const sheetTokens = norm(sheetName).split(' ').filter((t) => t.length >= 3);
  const f = norm(firstName);
  const l = norm(lastName);

  // Explicit aliases from the live roster sheet
  // Keys = normalised "firstName lastName" from our seed data
  // Values = alternate spellings/orderings that may appear in the Google Sheet
  const ALIASES: Record<string, string[]> = {
    // Mohammed Akram Ahmed — sheet may list as "Akram Ahmed", "Mohammed Akram", etc.
    'mohammed akram ahmed': ['akram ahmed', 'mohammed akram', 'akram mohammed'],
    // Zubair Mohammed — sheet may list as "Zubair Mohammad", "Mohammed Zubairuddin", etc.
    'zubair mohammed':      ['zubair mohammad', 'mohammed zubairuddin', 'zubairuddin'],
    // Samiti Mahalakshmi — sheet may reverse name order
    'samiti mahalakshmi':   ['mahalakshmi samiti'],
    // Lokesh Banavath — sheet may include middle name "Naik"
    'lokesh banavath':      ['lokesh naik banavath'],
    // Karthik Damagalla — old spelling: Kartik Damaggala
    'karthik damagalla':    ['kartik damaggala', 'karthik damaggala', 'kartik damagalla'],
    // Abishek Benarji — old spellings: Abhishek Benerji / Benarji
    'abishek benarji':      ['abhishek benarji', 'abhishek benerji', 'abishek benerji'],
    // Ashraf Mohammed — sheet may list as "Mohammed Ashraf"
    'ashraf mohammed':      ['mohammed ashraf'],
    // Hamza Rahmani Umme — sheet may list as "Hamza Umme" or "Hamza Rahmani"
    'hamza rahmani umme':   ['hamza umme', 'hamza rahmani'],
  };
  const fullName = `${f} ${l}`.replace(/\s+/g, ' ').trim();
  const sheetNorm = norm(sheetName);
  // Check direct alias match
  if (ALIASES[fullName]?.some((a) => sheetNorm.includes(a))) return true;
  // Also check if our full name appears in the sheet (covers exact matches)
  if (fullName.split(' ').every((tok) => tok.length >= 3 && sheetNorm.includes(tok))) return true;

  // Token-level fuzzy match: each of (first, last) must have a sheet token
  // within edit-distance 1 (handles Benarji↔Benerji, Kartik↔Karthik, etc.)
  const fuzzyMatch = (target: string): boolean => {
    return sheetTokens.some((t) => t === target || isCloseMatch(t, target));
  };
  return fuzzyMatch(f) && fuzzyMatch(l);
}

/** Loose token equality: equal, or one contains the other (≥4 chars),
 *  or Levenshtein distance ≤ 1 for short tokens, ≤ 2 for longer ones. */
function isCloseMatch(a: string, b: string): boolean {
  if (a === b) return true;
  if (a.length >= 4 && b.length >= 4 && (a.includes(b) || b.includes(a))) return true;
  const maxLen = Math.max(a.length, b.length);
  const allowed = maxLen >= 7 ? 2 : 1;
  return levenshtein(a, b) <= allowed;
}

function levenshtein(a: string, b: string): number {
  if (a === b) return 0;
  if (!a.length) return b.length;
  if (!b.length) return a.length;
  const prev = new Array(b.length + 1).fill(0).map((_, i) => i);
  const curr = new Array(b.length + 1).fill(0);
  for (let i = 1; i <= a.length; i++) {
    curr[0] = i;
    for (let j = 1; j <= b.length; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      curr[j] = Math.min(curr[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost);
    }
    for (let j = 0; j <= b.length; j++) prev[j] = curr[j];
  }
  return prev[b.length];
}
