/**
 * Clipboard engine — ChatGPT-style "paste bare HTML".
 *
 * GOAL: When user hits Copy (or selects text + Ctrl+C anywhere), the pasted
 * result in Outlook/Gmail/Slack/Word/ServiceNow/Confluence should:
 *   ✅ Keep bold, italic, bullets, numbered lists, headings, links
 *   ✅ Use the DESTINATION editor's font + size + spacing (no override)
 *   ✅ NOT carry background colors, font colors, font families, font sizes
 *   ✅ NOT add weird extra blank lines / double-spacing
 *
 * The trick: emit BARE HTML — <p>...</p><ul><li>...</li></ul><strong>...
 * No inline styles at all. The destination editor's CSS supplies the look.
 * That's exactly what ChatGPT's copy button does, and the result looks
 * native in any rich-text editor.
 *
 * STRATEGY (in order):
 *   1. ClipboardItem API (modern browsers, cleanest path)
 *   2. contenteditable div + execCommand('copy') (iframe-safe fallback)
 *   3. writeText (plain only, last resort)
 */

// ──────────────────────────────────────────────────────────────────
// NUKE list — every presentational attribute we delete on every element.
// This wipes Tailwind classes, dark-mode inline styles, alignment,
// width/height, framework data-* attributes, etc.
// ──────────────────────────────────────────────────────────────────
const NUKE_ATTRS = [
  'style', 'class', 'bgcolor', 'color', 'face', 'background',
  'dir', 'align', 'width', 'height', 'cellpadding', 'cellspacing',
  'border', 'valign', 'nowrap',
];

// Tags we drop entirely (and unwrap their children).
const DROP_TAGS = new Set(['style', 'script', 'link', 'meta', 'noscript']);

// Tags we replace with <span> so the structure stays but no behavior leaks.
const NEUTRALIZE_TAGS = new Set(['font', 'center']);

function sanitizeBareHtml(html: string): string {
  const parser = new DOMParser();
  const doc = parser.parseFromString(`<div>${html}</div>`, 'text/html');
  const root = doc.body.firstElementChild as HTMLElement;
  if (!root) return html;

  // Drop disallowed tags
  root.querySelectorAll([...DROP_TAGS].join(',')).forEach((el) => el.remove());

  const walk = (el: Element) => {
    // Replace presentational tags (<font>, <center>) with <span>
    if (NEUTRALIZE_TAGS.has(el.tagName.toLowerCase())) {
      const span = el.ownerDocument.createElement('span');
      while (el.firstChild) span.appendChild(el.firstChild);
      el.replaceWith(span);
      return walk(span);
    }

    // Strip ALL presentational attributes (style, class, color, bgcolor, …)
    for (const attr of NUKE_ATTRS) el.removeAttribute(attr);
    // Strip framework noise (data-*, aria-* except aria-hidden, on*)
    [...el.attributes].forEach((a) => {
      if (a.name.startsWith('data-') || a.name.startsWith('on')) {
        el.removeAttribute(a.name);
      }
    });

    // Keep only safe attributes on <a> and <img>
    const tag = el.tagName.toLowerCase();
    if (tag === 'a') {
      const href = el.getAttribute('href');
      [...el.attributes].forEach((a) => {
        if (a.name !== 'href') el.removeAttribute(a.name);
      });
      if (href) el.setAttribute('href', href);
      // Make external links open new tab on paste-side (most clients keep this)
      el.setAttribute('target', '_blank');
      el.setAttribute('rel', 'noopener noreferrer');
    } else if (tag === 'img') {
      const src = el.getAttribute('src');
      const alt = el.getAttribute('alt') ?? '';
      [...el.attributes].forEach((a) => el.removeAttribute(a.name));
      if (src) el.setAttribute('src', src);
      el.setAttribute('alt', alt);
    }

    for (const child of [...el.children]) walk(child);
  };
  walk(root);

  // Strip the wrapping div's own attributes too
  for (const attr of NUKE_ATTRS) root.removeAttribute(attr);

  return root.innerHTML.trim();
}

// Public alias kept for back-compat (other callers import this name).
const sanitizeAndForceClean = sanitizeBareHtml;

// ──────────────────────────────────────────────────────────────────
// Copy with rich HTML + plain text
// ──────────────────────────────────────────────────────────────────
export async function copyRichAndPlain(
  htmlIn: string,
  plain: string,
): Promise<boolean> {
  const sanitized = sanitizeAndForceClean(htmlIn);

  // PATH 1: ClipboardItem API — cleanest, no DOM manipulation needed
  try {
    if (
      typeof ClipboardItem !== 'undefined' &&
      navigator?.clipboard?.write
    ) {
      const htmlBlob = new Blob([sanitized], { type: 'text/html' });
      const textBlob = new Blob([plain], { type: 'text/plain' });
      await navigator.clipboard.write([
        new ClipboardItem({
          'text/html': htmlBlob,
          'text/plain': textBlob,
        }),
      ]);
      return true;
    }
  } catch {
    /* fall through */
  }

  // PATH 2: contenteditable div + execCommand — works in iframes/sandboxes
  // The trick: we create a div with contentEditable="true", set innerHTML to
  // our clean HTML, force a neutral background, select it, and copy.
  // The browser copies the RENDERED rich content, not plain text.
  try {
    const el = document.createElement('div');
    el.contentEditable = 'true';
    el.setAttribute('aria-hidden', 'true');

    // Position off-screen but still in the layout flow (some browsers
    // skip copying if the element is display:none or has zero dimensions).
    //
    // IMPORTANT: do NOT set font-family / font-size / line-height /
    // background here. Those settings leak into the clipboard HTML on some
    // browsers and override the destination editor's defaults — which is
    // exactly the bug the user reported (Outlook receives Arial 14px and
    // ignores its own font). Keep this offscreen div invisible only.
    Object.assign(el.style, {
      position: 'fixed',
      left: '-9999px',
      top: '0px',
      width: '600px',
      opacity: '0',
      pointerEvents: 'none',
      zIndex: '-1',
    });

    el.innerHTML = sanitized;

    document.body.appendChild(el);

    // Select the entire contents
    const range = document.createRange();
    range.selectNodeContents(el);
    const sel = window.getSelection();
    sel?.removeAllRanges();
    sel?.addRange(range);

    // Focus the element (required for some browsers to allow copy)
    el.focus();

    const ok = document.execCommand('copy');
    sel?.removeAllRanges();
    document.body.removeChild(el);
    if (ok) return true;
  } catch {
    /* fall through */
  }

  // PATH 3: writeText — plain only
  try {
    if (navigator?.clipboard?.writeText) {
      await navigator.clipboard.writeText(plain);
      return true;
    }
  } catch {
    /* fall through */
  }

  // PATH 4: textarea + execCommand — truly last resort
  try {
    const ta = document.createElement('textarea');
    ta.value = plain;
    Object.assign(ta.style, { position: 'fixed', left: '-99999px', top: '0' });
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    const ok = document.execCommand('copy');
    ta.remove();
    return ok;
  } catch {
    return false;
  }
}

// ──────────────────────────────────────────────────────────────────
// Plain-text-only copy
// ──────────────────────────────────────────────────────────────────
export async function copyPlainOnly(plain: string): Promise<boolean> {
  try {
    if (navigator?.clipboard?.writeText) {
      await navigator.clipboard.writeText(plain);
      return true;
    }
  } catch { /* fall through */ }
  try {
    const ta = document.createElement('textarea');
    ta.value = plain;
    Object.assign(ta.style, { position: 'fixed', left: '-99999px', top: '0' });
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    const ok = document.execCommand('copy');
    ta.remove();
    return ok;
  } catch {
    return false;
  }
}

// ──────────────────────────────────────────────────────────────────
// DOM-walker helpers for AI chat MessageActions
// ──────────────────────────────────────────────────────────────────

/**
 * Take a live DOM node (e.g. rendered ReactMarkdown output) and produce
 * bare HTML — just tags, no inline styles or classes. The destination
 * editor's CSS supplies the font/size/spacing on paste. (Same philosophy
 * as ChatGPT's copy button.)
 */
export function cleanRenderedHtml(node: HTMLElement | null): string {
  if (!node) return '';
  const clone = node.cloneNode(true) as HTMLElement;

  // Drop disallowed tags entirely
  clone.querySelectorAll([...DROP_TAGS].join(',')).forEach((el) => el.remove());

  const walk = (el: Element) => {
    if (NEUTRALIZE_TAGS.has(el.tagName.toLowerCase())) {
      const span = el.ownerDocument.createElement('span');
      while (el.firstChild) span.appendChild(el.firstChild);
      el.replaceWith(span);
      return walk(span);
    }
    for (const attr of NUKE_ATTRS) el.removeAttribute(attr);
    [...el.attributes].forEach((a) => {
      if (a.name.startsWith('data-') || a.name.startsWith('on')) {
        el.removeAttribute(a.name);
      }
    });
    const tag = el.tagName.toLowerCase();
    if (tag === 'a') {
      const href = el.getAttribute('href');
      [...el.attributes].forEach((a) => {
        if (a.name !== 'href') el.removeAttribute(a.name);
      });
      if (href) el.setAttribute('href', href);
    } else if (tag === 'img') {
      const src = el.getAttribute('src');
      const alt = el.getAttribute('alt') ?? '';
      [...el.attributes].forEach((a) => el.removeAttribute(a.name));
      if (src) el.setAttribute('src', src);
      el.setAttribute('alt', alt);
    }
    for (const child of [...el.children]) walk(child);
  };

  for (const attr of NUKE_ATTRS) clone.removeAttribute(attr);
  for (const child of [...clone.children]) walk(child);

  return clone.innerHTML.trim();
}

/**
 * Convert a rendered DOM node to structured plain text.
 * Headings → text (no ## prefix), bold → text, bullets → "• ", numbered → "1. "
 * This produces CLEAN plain text, not markdown syntax.
 */
export function renderedNodeToPlain(node: HTMLElement | null): string {
  if (!node) return '';
  const lines: string[] = [];

  let currentLine = '';
  const appendInline = (s: string) => { currentLine += s; };
  const flushLine = () => {
    const t = currentLine.replace(/\s+$/, '');
    if (t.length) lines.push(t);
    currentLine = '';
  };

  const walk = (el: ChildNode, depth = 0): void => {
    if (el.nodeType === Node.TEXT_NODE) {
      const t = (el.textContent ?? '').replace(/\s+/g, ' ');
      if (t.trim()) appendInline(t);
      return;
    }
    if (!(el instanceof HTMLElement)) return;

    const tag = el.tagName.toLowerCase();
    switch (tag) {
      case 'h1': case 'h2': case 'h3': case 'h4': case 'h5': case 'h6': {
        flushLine();
        lines.push('');
        for (const c of el.childNodes) walk(c, depth);
        flushLine();
        lines.push('');
        return;
      }
      case 'p': {
        flushLine();
        for (const c of el.childNodes) walk(c, depth);
        flushLine();
        lines.push('');
        return;
      }
      case 'ul': {
        flushLine();
        for (const c of el.childNodes) {
          if (c instanceof HTMLElement && c.tagName.toLowerCase() === 'li') {
            currentLine = '  '.repeat(depth) + '• ';
            for (const cc of c.childNodes) walk(cc, depth + 1);
            flushLine();
          }
        }
        lines.push('');
        return;
      }
      case 'ol': {
        flushLine();
        let n = 1;
        for (const c of el.childNodes) {
          if (c instanceof HTMLElement && c.tagName.toLowerCase() === 'li') {
            currentLine = '  '.repeat(depth) + `${n}. `;
            for (const cc of c.childNodes) walk(cc, depth + 1);
            flushLine();
            n++;
          }
        }
        lines.push('');
        return;
      }
      case 'li': {
        for (const c of el.childNodes) walk(c, depth);
        return;
      }
      case 'br': { flushLine(); return; }
      case 'pre': {
        flushLine();
        const code = (el.textContent ?? '').replace(/\n+$/, '');
        for (const ln of code.split('\n')) lines.push('  ' + ln);
        lines.push('');
        return;
      }
      case 'code': {
        appendInline(el.textContent ?? '');
        return;
      }
      case 'strong': case 'b':
      case 'em': case 'i': {
        // Just pass through the text — no markdown syntax in plain output
        for (const c of el.childNodes) walk(c, depth);
        return;
      }
      case 'a': {
        const href = (el as HTMLAnchorElement).href;
        const text = el.textContent ?? '';
        if (href && href !== text) appendInline(`${text} (${href})`);
        else appendInline(text);
        return;
      }
      case 'blockquote': {
        flushLine();
        const inner = (el.textContent ?? '').trim();
        for (const ln of inner.split('\n')) lines.push('  ' + ln);
        lines.push('');
        return;
      }
      case 'hr': { flushLine(); lines.push('---'); lines.push(''); return; }
      default: {
        for (const c of el.childNodes) walk(c, depth);
      }
    }
  };

  for (const c of node.childNodes) walk(c, 0);
  flushLine();

  return lines.join('\n').replace(/\n{3,}/g, '\n\n').trim();
}
