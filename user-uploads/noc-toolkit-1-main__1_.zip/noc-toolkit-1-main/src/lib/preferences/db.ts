/**
 * USER PREFERENCES — Pure Supabase. Zero localStorage.
 * Stores theme + AI settings per user.
 * Falls back gracefully if user_preferences table doesn't exist yet.
 *
 * SQL to create the table (run once in Supabase SQL Editor):
 *
 *   CREATE TABLE IF NOT EXISTS user_preferences (
 *     user_id text PRIMARY KEY,
 *     theme text NOT NULL DEFAULT 'dark',
 *     ai_model_override text NOT NULL DEFAULT '',
 *     updated_at timestamptz NOT NULL DEFAULT now()
 *   );
 */

import { supabase } from '../../db';

export interface UserPreferences {
  userId: string;
  theme: 'dark' | 'light';
  aiModelOverride: string;
}

const DEFAULTS: Omit<UserPreferences, 'userId'> = {
  theme: 'dark',
  aiModelOverride: '',
};

export async function getUserPreferences(userId: string): Promise<UserPreferences> {
  try {
    const { data, error } = await supabase
      .from('user_preferences')
      .select('*')
      .eq('user_id', userId)
      .single();

    if (error || !data) return { userId, ...DEFAULTS };

    return {
      userId,
      theme: (data.theme === 'light' ? 'light' : 'dark') as 'dark' | 'light',
      aiModelOverride: data.ai_model_override ?? '',
    };
  } catch {
    return { userId, ...DEFAULTS };
  }
}

export async function setUserPreferences(
  userId: string,
  patch: Partial<Omit<UserPreferences, 'userId'>>,
): Promise<void> {
  try {
    const updates: Record<string, unknown> = {
      user_id: userId,
      updated_at: new Date().toISOString(),
    };
    if (patch.theme !== undefined) updates.theme = patch.theme;
    if (patch.aiModelOverride !== undefined) updates.ai_model_override = patch.aiModelOverride;

    await supabase
      .from('user_preferences')
      .upsert(updates, { onConflict: 'user_id' });
  } catch (e) {
    // Table may not exist yet — fail silently
    console.warn('setUserPreferences failed (table may not exist):', (e as Error)?.message);
  }
}
