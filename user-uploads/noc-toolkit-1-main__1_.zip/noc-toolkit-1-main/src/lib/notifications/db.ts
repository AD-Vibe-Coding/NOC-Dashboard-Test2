/**
 * NOTIFICATIONS — Pure Supabase. Zero localStorage.
 * Every read and write goes directly to Supabase.
 * Context polls every 20s so notifications appear cross-browser within 20 seconds.
 */

import { supabase } from '../../db';

export type NotificationType = 'info' | 'success' | 'warning' | 'error' | 'system';

export interface Notification {
  id: string;
  targetUserId: string; // specific user id OR 'all' for broadcast
  title: string;
  message: string;
  type: NotificationType;
  read: boolean;
  link?: string;
  createdAt: string;
  createdBy?: string;
  createdByName?: string;
}

function fromRow(r: any): Notification {
  return {
    id: r.id,
    targetUserId: r.target_user_id,
    title: r.title,
    message: r.message,
    type: r.type as NotificationType,
    read: r.read ?? false,
    link: r.link ?? undefined,
    createdAt: r.created_at,
    createdBy: r.created_by ?? undefined,
    createdByName: r.created_by_name ?? undefined,
  };
}

// ─── Reads ────────────────────────────────────────────────────────────────────

export async function getNotificationsForUser(userId: string): Promise<Notification[]> {
  const { data, error } = await supabase
    .from('notifications')
    .select('*')
    .or(`target_user_id.eq.${userId},target_user_id.eq.all`)
    .order('created_at', { ascending: false })
    .limit(100);

  if (error) {
    console.warn('getNotificationsForUser:', error.message);
    return [];
  }
  return (data ?? []).map(fromRow);
}

export async function getAllNotificationsAdmin(): Promise<Notification[]> {
  const { data, error } = await supabase
    .from('notifications')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(200);

  if (error) { console.warn('getAllNotificationsAdmin:', error.message); return []; }
  return (data ?? []).map(fromRow);
}

// ─── Writes ───────────────────────────────────────────────────────────────────

export async function createNotification(
  targetUserId: string,
  title: string,
  message: string,
  type: NotificationType = 'info',
  options?: { link?: string; createdBy?: string; createdByName?: string }
): Promise<Notification | null> {
  const id = `n_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  const createdAt = new Date().toISOString();

  const { data, error } = await supabase
    .from('notifications')
    .insert({
      id,
      target_user_id: targetUserId,
      title,
      message,
      type,
      read: false,
      link: options?.link ?? null,
      created_at: createdAt,
      created_by: options?.createdBy ?? null,
      created_by_name: options?.createdByName ?? null,
    })
    .select()
    .single();

  if (error) {
    console.error('createNotification error:', error.message);
    return null;
  }
  return fromRow(data);
}

export async function markAsRead(id: string): Promise<void> {
  await supabase.from('notifications').update({ read: true }).eq('id', id);
}

export async function markAllAsRead(userId: string): Promise<void> {
  // Mark all notifications targeted at this user OR 'all' as read
  await supabase
    .from('notifications')
    .update({ read: true })
    .or(`target_user_id.eq.${userId},target_user_id.eq.all`)
    .eq('read', false);
}

export async function deleteNotification(id: string): Promise<void> {
  await supabase.from('notifications').delete().eq('id', id);
}
