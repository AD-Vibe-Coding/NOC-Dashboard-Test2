/**
 * Seed initial runbook data from NOCScriptsPage + FaultTypesPage into Supabase.
 * Called on first load of RunbookEditorPage if runbooks table is empty.
 */
import { createRunbook, hasAnyRunbooks, type RunbookCategory } from './db';

interface SeedEntry {
  title: string;
  category: RunbookCategory;
  content: string;
  plainText: string;
  sortOrder: number;
}

const SEED_DATA: SeedEntry[] = [
  // ─── Ticket Scripts ──────────────────────────────────────
  { sortOrder: 1, category: 'ticket-scripts', title: 'Ticket Acknowledgement (Initial Response)',
    content: `<p>Hello Team,</p><p>I have picked up your ticket and am currently investigating the issue. I will provide an update shortly.</p><p>In the meantime, please verify the power source, reboot the equipment (if authorized), and check cabling. Kindly share the local contact name, phone number, and site access hours in case dispatch is required. <strong>Please note: If no issue is found with the ISP, the dispatch may be billable.</strong></p>`,
    plainText: `Hello Team,\n\nI have picked up your ticket and am currently investigating the issue. I will provide an update shortly.\n\nIn the meantime, please verify the power source, reboot the equipment (if authorized), and check cabling. Kindly share the local contact name, phone number, and site access hours in case dispatch is required. Please note: If no issue is found with the ISP, the dispatch may be billable.` },

  { sortOrder: 2, category: 'ticket-scripts', title: 'Down Hard / Modem Unreachable (No Outage Confirmed)',
    content: `<p>Hello Team,</p><p>We are observing the circuit as down in our monitoring tool. The carrier has confirmed that there are no outages or maintenance activities in the area.</p><p>Please perform a <strong>Layer 1 check</strong> (power and cabling) and confirm the results. If the issue persists, kindly provide the local contact details (name, phone, and access hours) so we can coordinate a dispatch.</p><p><strong>Please note: If no issue is found with the ISP, the dispatch may be billable.</strong></p>`,
    plainText: `Hello Team,\n\nWe are observing the circuit as down in our monitoring tool. The carrier has confirmed that there are no outages or maintenance activities in the area.\n\nPlease perform a Layer 1 check (power and cabling) and confirm the results. If the issue persists, kindly provide the local contact details (name, phone, and access hours) so we can coordinate a dispatch.\n\nPlease note: If no issue is found with the ISP, the dispatch may be billable.` },

  { sortOrder: 3, category: 'ticket-scripts', title: 'Outage Confirmed by Carrier (With ETR)',
    content: `<p>Hello Team,</p><p>The carrier has confirmed an <strong>outage</strong> affecting the circuit. A technician is working to resolve the issue.</p><ul><li><strong>Estimated Time of Resolution (ETR):</strong> [Insert Time]</li></ul><p>We will continue to follow up with the carrier and provide updates until the issue is resolved.</p>`,
    plainText: `Hello Team,\n\nThe carrier has confirmed an outage affecting the circuit. A technician is working to resolve the issue.\n\n• Estimated Time of Resolution (ETR): [Insert Time]\n\nWe will continue to follow up with the carrier and provide updates until the issue is resolved.` },

  { sortOrder: 4, category: 'ticket-scripts', title: 'Circuit Up – Closing Ticket Notification',
    content: `<p>Hello Team,</p><p>The circuit is <strong>up and stable</strong> in our monitoring tool, and the carrier has confirmed the issue is cleared.</p><p>If you are still experiencing service issues, please reply to this message so we can re-engage the carrier. Otherwise, this ticket will be closed by end of business on <strong>[Date]</strong>.</p>`,
    plainText: `Hello Team,\n\nThe circuit is up and stable in our monitoring tool, and the carrier has confirmed the issue is cleared.\n\nIf you are still experiencing service issues, please reply to this message so we can re-engage the carrier. Otherwise, this ticket will be closed by end of business on [Date].` },

  { sortOrder: 5, category: 'ticket-scripts', title: 'ETR Reply to Customer',
    content: `<p>Hello Team,</p><p>We contacted the carrier regarding the circuit down issue. They informed us there is an unplanned outage in the area with an <strong>ETR of [Insert Time]</strong>.</p><p>We will follow up with the carrier post-ETR and keep you updated.</p>`,
    plainText: `Hello Team,\n\nWe contacted the carrier regarding the circuit down issue. They informed us there is an unplanned outage in the area with an ETR of [Insert Time].\n\nWe will follow up with the carrier post-ETR and keep you updated.` },

  { sortOrder: 6, category: 'ticket-scripts', title: 'Ongoing Outage – No ETR from Carrier Yet',
    content: `<p>Hello Team,</p><p>The carrier has confirmed there is an <strong>ongoing outage</strong> affecting this service. No estimated restoration time has been provided yet.</p><p>We will continue to follow up with the carrier and share updates as they become available.</p>`,
    plainText: `Hello Team,\n\nThe carrier has confirmed there is an ongoing outage affecting this service. No estimated restoration time has been provided yet.\n\nWe will continue to follow up with the carrier and share updates as they become available.` },

  // ─── Layer 1 ─────────────────────────────────────────────
  { sortOrder: 1, category: 'layer1', title: 'Circuit Down – No Outage (Layer 1 Steps)',
    content: `<p>Hello Team,</p><p>The carrier has confirmed that there are no active outages or planned maintenance for this site. Please complete the following <strong>Layer 1 troubleshooting steps</strong> on the circuit:</p><ul><li>Check the power and reboot the related network equipment (modem/router).</li><li>Reseat all cables and ensure they are in the correct ports.</li></ul><p>After performing these steps, please reply with the status. If the issue persists, we will engage the carrier for possible dispatch. In that case, please provide a local contact name, phone number, and access hours. <strong>Please note: If no issue is found with the ISP, the dispatch may be billable.</strong></p>`,
    plainText: `Hello Team,\n\nThe carrier has confirmed that there are no active outages or planned maintenance for this site. Please complete the following Layer 1 troubleshooting steps on the circuit:\n\n• Check the power and reboot the related network equipment (modem/router).\n• Reseat all cables and ensure they are in the correct ports.\n\nAfter performing these steps, please reply with the status. If the issue persists, we will engage the carrier for possible dispatch. In that case, please provide a local contact name, phone number, and access hours. Please note: If no issue is found with the ISP, the dispatch may be billable.` },

  { sortOrder: 2, category: 'layer1', title: 'IP Whitelisting Request',
    content: `<p>Hello Team,</p><p>Please whitelist the following IP ranges on your device:</p><ul><li><strong>Asia (Singapore):</strong> 18.139.118.192/26</li><li><strong>Australia (Sydney):</strong> 3.106.118.64/26</li><li><strong>EU (Dublin):</strong> 52.215.168.128/26</li><li><strong>US (Oregon):</strong> 34.223.95.64/26</li><li><strong>US (Washington DC):</strong> 52.202.255.64/26</li><li><strong>vCom:</strong> 104.42.63.159</li></ul>`,
    plainText: `Hello Team,\n\nPlease whitelist the following IP ranges on your device:\n\n• Asia (Singapore): 18.139.118.192/26\n• Australia (Sydney): 3.106.118.64/26\n• EU (Dublin): 52.215.168.128/26\n• US (Oregon): 34.223.95.64/26\n• US (Washington DC): 52.202.255.64/26\n• vCom: 104.42.63.159` },

  // ─── Maintenance ─────────────────────────────────────────
  { sortOrder: 1, category: 'maintenance', title: 'Scheduled Maintenance Notification',
    content: `<p>Hello Team,</p><p>Please be advised, the <strong>vCom</strong> provided Circuit <strong>[Circuit ID]</strong> from the <strong>[Carrier]</strong> carrier will be performing scheduled maintenance that may impact your service at <strong>[Address]</strong>.</p><ul><li><strong>Start Time:</strong> [Date/Time]</li><li><strong>End Time:</strong> [Date/Time]</li><li><strong>Reason:</strong> [Reason]</li></ul><p>Brief interruptions may occur during this window. If issues persist after maintenance, please reboot your equipment. For further support, reply to this message or call <strong>800-804-8266 opt 3</strong>, referencing this ticket.</p>`,
    plainText: `Hello Team,\n\nPlease be advised, the vCom provided Circuit [Circuit ID] from the [Carrier] carrier will be performing scheduled maintenance that may impact your service at [Address].\n\n• Start Time: [Date/Time]\n• End Time: [Date/Time]\n• Reason: [Reason]\n\nBrief interruptions may occur during this window.` },

  // ─── iPath Fault Types ────────────────────────────────────
  { sortOrder: 1, category: 'ipath-fault-types', title: 'Unreachable (MNS-Standard)',
    content: `<p><strong>Fault Type:</strong> Unreachable from 2+ global site monitors</p><p><strong>Severity:</strong> Critical</p><p><strong>Tier:</strong> MNS-Standard</p><p><strong>Description:</strong> Triggered when the monitored device is unreachable from testing locations (Asia, Australia, EU, US – Oregon and Washington DC).</p><p><strong>NOC Actions:</strong></p><ol><li>Follow up with the carrier to report the circuit down.</li><li>Simultaneously ask the customer to verify Layer 1 (power and cabling).</li></ol>`,
    plainText: `Fault Type: Unreachable\nSeverity: Critical | Tier: MNS-Standard\n\nDescription: Triggered when the monitored device is unreachable from testing locations.\n\nNOC Actions:\n1. Follow up with the carrier to report the circuit down.\n2. Simultaneously ask the customer to verify Layer 1 (power and cabling).` },

  { sortOrder: 2, category: 'ipath-fault-types', title: 'PingLossPercent = 100.0 (Critical)',
    content: `<p><strong>Fault Type:</strong> PingLossPercent = 100.0</p><p><strong>Severity:</strong> Critical</p><p><strong>Tiers:</strong> MNS-Circuit Performance, MNS-Hardware MGMT</p><p><strong>Description:</strong> Triggered when the monitored device is unreachable after 3 failed ping checks in a 3-minute duration.</p><p><strong>NOC Actions:</strong></p><ol><li>Follow up with the carrier to report the circuit down.</li><li>Simultaneously ask the customer to verify Layer 1 (power and cabling).</li></ol>`,
    plainText: `Fault Type: PingLossPercent = 100.0\nSeverity: Critical\n\nNOC Actions:\n1. Follow up with the carrier to report the circuit down.\n2. Ask the customer to verify Layer 1 (power and cabling).` },

  { sortOrder: 3, category: 'ipath-fault-types', title: 'idleInterval = 622.0 (Critical)',
    content: `<p><strong>Fault Type:</strong> idleInterval = 622.0</p><p><strong>Severity:</strong> Critical</p><p><strong>Description:</strong> The interval in seconds LogicMonitor does not get data from the host (~600 seconds / 10 minutes).</p><p><strong>Special Notes:</strong></p><ul><li>Most of the time, you will see both PingLoss and idleInterval alerts together.</li><li>When there is an idleInterval alert, all other SNMP alerts are suppressed because the root issue is the circuit.</li></ul><p><strong>NOC Actions:</strong></p><ol><li>Follow up with the carrier to report the circuit down.</li><li>Simultaneously ask the customer to verify Layer 1 (power and cabling).</li></ol>`,
    plainText: `Fault Type: idleInterval = 622.0\nSeverity: Critical\n\nNote: When idleInterval fires, all other SNMP alerts are suppressed.\n\nNOC Actions:\n1. Follow up with carrier to report circuit down.\n2. Ask customer to verify Layer 1.` },

  { sortOrder: 4, category: 'ipath-fault-types', title: 'PeerState = 2.0 (BGP Issue)',
    content: `<p><strong>Fault Type:</strong> PeerState = 2.0</p><p><strong>Severity:</strong> Warning</p><p><strong>Tier:</strong> MNS-Hardware MGMT</p><p><strong>Description:</strong> MNS-Hardware MGMT alert triggered by an issue with BGP.</p><p><strong>NOC Actions:</strong></p><ol><li>In LogicMonitor, ensure you are on the correct device by checking the serial number and looking for the Critical alert.</li><li>Check other services are up including the circuit.</li><li>Log into the CE device or request the client to verify no changes have been made to BGP including shutting it down.</li><li>If the circuit is continuously flapping, this will affect the BGP — follow up with the carrier to resolve the flapping.</li></ol>`,
    plainText: `Fault Type: PeerState = 2.0 (BGP)\nSeverity: Warning\n\nNOC Actions:\n1. Check correct device in LM.\n2. Verify circuit is up.\n3. Check if BGP was shut down.\n4. If circuit flapping, follow up with carrier.` },

  { sortOrder: 5, category: 'ipath-fault-types', title: 'InUtilizationPercent / OutUtilizationPercent',
    content: `<p><strong>Fault Type:</strong> InUtilizationPercent / OutUtilizationPercent</p><p><strong>Severity:</strong> Warning</p><p><strong>Tier:</strong> MNS-Circuit Performance</p><p><strong>Description:</strong> Triggered when the circuit is showing signs of overutilization. InUtilization = Download traffic. OutUtilization = Upload traffic.</p><p><strong>NOC Actions:</strong></p><ol><li>Update the client specifying whether it is Download or Upload traffic that is overutilizing.</li><li>Include the QSCare representative or Network AM in the email communication based on the channel.</li></ol>`,
    plainText: `Fault Type: InUtilizationPercent / OutUtilizationPercent\nSeverity: Warning\n\nNOC Actions:\n1. Update client on whether it is Download (In) or Upload (Out) traffic.\n2. Include QSCare rep or Network AM.` },
];

export async function seedRunbooksIfEmpty(userId: string, userName: string): Promise<void> {
  try {
    const hasData = await hasAnyRunbooks();
    if (hasData) return; // Already seeded
    console.log('[runbooks] Seeding initial runbook data…');
    for (const entry of SEED_DATA) {
      await createRunbook(
        { title: entry.title, category: entry.category, content: entry.content, plainText: entry.plainText, isPinned: false, sortOrder: entry.sortOrder },
        userId, userName,
      );
    }
    console.log('[runbooks] Seed complete.');
  } catch (e) {
    console.warn('[runbooks] Seed failed (table may not exist yet):', (e as Error)?.message);
  }
}
