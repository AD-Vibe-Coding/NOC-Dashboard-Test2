/**
 * RUNBOOKS — Pure Supabase. Zero localStorage.
 * NOC scripts, iPath fault types, carrier escalations — all editable by admins.
 *
 * SQL to create the table (run once in Supabase SQL Editor):
 *
 *   CREATE TABLE IF NOT EXISTS runbooks (
 *     id text PRIMARY KEY,
 *     title text NOT NULL,
 *     category text NOT NULL DEFAULT 'general',
 *     content text NOT NULL DEFAULT '',
 *     plain_text text NOT NULL DEFAULT '',
 *     created_by text,
 *     created_by_name text,
 *     updated_by text,
 *     updated_by_name text,
 *     is_pinned boolean NOT NULL DEFAULT false,
 *     sort_order integer NOT NULL DEFAULT 0,
 *     created_at timestamptz NOT NULL DEFAULT now(),
 *     updated_at timestamptz NOT NULL DEFAULT now()
 *   );
 */

import { supabase } from '../../db';

export type RunbookCategory =
  | 'ticket-scripts'
  | 'layer1'
  | 'carrier-escalation'
  | 'maintenance'
  | 'ipath-fault-types'
  | 'general';

export const CATEGORY_META: Record<RunbookCategory, { label: string; color: string }> = {
  'ticket-scripts':    { label: 'Ticket Scripts',    color: 'bg-blue-100 dark:bg-blue-500/20 text-blue-700 dark:text-blue-300' },
  'layer1':            { label: 'Layer 1',           color: 'bg-amber-100 dark:bg-amber-500/20 text-amber-700 dark:text-amber-300' },
  'carrier-escalation':{ label: 'Carrier Escalation',color: 'bg-violet-100 dark:bg-violet-500/20 text-violet-700 dark:text-violet-300' },
  'maintenance':       { label: 'Maintenance',       color: 'bg-emerald-100 dark:bg-emerald-500/20 text-emerald-700 dark:text-emerald-300' },
  'ipath-fault-types': { label: 'iPath Fault Types', color: 'bg-red-100 dark:bg-red-500/20 text-red-700 dark:text-red-300' },
  'general':           { label: 'General',           color: 'bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300' },
};

export interface Runbook {
  id: string;
  title: string;
  category: RunbookCategory;
  content: string;     // HTML
  plainText: string;   // plain text for copy
  createdBy?: string;
  createdByName?: string;
  updatedBy?: string;
  updatedByName?: string;
  isPinned: boolean;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
}

function fromRow(r: Record<string, unknown>): Runbook {
  return {
    id: r.id as string,
    title: r.title as string,
    category: (r.category ?? 'general') as RunbookCategory,
    content: (r.content ?? '') as string,
    plainText: (r.plain_text ?? '') as string,
    createdBy: r.created_by as string | undefined,
    createdByName: r.created_by_name as string | undefined,
    updatedBy: r.updated_by as string | undefined,
    updatedByName: r.updated_by_name as string | undefined,
    isPinned: (r.is_pinned ?? false) as boolean,
    sortOrder: (r.sort_order ?? 0) as number,
    createdAt: r.created_at as string,
    updatedAt: r.updated_at as string,
  };
}

export async function getRunbooks(category?: RunbookCategory): Promise<Runbook[]> {
  try {
    let q = supabase
      .from('runbooks')
      .select('*')
      .order('is_pinned', { ascending: false })
      .order('sort_order', { ascending: true })
      .order('title', { ascending: true });

    if (category) q = q.eq('category', category);

    const { data, error } = await q;
    if (error) { console.warn('getRunbooks:', error.message); return []; }
    return (data ?? []).map(r => fromRow(r as Record<string, unknown>));
  } catch {
    return [];
  }
}

export async function createRunbook(
  rb: Omit<Runbook, 'id' | 'createdAt' | 'updatedAt'>,
  userId: string,
  userName: string,
): Promise<Runbook | null> {
  const id = `rb_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  const now = new Date().toISOString();
  const { data, error } = await supabase
    .from('runbooks')
    .insert({
      id,
      title: rb.title,
      category: rb.category,
      content: rb.content,
      plain_text: rb.plainText,
      created_by: userId,
      created_by_name: userName,
      updated_by: userId,
      updated_by_name: userName,
      is_pinned: rb.isPinned,
      sort_order: rb.sortOrder,
      created_at: now,
      updated_at: now,
    })
    .select()
    .single();

  if (error) { console.error('createRunbook:', error.message); return null; }
  return fromRow(data as Record<string, unknown>);
}

export async function updateRunbook(
  id: string,
  patch: Partial<Pick<Runbook, 'title' | 'category' | 'content' | 'plainText' | 'isPinned' | 'sortOrder'>>,
  userId: string,
  userName: string,
): Promise<Runbook | null> {
  const updates: Record<string, unknown> = {
    updated_by: userId,
    updated_by_name: userName,
    updated_at: new Date().toISOString(),
  };
  if (patch.title !== undefined) updates.title = patch.title;
  if (patch.category !== undefined) updates.category = patch.category;
  if (patch.content !== undefined) updates.content = patch.content;
  if (patch.plainText !== undefined) updates.plain_text = patch.plainText;
  if (patch.isPinned !== undefined) updates.is_pinned = patch.isPinned;
  if (patch.sortOrder !== undefined) updates.sort_order = patch.sortOrder;

  const { data, error } = await supabase
    .from('runbooks')
    .update(updates)
    .eq('id', id)
    .select()
    .single();

  if (error) { console.error('updateRunbook:', error.message); return null; }
  return fromRow(data as Record<string, unknown>);
}

export async function deleteRunbook(id: string): Promise<void> {
  await supabase.from('runbooks').delete().eq('id', id);
}

export async function hasAnyRunbooks(): Promise<boolean> {
  try {
    const { count } = await supabase
      .from('runbooks')
      .select('id', { count: 'exact', head: true });
    return (count ?? 0) > 0;
  } catch {
    return false;
  }
}
