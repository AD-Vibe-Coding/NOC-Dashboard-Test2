/**
 * USER INTEGRATIONS — Pure Supabase. Zero localStorage.
 */

import { supabase } from '../../db';
import type { Integration, IntegrationKind, UserIntegrations } from '../../types/auth';

function emptyIntegrations(userId: string): UserIntegrations {
  return { userId, slack: null, gmail: null, gcal: null };
}

export async function getUserIntegrations(userId: string): Promise<UserIntegrations> {
  const { data } = await supabase
    .from('user_integrations')
    .select('*')
    .eq('user_id', userId);

  const result = emptyIntegrations(userId);
  for (const r of data ?? []) {
    const kind = r.kind as IntegrationKind;
    result[kind] = { kind, accountLabel: r.account_label, connectedAt: r.connected_at };
  }
  return result;
}

export async function connectIntegration(
  userId: string,
  kind: IntegrationKind,
  accountLabel: string,
): Promise<UserIntegrations> {
  await supabase.from('user_integrations').upsert({
    user_id: userId,
    kind,
    account_label: accountLabel,
    connected_at: new Date().toISOString(),
    is_active: true,
  }, { onConflict: 'user_id,kind' });

  return getUserIntegrations(userId);
}

export async function disconnectIntegration(
  userId: string,
  kind: IntegrationKind,
): Promise<UserIntegrations> {
  await supabase
    .from('user_integrations')
    .delete()
    .eq('user_id', userId)
    .eq('kind', kind);

  return getUserIntegrations(userId);
}

export async function resetIntegrations(userId: string): Promise<void> {
  await supabase.from('user_integrations').delete().eq('user_id', userId);
}
