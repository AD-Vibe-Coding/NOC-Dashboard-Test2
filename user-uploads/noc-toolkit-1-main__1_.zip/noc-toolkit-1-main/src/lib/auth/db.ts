/**
 * AUTH DATABASE — Pure Supabase. Zero localStorage.
 *
 * mustChangePassword is derived purely from password_hash:
 *   hash === DEFAULT_PW_HASH  →  mustChangePassword = true  (still using default)
 *   hash !== DEFAULT_PW_HASH  →  mustChangePassword = false (already changed)
 *
 * This requires ZERO extra columns in Supabase and works across all browsers
 * and devices forever — Supabase is the single source of truth via password_hash.
 */

import { supabase } from '../../db';
import type { User } from '../../types/auth';

// SHA-256 of '1234567' — the default/reset password.
// If a user's stored hash matches this, they haven't changed their password yet.
export const DEFAULT_PW_HASH = '8bb0cf6eb9b17d0f7d22b456f121257dc1254e1f01665370476383ea776df414';

interface UserRow {
  id: string;
  first_name: string;
  last_name: string;
  username: string;
  email: string;
  password_hash: string;
  role: User['role'];
  created_at: string;
}

function fromRow(row: UserRow): User {
  return {
    id: row.id,
    firstName: row.first_name,
    lastName: row.last_name,
    username: row.username,
    email: row.email,
    passwordHash: row.password_hash,
    role: row.role,
    createdAt: row.created_at,
    // DERIVED from password_hash — no extra column needed.
    // true  = still on default password → force change modal
    // false = user has set their own password → no modal ever
    mustChangePassword: row.password_hash === DEFAULT_PW_HASH,
  };
}

function toRow(user: User): Omit<UserRow, never> {
  return {
    id: user.id,
    first_name: user.firstName,
    last_name: user.lastName,
    username: user.username,
    email: user.email,
    password_hash: user.passwordHash,
    role: user.role,
    created_at: user.createdAt,
  };
}

// ─── Reads ───────────────────────────────────────────────────────────────────

export async function getAllUsers(): Promise<User[]> {
  const { data, error } = await supabase
    .from('users')
    .select('id,first_name,last_name,username,email,password_hash,role,created_at')
    .order('first_name', { ascending: true });
  if (error) { console.error('getAllUsers error:', error.message); return []; }
  return (data ?? []).map(r => fromRow(r as UserRow));
}

export async function getUserByEmail(email: string): Promise<User | null> {
  const { data, error } = await supabase
    .from('users')
    .select('id,first_name,last_name,username,email,password_hash,role,created_at')
    .eq('email', email.toLowerCase().trim())
    .single();
  if (error || !data) return null;
  return fromRow(data as UserRow);
}

export async function getUserById(id: string): Promise<User | null> {
  const { data, error } = await supabase
    .from('users')
    .select('id,first_name,last_name,username,email,password_hash,role,created_at')
    .eq('id', id)
    .single();
  if (error || !data) return null;
  return fromRow(data as UserRow);
}

export async function getUserByUsername(username: string): Promise<User | null> {
  const lower = username.trim().toLowerCase();
  const { data, error } = await supabase
    .from('users')
    .select('id,first_name,last_name,username,email,password_hash,role,created_at')
    .eq('username', lower)
    .single();
  if (error || !data) return null;
  return fromRow(data as UserRow);
}

export async function hasAnyUsers(): Promise<boolean> {
  const { count, error } = await supabase
    .from('users')
    .select('id', { count: 'exact', head: true });
  if (error) return false;
  return (count ?? 0) > 0;
}

// ─── Writes ──────────────────────────────────────────────────────────────────

export async function updateUser(id: string, patch: Partial<User>): Promise<User | null> {
  // Only update columns that actually exist in Supabase
  const updates: Partial<UserRow> = {};
  if (patch.firstName !== undefined)    updates.first_name    = patch.firstName;
  if (patch.lastName !== undefined)     updates.last_name     = patch.lastName;
  if (patch.username !== undefined)     updates.username      = patch.username;
  if (patch.email !== undefined)        updates.email         = patch.email;
  if (patch.passwordHash !== undefined) updates.password_hash = patch.passwordHash;
  if (patch.role !== undefined)         updates.role          = patch.role;
  // NOTE: mustChangePassword is NOT a column — it's derived from password_hash.
  // To change it, update passwordHash. No separate column write needed.

  const { data, error } = await supabase
    .from('users')
    .update(updates)
    .eq('id', id)
    .select('id,first_name,last_name,username,email,password_hash,role,created_at')
    .single();

  if (error) { console.error('updateUser error:', error.message); return null; }
  return fromRow(data as UserRow);
}

/** Admin reset: sets hash back to default → forces user to change on next login */
export async function adminResetPassword(targetUserId: string): Promise<User | null> {
  return updateUser(targetUserId, { passwordHash: DEFAULT_PW_HASH });
}

/** Seed-only: insert users that don't exist yet. Never overwrites existing rows. */
export async function setAllUsers(users: User[]): Promise<void> {
  const rows = users.map(toRow);
  const { error } = await supabase
    .from('users')
    .upsert(rows, { onConflict: 'id', ignoreDuplicates: true });
  if (error) console.error('setAllUsers error:', error.message);
}

export async function resetDatabase(): Promise<void> {
  await supabase.from('users').delete().neq('id', '');
}

/** @deprecated — no longer needed. mustChangePassword is derived from password_hash. */
export function markPasswordChangedInMemory(_userId: string) { /* no-op */ }
