import type { Role, User } from '../../types/auth';
import { hashPassword } from './hash';
import { setAllUsers } from './db';

const DEFAULT_PASSWORD = '1234567';

/**
 * Canonical NOC team roster.
 * username = email prefix (before @appdirect.com) — this is what people type to log in.
 * id       = stable deterministic key so re-seeds don't create duplicate rows in Supabase.
 */
interface SeedEntry {
  id: string;
  first: string;
  last: string;
  username: string;
  email: string;
  role: Role;
}

const TEAM: SeedEntry[] = [
  // ── Super Admins ──────────────────────────────────────────────────────────
  // username = full email — used for login
  { id: 'u_sriram_parisa',          first: 'Sriram',          last: 'Parisa',         username: 'sriram.parisa@appdirect.com',          email: 'sriram.parisa@appdirect.com',          role: 'super_admin' },
  { id: 'u_anirudh_kukudala',       first: 'Anirudh',         last: 'Kukudala',        username: 'anirudh.kukudala@appdirect.com',        email: 'anirudh.kukudala@appdirect.com',        role: 'super_admin' },
  // ── Admins ────────────────────────────────────────────────────────────────
  { id: 'u_matt_marquez',           first: 'Matt',            last: 'Marquez',         username: 'matt.marquez@appdirect.com',            email: 'matt.marquez@appdirect.com',            role: 'admin' },
  { id: 'u_perry_cox',              first: 'Perry',           last: 'Cox',             username: 'perry.cox@appdirect.com',               email: 'perry.cox@appdirect.com',               role: 'admin' },
  { id: 'u_otukho_olembo',          first: 'Otukho',          last: 'Olembo',          username: 'otukho.olembo@appdirect.com',           email: 'otukho.olembo@appdirect.com',           role: 'admin' },
  { id: 'u_zubair_mohammed',        first: 'Zubair',          last: 'Mohammed',        username: 'zubair.mohd@appdirect.com',             email: 'zubair.mohd@appdirect.com',             role: 'admin' },
  { id: 'u_karthik_radhakrishnan',  first: 'Karthik',         last: 'Radhakrishnan',   username: 'karthik.radhakrishnan@appdirect.com',   email: 'karthik.radhakrishnan@appdirect.com',   role: 'admin' },
  // ── Users ─────────────────────────────────────────────────────────────────
  { id: 'u_kenya_gentry',           first: 'Kenya',           last: 'Gentry',          username: 'kenya.gentry@appdirect.com',            email: 'kenya.gentry@appdirect.com',            role: 'user' },
  { id: 'u_abishek_benarji',        first: 'Abishek',         last: 'Benarji',         username: 'abishek.benarji@appdirect.com',         email: 'abishek.benarji@appdirect.com',         role: 'user' },
  { id: 'u_pranav_dandibhotla',     first: 'Pranav',          last: 'Dandibhotla',     username: 'pranav.dandibhotla@appdirect.com',      email: 'pranav.dandibhotla@appdirect.com',      role: 'user' },
  { id: 'u_lokesh_banavath',        first: 'Lokesh',          last: 'Banavath',        username: 'lokesh.banavath@appdirect.com',         email: 'lokesh.banavath@appdirect.com',         role: 'user' },
  { id: 'u_hamza_umme',             first: 'Hamza',           last: 'Rahmani Umme',    username: 'hamza.umme@appdirect.com',              email: 'hamza.umme@appdirect.com',              role: 'user' },
  { id: 'u_samiti_mahalakshmi',     first: 'Samiti',          last: 'Mahalakshmi',     username: 'samiti.mahalakshmi@appdirect.com',      email: 'samiti.mahalakshmi@appdirect.com',      role: 'user' },
  { id: 'u_akram_mohammed',         first: 'Mohammed Akram',  last: 'Ahmed',           username: 'akram.mohammed@appdirect.com',          email: 'akram.mohammed@appdirect.com',          role: 'user' },
  { id: 'u_akash_hanvate',          first: 'Akash',           last: 'Hanvate',         username: 'akash.hanvate@appdirect.com',           email: 'akash.hanvate@appdirect.com',           role: 'user' },
  { id: 'u_karthik_damagalla',      first: 'Karthik',         last: 'Damagalla',       username: 'karthik.damagalla@appdirect.com',       email: 'karthik.damagalla@appdirect.com',       role: 'user' },
  { id: 'u_ashraf_mohammed',        first: 'Ashraf',          last: 'Mohammed',        username: 'ashraf.mohammed@appdirect.com',         email: 'ashraf.mohammed@appdirect.com',         role: 'user' },
];

export async function seedUsers(): Promise<void> {
  const hash = await hashPassword(DEFAULT_PASSWORD);
  const now = new Date().toISOString();
  const users: User[] = TEAM.map((t) => ({
    id: t.id,
    firstName: t.first,
    lastName: t.last,
    username: t.username,
    email: t.email,
    passwordHash: hash,
    role: t.role,
    createdAt: now,
    mustChangePassword: true,
  }));
  await setAllUsers(users);
}
