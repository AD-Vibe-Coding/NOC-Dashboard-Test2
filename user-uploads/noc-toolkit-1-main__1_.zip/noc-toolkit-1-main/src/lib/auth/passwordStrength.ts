/**
 * Password strength checker — shared between ForcePasswordChangeModal and PasswordTab.
 * Minimum criteria for NOC accounts:
 *  - At least 8 characters
 *  - At least 1 uppercase letter
 *  - At least 1 lowercase letter
 *  - At least 1 number
 *  - At least 1 special character
 *  - Must not match any known default / common password
 */

export const DEFAULT_PASSWORDS = [
  '1234567', '12345678', '123456', '1234567890',
  'password', 'password1', 'Password1', 'Password1!',
  'qwerty', 'abc123', 'letmein', 'welcome',
];

export interface StrengthCheck {
  label: string;
  pass: boolean;
}

export interface StrengthResult {
  score: number;         // 0-5
  checks: StrengthCheck[];
  label: string;         // 'Too weak' | 'Weak' | 'Fair' | 'Good' | 'Strong'
  color: string;         // Tailwind bg class
  textColor: string;     // Tailwind text class
  barWidth: string;      // e.g. '60%'
  isAcceptable: boolean; // score >= 4 AND not a default password
  isDefault: boolean;
}

export function checkPasswordStrength(pw: string): StrengthResult {
  const isDefault = DEFAULT_PASSWORDS.includes(pw);

  const checks: StrengthCheck[] = [
    { label: 'At least 8 characters',        pass: pw.length >= 8 },
    { label: 'Uppercase letter (A-Z)',        pass: /[A-Z]/.test(pw) },
    { label: 'Lowercase letter (a-z)',        pass: /[a-z]/.test(pw) },
    { label: 'Number (0-9)',                  pass: /[0-9]/.test(pw) },
    { label: 'Special character (!@#$…)',     pass: /[^A-Za-z0-9]/.test(pw) },
  ];

  const score = checks.filter(c => c.pass).length;

  const levels = [
    { label: 'Too weak', color: 'bg-red-500',    textColor: 'text-red-600 dark:text-red-400',    barWidth: '20%' },
    { label: 'Weak',     color: 'bg-orange-500', textColor: 'text-orange-600 dark:text-orange-400', barWidth: '35%' },
    { label: 'Fair',     color: 'bg-amber-400',  textColor: 'text-amber-600 dark:text-amber-400', barWidth: '55%' },
    { label: 'Good',     color: 'bg-lime-500',   textColor: 'text-lime-600 dark:text-lime-400',   barWidth: '75%' },
    { label: 'Strong',   color: 'bg-emerald-500',textColor: 'text-emerald-600 dark:text-emerald-400', barWidth: '100%' },
  ];

  const level = levels[Math.min(score, 4)];

  return {
    score,
    checks,
    label: isDefault ? 'Default password — not allowed' : level.label,
    color: isDefault ? 'bg-red-500' : level.color,
    textColor: isDefault ? 'text-red-600 dark:text-red-400' : level.textColor,
    barWidth: isDefault ? '20%' : level.barWidth,
    isAcceptable: score >= 4 && !isDefault,
    isDefault,
  };
}
