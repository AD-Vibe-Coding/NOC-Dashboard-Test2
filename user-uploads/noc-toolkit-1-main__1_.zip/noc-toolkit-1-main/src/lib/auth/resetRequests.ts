/**
 * PASSWORD RESET REQUESTS — Pure Supabase. Zero localStorage.
 */

import { supabase } from '../../db';

export interface PasswordResetRequest {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  requestedAt: string;
  status: 'pending' | 'approved' | 'rejected';
  approvedBy?: string;
  approvedAt?: string;
}

function fromRow(r: any): PasswordResetRequest {
  return {
    id: r.id,
    userId: r.user_id,
    userName: r.user_name ?? '',
    userEmail: r.user_email ?? '',
    requestedAt: r.requested_at,
    status: r.status as 'pending' | 'approved' | 'rejected',
    approvedBy: r.approved_by ?? undefined,
    approvedAt: r.approved_at ?? undefined,
  };
}

export async function createResetRequest(
  userId: string,
  userName: string,
  userEmail: string,
): Promise<void> {
  // Check for existing pending request first
  const { data: existing } = await supabase
    .from('password_reset_requests')
    .select('id')
    .eq('user_id', userId)
    .eq('status', 'pending')
    .single();

  if (existing) return; // already pending

  const id = `rr_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  await supabase.from('password_reset_requests').insert({
    id,
    user_id: userId,
    user_name: userName,
    user_email: userEmail,
    requested_at: new Date().toISOString(),
    status: 'pending',
  });
}

export async function getPendingRequests(): Promise<PasswordResetRequest[]> {
  const { data } = await supabase
    .from('password_reset_requests')
    .select('*')
    .eq('status', 'pending')
    .order('requested_at', { ascending: false });
  return (data ?? []).map(fromRow);
}

export async function getAllRequests(): Promise<PasswordResetRequest[]> {
  const { data } = await supabase
    .from('password_reset_requests')
    .select('*')
    .order('requested_at', { ascending: false })
    .limit(100);
  return (data ?? []).map(fromRow);
}

export async function hasActivePendingRequest(userId: string): Promise<boolean> {
  const { count } = await supabase
    .from('password_reset_requests')
    .select('id', { count: 'exact', head: true })
    .eq('user_id', userId)
    .eq('status', 'pending');
  return (count ?? 0) > 0;
}

export async function approveRequest(requestId: string, approvedByName: string): Promise<void> {
  await supabase
    .from('password_reset_requests')
    .update({ status: 'approved', approved_by: approvedByName, approved_at: new Date().toISOString() })
    .eq('id', requestId);
}

export async function rejectRequest(requestId: string, approvedByName: string): Promise<void> {
  await supabase
    .from('password_reset_requests')
    .update({ status: 'rejected', approved_by: approvedByName, approved_at: new Date().toISOString() })
    .eq('id', requestId);
}
