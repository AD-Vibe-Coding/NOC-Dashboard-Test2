// Session persists for 9 hours (one full NOC shift)
const KEY = 'noc_toolkit_session_v2';
const SESSION_DURATION_MS = 9 * 60 * 60 * 1000; // 9 hours

interface Session {
  userId: string;
  expiresAt: number; // unix ms
}

function readSession(): Session | null {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;
    return JSON.parse(raw) as Session;
  } catch { return null; }
}

export function getSessionUserId(): string | null {
  const s = readSession();
  if (!s) return null;
  if (Date.now() > s.expiresAt) {
    clearSession();
    return null;
  }
  return s.userId;
}

export function setSessionUserId(id: string) {
  const session: Session = {
    userId: id,
    expiresAt: Date.now() + SESSION_DURATION_MS,
  };
  localStorage.setItem(KEY, JSON.stringify(session));
}

export function getSessionExpiresAt(): number | null {
  const s = readSession();
  if (!s) return null;
  if (Date.now() > s.expiresAt) { clearSession(); return null; }
  return s.expiresAt;
}

export function clearSession() {
  localStorage.removeItem(KEY);
  // Also clear old v1 key if present
  localStorage.removeItem('noc_toolkit_session_user_id');
}
