/**
 * TEAM STATUS — Pure Supabase. Zero localStorage.
 * Reads/writes directly to user_statuses and status_history tables.
 */

import { supabase } from '../../db';

export type StatusKind = 'available' | 'coffee' | 'bio' | 'lunch' | 'break' | 'offline';

export interface StatusMeta {
  label: string;
  emoji: string;
  className: string;
  trackable: boolean;
}

export const STATUS_META: Record<StatusKind, StatusMeta> = {
  available: { label: 'Available',    emoji: '🟢', className: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-300', trackable: false },
  coffee:    { label: 'Coffee Break', emoji: '☕', className: 'bg-amber-100 text-amber-700 dark:bg-amber-500/20 dark:text-amber-300',         trackable: true  },
  bio:       { label: 'Bio Break',    emoji: '🚻', className: 'bg-blue-100 text-blue-700 dark:bg-blue-500/20 dark:text-blue-300',             trackable: true  },
  lunch:     { label: 'Lunch',        emoji: '🍽️', className: 'bg-orange-100 text-orange-700 dark:bg-orange-500/20 dark:text-orange-300',     trackable: true  },
  break:     { label: 'On Break',     emoji: '🌙', className: 'bg-violet-100 text-violet-700 dark:bg-violet-500/20 dark:text-violet-300',     trackable: true  },
  offline:   { label: 'Offline',      emoji: '🔴', className: 'bg-red-100 text-red-700 dark:bg-red-500/20 dark:text-red-300',               trackable: false },
};

export interface UserStatus {
  userId: string;
  status: StatusKind;
  startedAt: string;
  startedByUserId: string;
}

export interface StatusHistoryEntry {
  id: string;
  userId: string;
  fromStatus: StatusKind | null;
  toStatus: StatusKind;
  changedAt: string;
  changedByUserId: string;
  durationSeconds: number | null;
}

// ─── Reads ────────────────────────────────────────────────────────────────────

export async function getUserStatus(userId: string): Promise<UserStatus> {
  const { data } = await supabase
    .from('user_statuses')
    .select('*')
    .eq('user_id', userId)
    .single();

  if (!data) return { userId, status: 'available', startedAt: new Date().toISOString(), startedByUserId: userId };
  return {
    userId: data.user_id,
    status: data.status as StatusKind,
    startedAt: data.started_at,
    startedByUserId: data.started_by_user_id,
  };
}

export async function getAllStatuses(): Promise<Record<string, UserStatus>> {
  const { data } = await supabase.from('user_statuses').select('*');
  const map: Record<string, UserStatus> = {};
  for (const r of data ?? []) {
    map[r.user_id] = {
      userId: r.user_id,
      status: r.status as StatusKind,
      startedAt: r.started_at,
      startedByUserId: r.started_by_user_id,
    };
  }
  return map;
}

export async function getStatusHistory(limit = 100): Promise<StatusHistoryEntry[]> {
  const { data } = await supabase
    .from('status_history')
    .select('*')
    .order('changed_at', { ascending: false })
    .limit(limit);

  return (data ?? []).map(r => ({
    id: r.id,
    userId: r.user_id,
    fromStatus: r.from_status ?? null,
    toStatus: r.to_status as StatusKind,
    changedAt: r.changed_at,
    changedByUserId: r.changed_by_user_id,
    durationSeconds: r.duration_seconds ?? null,
  }));
}

// ─── Writes ───────────────────────────────────────────────────────────────────

export async function setUserStatus(
  userId: string,
  newStatus: StatusKind,
  changedByUserId: string,
): Promise<UserStatus> {
  const now = new Date().toISOString();

  // Get previous status to calculate duration
  const { data: prev } = await supabase
    .from('user_statuses')
    .select('*')
    .eq('user_id', userId)
    .single();

  let durationSeconds: number | null = null;
  if (prev) {
    durationSeconds = Math.floor(
      (Date.now() - new Date(prev.started_at).getTime()) / 1000
    );
  }

  // Upsert current status
  await supabase.from('user_statuses').upsert({
    user_id: userId,
    status: newStatus,
    started_at: now,
    started_by_user_id: changedByUserId,
  }, { onConflict: 'user_id' });

  // Insert history record
  const histId = `h_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  await supabase.from('status_history').insert({
    id: histId,
    user_id: userId,
    from_status: prev?.status ?? null,
    to_status: newStatus,
    changed_at: now,
    changed_by_user_id: changedByUserId,
    duration_seconds: durationSeconds,
  });

  return { userId, status: newStatus, startedAt: now, startedByUserId: changedByUserId };
}

export async function clearStatusHistory(): Promise<void> {
  await supabase.from('status_history').delete().neq('id', '');
}

export async function resetStatuses(): Promise<void> {
  await supabase.from('user_statuses').delete().neq('user_id', '');
  await supabase.from('status_history').delete().neq('id', '');
}

// ─── Heartbeat (via user_sessions table) ─────────────────────────────────────
export function recordHeartbeat(_userId: string): void {
  // Heartbeats are handled by useActivityTracker → /api/activity
  // No localStorage needed — user_sessions table is the source of truth
}

export function isUserStale(_userId: string): boolean {
  return false; // Staleness determined from user_sessions in Team page
}

export function formatDuration(seconds: number): string {
  if (seconds < 60) return `${seconds}s`;
  const m = Math.floor(seconds / 60);
  if (m < 60) return `${m}m`;
  const h = Math.floor(m / 60);
  const rem = m % 60;
  return rem === 0 ? `${h}h` : `${h}h ${rem}m`;
}
