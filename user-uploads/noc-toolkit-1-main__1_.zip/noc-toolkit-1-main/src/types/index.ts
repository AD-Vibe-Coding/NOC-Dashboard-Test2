// Confidence levels for parsed fields
export type ConfidenceLevel = 'found' | 'guessed' | 'not_found';

export interface ParsedField<T = string> {
  value: T;
  confidence: ConfidenceLevel;
}

export interface MaintenanceData {
  carrier: ParsedField;
  address: ParsedField;
  circuitId: ParsedField;
  startTime: ParsedField;
  endTime: ParsedField;
  duration: ParsedField;
  reason: ParsedField;
  timezone: ParsedField;
}

export type MaintenanceType = 'scheduled' | 'emergency';

// Subnet Calculator Types
export interface SubnetResult {
  networkAddress: string;
  subnetMask: string;
  wildcardMask: string;
  gateway: string;
  usableRange: { start: string; end: string };
  broadcastAddress: string;
  totalIPs: number;
  usableIPs: number;
  cidr: number;
  allIPs: IPEntry[];
}

export interface IPEntry {
  ip: string;
  role: 'network' | 'gateway' | 'usable' | 'broadcast';
  label: string;
}

// AI Chat
export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: Date;
}

// Navigation
export interface NavItem {
  path: string;
  label: string;
  icon: string;
  description: string;
}

// CIDR Reference
export interface CIDRReference {
  cidr: number;
  subnetMask: string;
  total: number;
  usable: number | string;
  commonUse: string;
}

// ────────────────────────────────────────────────────────────────
// Carrier Contact Types (NOC / Escalations)
// ────────────────────────────────────────────────────────────────

export type CarrierCategory = 'Business' | 'Residential' | 'Both';

export interface CarrierService {
  service: string;        // e.g. "DIA", "MPLS", "Cable"
  phones: string[];       // normalized 1-XXX-XXX-XXXX
  emails: string[];
  urls: string[];
  notes: string | null;   // dial codes, options, etc.
}

export interface Carrier {
  name: string;
  category: CarrierCategory;
  services: CarrierService[];
  allPhones: string[];
  allEmails: string[];
  allUrls: string[];
}

export interface EscalationContact {
  tier: number;             // 1 = front-line, escalating up
  name: string | null;      // person or team name
  title: string | null;     // role
  phones: string[];
  emails: string[];
  urls: string[];
  notes: string | null;
}

export interface EscalationsByCarrier {
  [carrierName: string]: {
    'Buyers Club': EscalationContact[];
    'Brokerage': EscalationContact[];
  };
}
