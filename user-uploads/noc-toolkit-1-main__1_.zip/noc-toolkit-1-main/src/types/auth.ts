export type Role = 'super_admin' | 'admin' | 'user';

export const ROLE_LABELS: Record<Role, string> = {
  super_admin: 'Super Admin',
  admin: 'Admin',
  user: 'Normal User',
};

export interface User {
  id: string;
  firstName: string;
  lastName: string;
  username: string;
  email: string;
  passwordHash: string;
  role: Role;
  createdAt: string;
  mustChangePassword: boolean;
}

export type IntegrationKind = 'slack' | 'gmail' | 'gcal';

export interface Integration {
  kind: IntegrationKind;
  connectedAt: string;
  accountLabel: string;
}

export interface UserIntegrations {
  userId: string;
  slack: Integration | null;
  gmail: Integration | null;
  gcal: Integration | null;
}
