import { Suspense, lazy } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { Layout } from './components/layout/Layout';
import { ProtectedRoute } from './components/auth/ProtectedRoute';

// ─── Eagerly imported pages (most-used — zero navigation delay) ──────────────
import Dashboard from './pages/Dashboard';
import MaintenancePage from './pages/MaintenancePage';
import NOCToolsPage from './pages/NOCToolsPage';
import CarrierContactsPage from './pages/CarrierContactsPage';
import AIAssistantPage from './pages/AIAssistantPage';
import TeamPage from './pages/TeamPage';

// ─── Lazily imported pages (heavy or rarely visited) ─────────────────────────
const LoginPage         = lazy(() => import('./pages/LoginPage'));
const MobilityPage      = lazy(() => import('./pages/MobilityPage'));
const NetworkPage       = lazy(() => import('./pages/NetworkPage'));
const DocumentationPage = lazy(() => import('./pages/DocumentationPage'));
const SettingsPage      = lazy(() => import('./pages/SettingsPage'));
const AnalyticsPage     = lazy(() => import('./pages/AnalyticsPage'));
const AdminPage         = lazy(() => import('./pages/AdminPage'));
const SubnetPage        = lazy(() => import('./pages/SubnetPage'));
const RunbookEditorPage = lazy(() => import('./pages/RunbookEditorPage'));
const NotFound          = lazy(() => import('./pages/NotFound'));

function FullPageLoader() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-900">
      <div className="w-4 h-4 border-2 border-primary-500 border-t-transparent rounded-full animate-spin" />
    </div>
  );
}

export default function App() {
  return (
    <>
      <Toaster
        position="bottom-right"
        toastOptions={{
          duration: 2500,
          style: {
            background: '#1e293b',
            color: '#f1f5f9',
            borderRadius: '10px',
            fontSize: '14px',
          },
        }}
      />
      <Routes>
        <Route path="/login" element={<Suspense fallback={<FullPageLoader />}><LoginPage /></Suspense>} />
        <Route path="/" element={<ProtectedRoute><Layout /></ProtectedRoute>}>
          <Route index element={<Dashboard />} />
          <Route path="maintenance" element={<MaintenancePage />} />
          <Route path="subnet"    element={<Navigate to="/noc-tools" replace />} />
          <Route path="noc-tools" element={<NOCToolsPage />} />
          <Route path="carriers"  element={<CarrierContactsPage />} />
          <Route path="mobility"  element={<Suspense fallback={null}><MobilityPage /></Suspense>} />
          <Route path="network"   element={<Suspense fallback={null}><NetworkPage /></Suspense>} />
          <Route path="network-hub/scripts"       element={<Navigate to="/network?tab=scripts"        replace />} />
          <Route path="network-hub/devices"       element={<Navigate to="/network?tab=troubleshooting" replace />} />
          <Route path="network-hub/fault-types"   element={<Navigate to="/network?tab=fault-types"    replace />} />
          <Route path="network-hub/sdwan-metrics" element={<Navigate to="/network?tab=sdwan"          replace />} />
          <Route path="escalation" element={<Navigate to="/carriers" replace />} />
          <Route path="handoff"    element={<Navigate to="/" replace />} />
          <Route path="ai-assistant"  element={<AIAssistantPage />} />
          <Route path="runbooks"      element={<Suspense fallback={null}><RunbookEditorPage /></Suspense>} />
          <Route path="documentation" element={<Suspense fallback={null}><DocumentationPage /></Suspense>} />
          <Route path="team"       element={<TeamPage />} />
          <Route path="settings"   element={<Suspense fallback={null}><SettingsPage /></Suspense>} />
          <Route path="analytics"  element={<Suspense fallback={null}><AnalyticsPage /></Suspense>} />
          <Route path="admin"      element={<Suspense fallback={null}><AdminPage /></Suspense>} />
          <Route path="*"          element={<Suspense fallback={null}><NotFound /></Suspense>} />
        </Route>
      </Routes>
    </>
  );
}
