// Curated official outage map / status page URLs for major US carriers.
// Smaller/regional carriers don't publish public outage maps — use DownDetector fallback.

export interface OutageMap {
  carrier: string;          // matches Carrier.name (case-insensitive substring match)
  label: string;            // display label
  url: string;              // official URL
  source: 'official' | 'downdetector';
}

export const OUTAGE_MAPS: OutageMap[] = [
  // Cable / Residential
  { carrier: 'Comcast', label: 'Xfinity Status Center', url: 'https://www.xfinity.com/support/statusmap', source: 'official' },
  { carrier: 'Spectrum', label: 'Spectrum Outage Map', url: 'https://www.spectrum.net/support/general/check-spectrum-status', source: 'official' },
  { carrier: 'Cox', label: 'Cox Outage Map', url: 'https://www.cox.com/residential/support/check-for-outages.html', source: 'official' },
  { carrier: 'Optimum', label: 'Optimum Status', url: 'https://www.optimum.net/support/service-status', source: 'official' },
  { carrier: 'Altice', label: 'Optimum Service Status', url: 'https://www.optimum.net/support/service-status', source: 'official' },
  { carrier: 'WOW', label: 'WOW! Network Status', url: 'https://www.wowway.com/support', source: 'official' },
  { carrier: 'Mediacom', label: 'Mediacom Service Status', url: 'https://mediacomcable.com/support/service-status/', source: 'official' },
  { carrier: 'Breezeline', label: 'Breezeline Status', url: 'https://www.breezeline.com/support/service-status', source: 'official' },
  { carrier: 'Sparklight', label: 'Sparklight Outage Status', url: 'https://support.sparklight.com/hc/en-us', source: 'official' },
  { carrier: 'Midco', label: 'Midco Service Status', url: 'https://www.midco.com/support/service-status/', source: 'official' },

  // Telco / Major IXC
  { carrier: 'AT&T', label: 'AT&T Outage Map', url: 'https://www.att.com/outages/', source: 'official' },
  { carrier: 'Verizon', label: 'Verizon Repair Status', url: 'https://www.verizon.com/business/support/network-status/', source: 'official' },
  { carrier: 'CenturyLink', label: 'CenturyLink Network Status', url: 'https://www.centurylink.com/home/help/repair/check-for-outages.html', source: 'official' },
  { carrier: 'Lumen', label: 'Lumen Network Health', url: 'https://www.lumen.com/help/en-us/network-maintenance.html', source: 'official' },
  { carrier: 'Level 3', label: 'Lumen Network Health (Level 3)', url: 'https://www.lumen.com/help/en-us/network-maintenance.html', source: 'official' },
  { carrier: 'Frontier', label: 'Frontier Service Status', url: 'https://frontier.com/helpcenter/categories/service/service-status', source: 'official' },
  { carrier: 'Brightspeed', label: 'Brightspeed Status', url: 'https://www.brightspeed.com/support/', source: 'official' },
  { carrier: 'Windstream', label: 'Kinetic by Windstream Status', url: 'https://www.windstream.com/support/network-status', source: 'official' },
  { carrier: 'Ziply Fiber', label: 'Ziply Fiber Network Status', url: 'https://ziplyfiber.com/help/network-status', source: 'official' },
  { carrier: 'Consolidated Communications', label: 'Consolidated Service Alerts', url: 'https://www.consolidated.com/support/service-alerts', source: 'official' },
  { carrier: 'Hawaiian Telecom', label: 'Hawaiian Telcom Status', url: 'https://www.hawaiiantel.com/support', source: 'official' },
  { carrier: 'altafiber', label: 'altafiber (Cincinnati Bell) Status', url: 'https://www.altafiber.com/support', source: 'official' },
  { carrier: 'Cincinnati Bell', label: 'altafiber (Cincinnati Bell) Status', url: 'https://www.altafiber.com/support', source: 'official' },

  // Wireless
  { carrier: 'T-Mobile', label: 'T-Mobile Outage Lookup', url: 'https://www.t-mobile.com/support/coverage/outage-status', source: 'official' },
  { carrier: 'Verizon Wireless', label: 'Verizon Wireless Outage', url: 'https://www.verizon.com/support/check-network-status/', source: 'official' },
  { carrier: 'AT&T Wireless', label: 'AT&T Wireless Outages', url: 'https://www.att.com/outages/', source: 'official' },
  { carrier: 'Sprint', label: 'T-Mobile (Sprint legacy)', url: 'https://www.t-mobile.com/support/coverage/outage-status', source: 'official' },
  { carrier: 'Sprint Wireless', label: 'T-Mobile (Sprint legacy)', url: 'https://www.t-mobile.com/support/coverage/outage-status', source: 'official' },
  { carrier: 'GCI', label: 'GCI Service Status', url: 'https://www.gci.com/support/contact', source: 'official' },

  // Fiber / Enterprise
  { carrier: 'Google Fiber', label: 'Google Fiber Status', url: 'https://fiber.google.com/help/', source: 'official' },
  { carrier: 'MetroNet', label: 'MetroNet Status', url: 'https://metronetinc.com/support/', source: 'official' },
  { carrier: 'TDS', label: 'TDS Telecom Status', url: 'https://tdstelecom.com/support/outage.html', source: 'official' },
  { carrier: 'Crown Castle', label: 'Crown Castle Customer Portal', url: 'https://fibercustomer.crowncastle.com/users/sign_in', source: 'official' },
  { carrier: 'Zayo', label: 'Zayo Tranzact Portal', url: 'https://tranzact.zayo.com/', source: 'official' },
  { carrier: 'Cogent', label: 'Cogent Customer Portal', url: 'https://ecogent.cogentco.com/', source: 'official' },
  { carrier: 'Uniti', label: 'Uniti Fiber Status', url: 'https://unitifiber.com/about/contact-us/', source: 'official' },
  { carrier: 'Lightpath', label: 'Lightpath Status', url: 'https://www.lightpathfiber.com/support', source: 'official' },
  { carrier: 'Astound', label: 'Astound Business Status', url: 'https://www.astound.com/business/support/', source: 'official' },

  // International / Global
  { carrier: 'GTT', label: 'GTT Customer Portal', url: 'https://www.gtt.net/us-en/contact-us', source: 'official' },
  { carrier: 'Colt', label: 'Colt Online Service Status', url: 'https://www.colt.net/support/', source: 'official' },
  { carrier: 'Telstra', label: 'Telstra Outage Page', url: 'https://www.telstra.com.au/outages', source: 'official' },
  { carrier: 'Expereo', label: 'Expereo Status', url: 'https://expereo.com/contact-us/', source: 'official' },
  { carrier: 'Rogers', label: 'Rogers Outage Map', url: 'https://www.rogers.com/customer/support/network-status', source: 'official' },

  // Satellite / Fixed Wireless
  { carrier: 'Viasat', label: 'Viasat Outage Status', url: 'https://www.viasat.com/help/', source: 'official' },
  { carrier: 'Rise Broadband', label: 'Rise Broadband Status', url: 'https://www.risebroadband.com/support/', source: 'official' },
];

/**
 * Find the best official outage map for a given carrier name.
 * Falls back to DownDetector search URL if no match.
 */
export function getOutageMap(carrierName: string): OutageMap {
  const lower = carrierName.toLowerCase();
  // Try exact / specific matches first (longer keys win)
  const ranked = [...OUTAGE_MAPS].sort((a, b) => b.carrier.length - a.carrier.length);
  for (const m of ranked) {
    if (lower.includes(m.carrier.toLowerCase())) return m;
  }
  // Fallback to DownDetector search
  const slug = carrierName.replace(/[^A-Za-z0-9]+/g, '-').toLowerCase();
  return {
    carrier: carrierName,
    label: 'Search DownDetector',
    url: `https://downdetector.com/search/?q=${encodeURIComponent(carrierName)}#${slug}`,
    source: 'downdetector',
  };
}
