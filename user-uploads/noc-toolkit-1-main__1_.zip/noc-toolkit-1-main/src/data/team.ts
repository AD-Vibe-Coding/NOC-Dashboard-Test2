/**
 * NOC team constants — channel info, shared contacts.
 */

export const NOC_SLACK_CHANNEL = {
  name: 'noc-team',
  displayName: 'noc-team (Slack)',
  email: 'noc-team-aaaar33hvugslfvb655ghnmqka@appdirect.slack.com',
  mailto: 'mailto:noc-team-aaaar33hvugslfvb655ghnmqka@appdirect.slack.com',
};
