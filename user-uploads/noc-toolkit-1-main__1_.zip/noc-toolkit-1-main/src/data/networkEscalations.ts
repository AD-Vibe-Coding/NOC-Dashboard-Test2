/**
 * NETWORK CARRIER ESCALATION SCAFFOLD
 *
 * Hardcoded baseline for the top Network carriers, sourced from the existing
 * `carrierContacts.ts` (Level 1 / NOC support numbers). Higher tiers (L2-L5)
 * are intentionally left blank and get auto-filled at runtime by the
 * `/api/confluence/escalations` endpoint which searches the wiki for
 * escalation pages and merges any tier contacts it finds.
 *
 * Tier semantics:
 *   L1 — Frontline NOC / Support               (24/7 phone)
 *   L2 — Tier 2 / Team Lead
 *   L3 — Manager / Supervisor
 *   L4 — Director / VP
 *   L5 — SVP / Executive
 */

export type EscalationTier = 'L1' | 'L2' | 'L3' | 'L4' | 'L5';

export interface TierContact {
  tier: EscalationTier;
  title: string;            // "Frontline NOC", "Manager", etc.
  name?: string;            // contact name if known
  phones: string[];
  emails: string[];
  hours?: string;           // "24/7", "M-F 8am-6pm ET", etc.
  whenToEscalate?: string;  // criteria for moving to this level
  notes?: string;
  source?: 'hardcoded' | 'confluence';
}

export interface NetworkCarrierEscalation {
  /** Stable slug — used in URLs and as object key */
  key: string;
  name: string;
  category: 'tier1-isp' | 'cable-msb' | 'fiber' | 'wireless' | 'aggregator';
  logoColor: string;        // tailwind color name for the strip
  services?: string[];
  tiers: Partial<Record<EscalationTier, TierContact>>;
}

const TIER_META: Record<EscalationTier, { label: string; subtitle: string }> = {
  L1: { label: 'Level 1 — Support', subtitle: 'Frontline NOC · 24/7' },
  L2: { label: 'Level 2 — Tier 2 / Lead', subtitle: 'Engineering escalation' },
  L3: { label: 'Level 3 — Manager', subtitle: 'Supervisor escalation' },
  L4: { label: 'Level 4 — Director / VP', subtitle: 'Major outage only' },
  L5: { label: 'Level 5 — SVP / Executive', subtitle: 'Severity 1 only' },
};

export { TIER_META };

export const NETWORK_ESCALATIONS: NetworkCarrierEscalation[] = [
  {
    key: 'att',
    name: 'AT&T Business',
    category: 'tier1-isp',
    logoColor: 'blue',
    services: ['DIA', 'MPLS', 'Fiber', 'Local Line', 'Centrex'],
    tiers: {
      L1: { tier: 'L1', title: 'AT&T Business DIA NOC',
        phones: ['1-888-613-6330', '1-877-937-5288'],
        emails: [], hours: '24/7',
        whenToEscalate: 'Default first call — circuit down, port flapping, brownouts',
        notes: 'Options 2-2-2 for DIA',
        source: 'hardcoded' },
    },
  },
  {
    key: 'verizon',
    name: 'Verizon Business',
    category: 'tier1-isp',
    logoColor: 'red',
    services: ['DIA', 'MPLS', 'VPLS', 'Fios', 'Local Line'],
    tiers: {
      L1: { tier: 'L1', title: 'Verizon Business Repair',
        phones: ['1-800-444-1111', '1-800-291-5533'],
        emails: [], hours: '24/7',
        whenToEscalate: 'Circuit down, frame relay issues, MPLS routing',
        notes: 'Also use Verizon Enterprise Center portal',
        source: 'hardcoded' },
    },
  },
  {
    key: 'comcast',
    name: 'Comcast Business',
    category: 'cable-msb',
    logoColor: 'gray',
    services: ['DIA', 'MetroE', 'Cable', 'Fiber'],
    tiers: {
      L1: { tier: 'L1', title: 'Comcast Business / Metro-E',
        phones: ['1-800-741-4141', '1-833-847-4249'],
        emails: [], hours: '24/7',
        whenToEscalate: 'Options 2-1-2 · Ask to be transferred to Metro-E team for Enterprise Ethernet',
        source: 'hardcoded' },
    },
  },
  {
    key: 'spectrum',
    name: 'Spectrum Business / Enterprise',
    category: 'cable-msb',
    logoColor: 'sky',
    services: ['Cable', 'DIA', 'Fiber'],
    tiers: {
      L1: { tier: 'L1', title: 'Spectrum Enterprise NOC',
        phones: ['1-888-812-2591', '1-844-350-5679'],
        emails: [], hours: '24/7',
        whenToEscalate: 'DIA / fiber / metro-E first call',
        source: 'hardcoded' },
    },
  },
  {
    key: 'lumen',
    name: 'Lumen (CenturyLink / Level 3)',
    category: 'tier1-isp',
    logoColor: 'indigo',
    services: ['DIA', 'MPLS', 'Fiber', 'SIP', 'POTS'],
    tiers: {
      L1: { tier: 'L1', title: 'Lumen NOC',
        phones: ['1-877-453-8353'],
        emails: ['tscip@lumen.com'], hours: '24/7',
        whenToEscalate: 'Default first call. Use portal for ticket updates · code X80 for broadband, M19 for POTS',
        source: 'hardcoded' },
    },
  },
  {
    key: 'cox',
    name: 'Cox Business',
    category: 'cable-msb',
    logoColor: 'blue',
    services: ['Cable', 'DIA', 'Fiber', 'MPLS'],
    tiers: {
      L1: { tier: 'L1', title: 'Cox Business Support',
        phones: ['1-877-897-2475', '1-866-272-5111'],
        emails: [], hours: '24/7',
        whenToEscalate: 'Default first call',
        source: 'hardcoded' },
    },
  },
  {
    key: 'frontier',
    name: 'Frontier',
    category: 'tier1-isp',
    logoColor: 'red',
    services: ['DSL', 'Fiber', 'DIA', 'MPLS'],
    tiers: {
      L1: { tier: 'L1', title: 'Frontier Wholesale / Business',
        phones: ['1-877-500-5514', '1-800-447-3140', '1-888-444-2267'],
        emails: [], hours: '24/7',
        whenToEscalate: 'Default · 1-888-488-0065 for OR/WA/ID Frontier territories',
        source: 'hardcoded' },
    },
  },
  {
    key: 'granite',
    name: 'Granite Telecommunications',
    category: 'aggregator',
    logoColor: 'amber',
    services: ['DIA', 'POTS', 'DSL', 'Cable', 'Fiber'],
    tiers: {
      L1: { tier: 'L1', title: 'Granite NetOps',
        phones: ['1-866-847-1500', '1-844-478-6621', '1-866-450-7625'],
        emails: ['netopsticketing@granitenet.com'], hours: '24/7',
        whenToEscalate: 'Default · email is preferred for ticket creation',
        source: 'hardcoded' },
    },
  },
  {
    key: 'windstream',
    name: 'Windstream / Kinetic Business',
    category: 'tier1-isp',
    logoColor: 'emerald',
    services: ['DIA', 'MPLS', 'Fiber', 'SD-WAN'],
    tiers: {
      L1: { tier: 'L1', title: 'Windstream Wholesale NOC',
        phones: [],
        emails: [], hours: '24/7',
        whenToEscalate: 'Add Confluence-sourced number',
        notes: 'Will auto-populate from Confluence escalation page',
        source: 'hardcoded' },
    },
  },
  {
    key: 'altice',
    name: 'Altice / Optimum / Lightpath',
    category: 'cable-msb',
    logoColor: 'sky',
    services: ['Cable', 'DIA', 'Fiber'],
    tiers: {
      L1: { tier: 'L1', title: 'Lightpath NOC',
        phones: ['1-866-611-3434'],
        emails: ['networkops@lightpathfiber.com'], hours: '24/7',
        whenToEscalate: 'Default for DIA / metro-E',
        source: 'hardcoded' },
    },
  },
  {
    key: 'crown-castle',
    name: 'Crown Castle Fiber',
    category: 'fiber',
    logoColor: 'violet',
    services: ['DIA', 'MPLS', 'Dark Fiber'],
    tiers: {
      L1: { tier: 'L1', title: 'Crown Castle NOC',
        phones: ['1-855-933-4237'],
        emails: [], hours: '24/7',
        whenToEscalate: 'Default · also use https://fibercustomer.crowncastle.com portal',
        source: 'hardcoded' },
    },
  },
  {
    key: 'gtt',
    name: 'GTT',
    category: 'tier1-isp',
    logoColor: 'pink',
    services: ['DIA', 'MPLS', 'Fiber', 'DSL'],
    tiers: {
      L1: { tier: 'L1', title: 'GTT NOC',
        phones: ['1-866-867-7115', '1-202-921-0223'],
        emails: ['noc@gtt.net'], hours: '24/7',
        whenToEscalate: 'Default · GTT Portal is required for ticket updates',
        source: 'hardcoded' },
    },
  },
  {
    key: 'cogent',
    name: 'Cogent',
    category: 'tier1-isp',
    logoColor: 'orange',
    services: ['DIA', 'VPLS', 'Point-to-Point'],
    tiers: {
      L1: { tier: 'L1', title: 'Cogent Support',
        phones: ['1-877-726-4368'],
        emails: ['support@cogentco.com'], hours: '24/7',
        whenToEscalate: 'Default first call',
        source: 'hardcoded' },
    },
  },
  {
    key: 'tmobile',
    name: 'T-Mobile for Business',
    category: 'wireless',
    logoColor: 'pink',
    services: ['Cell Phone', 'Tablet', '5G WWAN'],
    tiers: {
      L1: { tier: 'L1', title: 'T-Mobile Business',
        phones: ['1-800-937-8997'],
        emails: [], hours: '24/7',
        whenToEscalate: 'Press 0 for representative',
        source: 'hardcoded' },
    },
  },
  {
    key: 'mediacom',
    name: 'Mediacom Business',
    category: 'cable-msb',
    logoColor: 'red',
    services: ['Cable', 'Fiber', 'POTS'],
    tiers: {
      L1: { tier: 'L1', title: 'Mediacom Business / Enterprise',
        phones: ['1-800-379-7412', '1-855-633-4226'],
        emails: ['enterprise_support@mediacomcc.com'], hours: '24/7',
        whenToEscalate: 'Default · use email for fiber support',
        source: 'hardcoded' },
    },
  },
  {
    key: 'fusion',
    name: 'Fusion Connect',
    category: 'aggregator',
    logoColor: 'cyan',
    services: ['Fiber', 'DIA', 'DSL', 'POTS'],
    tiers: {
      L1: { tier: 'L1', title: 'Fusion Connect NOC',
        phones: ['1-888-301-1721'],
        emails: [], hours: '24/7',
        whenToEscalate: 'Default · ticket.fusionconnect.com',
        source: 'hardcoded' },
    },
  },
];
