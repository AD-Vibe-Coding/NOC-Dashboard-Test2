import { useState, useRef, useEffect, useCallback } from 'react';
import {
  Wrench, Globe, Activity, Search, Brain,
  Info, Loader2, X, Terminal, Clock, Repeat, StopCircle, Sparkles,
  Building2, Network, MapPin, Shield, ChevronDown, Upload, FileText,
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { SubnetCalculator } from '../components/subnet/SubnetCalculator';
import { IPVisualMap } from '../components/subnet/IPVisualMap';
import { CIDRReferenceTable } from '../components/subnet/CIDRReferenceTable';
import { getPlainEnglishExplanation } from '../utils/subnetCalculator';
import { sendMessage, type AIMessage } from '../lib/devs-ai/client';
import { trackEvent } from '../lib/analytics/db';
import { useAuth } from '../hooks/useAuth';
import type { SubnetResult } from '../types';

type TabKey = 'subnet' | 'ping' | 'whois' | 'wireshark';

const TABS: { key: TabKey; label: string; icon: React.ElementType; badge?: string }[] = [
  { key: 'subnet',    label: 'IP / Subnet Calc',      icon: Globe },
  { key: 'ping',      label: 'Ping Test',              icon: Activity },
  { key: 'whois',     label: 'WHOIS Lookup',           icon: Search },
  { key: 'wireshark', label: 'AI Wireshark Analyzer',  icon: Brain, badge: 'AI' },
];

// ─── Ping Tab ──────────────────────────────────────────────────────────────
const TIMER_OPTIONS = [
  { label: 'Standard (4 packets)', value: 0 },
  { label: '5 minutes',  value: 5 },
  { label: '10 minutes', value: 10 },
  { label: '15 minutes', value: 15 },
  { label: '20 minutes', value: 20 },
  { label: '25 minutes', value: 25 },
  { label: '30 minutes', value: 30 },
];

function PingTab() {
  const [host, setHost]               = useState('');
  const [minutes, setMinutes]         = useState(0);
  const [continuous, setContinuous]   = useState(false);
  const [running, setRunning]         = useState(false);
  const [done, setDone]               = useState(false);
  const [lines, setLines]             = useState<string[]>([]);
  const [error, setError]             = useState<string | null>(null);
  const [aiSummary, setAiSummary]     = useState('');
  const [aiLoading, setAiLoading]     = useState(false);
  const [elapsed, setElapsed]         = useState(0);
  const outputRef   = useRef<HTMLDivElement>(null);
  const esRef       = useRef<EventSource | null>(null);
  const timerRef    = useRef<ReturnType<typeof setInterval> | null>(null);
  const abortAiRef  = useRef<AbortController | null>(null);

  // Auto-scroll output to bottom
  useEffect(() => {
    if (outputRef.current) outputRef.current.scrollTop = outputRef.current.scrollHeight;
  }, [lines]);

  // Elapsed timer
  useEffect(() => {
    if (running) {
      setElapsed(0);
      timerRef.current = setInterval(() => setElapsed(s => s + 1), 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [running]);

  const stop = useCallback(() => {
    esRef.current?.close(); esRef.current = null;
    setRunning(false); setDone(true);
  }, []);

  const run = useCallback(() => {
    if (!host.trim()) return;
    esRef.current?.close();
    setLines([]); setError(null); setAiSummary(''); setDone(false); setRunning(true);

    const params = new URLSearchParams({ host: host.trim() });
    if (continuous) params.set('continuous', '1');
    else if (minutes > 0) params.set('minutes', String(minutes));

    const es = new EventSource(`/api/ping?${params.toString()}`);
    esRef.current = es;

    es.addEventListener('line',  (e) => setLines(prev => [...prev, JSON.parse(e.data)]));
    es.addEventListener('done',  ()  => { es.close(); esRef.current = null; setRunning(false); setDone(true); });
    es.addEventListener('error', (e: any) => {
      const msg = e.data ? JSON.parse(e.data) : 'Connection error';
      setError(msg); es.close(); esRef.current = null; setRunning(false); setDone(true);
    });
    es.onerror = () => { if (esRef.current) { es.close(); esRef.current = null; setRunning(false); setDone(true); } };
  }, [host, minutes, continuous]);

  const analyzeWithAI = useCallback(async () => {
    if (!lines.length) return;
    abortAiRef.current?.abort();
    const ctrl = new AbortController();
    abortAiRef.current = ctrl;
    setAiLoading(true); setAiSummary('');
    const fullOutput = lines.join('\n');
    const messages: AIMessage[] = [
      { role: 'system', content: 'You are a NOC network analyst. Analyze the following ping test output. Provide a concise structured summary with: 1) Overall status (healthy/degraded/critical), 2) Packet loss percentage and significance, 3) RTT stats (min/avg/max if available), 4) Any notable patterns or anomalies, 5) Recommended NOC action. Keep it brief and actionable. Use markdown.' },
      { role: 'user', content: `Ping test to ${host}:\n\n\`\`\`\n${fullOutput}\n\`\`\`` },
    ];
    let acc = '';
    await sendMessage(messages,
      (d) => { acc += d; setAiSummary(acc); },
      () => setAiLoading(false),
      (e) => { setError(e); setAiLoading(false); },
      { signal: ctrl.signal },
    );
  }, [lines, host]);

  const formatElapsed = (s: number) => {
    const m = Math.floor(s / 60), sec = s % 60;
    return m > 0 ? `${m}m ${sec}s` : `${sec}s`;
  };

  const cmdPreview = continuous
    ? `ping ${host || '<host>'} -t`
    : minutes > 0
      ? `ping -c ${minutes * 60} -i 1 ${host || '<host>'}`
      : `ping -c 4 ${host || '<host>'}`;

  return (
    <div className="space-y-4 max-w-3xl">
      {/* Config bar */}
      <div className="card space-y-3">
        <div className="flex gap-2 flex-wrap">
          <input
            type="text"
            value={host}
            onChange={e => setHost(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && !running && run()}
            placeholder="Hostname or IP — e.g. 8.8.8.8 or google.com"
            className="input-base flex-1 min-w-48"
            disabled={running}
            autoFocus
          />

          {/* Timer dropdown */}
          <div className="relative">
            <select
              value={continuous ? 'continuous' : String(minutes)}
              onChange={e => {
                if (e.target.value === 'continuous') { setContinuous(true); setMinutes(0); }
                else { setContinuous(false); setMinutes(Number(e.target.value)); }
              }}
              disabled={running}
              className="input-base pr-8 appearance-none cursor-pointer text-sm min-w-44"
            >
              {TIMER_OPTIONS.map(o => (
                <option key={o.value} value={o.value}>{o.label}</option>
              ))}
              <option value="continuous">Continuous (-t)</option>
            </select>
            <ChevronDown className="w-4 h-4 absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400" />
          </div>

          {running ? (
            <button onClick={stop} className="inline-flex items-center gap-2 px-5 py-2 rounded-lg bg-red-500 hover:bg-red-600 text-white font-medium text-sm transition-colors">
              <StopCircle className="w-4 h-4" /> Stop
            </button>
          ) : (
            <button onClick={run} disabled={!host.trim()} className="btn-primary px-5 gap-2">
              <Activity className="w-4 h-4" /> Ping
            </button>
          )}
        </div>

        {/* Command preview */}
        <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
          <Terminal className="w-3.5 h-3.5 flex-shrink-0" />
          <code className="font-mono text-slate-600 dark:text-slate-300">{cmdPreview}</code>
          {running && (
            <span className="ml-auto inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-medium">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
              Running · {formatElapsed(elapsed)}
            </span>
          )}
        </div>

        {/* Quick presets */}
        <div className="flex items-center gap-1 flex-wrap">
          <span className="text-xs text-slate-400 mr-1">Quick:</span>
          {['8.8.8.8', '1.1.1.1', 'google.com', 'cloudflare.com', '208.67.222.222'].map(h => (
            <button key={h} onClick={() => setHost(h)} disabled={running}
              className="text-xs px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 font-mono text-slate-600 dark:text-slate-300 transition-colors disabled:opacity-50">
              {h}
            </button>
          ))}
        </div>
      </div>

      {error && (
        <div className="flex items-center gap-2 p-3 bg-red-50 dark:bg-red-500/10 rounded-lg text-sm text-red-600 dark:text-red-400 border border-red-200 dark:border-red-500/20">
          <X className="w-4 h-4 flex-shrink-0" /> {error}
        </div>
      )}

      {/* Output container — fixed height with internal scroll */}
      {(lines.length > 0 || running) && (
        <div className="card !p-0 overflow-hidden">
          <div className="flex items-center justify-between px-4 py-2 bg-slate-100 dark:bg-slate-700/50 border-b border-slate-200 dark:border-slate-700">
            <div className="flex items-center gap-2">
              <Terminal className="w-3.5 h-3.5 text-slate-400" />
              <span className="text-xs font-mono text-slate-500">{cmdPreview}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-400 font-mono">{lines.length} lines</span>
              {running && <span className="text-xs text-emerald-500 animate-pulse font-medium">● Live</span>}
              {done && !running && <span className="text-xs text-slate-400">Complete</span>}
            </div>
          </div>
          {/* FIXED HEIGHT — scrolls internally */}
          <div ref={outputRef} className="h-72 overflow-y-auto bg-slate-950 dark:bg-slate-950 p-4 font-mono text-xs leading-relaxed">
            {lines.map((line, i) => {
              const isLoss  = /100%|request timed out|unreachable/i.test(line);
              const isWarn  = /[1-9]\d*%|timeout|error/i.test(line);
              const isStat  = /packets|statistics|round-trip|rtt/i.test(line);
              return (
                <div key={i} className={`${isLoss ? 'text-red-400' : isWarn ? 'text-amber-400' : isStat ? 'text-cyan-400' : 'text-slate-300'}`}>
                  {line}
                </div>
              );
            })}
            {running && (
              <div className="flex items-center gap-1.5 text-slate-500 mt-1">
                <Loader2 className="w-3 h-3 animate-spin" /> waiting…
              </div>
            )}
          </div>
        </div>
      )}

      {/* AI Summary — shows after completion */}
      {done && lines.length > 0 && (
        <div className="card space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-violet-500" />
              <span className="text-sm font-semibold text-slate-800 dark:text-slate-200">AI Summary</span>
            </div>
            {!aiSummary && !aiLoading && (
              <button onClick={analyzeWithAI} className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg bg-violet-100 dark:bg-violet-500/20 text-violet-700 dark:text-violet-300 hover:bg-violet-200 dark:hover:bg-violet-500/30 transition-colors">
                <Brain className="w-3.5 h-3.5" /> Analyze Results
              </button>
            )}
            {aiLoading && (
              <span className="text-xs text-violet-500 flex items-center gap-1 animate-pulse">
                <Loader2 className="w-3 h-3 animate-spin" /> Analyzing…
              </span>
            )}
          </div>
          {aiSummary && (
            <div className="prose prose-sm dark:prose-invert max-w-none prose-p:my-1 prose-headings:text-sm prose-headings:font-semibold prose-ul:my-1 prose-li:my-0">
              <ReactMarkdown>{aiSummary}</ReactMarkdown>
            </div>
          )}
          {!aiSummary && !aiLoading && (
            <p className="text-xs text-slate-400">Click "Analyze Results" for an AI-powered packet loss and performance summary.</p>
          )}
        </div>
      )}
    </div>
  );
}

// ─── WHOIS Lookup Tab ──────────────────────────────────────────────────────
function WhoisTab() {
  const [query, setQuery]   = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<Record<string, any> | null>(null);
  const [error, setError]   = useState<string | null>(null);
  const [aiNote, setAiNote] = useState('');
  const [aiLoading, setAiLoading] = useState(false);
  const abortRef = useRef<AbortController | null>(null);

  const run = async () => {
    if (!query.trim()) return;
    setLoading(true); setResult(null); setError(null); setAiNote('');
    try {
      const r = await fetch(`/api/whois?query=${encodeURIComponent(query.trim())}`);
      const d = await r.json();
      if (!r.ok || d.error) setError(d.error || 'Lookup failed');
      else setResult(d);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Network error');
    } finally {
      setLoading(false);
    }
  };

  const identifyISP = async () => {
    if (!result) return;
    abortRef.current?.abort();
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    setAiLoading(true); setAiNote('');
    const context = result.type === 'ip'
      ? `IP: ${result.ip}\nISP (ipapi): ${result.isp_consumer || 'N/A'}\nOrg (ARIN): ${result.org_arin || 'N/A'}\nNetwork Name: ${result.network_name || 'N/A'}\nASN: ${result.asn || 'N/A'}\nCountry: ${result.country_name || 'N/A'}`
      : `Domain: ${result.ldhName}\nRegistrar: ${result.registrar}\nRegistrant: ${result.registrant}`;
    const messages: AIMessage[] = [
      { role: 'system', content: 'You are a NOC network analyst with deep knowledge of ISPs, carriers, and telecom companies worldwide. When given IP/org data, identify: 1) The actual consumer-facing brand name of the ISP/carrier (e.g. "Consolidated Communications" not just "CCIG"), 2) Whether it is a residential, commercial, or datacenter provider, 3) Any known aliases or DBAs, 4) Brief context useful for a NOC engineer (e.g. regional fiber provider, major Tier-1, CLEC, etc.). Be concise — 3-5 sentences max. Use markdown.' },
      { role: 'user', content: `Identify the actual ISP/carrier for this network data:\n\n${context}` },
    ];
    let acc = '';
    await sendMessage(messages,
      (d) => { acc += d; setAiNote(acc); },
      () => setAiLoading(false),
      () => setAiLoading(false),
      { signal: ctrl.signal },
    );
  };

  const Row = ({ label, value, mono = false, highlight = false }: { label: string; value?: string | null; mono?: boolean; highlight?: boolean }) => {
    if (!value) return null;
    return (
      <div className="flex gap-3 py-2 border-b border-slate-100 dark:border-slate-700/40 last:border-0">
        <span className="text-xs text-slate-500 dark:text-slate-400 w-40 flex-shrink-0 font-medium pt-0.5">{label}</span>
        <span className={`text-xs break-all leading-relaxed ${mono ? 'font-mono' : ''} ${highlight ? 'text-primary-700 dark:text-primary-300 font-semibold' : 'text-slate-800 dark:text-slate-200'}`}>{value}</span>
      </div>
    );
  };

  const Section = ({ title, icon: Icon, children }: { title: string; icon: React.ElementType; children: React.ReactNode }) => (
    <div className="mb-1">
      <div className="flex items-center gap-2 px-4 py-2 bg-slate-50 dark:bg-slate-700/30 border-b border-slate-200 dark:border-slate-700">
        <Icon className="w-3.5 h-3.5 text-slate-400" />
        <span className="text-xs font-semibold text-slate-600 dark:text-slate-300 uppercase tracking-wide">{title}</span>
      </div>
      <div className="px-4 py-1">{children}</div>
    </div>
  );

  const fmt = (d?: string | null) => { if (!d) return null; try { return new Date(d).toLocaleString(); } catch { return d; } };

  return (
    <div className="space-y-4 max-w-2xl">
      <div className="flex gap-2">
        <input
          type="text"
          value={query}
          onChange={e => setQuery(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && !loading && run()}
          placeholder="IP address or domain — e.g. 64.61.211.202 or google.com"
          className="input-base flex-1"
          disabled={loading}
          autoFocus
        />
        <button onClick={run} disabled={loading || !query.trim()} className="btn-primary px-5 gap-2">
          {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
          Lookup
        </button>
      </div>

      <div className="flex items-center gap-1 flex-wrap">
        <span className="text-xs text-slate-400 mr-1">Quick:</span>
        {['8.8.8.8', '1.1.1.1', '64.61.211.202', 'google.com', 'cloudflare.com'].map(h => (
          <button key={h} onClick={() => setQuery(h)}
            className="text-xs px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 font-mono text-slate-600 dark:text-slate-300 transition-colors">
            {h}
          </button>
        ))}
      </div>

      {error && (
        <div className="flex items-center gap-2 p-3 bg-red-50 dark:bg-red-500/10 rounded-lg text-sm text-red-600 dark:text-red-400 border border-red-200 dark:border-red-500/20">
          <X className="w-4 h-4 flex-shrink-0" /> {error}
        </div>
      )}

      {loading && (
        <div className="card flex items-center gap-3 text-slate-500 dark:text-slate-400 text-sm">
          <Loader2 className="w-4 h-4 animate-spin text-primary-500" />
          Looking up <span className="font-mono font-medium text-slate-700 dark:text-slate-200">{query}</span> via ipapi.co + ARIN RDAP…
        </div>
      )}

      {/* Fixed-height scrollable result container */}
      {result && !loading && (
        <div className="card !p-0 overflow-hidden flex flex-col" style={{ maxHeight: '560px' }}>
          {/* Header */}
          <div className="px-4 py-3 bg-slate-50 dark:bg-slate-700/30 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between flex-shrink-0">
            <div className="flex items-center gap-2">
              <Search className="w-4 h-4 text-primary-500" />
              <span className="text-sm font-semibold text-slate-900 dark:text-white font-mono">{result.ip || result.ldhName || query}</span>
              <span className="text-xs px-2 py-0.5 rounded-full bg-primary-100 text-primary-700 dark:bg-primary-500/20 dark:text-primary-300">
                {result.type === 'ip' ? 'IP Address' : 'Domain'}
              </span>
            </div>
            {result.type === 'ip' && (
              <button onClick={identifyISP} disabled={aiLoading}
                className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-lg bg-violet-100 dark:bg-violet-500/20 text-violet-700 dark:text-violet-300 hover:bg-violet-200 dark:hover:bg-violet-500/30 transition-colors disabled:opacity-50">
                {aiLoading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Brain className="w-3 h-3" />}
                Identify ISP
              </button>
            )}
          </div>

          {/* Scrollable body */}
          <div className="overflow-y-auto flex-1">
            {result.type === 'ip' ? (
              <>
                {/* ISP / Carrier — most important, shown first */}
                <Section title="ISP / Carrier" icon={Building2}>
                  <Row label="ISP (consumer-facing)" value={result.isp_consumer} highlight />
                  <Row label="Org (ARIN technical)"  value={result.org_arin} />
                  <Row label="ASN"                   value={result.asn} mono />
                  <Row label="Network Name"          value={result.network_name} mono />
                  <Row label="Network Handle"        value={result.network_handle} mono />
                  {aiNote && (
                    <div className="my-2 p-3 bg-violet-50 dark:bg-violet-500/10 rounded-lg border border-violet-200 dark:border-violet-500/20">
                      <div className="flex items-center gap-1.5 mb-1.5">
                        <Sparkles className="w-3 h-3 text-violet-500" />
                        <span className="text-xs font-semibold text-violet-700 dark:text-violet-300">AI ISP Identification</span>
                      </div>
                      <div className="prose prose-xs dark:prose-invert max-w-none prose-p:my-0.5 prose-p:text-xs">
                        <ReactMarkdown>{aiNote}</ReactMarkdown>
                      </div>
                    </div>
                  )}
                  {aiLoading && !aiNote && (
                    <div className="flex items-center gap-2 py-2 text-xs text-violet-500 animate-pulse">
                      <Loader2 className="w-3 h-3 animate-spin" /> Identifying ISP…
                    </div>
                  )}
                </Section>

                {/* Network range */}
                <Section title="Network Range" icon={Network}>
                  <Row label="CIDR"       value={result.cidr} mono />
                  <Row label="Start IP"   value={result.start_ip} mono />
                  <Row label="End IP"     value={result.end_ip} mono />
                  <Row label="Hostname"   value={result.hostname} mono />
                </Section>

                {/* Location */}
                <Section title="Location" icon={MapPin}>
                  <Row label="Country"     value={result.country_name ? `${result.country_name} (${result.country_code || ''})` : null} />
                  <Row label="Region"      value={result.region} />
                  <Row label="City"        value={result.city} />
                  <Row label="Timezone"    value={result.timezone} />
                  <Row label="Coordinates" value={result.latitude ? `${result.latitude}, ${result.longitude}` : null} />
                </Section>

                {/* Abuse contact */}
                {(result.abuse_email || result.abuse_phone) && (
                  <Section title="Abuse Contact" icon={Shield}>
                    <Row label="Abuse Email" value={result.abuse_email} mono />
                    <Row label="Abuse Phone" value={result.abuse_phone} mono />
                  </Section>
                )}
              </>
            ) : (
              <>
                <Section title="Domain Registration" icon={Globe}>
                  <Row label="Domain"       value={result.ldhName || result.handle} />
                  <Row label="Status"       value={result.status} />
                  <Row label="Registrar"    value={result.registrar} />
                  <Row label="Registered"   value={fmt(result.registered)} />
                  <Row label="Expires"      value={fmt(result.expires)} />
                  <Row label="Last Updated" value={fmt(result.updated)} />
                  <Row label="Name Servers" value={result.nameservers} mono />
                </Section>
                <Section title="Contacts" icon={Building2}>
                  <Row label="Registrant"       value={result.registrant} />
                  <Row label="Registrant Email"  value={result.registrant_email} mono />
                  <Row label="Admin"             value={result.admin} />
                  <Row label="Tech"              value={result.tech} />
                  <Row label="Abuse Email"       value={result.abuse_email} mono />
                </Section>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── AI Wireshark Analyzer Tab ─────────────────────────────────────────────
const WIRESHARK_SYSTEM_PROMPT = `You are a senior network engineer and Wireshark/tshark expert working in a NOC (Network Operations Center). The user will paste Wireshark packet capture output, tshark dissection, or pcap text exports.

Analyze the provided logs and structure your response exactly as follows:

## Summary
What is happening in this capture — protocols involved, endpoints, traffic flow, duration/packet count if visible.

## Issues Detected
List any anomalies: TCP retransmissions, RST packets, high RTT/latency, DNS failures, ICMP errors, packet loss, malformed packets, authentication failures, unusual port usage. If none found, say "No issues detected."

## Notable Patterns
Repeated events, port scans, broadcast storms, asymmetric routing, mismatched MTU, TLS errors, high jitter, etc.

## NOC Action Items
Concrete next steps the NOC team should take. Be specific (e.g. "Check BGP session on router X", "Verify DHCP server availability", "Escalate to Tier 2 if packet loss > 5%").

## Verdict
One sentence — is this capture healthy, degraded, or critical?

Be concise and actionable. Use bullet points within sections. Focus on what a NOC engineer needs to act on.`;

function WiresharkTab() {
  const [logs, setLogs] = useState('');
  const [loading, setLoading] = useState(false);
  const [analysis, setAnalysis] = useState('');
  const [error, setError] = useState<string | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  const analyze = async () => {
    if (!logs.trim()) return;
    abortRef.current?.abort();
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    setLoading(true); setAnalysis(''); setError(null);
    let acc = '';
    const messages: AIMessage[] = [
      { role: 'system', content: WIRESHARK_SYSTEM_PROMPT },
      { role: 'user', content: `Analyze these network logs:\n\n\`\`\`\n${logs.trim()}\n\`\`\`` },
    ];
    await sendMessage(
      messages,
      (delta) => { acc += delta; setAnalysis(acc); },
      () => setLoading(false),
      (err) => { setError(err); setLoading(false); },
      { signal: ctrl.signal },
    );
  };

  const clear = () => {
    setLogs(''); setAnalysis(''); setError(null);
    abortRef.current?.abort();
  };

  const EXAMPLE = `No.  Time        Source          Destination     Protocol  Length  Info
1    0.000000    192.168.1.10    8.8.8.8         DNS       74      Standard query 0x1a2b A google.com
2    0.012341    8.8.8.8         192.168.1.10    DNS       90      Standard query response A 142.250.80.46
3    0.013002    192.168.1.10    142.250.80.46   TCP       66      49152 → 443 [SYN] Seq=0 Win=64240
4    0.045231    142.250.80.46   192.168.1.10    TCP       66      443 → 49152 [SYN, ACK] Seq=0 Ack=1
5    0.045300    192.168.1.10    142.250.80.46   TCP       54      49152 → 443 [ACK] Seq=1 Ack=1
6    0.250100    192.168.1.10    142.250.80.46   TCP       54      49152 → 443 [RST] Seq=1
7    0.510000    192.168.1.10    192.168.1.1     TCP       66      49153 → 80 [SYN] Seq=0 Win=64240
8    1.510000    192.168.1.10    192.168.1.1     TCP       66      [TCP Retransmission] 49153 → 80 [SYN]
9    2.510000    192.168.1.10    192.168.1.1     TCP       66      [TCP Retransmission] 49153 → 80 [SYN]`;

  return (
    <div className="space-y-4">
      <div className="p-3 bg-violet-50 dark:bg-violet-500/10 border border-violet-200 dark:border-violet-500/20 rounded-lg text-xs text-violet-700 dark:text-violet-300">
        Paste Wireshark packet list, tshark output, or any pcap text export. The AI will identify issues, patterns, and recommended actions for the NOC team.
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Input panel */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase tracking-wide">
              Paste or upload Wireshark / tshark output
            </label>
            <div className="flex items-center gap-2">
              {logs && (
                <button onClick={clear} className="text-xs text-slate-400 hover:text-red-500 transition-colors">Clear</button>
              )}
              <button onClick={() => setLogs(EXAMPLE)} className="text-xs text-primary-500 hover:text-primary-600 underline underline-offset-2">
                Load example
              </button>
            </div>
          </div>
          {/* File upload drop zone */}
          <label className="flex items-center gap-2 px-3 py-2 rounded-lg border border-dashed border-slate-300 dark:border-slate-600 hover:border-primary-400 dark:hover:border-primary-500 cursor-pointer transition-colors bg-slate-50 dark:bg-slate-800/50 group">
            <Upload className="w-4 h-4 text-slate-400 group-hover:text-primary-500 transition-colors flex-shrink-0" />
            <span className="text-xs text-slate-500 dark:text-slate-400 group-hover:text-primary-600 dark:group-hover:text-primary-400 transition-colors">
              Upload .txt / .log / .csv / .pcap (tshark text export) — or paste below
            </span>
            <input type="file" accept=".txt,.log,.csv,.pcap,.pcapng,.cap,.json" className="hidden"
              onChange={async e => {
                const file = e.target.files?.[0];
                if (!file) return;
                if (file.name.match(/\.(pcap|pcapng|cap)$/i)) {
                  setLogs(`# ${file.name} (${(file.size/1024).toFixed(1)} KB)\n# Binary PCAP file — run: tshark -r "${file.name}" -T text > output.txt\n# Then upload the output.txt file, or paste the tshark text output below.\n\n[Binary PCAP uploaded — paste tshark text output for analysis]`);
                } else {
                  const text = await file.text();
                  setLogs(text.slice(0, 100_000));
                }
                (e.target as HTMLInputElement).value = '';
              }}
            />
          </label>
          <textarea
            value={logs}
            onChange={e => setLogs(e.target.value)}
            placeholder={"Paste Wireshark or tshark output here…\n\nExample:\n1  0.000000  192.168.1.1 → 8.8.8.8  DNS  74  Standard query A google.com\n2  0.012453  8.8.8.8 → 192.168.1.1  DNS  90  Standard query response..."}
            rows={15}
            className="input-base font-mono text-xs resize-y w-full"
          />
          <button
            onClick={analyze}
            disabled={loading || !logs.trim()}
            className="btn-primary w-full gap-2"
          >
            {loading
              ? <><Loader2 className="w-4 h-4 animate-spin" /> Analyzing…</>
              : <><Brain className="w-4 h-4" /> Analyze with AI</>
            }
          </button>
          {loading && (
            <button
              onClick={() => { abortRef.current?.abort(); setLoading(false); }}
              className="btn-secondary w-full text-xs"
            >
              Stop
            </button>
          )}
        </div>

        {/* Output panel */}
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase tracking-wide">
              AI Analysis
            </label>
            {loading && (
              <span className="text-xs text-violet-500 animate-pulse flex items-center gap-1">
                <span className="w-1.5 h-1.5 bg-violet-500 rounded-full animate-ping" />
                Analyzing…
              </span>
            )}
          </div>
          <div className="card min-h-[420px] max-h-[600px] overflow-y-auto">
            {error && (
              <div className="flex items-start gap-2 p-3 bg-red-50 dark:bg-red-500/10 rounded-lg text-sm text-red-600 dark:text-red-400">
                <X className="w-4 h-4 mt-0.5 flex-shrink-0" /> {error}
              </div>
            )}
            {!analysis && !error && !loading && (
              <div className="flex flex-col items-center justify-center h-64 text-slate-400 dark:text-slate-500">
                <Brain className="w-10 h-10 mb-3 opacity-20" />
                <p className="text-sm">Paste logs and click "Analyze with AI"</p>
                <p className="text-xs mt-1 opacity-70">Supports Wireshark, tshark, and pcap text exports</p>
              </div>
            )}
            {analysis && (
              <div className="prose prose-sm dark:prose-invert max-w-none prose-headings:text-sm prose-headings:font-bold prose-p:my-1.5 prose-ul:my-1 prose-li:my-0.5 prose-code:text-xs">
                <ReactMarkdown>{analysis}</ReactMarkdown>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Main Page ──────────────────────────────────────────────────────────────
export default function NOCToolsPage() {
  const { user } = useAuth();
  const [tab, setTab] = useState<TabKey>('subnet');
  const [subnetResult, setSubnetResult] = useState<SubnetResult | null>(null);

  const handleTabChange = (key: TabKey) => {
    setTab(key);
    if (user) {
      const toolMap: Record<TabKey, string> = {
        subnet: 'noc_tools_subnet',
        ping: 'noc_tools_ping',
        whois: 'noc_tools_whois',
        wireshark: 'noc_tools_wireshark',
      };
      trackEvent(user.id, toolMap[key] as any, 'tab_open');
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-5">
      {/* Page header */}
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 bg-primary-100 dark:bg-primary-500/10 rounded-lg flex items-center justify-center">
          <Wrench className="w-5 h-5 text-primary-600 dark:text-primary-400" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">NOC Tools</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            IP calculator · Ping · WHOIS · AI Wireshark log analysis
          </p>
        </div>
      </div>

      {/* Tab bar */}
      <div className="flex flex-wrap gap-1 border-b border-slate-200 dark:border-slate-700">
        {TABS.map(t => {
          const Icon = t.icon;
          const active = tab === t.key;
          return (
            <button
              key={t.key}
              onClick={() => handleTabChange(t.key)}
              className={`inline-flex items-center gap-2 px-4 py-2.5 text-sm font-medium rounded-t-lg border-b-2 -mb-px transition-all ${
                active
                  ? 'border-primary-500 text-primary-700 dark:text-primary-300 bg-primary-50/50 dark:bg-primary-500/5'
                  : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800/50'
              }`}
            >
              <Icon className="w-4 h-4" />
              {t.label}
              {t.badge && (
                <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-violet-100 text-violet-700 dark:bg-violet-500/20 dark:text-violet-300 font-semibold leading-none">
                  {t.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Tab content */}
      <div>
        {tab === 'subnet' && (
          <div className="space-y-6">
            <SubnetCalculator onResult={setSubnetResult} />
            {subnetResult && (
              <div className="flex items-start gap-3 p-4 bg-primary-50 dark:bg-primary-500/5 rounded-xl border border-primary-200 dark:border-primary-500/20">
                <Info className="w-5 h-5 text-primary-500 mt-0.5 flex-shrink-0" />
                <p className="text-sm text-primary-800 dark:text-primary-300 leading-relaxed">
                  {getPlainEnglishExplanation(subnetResult)}
                </p>
              </div>
            )}
            {subnetResult && <IPVisualMap result={subnetResult} />}
            <CIDRReferenceTable />
          </div>
        )}
        {tab === 'ping'      && <PingTab />}
        {tab === 'whois'     && <WhoisTab />}
        {tab === 'wireshark' && <WiresharkTab />}
      </div>
    </div>
  );
}
