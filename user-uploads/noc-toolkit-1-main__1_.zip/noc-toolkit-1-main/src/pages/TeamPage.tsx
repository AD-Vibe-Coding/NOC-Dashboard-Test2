import { useState, useEffect, useCallback, useMemo } from 'react';
import { Search, Users, Mail, RefreshCw, ExternalLink, Wifi, WifiOff, Clock } from 'lucide-react';
import { getAllUsers } from '../lib/auth/db';
import { useAuth } from '../hooks/useAuth';
import { RoleBadge } from '../components/auth/RoleBadge';
import type { Role, User } from '../types/auth';
import { ROLE_LABELS } from '../types/auth';
import { supabase } from '../db';

const COLORS = ['bg-primary-500','bg-emerald-500','bg-amber-500','bg-indigo-500','bg-rose-500','bg-cyan-500','bg-violet-500','bg-orange-500'];
function avatarColor(name: string) { let h = 0; for (const c of name) h = (h * 31 + c.charCodeAt(0)) | 0; return COLORS[Math.abs(h) % COLORS.length]; }

const SHEET_URL = 'https://docs.google.com/spreadsheets/d/10uLWD3QoWVAIbGGF9jOZ5NHenEDxZRjVxk7nYzf6qss/edit';
const REFRESH_MS = 30_000; // poll every 30s

interface SessionRow {
  user_id: string;
  user_name: string;
  user_email: string;
  status: 'active' | 'inactive' | 'offline';
  last_seen_at: string;
  logged_in_at: string;
  logged_out_at: string | null;
  last_tool: string | null;
}

function timeAgo(iso: string): string {
  const diff = Math.floor((Date.now() - new Date(iso).getTime()) / 1000);
  if (diff < 60) return `${diff}s ago`;
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  return `${Math.floor(diff / 3600)}h ago`;
}

function StatusDot({ status }: { status: string }) {
  if (status === 'active') return (
    <span className="relative flex h-2.5 w-2.5">
      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
      <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500" />
    </span>
  );
  if (status === 'inactive') return <span className="h-2.5 w-2.5 rounded-full bg-amber-400 block" />;
  return <span className="h-2.5 w-2.5 rounded-full bg-slate-400 dark:bg-slate-600 block" />;
}

export default function TeamPage() {
  const { isSuperAdmin } = useAuth();
  const [search, setSearch]         = useState('');
  const [roleFilter, setRoleFilter] = useState<Role | 'all'>('all');
  const [sessions, setSessions]     = useState<SessionRow[]>([]);
  const [users, setUsers]           = useState<User[]>([]);
  const [loadingSessions, setLoadingSessions] = useState(false);

  // Load users from Supabase
  useEffect(() => { getAllUsers().then(setUsers); }, []);

  // Load live sessions from Supabase directly
  const loadSessions = useCallback(async () => {
    if (!isSuperAdmin) return;
    setLoadingSessions(true);
    try {
      const { data } = await supabase
        .from('user_sessions')
        .select('*')
        .order('last_seen_at', { ascending: false });
      setSessions((data ?? []) as SessionRow[]);
    } catch { /* non-critical */ }
    finally { setLoadingSessions(false); }
  }, [isSuperAdmin]);

  useEffect(() => {
    loadSessions();
    const id = setInterval(loadSessions, REFRESH_MS);
    return () => clearInterval(id);
  }, [loadSessions]);

  const sessionMap = useMemo(() => {
    const m = new Map<string, SessionRow>();
    for (const s of sessions) m.set(s.user_id, s);
    return m;
  }, [sessions]);

  // Count live users
  const liveCount   = sessions.filter(s => s.status === 'active').length;
  const onlineCount = sessions.filter(s => s.status !== 'offline').length;

  const filtered = useMemo(() => {
    let list = users;
    if (roleFilter !== 'all') list = list.filter((u) => u.role === roleFilter);
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter((u) => `${u.firstName} ${u.lastName} ${u.username} ${u.email}`.toLowerCase().includes(q));
    }
    return list.sort((a, b) => a.firstName.localeCompare(b.firstName));
  }, [users, search, roleFilter]);

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-primary-100 dark:bg-primary-500/10 flex items-center justify-center">
            <Users className="w-5 h-5 text-primary-600 dark:text-primary-400" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">Team</h1>
            <p className="text-sm text-slate-500 dark:text-slate-400">{users.length} members</p>
          </div>
        </div>
        {/* Super admin: live stats + sheet link */}
        {isSuperAdmin && (
          <div className="flex items-center gap-2 flex-wrap">
            {sessions.length > 0 && (
              <div className="flex items-center gap-3 px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-xs font-medium text-slate-600 dark:text-slate-300">
                <span className="flex items-center gap-1.5">
                  <span className="relative flex h-2 w-2"><span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" /><span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" /></span>
                  {liveCount} live
                </span>
                <span className="text-slate-400">·</span>
                <span>{onlineCount} online</span>
              </div>
            )}
            <button onClick={loadSessions} disabled={loadingSessions}
              className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 transition-colors"
              title="Refresh session data">
              <RefreshCw className={`w-4 h-4 ${loadingSessions ? 'animate-spin' : ''}`} />
            </button>
            <a href={SHEET_URL} target="_blank" rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-emerald-100 hover:bg-emerald-200 dark:bg-emerald-500/15 dark:hover:bg-emerald-500/25 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-500/30 transition-colors">
              <ExternalLink className="w-3.5 h-3.5" />
              Activity Sheet
            </a>
          </div>
        )}
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search by name, username, or email..." className="input-base pl-10" />
        </div>
        {isSuperAdmin && (
          <select value={roleFilter} onChange={(e) => setRoleFilter(e.target.value as Role | 'all')} className="input-base w-auto min-w-[160px]">
            <option value="all">All roles</option>
            <option value="super_admin">{ROLE_LABELS.super_admin}</option>
            <option value="admin">{ROLE_LABELS.admin}</option>
            <option value="user">{ROLE_LABELS.user}</option>
          </select>
        )}
      </div>

      {/* Team cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {filtered.map((u) => {
          const initials = `${u.firstName[0]}${u.lastName[0]}`.toUpperCase();
          const session  = sessionMap.get(u.id);
          const status   = session?.status ?? 'offline';
          const isActive = status === 'active';
          const isInactive = status === 'inactive';

          return (
            <div key={u.id} className={`card flex items-center gap-4 transition-all ${
              isActive ? 'border-l-4 border-l-emerald-500' : isInactive ? 'border-l-4 border-l-amber-400' : ''
            }`}>
              {/* Avatar with status dot */}
              <div className="relative flex-shrink-0">
                <div className={`w-11 h-11 rounded-full ${avatarColor(u.username)} flex items-center justify-center text-white text-sm font-bold`}>
                  {initials}
                </div>
                {isSuperAdmin && (
                  <span className="absolute -bottom-0.5 -right-0.5">
                    <StatusDot status={status} />
                  </span>
                )}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-sm font-semibold text-slate-900 dark:text-white">{u.firstName} {u.lastName}</span>
                  <RoleBadge role={u.role} />
                  {/* Live badge — super admin only */}
                  {isSuperAdmin && isActive && (
                    <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-300">
                      <Wifi className="w-2.5 h-2.5" /> LIVE
                    </span>
                  )}
                  {isSuperAdmin && isInactive && (
                    <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[10px] font-medium bg-amber-100 text-amber-700 dark:bg-amber-500/20 dark:text-amber-300">
                      <Clock className="w-2.5 h-2.5" /> Idle
                    </span>
                  )}
                  {isSuperAdmin && status === 'offline' && session && (
                    <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[10px] font-medium bg-slate-100 text-slate-500 dark:bg-slate-700 dark:text-slate-400">
                      <WifiOff className="w-2.5 h-2.5" /> Offline
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-1 mt-0.5">
                  <Mail className="w-3 h-3 text-slate-400 flex-shrink-0" />
                  <span className="text-xs text-slate-500 dark:text-slate-400 truncate">{u.email}</span>
                </div>
                {/* Session details — super admin only */}
                {isSuperAdmin && session && (
                  <div className="flex items-center gap-3 mt-1 flex-wrap">
                    {session.last_tool && (
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-primary-50 dark:bg-primary-500/10 text-primary-600 dark:text-primary-400 font-mono">
                        /{session.last_tool}
                      </span>
                    )}
                    <span className="text-[10px] text-slate-400 dark:text-slate-500 flex items-center gap-1">
                      <Clock className="w-2.5 h-2.5" />
                      {isActive || isInactive ? `Active ${timeAgo(session.last_seen_at)}` : `Last seen ${timeAgo(session.last_seen_at)}`}
                    </span>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
      {filtered.length === 0 && <p className="text-center text-sm text-slate-500 dark:text-slate-400 py-8">No team members found.</p>}
    </div>
  );
}
