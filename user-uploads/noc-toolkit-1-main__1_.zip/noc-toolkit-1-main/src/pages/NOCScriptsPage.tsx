import { useState } from 'react';
import { Copy, Check, ChevronDown, ChevronRight, FileText, Search } from 'lucide-react';
import toast from 'react-hot-toast';
import { copyRichAndPlain, copyPlainOnly } from '../lib/clipboard-rich';

// ─── Script data ────────────────────────────────────────────────
interface Script {
  id: number;
  title: string;
  /** HTML body — <strong> for bold, <ul>/<ol> for lists, <p> for paragraphs */
  html: string;
  /** Plain-text body for the "Plain" copy button */
  plain: string;
}

const SCRIPTS: Script[] = [
  {
    id: 1,
    title: 'Ticket Acknowledgement (Initial Response)',
    html: `<p>Hello Team,</p><p>I have picked up your ticket and am currently investigating the issue. I will provide an update shortly.</p><p>In the meantime, please verify the power source, reboot the equipment (if authorized), and check cabling. Kindly share the local contact name, phone number, and site access hours in case dispatch is required. <strong>Please note: If no issue is found with the ISP, the dispatch may be billable.</strong></p>`,
    plain: `Hello Team,

I have picked up your ticket and am currently investigating the issue. I will provide an update shortly.

In the meantime, please verify the power source, reboot the equipment (if authorized), and check cabling. Kindly share the local contact name, phone number, and site access hours in case dispatch is required. Please note: If no issue is found with the ISP, the dispatch may be billable.`,
  },
  {
    id: 2,
    title: 'Down Hard / Modem Unreachable (No Outage Confirmed)',
    html: `<p>Hello Team,</p><p>We are observing the circuit as down in our monitoring tool. The carrier has confirmed that there are no outages or maintenance activities in the area.</p><p>Please perform a <strong>Layer 1 check</strong> (power and cabling) and confirm the results. If the issue persists, kindly provide the local contact details (name, phone, and access hours) so we can coordinate a dispatch.</p><p><strong>Please note: If no issue is found with the ISP, the dispatch may be billable.</strong></p>`,
    plain: `Hello Team,

We are observing the circuit as down in our monitoring tool. The carrier has confirmed that there are no outages or maintenance activities in the area.

Please perform a Layer 1 check (power and cabling) and confirm the results. If the issue persists, kindly provide the local contact details (name, phone, and access hours) so we can coordinate a dispatch.

Please note: If no issue is found with the ISP, the dispatch may be billable.`,
  },
  {
    id: 3,
    title: 'Circuit Down – No Outage Confirmed by Carrier',
    html: `<p>Hello Team,</p><p>We are observing the circuit as down in our monitoring tool. The carrier has confirmed that there are no outages or maintenance activities in the area.</p><p>Please perform a <strong>Layer 1 check</strong> (power and cabling) and confirm the results. If the issue persists, kindly provide the local contact details (name, phone, and access hours) so we can coordinate a dispatch. <strong>Please note: If no issue is found with the ISP, the dispatch may be billable.</strong></p>`,
    plain: `Hello Team,

We are observing the circuit as down in our monitoring tool. The carrier has confirmed that there are no outages or maintenance activities in the area.

Please perform a Layer 1 check (power and cabling) and confirm the results. If the issue persists, kindly provide the local contact details (name, phone, and access hours) so we can coordinate a dispatch. Please note: If no issue is found with the ISP, the dispatch may be billable.`,
  },
  {
    id: 4,
    title: 'Circuit Down – No Outage (Layer 1 Steps)',
    html: `<p>Hello Team,</p><p>The carrier has confirmed that there are no active outages or planned maintenance for this site. Please complete the following <strong>Layer 1 troubleshooting steps</strong> on the circuit:</p><ul><li>Check the power and reboot the related network equipment (modem/router).</li><li>Reseat all cables and ensure they are in the correct ports.</li></ul><p>After performing these steps, please reply with the status. If the issue persists, we will engage the carrier for possible dispatch. In that case, please provide a local contact name, phone number, and access hours. <strong>Please note: If no issue is found with the ISP, the dispatch may be billable.</strong></p>`,
    plain: `Hello Team,

The carrier has confirmed that there are no active outages or planned maintenance for this site. Please complete the following Layer 1 troubleshooting steps on the circuit:

• Check the power and reboot the related network equipment (modem/router).
• Reseat all cables and ensure they are in the correct ports.

After performing these steps, please reply with the status. If the issue persists, we will engage the carrier for possible dispatch. In that case, please provide a local contact name, phone number, and access hours. Please note: If no issue is found with the ISP, the dispatch may be billable.`,
  },
  {
    id: 5,
    title: 'Circuit Up – No Issue Found (Confirm Layer 1 Check)',
    html: `<p>Hello Team,</p><p>The circuit is currently <strong>up and stable</strong> in our monitoring tool. The carrier has confirmed that there are no outages or maintenance activities at this time.</p><p>Please confirm by performing a Layer 1 check on-site to ensure power and cabling are in good condition.</p><p>We will continue monitoring and provide updates if any issues occur.</p>`,
    plain: `Hello Team,

The circuit is currently up and stable in our monitoring tool. The carrier has confirmed that there are no outages or maintenance activities at this time.

Please confirm by performing a Layer 1 check on-site to ensure power and cabling are in good condition.

We will continue monitoring and provide updates if any issues occur.`,
  },
  {
    id: 6,
    title: 'Outage Confirmed by Carrier (With ETR)',
    html: `<p>Hello Team,</p><p>The carrier has confirmed an <strong>outage</strong> affecting the circuit. A technician is working to resolve the issue.</p><ul><li><strong>Estimated Time of Resolution (ETR):</strong> [Insert Time]</li></ul><p>We will continue to follow up with the carrier and provide updates until the issue is resolved.</p>`,
    plain: `Hello Team,

The carrier has confirmed an outage affecting the circuit. A technician is working to resolve the issue.

• Estimated Time of Resolution (ETR): [Insert Time]

We will continue to follow up with the carrier and provide updates until the issue is resolved.`,
  },
  {
    id: 7,
    title: 'Circuit Up – Closing Ticket Notification',
    html: `<p>Hello Team,</p><p>The circuit is <strong>up and stable</strong> in our monitoring tool, and the carrier has confirmed the issue is cleared.</p><p>If you are still experiencing service issues, please reply to this message so we can re-engage the carrier. Otherwise, this ticket will be closed by end of business on <strong>[Date]</strong>.</p>`,
    plain: `Hello Team,

The circuit is up and stable in our monitoring tool, and the carrier has confirmed the issue is cleared.

If you are still experiencing service issues, please reply to this message so we can re-engage the carrier. Otherwise, this ticket will be closed by end of business on [Date].`,
  },
  {
    id: 8,
    title: 'Ongoing Outage – No ETR from Carrier Yet',
    html: `<p>Hello Team,</p><p>The carrier has confirmed there is an <strong>ongoing outage</strong> affecting this service. No estimated restoration time has been provided yet.</p><p>We will continue to follow up with the carrier and share updates as they become available.</p>`,
    plain: `Hello Team,

The carrier has confirmed there is an ongoing outage affecting this service. No estimated restoration time has been provided yet.

We will continue to follow up with the carrier and share updates as they become available.`,
  },
  {
    id: 9,
    title: 'Scheduled Maintenance Notification',
    html: `<p>Hello Team,</p><p>Please be advised, the <strong>vCom</strong> provided Circuit <strong>[Circuit ID]</strong> from the <strong>[Carrier]</strong> carrier will be performing scheduled maintenance that may impact your service at <strong>[Address]</strong>.</p><ul><li><strong>Start Time:</strong> [Date/Time]</li><li><strong>End Time:</strong> [Date/Time]</li><li><strong>Reason:</strong> [Reason]</li></ul><p>Brief interruptions may occur during this window. If issues persist after maintenance, please reboot your equipment. For further support, reply to this message or call <strong>800-804-8266 opt 3</strong>, referencing this ticket.</p>`,
    plain: `Hello Team,

Please be advised, the vCom provided Circuit [Circuit ID] from the [Carrier] carrier will be performing scheduled maintenance that may impact your service at [Address].

• Start Time: [Date/Time]
• End Time: [Date/Time]
• Reason: [Reason]

Brief interruptions may occur during this window. If issues persist after maintenance, please reboot your equipment. For further support, reply to this message or call 800-804-8266 opt 3, referencing this ticket.`,
  },
  {
    id: 10,
    title: 'Packet Loss / Latency Troubleshooting Info Request',
    html: `<p>Hello Team,</p><p>We have opened a ticket with the carrier for further testing. To proceed with investigation, please provide:</p><ol><li>Source and destination IP addresses affected</li><li>Ping, traceroute, or reverse traceroute results</li><li>Observed latency vs. expected latency</li><li>Whether the issue occurs over direct Internet or via VPN</li></ol><p>We will update you once we receive additional information from the carrier.</p>`,
    plain: `Hello Team,

We have opened a ticket with the carrier for further testing. To proceed with investigation, please provide:

1. Source and destination IP addresses affected
2. Ping, traceroute, or reverse traceroute results
3. Observed latency vs. expected latency
4. Whether the issue occurs over direct Internet or via VPN

We will update you once we receive additional information from the carrier.`,
  },
  {
    id: 11,
    title: 'Gateway Offline – No Outage Reported',
    html: `<p>Hello Team,</p><p>The carrier has confirmed no outages in the area, but they are observing the <strong>gateway as offline</strong>.</p><p>Please verify the power and cabling (Layer 1) on site. If the issue persists, kindly share local contact details (name, phone, and access hours) so we can arrange a dispatch if required. <strong>Please note: If no issue is found with the ISP, the dispatch may be billable.</strong></p>`,
    plain: `Hello Team,

The carrier has confirmed no outages in the area, but they are observing the gateway as offline.

Please verify the power and cabling (Layer 1) on site. If the issue persists, kindly share local contact details (name, phone, and access hours) so we can arrange a dispatch if required. Please note: If no issue is found with the ISP, the dispatch may be billable.`,
  },
  {
    id: 12,
    title: 'Ticket Closure Follow-up – Requesting Fix Details',
    html: `<p>Hello Team,</p><p>Thank you for confirming service restoration. For our records, could you kindly share the <strong>root cause</strong> of the issue and the <strong>steps taken to resolve it</strong>?</p><p>We appreciate your support.</p>`,
    plain: `Hello Team,

Thank you for confirming service restoration. For our records, could you kindly share the root cause of the issue and the steps taken to resolve it?

We appreciate your support.`,
  },
  {
    id: 13,
    title: 'Recurrent Outage – Emerging Carrier Issue (No ETR)',
    html: `<p>Hello Team,</p><p>We are observing that the circuit has gone <strong>down again</strong>. The carrier has confirmed an emerging outage affecting the area, which started at <strong>[Time]</strong>.</p><p>No ETR has been provided yet. We will continue following up with the carrier and keep you updated until the service is fully restored.</p>`,
    plain: `Hello Team,

We are observing that the circuit has gone down again. The carrier has confirmed an emerging outage affecting the area, which started at [Time].

No ETR has been provided yet. We will continue following up with the carrier and keep you updated until the service is fully restored.`,
  },
  {
    id: 14,
    title: 'Oututilization Note',
    html: `<p>Hello Team,</p><p>We have observed that this circuit reached <strong>[XX]%</strong> of its bandwidth utilization. The usage has since normalized in our monitoring platform.</p><p>If additional bandwidth is required, please let us know. We have also included your Network AM in this notification.</p><p>We will keep this ticket on monitoring and keep you posted if anything changes. Otherwise, we will close this ticket by EOB, <strong>[Date/Time]</strong>.</p>`,
    plain: `Hello Team,

We have observed that this circuit reached [XX]% of its bandwidth utilization. The usage has since normalized in our monitoring platform.

If additional bandwidth is required, please let us know. We have also included your Network AM in this notification.

We will keep this ticket on monitoring and keep you posted if anything changes. Otherwise, we will close this ticket by EOB, [Date/Time].`,
  },
  {
    id: 15,
    title: 'Interface Flap Notification (Switch Port Flapping)',
    html: `<p>Hello Team,</p><p>We have observed that network interface <strong>[Port]</strong> on <strong>[Device]</strong> is <strong>flapping</strong>.</p><p>This is commonly caused by faulty cabling or a duplex mismatch. Please check Layer 1 (cables and port configuration) to address the issue.</p><p>We will hold the ticket open until the circuit stabilizes.</p>`,
    plain: `Hello Team,

We have observed that network interface [Port] on [Device] is flapping.

This is commonly caused by faulty cabling or a duplex mismatch. Please check Layer 1 (cables and port configuration) to address the issue.

We will hold the ticket open until the circuit stabilizes.`,
  },
  {
    id: 16,
    title: 'Carrier TT Created – Requesting Layer 1 Checks',
    html: `<p>Hello Team,</p><p>We have created a trouble ticket with the carrier, which is currently in <strong>queue for initial testing</strong>. In the meantime, please complete the following checks:</p><ol><li>Verify power and reboot network equipment (modem/router).</li><li>Reseat all cables and confirm they are properly connected.</li></ol><p>After completing these steps, please reply with status and provide local contact details (name, phone, access hours) in case a dispatch is needed. <strong>Please note: If no issue is found with the ISP, the dispatch may be billable.</strong></p>`,
    plain: `Hello Team,

We have created a trouble ticket with the carrier, which is currently in queue for initial testing. In the meantime, please complete the following checks:

1. Verify power and reboot network equipment (modem/router).
2. Reseat all cables and confirm they are properly connected.

After completing these steps, please reply with status and provide local contact details (name, phone, access hours) in case a dispatch is needed. Please note: If no issue is found with the ISP, the dispatch may be billable.`,
  },
  {
    id: 17,
    title: 'Circuit Down – No Outage (Layer 1 Troubleshooting)',
    html: `<p>Hello Team,</p><p>The carrier has confirmed that there are no active outages or planned maintenance for this site. Please complete the following <strong>Layer 1 troubleshooting steps</strong>:</p><ul><li>Check the power and reboot the related network equipment (modem/router).</li><li>Reseat all cables and ensure they are in the correct ports.</li></ul><p>After performing these steps, please reply with the status. If the issue persists, we will engage the carrier for possible dispatch. In that case, please provide a local contact name, phone number, and access hours. <strong>Please note: If no issue is found with the ISP, the dispatch may be billable.</strong></p>`,
    plain: `Hello Team,

The carrier has confirmed that there are no active outages or planned maintenance for this site. Please complete the following Layer 1 troubleshooting steps:

• Check the power and reboot the related network equipment (modem/router).
• Reseat all cables and ensure they are in the correct ports.

After performing these steps, please reply with the status. If the issue persists, we will engage the carrier for possible dispatch. In that case, please provide a local contact name, phone number, and access hours. Please note: If no issue is found with the ISP, the dispatch may be billable.`,
  },
  {
    id: 18,
    title: 'IP Whitelisting Request',
    html: `<p>Hello Team,</p><p>Please whitelist the following IP ranges on your device:</p><ul><li><strong>Asia (Singapore):</strong> 18.139.118.192/26</li><li><strong>Australia (Sydney):</strong> 3.106.118.64/26</li><li><strong>EU (Dublin):</strong> 52.215.168.128/26</li><li><strong>US (Oregon):</strong> 34.223.95.64/26</li><li><strong>US (Washington DC):</strong> 52.202.255.64/26</li><li><strong>vCom:</strong> 104.42.63.159</li></ul>`,
    plain: `Hello Team,

Please whitelist the following IP ranges on your device:

• Asia (Singapore): 18.139.118.192/26
• Australia (Sydney): 3.106.118.64/26
• EU (Dublin): 52.215.168.128/26
• US (Oregon): 34.223.95.64/26
• US (Washington DC): 52.202.255.64/26
• vCom: 104.42.63.159`,
  },
  {
    id: 19,
    title: 'Generic Acknowledgement Template',
    html: `<p>Hello,</p><p>I have picked up your ticket and am currently investigating the issue. I will provide an update shortly.</p><p>Please let me know if there are any additional questions or important details we should be aware of while addressing this issue.</p>`,
    plain: `Hello,

I have picked up your ticket and am currently investigating the issue. I will provide an update shortly.

Please let me know if there are any additional questions or important details we should be aware of while addressing this issue.`,
  },
  {
    id: 20,
    title: 'Down Hard Acknowledgement Template',
    html: `<p>Hello Team,</p><p>I have been assigned your ticket and will begin working with the carrier to troubleshoot your service. I will provide updates as soon as possible.</p><p>In the meantime, please:</p><ul><li>Verify power on site, reboot equipment (if authorized), and check cabling.</li><li>Provide local contact details (name, phone number, and access hours) in case a dispatch is needed. <strong>Please note: If no issue is found with the ISP, the dispatch may be billable.</strong></li></ul>`,
    plain: `Hello Team,

I have been assigned your ticket and will begin working with the carrier to troubleshoot your service. I will provide updates as soon as possible.

In the meantime, please:

• Verify power on site, reboot equipment (if authorized), and check cabling.
• Provide local contact details (name, phone number, and access hours) in case a dispatch is needed. Please note: If no issue is found with the ISP, the dispatch may be billable.`,
  },
  {
    id: 21,
    title: 'ETR Reply to Customer',
    html: `<p>Hello Team,</p><p>We contacted the carrier regarding the circuit down issue. They informed us there is an unplanned outage in the area with an <strong>ETR of [Insert Time]</strong>.</p><p>We will follow up with the carrier post-ETR and keep you updated.</p>`,
    plain: `Hello Team,

We contacted the carrier regarding the circuit down issue. They informed us there is an unplanned outage in the area with an ETR of [Insert Time].

We will follow up with the carrier post-ETR and keep you updated.`,
  },
  {
    id: 22,
    title: 'Ping/Packet Loss Template (Customer Info Request)',
    html: `<p>Hello Team,</p><p>We have created a ticket with the carrier, which is currently in queue for initial testing.</p><p>In the meantime, please provide the following details for further isolation:</p><ol><li>Source and destination IP addresses affected</li><li>Ping, traceroute, and reverse traceroute results</li><li>Observed latency vs. expected latency</li><li>Whether services are running direct to Internet or through VPN</li></ol>`,
    plain: `Hello Team,

We have created a ticket with the carrier, which is currently in queue for initial testing.

In the meantime, please provide the following details for further isolation:

1. Source and destination IP addresses affected
2. Ping, traceroute, and reverse traceroute results
3. Observed latency vs. expected latency
4. Whether services are running direct to Internet or through VPN`,
  },
  {
    id: 23,
    title: 'No Outage & Request for LCON',
    html: `<p>Hello Team,</p><p>The carrier has confirmed there are <strong>no outages</strong> in the area.</p><p>Please verify the power source and cabling on the equipment. Additionally, kindly provide the <strong>local contact name, phone number, and site access hours</strong>. The ticket will remain on hold pending your response.</p>`,
    plain: `Hello Team,

The carrier has confirmed there are no outages in the area.

Please verify the power source and cabling on the equipment. Additionally, kindly provide the local contact name, phone number, and site access hours. The ticket will remain on hold pending your response.`,
  },
  {
    id: 24,
    title: 'No Outages but Gateway Offline & Request for LCON',
    html: `<p>Hello Team,</p><p>The carrier has confirmed there are no outages; however, they are observing the <strong>gateway as offline</strong>.</p><p>Please perform a power and cabling check (Layer 1). If the issue persists, provide local contact details (name, phone number, and site access hours) so we can arrange a dispatch if necessary.</p>`,
    plain: `Hello Team,

The carrier has confirmed there are no outages; however, they are observing the gateway as offline.

Please perform a power and cabling check (Layer 1). If the issue persists, provide local contact details (name, phone number, and site access hours) so we can arrange a dispatch if necessary.`,
  },
  {
    id: 25,
    title: 'Clear Alert & Ticket Closure Notification',
    html: `<p>Hello Team,</p><p>The circuit is <strong>up and stable</strong>, and the carrier has confirmed the outage is cleared.</p><p>If you are still experiencing issues, please reply to this message so we can re-engage the carrier. If no further issues are reported, this ticket will be closed by end of business <strong>[Date]</strong>.</p>`,
    plain: `Hello Team,

The circuit is up and stable, and the carrier has confirmed the outage is cleared.

If you are still experiencing issues, please reply to this message so we can re-engage the carrier. If no further issues are reported, this ticket will be closed by end of business [Date].`,
  },
  {
    id: 26,
    title: 'Planned Maintenance Hold Notification',
    html: `<p>Hello Team,</p><p>We engaged with the carrier regarding the reported issue, and they confirmed there is no outage. However, a <strong>planned maintenance</strong> is scheduled on <strong>[Date &amp; Time]</strong>.</p><p>You may experience interruptions during this window. We will hold this ticket until the maintenance is completed.</p><p>If issues persist after the window, please reboot your equipment and let us know. For further assistance, you may also call our support team at <strong>800-804-8266 opt 3</strong> and reference this ticket.</p>`,
    plain: `Hello Team,

We engaged with the carrier regarding the reported issue, and they confirmed there is no outage. However, a planned maintenance is scheduled on [Date & Time].

You may experience interruptions during this window. We will hold this ticket until the maintenance is completed.

If issues persist after the window, please reboot your equipment and let us know. For further assistance, you may also call our support team at 800-804-8266 opt 3 and reference this ticket.`,
  },
  {
    id: 27,
    title: 'Repeated Outages / Circuit Flapping + Active Outage with ETR',
    html: `<p>Hello Team,</p><p>We are observing <strong>repeated outages</strong> on this circuit. The carrier has confirmed there is an active outage impacting this link.</p><p>An ETR has been provided for <strong>[Time]</strong>, and we are following up for additional RCA details.</p><p>We will continue to monitor and provide updates until the service is confirmed stable.</p>`,
    plain: `Hello Team,

We are observing repeated outages on this circuit. The carrier has confirmed there is an active outage impacting this link.

An ETR has been provided for [Time], and we are following up for additional RCA details.

We will continue to monitor and provide updates until the service is confirmed stable.`,
  },
  {
    id: 28,
    title: 'Carrier Outage Cleared – Service Still Down (Layer 1 Checks)',
    html: `<p>Hello Team,</p><p>The carrier has confirmed that the outage impacting your service has been <strong>resolved</strong>. However, our monitoring tool still shows the circuit as down, and the on-site router/equipment is not reachable. Please perform the following <strong>Layer 1 checks</strong> on-site:</p><ol><li>Verify the power source and ensure the equipment is powered on.</li><li>Reboot the modem/router (if authorized).</li><li>Reseat all cables and confirm they are connected to the correct ports.</li><li>Check for any link lights or physical port indicators.</li></ol><p>Once completed, please reply with the results. If the issue persists, kindly provide local contact details (name, phone number, and access hours) so we can engage the carrier for a dispatch if required.</p>`,
    plain: `Hello Team,

The carrier has confirmed that the outage impacting your service has been resolved. However, our monitoring tool still shows the circuit as down, and the on-site router/equipment is not reachable. Please perform the following Layer 1 checks on-site:

1. Verify the power source and ensure the equipment is powered on.
2. Reboot the modem/router (if authorized).
3. Reseat all cables and confirm they are connected to the correct ports.
4. Check for any link lights or physical port indicators.

Once completed, please reply with the results. If the issue persists, kindly provide local contact details (name, phone number, and access hours) so we can engage the carrier for a dispatch if required.`,
  },
];

// ─── Component ──────────────────────────────────────────────────

function ScriptCard({ script }: { script: Script }) {
  const [expanded, setExpanded] = useState(false);
  const [copied, setCopied] = useState<'rich' | 'plain' | null>(null);

  const flash = (kind: 'rich' | 'plain') => {
    setCopied(kind);
    setTimeout(() => setCopied((k) => (k === kind ? null : k)), 1800);
  };

  const handleCopyRich = async (e: React.MouseEvent) => {
    e.stopPropagation();
    const ok = await copyRichAndPlain(script.html, script.plain);
    if (ok) {
      flash('rich');
      toast.success(`Script #${script.id} copied`, { duration: 1500 });
    } else {
      toast.error('Copy failed');
    }
  };

  const handleCopyPlain = async (e: React.MouseEvent) => {
    e.stopPropagation();
    const ok = await copyPlainOnly(script.plain);
    if (ok) {
      flash('plain');
      toast.success(`Script #${script.id} copied (plain)`, { duration: 1500 });
    } else {
      toast.error('Copy failed');
    }
  };

  return (
    <div className="card !p-0 overflow-hidden">
      {/* Header row — always visible */}
      <button
        onClick={() => setExpanded((v) => !v)}
        className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors"
      >
        <span className="w-7 h-7 rounded-md bg-primary-100 dark:bg-primary-500/10 flex items-center justify-center text-xs font-bold text-primary-600 dark:text-primary-400 flex-shrink-0">
          {script.id}
        </span>
        <span className="flex-1 text-sm font-medium text-slate-800 dark:text-slate-200 truncate">
          {script.title}
        </span>

        {/* Copy buttons */}
        <div className="flex items-center gap-1 flex-shrink-0">
          <button
            onClick={handleCopyRich}
            className="flex items-center gap-1 px-2 py-1 rounded-md text-[11px] font-medium text-slate-500 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
            title="Copy with bold + bullets"
          >
            {copied === 'rich' ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
            Copy
          </button>
          <button
            onClick={handleCopyPlain}
            className="flex items-center gap-1 px-2 py-1 rounded-md text-[11px] font-medium text-slate-500 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
            title="Copy as plain text"
          >
            {copied === 'plain' ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <FileText className="w-3.5 h-3.5" />}
            Plain
          </button>
        </div>

        {expanded ? (
          <ChevronDown className="w-4 h-4 text-slate-400 flex-shrink-0" />
        ) : (
          <ChevronRight className="w-4 h-4 text-slate-400 flex-shrink-0" />
        )}
      </button>

      {/* Expandable body */}
      {expanded && (
        <div className="border-t border-slate-200 dark:border-slate-700 px-5 py-4 bg-slate-50 dark:bg-slate-800/30 text-sm leading-relaxed text-slate-800 dark:text-slate-200 animate-fade-in"
             dangerouslySetInnerHTML={{ __html: script.html }}
        />
      )}
    </div>
  );
}

export default function NOCScriptsPage() {
  const [search, setSearch] = useState('');

  const filtered = search.trim()
    ? SCRIPTS.filter(
        (s) =>
          s.title.toLowerCase().includes(search.toLowerCase()) ||
          s.plain.toLowerCase().includes(search.toLowerCase()),
      )
    : SCRIPTS;

  return (
    <div className="max-w-4xl mx-auto space-y-5">
      {/* Header */}
      <div className="flex items-center gap-3 mb-2">
        <div className="w-10 h-10 bg-orange-100 dark:bg-orange-500/10 rounded-lg flex items-center justify-center">
          <FileText className="w-5 h-5 text-orange-600 dark:text-orange-400" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">NOC Scripts</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            {SCRIPTS.length} ready-to-use scripts · Click Copy for rich text (Outlook/Slack) or Plain for text-only
          </p>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
        <input
          type="text"
          className="input-base !pl-10 text-sm"
          placeholder="Search scripts by title or content…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {/* Script list */}
      <div className="space-y-2">
        {filtered.map((s) => (
          <ScriptCard key={s.id} script={s} />
        ))}
        {filtered.length === 0 && (
          <p className="text-center text-sm text-slate-500 dark:text-slate-400 py-8">
            No scripts match your search.
          </p>
        )}
      </div>
    </div>
  );
}
