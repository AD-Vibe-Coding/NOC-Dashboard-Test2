import { BookOpen, Shield, Lock, Wrench, Globe, Phone, Bot, HelpCircle, Code } from 'lucide-react';

const sections = [
  {
    id: 'overview',
    icon: BookOpen,
    title: 'What is this tool?',
    content: `The NOC Operations Toolkit is a comprehensive web application designed for Network Operations Center and Security Operations Center engineers. It provides a suite of tools that streamline daily operations — parsing carrier maintenance emails, calculating subnets, looking up carrier NOC contacts and escalation tiers, and getting AI assistance for live incidents.

This toolkit was built around the real-world needs of NOC and SOC engineers who spend their days managing network incidents and communicating with carriers.`,
  },
  {
    id: 'how-it-works',
    icon: Code,
    title: 'How it works',
    content: `This application runs 100% in your web browser. When you open it, the entire application is loaded into your browser, and all processing happens locally on your device.

• Maintenance emails are parsed using JavaScript regex patterns — no data is sent to any server
• Subnet calculations are performed using pure mathematical operations in your browser
• The carrier contact directory is bundled with the app — no DB lookups
• AI features (when configured) call OpenAI directly from your browser; no intermediate server
• Theme preferences and AI API keys are stored in localStorage only`,
  },
  {
    id: 'security',
    icon: Lock,
    title: 'Security & Privacy',
    content: `This tool is designed with security and privacy as top priorities:

• No Backend Server — there is nothing collecting, storing, or processing your data
• No Database — all data exists in browser memory only
• No Analytics — no tracking, no telemetry, no third-party cookies
• No Data Transmission — your pasted emails, IPs, and notes never leave your browser
• Local Processing — all parsing, calculations, and formatting happen client-side
• AI Chat Privacy — if used, your messages go directly to OpenAI from your browser

For IT/Security Teams: This application can be deployed on an internal server or run from a CDN. It requires no backend infrastructure, no database connections, and no server-side processing.`,
  },
  {
    id: 'tools',
    icon: Wrench,
    title: 'Tool Descriptions',
    content: '',
  },
];

const toolDocs = [
  {
    icon: Wrench,
    title: 'Maintenance Note Generator',
    description: 'Paste a raw carrier maintenance email and get a formatted vCom customer notification. The parser detects carrier names, circuit IDs, addresses, maintenance windows, durations, reasons, and timezones with DST-aware conversion. Supports 15+ carrier formats including AT&T (IP & VPN), Spectrum Business, Windstream, Nitel, Uniti Fiber, Expereo, Lumen, Frontier, Comcast, and more.',
  },
  {
    icon: Globe,
    title: 'IP / Subnet Calculator',
    description: 'Enter CIDR notation (/29) or IP+mask and get full subnet info: network address, mask, wildcard, gateway, usable range, broadcast, total/usable IP counts. Includes a visual IP map and a quick CIDR reference table.',
  },
  {
    icon: Phone,
    title: 'Carrier Contacts',
    description: 'Searchable directory of 200+ US carriers with NOC phone numbers (click-to-call), support emails (mailto), customer portals, dial codes/options, and tiered escalation contacts (Buyers\' Club & Brokerage). Each major carrier links to its official outage map (Xfinity Status, Spectrum Outage, AT&T Outages, etc.). Smaller carriers fall back to DownDetector. Includes optional AI-powered natural-language search ("who do I call for AT&T MPLS?").',
  },
  {
    icon: Bot,
    title: 'AI Assistant',
    description: 'Chat interface that connects to OpenAI for help with networking troubleshooting, escalation procedures, BGP/DNS/DHCP questions, and customer communications. Requires your own OpenAI API key (stored in localStorage only).',
  },
];

const howToUse = [
  {
    title: 'Maintenance Note Generator',
    steps: [
      'Paste the raw carrier email into the text area',
      'Click "Generate Note" — the parser auto-detects carrier, type, address, circuit ID, times',
      'Review the parsed fields and confidence indicators',
      'Click "Copy to Clipboard" — formatting is preserved when pasting into Outlook/Gmail',
    ],
  },
  {
    title: 'IP / Subnet Calculator',
    steps: [
      'Choose between CIDR notation or IP + Subnet Mask mode',
      'Enter your CIDR prefix (e.g., /29) or full IP/CIDR (e.g., 192.168.1.0/29)',
      'Click "Calculate" to compute the subnet information',
      'Review the results table, visual IP map, and plain English explanation',
    ],
  },
  {
    title: 'Carrier Contacts',
    steps: [
      'Use the search bar to find a carrier by name, phone, email, or service type',
      'Filter by Business / Residential / Both, or by specific service (DIA, MPLS, Cable, etc.)',
      'Click any phone to call, any email to compose, or any portal link to open',
      'Expand "Escalation Tiers" inside a card for tiered contact drill-down (Front-line → VP)',
      'Click the Outage Map button to jump to the carrier\'s official status page',
      'Optionally enable AI mode to ask natural-language questions over the directory',
    ],
  },
  {
    title: 'AI Assistant',
    steps: [
      'Click "Settings" to configure your OpenAI API key (stored locally only)',
      'Select your preferred model (GPT-4o Mini recommended for cost/speed)',
      'Type your question and press Enter',
      'The same key powers AI search inside Carrier Contacts',
    ],
  },
];

export default function DocumentationPage() {
  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div>
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 bg-primary-100 dark:bg-primary-500/10 rounded-lg flex items-center justify-center">
            <BookOpen className="w-5 h-5 text-primary-600 dark:text-primary-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Documentation</h1>
            <p className="text-sm text-slate-500 dark:text-slate-400">Complete guide to the NOC Operations Toolkit</p>
          </div>
        </div>
      </div>

      {sections.map((section) => (
        <div key={section.id} className="card" id={section.id}>
          <div className="flex items-center gap-3 mb-4">
            <section.icon className="w-5 h-5 text-primary-500" />
            <h2 className="text-lg font-semibold text-slate-900 dark:text-white">{section.title}</h2>
          </div>
          {section.content && (
            <div className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed whitespace-pre-line">
              {section.content}
            </div>
          )}
          {section.id === 'tools' && (
            <div className="space-y-4 mt-2">
              {toolDocs.map((tool) => (
                <div key={tool.title} className="flex gap-3 p-3 bg-slate-50 dark:bg-slate-800/50 rounded-lg">
                  <tool.icon className="w-5 h-5 text-primary-500 mt-0.5 flex-shrink-0" />
                  <div>
                    <h3 className="text-sm font-semibold text-slate-800 dark:text-slate-200 mb-1">{tool.title}</h3>
                    <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">{tool.description}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      ))}

      <div className="card">
        <div className="flex items-center gap-3 mb-4">
          <HelpCircle className="w-5 h-5 text-primary-500" />
          <h2 className="text-lg font-semibold text-slate-900 dark:text-white">How to Use — Step by Step</h2>
        </div>
        <div className="space-y-6">
          {howToUse.map((tool) => (
            <div key={tool.title}>
              <h3 className="text-sm font-semibold text-slate-800 dark:text-slate-200 mb-2">{tool.title}</h3>
              <ol className="list-decimal list-inside space-y-1">
                {tool.steps.map((step, idx) => (
                  <li key={idx} className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed pl-1">
                    {step}
                  </li>
                ))}
              </ol>
            </div>
          ))}
        </div>
      </div>

      <div className="card">
        <div className="flex items-center gap-3 mb-4">
          <Shield className="w-5 h-5 text-primary-500" />
          <h2 className="text-lg font-semibold text-slate-900 dark:text-white">For IT / Security Teams</h2>
        </div>
        <div className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed space-y-3">
          <p>
            This application is a <strong className="text-slate-800 dark:text-slate-200">static single-page application (SPA)</strong> that runs entirely in the user's browser. Key technical details:
          </p>
          <ul className="list-disc pl-5 space-y-1.5">
            <li>No server-side code — entire app is static HTML, CSS, and JavaScript</li>
            <li>No database connections — no persistent storage beyond browser localStorage</li>
            <li>No external API calls except OpenAI when explicitly configured</li>
            <li>No cookies, tracking pixels, or analytics</li>
            <li>Sensitive information (pasted emails, IPs, notes) never leaves the browser</li>
            <li>Can be hosted on internal servers or private CDNs</li>
            <li>CSP-compatible — no inline scripts, no eval()</li>
            <li>All dependencies are well-known open-source libraries</li>
          </ul>
        </div>
      </div>

      <div className="card">
        <div className="flex items-center gap-3 mb-4">
          <Code className="w-5 h-5 text-primary-500" />
          <h2 className="text-lg font-semibold text-slate-900 dark:text-white">Tech Stack</h2>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { name: 'React 18', desc: 'UI Framework' },
            { name: 'TypeScript', desc: 'Type Safety' },
            { name: 'Tailwind CSS', desc: 'Styling' },
            { name: 'Vite', desc: 'Build Tool' },
            { name: 'React Router v6', desc: 'Routing' },
            { name: 'Lucide React', desc: 'Icons' },
            { name: 'react-hot-toast', desc: 'Notifications' },
            { name: 'OpenAI API', desc: 'AI Chat (optional)' },
          ].map((tech) => (
            <div key={tech.name} className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-lg text-center">
              <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">{tech.name}</p>
              <p className="text-xs text-slate-500 dark:text-slate-400">{tech.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
