import { useState } from 'react';
import { Globe, Info } from 'lucide-react';
import { SubnetCalculator } from '../components/subnet/SubnetCalculator';
import { IPVisualMap } from '../components/subnet/IPVisualMap';
import { CIDRReferenceTable } from '../components/subnet/CIDRReferenceTable';
import { getPlainEnglishExplanation } from '../utils/subnetCalculator';
import type { SubnetResult } from '../types';

export default function SubnetPage() {
  const [result, setResult] = useState<SubnetResult | null>(null);

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div>
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 bg-primary-100 dark:bg-primary-500/10 rounded-lg flex items-center justify-center">
            <Globe className="w-5 h-5 text-primary-600 dark:text-primary-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">IP / Subnet Calculator</h1>
            <p className="text-sm text-slate-500 dark:text-slate-400">Comprehensive networking calculator for IP addressing and CIDR notation</p>
          </div>
        </div>
      </div>

      {/* Section A: Calculator */}
      <SubnetCalculator onResult={setResult} />

      {/* Plain English Explainer */}
      {result && (
        <div className="flex items-start gap-3 p-4 bg-primary-50 dark:bg-primary-500/5 rounded-xl border border-primary-200 dark:border-primary-500/20 animate-fade-in">
          <Info className="w-5 h-5 text-primary-500 mt-0.5 flex-shrink-0" />
          <p className="text-sm text-primary-800 dark:text-primary-300 leading-relaxed">
            {getPlainEnglishExplanation(result)}
          </p>
        </div>
      )}

      {/* Section B: Visual IP Map */}
      {result && <IPVisualMap result={result} />}

      {/* Section C: Reference Table */}
      <CIDRReferenceTable />
    </div>
  );
}
