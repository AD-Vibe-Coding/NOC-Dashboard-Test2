import { useState } from 'react';
import {
  Zap,
  Search,
  ChevronDown,
  ChevronRight,
  AlertTriangle,
  AlertCircle,
  Info,
  Phone,
  Users,
} from 'lucide-react';

// ────────────────────────────────────────────────────────────────
// Types
// ────────────────────────────────────────────────────────────────

type Severity = 'critical' | 'warning' | 'info';
type MonitoringTier = 'MNS-Standard' | 'MNS-Circuit Performance' | 'MNS-Hardware MGMT';

interface FaultType {
  id: string;
  name: string;
  value: string;
  severity: Severity;
  tiers: MonitoringTier[];
  description: string;
  nocActions: string[];
  specialNotes?: string[];
}

// ────────────────────────────────────────────────────────────────
// Data — all 14 iPath fault types from LogicMonitor
// ────────────────────────────────────────────────────────────────

const FAULT_TYPES: FaultType[] = [
  {
    id: 'unreachable',
    name: 'Unreachable from 2+ global site monitors',
    value: 'Unreachable',
    severity: 'critical',
    tiers: ['MNS-Standard'],
    description:
      'This is an MNS-Standard alert triggered when the monitored device is unreachable from the testing locations (Asia, Australia, EU, US – Oregon and Washington DC).',
    nocActions: [
      'Follow up with the carrier to report the circuit down.',
      'Simultaneously ask the customer to verify Layer 1 (power and cabling).',
    ],
  },
  {
    id: 'pingloss',
    name: 'PingLossPercent',
    value: '= 100.0',
    severity: 'critical',
    tiers: ['MNS-Circuit Performance', 'MNS-Hardware MGMT'],
    description:
      'Triggered when the monitored device is unreachable after 3 failed ping checks in a 3-minute duration.',
    nocActions: [
      'Follow up with the carrier to report the circuit down.',
      'Simultaneously ask the customer to verify Layer 1 (power and cabling).',
    ],
  },
  {
    id: 'idleinterval',
    name: 'idleInterval',
    value: '= 622.0',
    severity: 'critical',
    tiers: ['MNS-Circuit Performance', 'MNS-Hardware MGMT'],
    description:
      'This is the interval in seconds LogicMonitor does not get data from the host. The interval ranges about 600 seconds / 10 minutes.',
    nocActions: [
      'Follow up with the carrier to report the circuit down.',
      'Simultaneously ask the customer to verify Layer 1 (power and cabling).',
    ],
    specialNotes: [
      'Most of the time, you will see both PingLoss and idleInterval alerts together.',
      'When there is an idleInterval alert, all other SNMP alerts are suppressed — for example "Uptime = No Data" — because the root issue is the circuit.',
    ],
  },
  {
    id: 'outmbps-inmbps',
    name: 'OutMbps / InMbps',
    value: '= 0.0',
    severity: 'critical',
    tiers: ['MNS-Circuit Performance'],
    description:
      'This fault type currently alerts for Dentons US LLP circuits and implies the circuit is down.',
    nocActions: [
      'Ignore the positive ping tests in LogicMonitor — pings are to internal private IPs that can be accessed through the unaffected backup circuit.',
      'Follow up with the carrier to resolve the downtime.',
    ],
    specialNotes: [
      '⚠️ DENTONS US LLP SPECIFIC: Ignore positive ping tests in LM as the pings are to internal private IPs accessible through the unaffected backup circuit.',
      'Work is still in progress to either set up a Dentons Collector or monitor the public WAN IPs which will allow monitoring with the default MNS-Circuit Performance standard.',
    ],
  },
  {
    id: 'peerstate',
    name: 'PeerState',
    value: '= 2.0',
    severity: 'warning',
    tiers: ['MNS-Hardware MGMT'],
    description:
      'This is an MNS-Hardware MGMT alert triggered by an issue with BGP.',
    nocActions: [
      'In LogicMonitor, ensure you are on the correct device by checking the serial number and looking for the Critical alert.',
      'Check other services are up including the circuit.',
      'Log into the CE device or request the client to verify no changes have been made to BGP including shutting it down.',
      'If the circuit is continuously flapping, this will affect the BGP — follow up with the carrier to resolve the flapping.',
      'If the client has shut the BGP due to issues on the circuit, the carrier can still troubleshoot the circuit with the BGP shut.',
    ],
  },
  {
    id: 'status-vpn',
    name: 'Status',
    value: '= 1.0',
    severity: 'warning',
    tiers: ['MNS-Hardware MGMT'],
    description:
      'This is an MNS-Hardware MGMT alert triggered by an issue with the VPN.',
    nocActions: [
      'Check other services are up including the circuit.',
      'Log into the CE device or request the client to verify if the issue is with the peering end.',
      'If the circuit is continuously flapping, this will affect the VPN — follow up with the carrier to resolve the flapping.',
      'If there are no issues with the circuit, request the client to verify if there are any issues with the peering end (e.g., ZScaler).',
    ],
  },
  {
    id: 'uptime',
    name: 'Uptime',
    value: '= No Data',
    severity: 'warning',
    tiers: ['MNS-Hardware MGMT'],
    description:
      'This is an MNS-Hardware MGMT alert triggered by an issue with SNMP monitoring. This can be caused by the client replacing the CE device or by high CPU/Memory usage on the CE.',
    nocActions: [
      'Verify both CE and LM configurations match: Username, Authentication Type, Privacy Type, Authentication Key, and Privacy Password.',
      'Ensure the Hardware-MGMT Collector IPs are permitted on any inbound access-list on the client CE.',
      'If the service is SD-WAN or a vCom Managed device, the NOC will need to verify the configurations.',
      'Ensure the LM Collector IPs are configured as Static Routes on the VMWare Edge device.',
    ],
    specialNotes: [
      'For Susser Bank FortiGate alerts: reach out to Karthik, Otukho, Anirudh, or Perry.',
    ],
  },
  {
    id: 'inutilization',
    name: 'InUtilizationPercent',
    value: '= 100.453 (example)',
    severity: 'warning',
    tiers: ['MNS-Circuit Performance'],
    description:
      'Triggered when the circuit is showing signs of overutilization. Since the alert is generated from the CE device, InUtilization signifies Inbound / Download traffic.',
    nocActions: [
      'Update the client that it is Download traffic that is overutilizing.',
      'Include the QSCare representative or Network AM in the email communication based on the channel.',
    ],
  },
  {
    id: 'oututilization',
    name: 'OutUtilizationPercent',
    value: '= 95.342 (example)',
    severity: 'warning',
    tiers: ['MNS-Circuit Performance'],
    description:
      'Triggered when the circuit is showing signs of overutilization. Since the alert is generated from the CE device, OutUtilization signifies Outbound / Upload traffic.',
    nocActions: [
      'Update the client that it is Upload traffic that is overutilizing.',
      'Include the QSCare representative or Network AM in the email communication based on the channel.',
    ],
  },
  {
    id: 'outerrors',
    name: 'OutErrors',
    value: '= 1.425 (example)',
    severity: 'warning',
    tiers: ['MNS-Hardware MGMT', 'MNS-Circuit Performance'],
    description:
      'Number of outbound packets with errors. The errors can be viewed in LogicMonitor under Interfaces (64bit) → Raw Data Tab.',
    nocActions: [
      'Check the managed device interface for errors including Duplex settings for incremental errors.',
      'In case of duplex errors, update the settings according to our Inventory or request the carrier to change their end so the settings match.',
      'You can clear errors by clearing interface counters or shut/unshut the interface during a maintenance window.',
    ],
  },
  {
    id: 'inerrors',
    name: 'InErrors',
    value: '= 1.0667 (example)',
    severity: 'warning',
    tiers: ['MNS-Hardware MGMT', 'MNS-Circuit Performance'],
    description:
      'Number of inbound packets with errors. The errors can be viewed in LogicMonitor under Interfaces (64bit) → Raw Data Tab.',
    nocActions: [
      'Check the managed device interface for errors including Duplex settings for incremental errors.',
      'In case of duplex errors, update the settings according to our Inventory or request the carrier to change their end so the settings match.',
      'You can clear errors by clearing interface counters or shut/unshut the interface during a maintenance window.',
    ],
  },
  {
    id: 'statusflap',
    name: 'StatusFlap',
    value: '= 1.0',
    severity: 'warning',
    tiers: ['MNS-Hardware MGMT', 'MNS-Circuit Performance'],
    description:
      'Measures if the interface is up but is flapping over repeated poll intervals. The ticket will reference the instance.',
    nocActions: [
      'Request the client to check the issue in this sequence: reseat the cables → replace the cables → reboot the device or change the connecting port to stop the flapping.',
      'In LogicMonitor, verify the instance is associated with which interface and share the interface detail (not the instance) to the client.',
    ],
  },
  {
    id: 'cpuusage',
    name: 'CpuUsage',
    value: '> threshold',
    severity: 'info',
    tiers: ['MNS-Hardware MGMT'],
    description:
      'Shows the current CPU utilization on the specified thread instance.',
    nocActions: [
      'Share the high usage details with the client.',
      'Monitor for consistent high CPU usage which can impact services.',
    ],
  },
  {
    id: 'diskutilization',
    name: 'diskUtilization',
    value: '> threshold',
    severity: 'info',
    tiers: ['MNS-Hardware MGMT'],
    description:
      'Shows the current Hard Disk usage has passed the configured threshold.',
    nocActions: [
      'Share the usage details with the client.',
      'Monitor the disk utilization trend.',
    ],
  },
  {
    id: 'memoryutilization',
    name: 'memoryUtilization',
    value: '> threshold',
    severity: 'info',
    tiers: ['MNS-Hardware MGMT'],
    description:
      'Caused by high memory usage. High memory usage can cause the device to reboot.',
    nocActions: [
      'Share the usage details with the client.',
      'Reach out to the Hardware Vendor to assist troubleshoot the cause of high memory usage.',
    ],
  },
];

// ────────────────────────────────────────────────────────────────
// Helpers
// ────────────────────────────────────────────────────────────────

const SEVERITY_META: Record<Severity, { label: string; color: string; bg: string; Icon: typeof AlertCircle }> = {
  critical: { label: 'Critical', color: 'text-red-600 dark:text-red-400', bg: 'bg-red-100 dark:bg-red-500/15', Icon: AlertCircle },
  warning: { label: 'Warning', color: 'text-amber-600 dark:text-amber-400', bg: 'bg-amber-100 dark:bg-amber-500/15', Icon: AlertTriangle },
  info: { label: 'Info', color: 'text-blue-600 dark:text-blue-400', bg: 'bg-blue-100 dark:bg-blue-500/15', Icon: Info },
};

const TIER_COLORS: Record<MonitoringTier, string> = {
  'MNS-Standard': 'bg-purple-100 dark:bg-purple-500/15 text-purple-700 dark:text-purple-300',
  'MNS-Circuit Performance': 'bg-sky-100 dark:bg-sky-500/15 text-sky-700 dark:text-sky-300',
  'MNS-Hardware MGMT': 'bg-rose-100 dark:bg-rose-500/15 text-rose-700 dark:text-rose-300',
};

// ────────────────────────────────────────────────────────────────
// Component
// ────────────────────────────────────────────────────────────────

export default function FaultTypesPage() {
  const [search, setSearch] = useState('');
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const [filterSeverity, setFilterSeverity] = useState<Severity | 'all'>('all');
  const [filterTier, setFilterTier] = useState<MonitoringTier | 'all'>('all');

  const toggleExpand = (id: string) => {
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const expandAll = () => setExpanded(new Set(FAULT_TYPES.map((f) => f.id)));
  const collapseAll = () => setExpanded(new Set());

  const filtered = FAULT_TYPES.filter((f) => {
    if (filterSeverity !== 'all' && f.severity !== filterSeverity) return false;
    if (filterTier !== 'all' && !f.tiers.includes(filterTier)) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      return (
        f.name.toLowerCase().includes(q) ||
        f.description.toLowerCase().includes(q) ||
        f.nocActions.some((a) => a.toLowerCase().includes(q)) ||
        (f.specialNotes ?? []).some((n) => n.toLowerCase().includes(q))
      );
    }
    return true;
  });

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div>
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 bg-red-100 dark:bg-red-500/10 rounded-lg flex items-center justify-center">
            <Zap className="w-5 h-5 text-red-600 dark:text-red-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
              iPath Fault Types
            </h1>
            <p className="text-sm text-slate-500 dark:text-slate-400">
              LogicMonitor alert types, monitoring tiers, and NOC action steps
            </p>
          </div>
        </div>
      </div>

      {/* Monitoring Tiers Legend */}
      <div className="card">
        <h3 className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-3">Monitoring Solutions</h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="p-3 rounded-lg bg-purple-50 dark:bg-purple-500/5 border border-purple-200 dark:border-purple-500/20">
            <span className="text-xs font-bold text-purple-700 dark:text-purple-300">MNS-Standard</span>
            <p className="text-[11px] text-purple-600 dark:text-purple-400 mt-1">
              Global site reachability from 5 locations (Asia, Australia, EU, US-Oregon, US-DC)
            </p>
          </div>
          <div className="p-3 rounded-lg bg-sky-50 dark:bg-sky-500/5 border border-sky-200 dark:border-sky-500/20">
            <span className="text-xs font-bold text-sky-700 dark:text-sky-300">MNS-Circuit Performance</span>
            <p className="text-[11px] text-sky-600 dark:text-sky-400 mt-1">
              Ping, latency, bandwidth utilization, errors, interface flaps, throughput
            </p>
          </div>
          <div className="p-3 rounded-lg bg-rose-50 dark:bg-rose-500/5 border border-rose-200 dark:border-rose-500/20">
            <span className="text-xs font-bold text-rose-700 dark:text-rose-300">MNS-Hardware MGMT</span>
            <p className="text-[11px] text-rose-600 dark:text-rose-400 mt-1">
              SNMP, BGP, VPN, CPU, memory, disk, uptime, interface errors
            </p>
          </div>
        </div>
      </div>

      {/* Search & Filters */}
      <div className="space-y-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search fault types, descriptions, actions..."
            className="input-base !pl-10 text-sm"
          />
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {/* Severity Filter */}
          <span className="text-xs text-slate-500">Severity:</span>
          {(['all', 'critical', 'warning', 'info'] as const).map((s) => (
            <button
              key={s}
              onClick={() => setFilterSeverity(s)}
              className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors ${
                filterSeverity === s
                  ? 'bg-slate-700 dark:bg-slate-200 text-white dark:text-slate-900'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              {s === 'all' ? 'All' : s.charAt(0).toUpperCase() + s.slice(1)}
            </button>
          ))}
          <span className="text-slate-300 dark:text-slate-600">|</span>
          {/* Tier Filter */}
          <span className="text-xs text-slate-500">Tier:</span>
          <button
            onClick={() => setFilterTier('all')}
            className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors ${
              filterTier === 'all'
                ? 'bg-slate-700 dark:bg-slate-200 text-white dark:text-slate-900'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
          >
            All
          </button>
          {(['MNS-Standard', 'MNS-Circuit Performance', 'MNS-Hardware MGMT'] as MonitoringTier[]).map((t) => (
            <button
              key={t}
              onClick={() => setFilterTier(t)}
              className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors ${
                filterTier === t
                  ? TIER_COLORS[t]
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              {t.replace('MNS-', '')}
            </button>
          ))}
          <span className="text-slate-300 dark:text-slate-600">|</span>
          <button onClick={expandAll} className="text-[11px] text-primary-500 hover:text-primary-600 font-medium">
            Expand All
          </button>
          <button onClick={collapseAll} className="text-[11px] text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 font-medium">
            Collapse All
          </button>
        </div>
      </div>

      {/* Count */}
      <p className="text-xs text-slate-400">
        Showing {filtered.length} of {FAULT_TYPES.length} fault types
      </p>

      {/* Fault Type Cards */}
      <div className="space-y-3">
        {filtered.map((fault) => {
          const isOpen = expanded.has(fault.id);
          const sev = SEVERITY_META[fault.severity];
          const SevIcon = sev.Icon;
          return (
            <div key={fault.id} className="card !p-0 overflow-hidden">
              {/* Header */}
              <button
                onClick={() => toggleExpand(fault.id)}
                className="w-full flex items-start gap-3 px-4 py-3.5 text-left hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors"
              >
                {isOpen ? (
                  <ChevronDown className="w-4 h-4 text-slate-400 mt-0.5 flex-shrink-0" />
                ) : (
                  <ChevronRight className="w-4 h-4 text-slate-400 mt-0.5 flex-shrink-0" />
                )}
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2 mb-1">
                    {/* Severity badge */}
                    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold ${sev.bg} ${sev.color}`}>
                      <SevIcon className="w-3 h-3" />
                      {sev.label.toUpperCase()}
                    </span>
                    {/* Tier badges */}
                    {fault.tiers.map((tier) => (
                      <span key={tier} className={`px-2 py-0.5 rounded text-[10px] font-medium ${TIER_COLORS[tier]}`}>
                        {tier}
                      </span>
                    ))}
                  </div>
                  <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">
                    Fault: {fault.name} <span className="font-mono text-slate-500 dark:text-slate-400">{fault.value}</span>
                  </p>
                </div>
              </button>

              {/* Expanded Content */}
              {isOpen && (
                <div className="px-4 pb-4 pt-1 ml-7 border-t border-slate-100 dark:border-slate-700/50 space-y-4">
                  {/* Description */}
                  <div>
                    <h4 className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1.5">Description</h4>
                    <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed">{fault.description}</p>
                  </div>

                  {/* NOC Actions */}
                  <div>
                    <h4 className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1.5">📋 NOC Action Steps</h4>
                    <ol className="space-y-1.5">
                      {fault.nocActions.map((action, i) => (
                        <li key={i} className="flex gap-2 text-sm text-slate-600 dark:text-slate-300">
                          <span className="text-xs font-bold text-slate-400 mt-0.5 min-w-[18px]">{i + 1}.</span>
                          <span className="leading-relaxed">{action}</span>
                        </li>
                      ))}
                    </ol>
                  </div>

                  {/* Special Notes */}
                  {fault.specialNotes && fault.specialNotes.length > 0 && (
                    <div className="p-3 rounded-lg bg-amber-50 dark:bg-amber-500/5 border border-amber-200 dark:border-amber-500/20">
                      <h4 className="text-xs font-semibold text-amber-700 dark:text-amber-300 mb-1.5">⚠️ Special Notes</h4>
                      <ul className="space-y-1">
                        {fault.specialNotes.map((note, i) => (
                          <li key={i} className="text-xs text-amber-700 dark:text-amber-400 leading-relaxed flex gap-1.5">
                            <span className="mt-0.5">•</span>
                            <span>{note}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-12 text-slate-500 dark:text-slate-400 text-sm">
          No fault types match your filters. Try adjusting search or filters.
        </div>
      )}

      {/* Extra Troubleshooting: Check Alerts */}
      <div className="card border-amber-200 dark:border-amber-500/30 !bg-amber-50/50 dark:!bg-amber-500/5">
        <div className="flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-500 mt-0.5 flex-shrink-0" />
          <div className="space-y-3">
            <h3 className="font-semibold text-amber-800 dark:text-amber-300">
              Extra Troubleshooting: Check Alerts
            </h3>
            <p className="text-sm text-amber-700 dark:text-amber-400 leading-relaxed">
              As an extra step for Circuit Performance and Hardware Management fault tickets (e.g., Fault: OutMbps = 0.0), check for anything unusual that could have triggered the alert including:
            </p>
            <ul className="space-y-1 text-sm text-amber-700 dark:text-amber-400">
              <li className="flex gap-1.5"><span>•</span> A LAN interface we are not supposed to be monitoring</li>
              <li className="flex gap-1.5"><span>•</span> Tunnels that should be disabled</li>
              <li className="flex gap-1.5"><span>•</span> Over-utilization alerts from the wrong interface</li>
              <li className="flex gap-1.5"><span>•</span> Especially from Collectors the client manages — the client may have made changes erroneously</li>
            </ul>
            <p className="text-sm text-amber-700 dark:text-amber-400 leading-relaxed">
              Check Alerts in LogicMonitor and verify what is actually triggering the alert. For example, alerts may be triggered on interfaces that are not associated with the circuit itself. If anything unusual is noted from Alerts, escalate immediately.
            </p>

            {/* Escalation Contacts */}
            <div className="p-3 rounded-lg bg-white dark:bg-slate-800 border border-amber-200 dark:border-amber-500/20">
              <div className="flex items-center gap-2 mb-2">
                <Users className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                <span className="text-xs font-bold text-amber-700 dark:text-amber-300 uppercase tracking-wider">Escalation Contacts</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {['Otukho', 'Ani', 'Perry', 'Karthik', 'Anirudh'].map((name) => (
                  <span key={name} className="px-2.5 py-1 rounded-md text-xs font-medium bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300">
                    {name}
                  </span>
                ))}
              </div>
              <div className="flex flex-wrap gap-2 mt-2">
                {['Engineering Chat', '_MNSChanges Group Distro'].map((ch) => (
                  <span key={ch} className="px-2.5 py-1 rounded-md text-xs font-medium bg-primary-50 dark:bg-primary-500/10 text-primary-600 dark:text-primary-400">
                    <Phone className="w-3 h-3 inline mr-1" />
                    {ch}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
