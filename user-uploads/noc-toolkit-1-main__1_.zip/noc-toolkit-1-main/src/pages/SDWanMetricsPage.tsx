import { BarChart3, Wifi, Phone, Video, Monitor, Activity } from 'lucide-react';

// ────────────────────────────────────────────────────────────────
// Data
// ────────────────────────────────────────────────────────────────

interface Metric {
  name: string;
  unit: string;
  good: string;
  watch: string;
  degraded: string;
  description: string;
}

const METRICS: Metric[] = [
  {
    name: 'Latency',
    unit: 'ms',
    good: '< 50 ms',
    watch: '50 – 150 ms',
    degraded: '> 150 ms',
    description: 'Round-trip time for packets between source and destination. High latency affects real-time applications like VoIP and video conferencing.',
  },
  {
    name: 'Jitter',
    unit: 'ms',
    good: '< 10 ms',
    watch: '10 – 30 ms',
    degraded: '> 30 ms',
    description: 'Variation in packet arrival time. High jitter causes audio distortion in VoIP calls and buffering in video streams.',
  },
  {
    name: 'Packet Loss',
    unit: '%',
    good: '< 0.1%',
    watch: '0.1 – 1%',
    degraded: '> 1%',
    description: 'Percentage of packets that fail to reach their destination. Even 1% packet loss can severely degrade VoIP quality.',
  },
  {
    name: 'MOS Score',
    unit: '',
    good: '> 4.0',
    watch: '3.5 – 4.0',
    degraded: '< 3.5',
    description: 'Mean Opinion Score — measures voice quality on a scale of 1–5. Computed from latency, jitter, and packet loss. ITU-T standard.',
  },
];

interface AppProfile {
  app: string;
  icon: typeof Phone;
  latency: string;
  jitter: string;
  packetLoss: string;
  notes: string;
}

const APP_PROFILES: AppProfile[] = [
  {
    app: 'VoIP / SIP',
    icon: Phone,
    latency: '< 150 ms',
    jitter: '< 30 ms',
    packetLoss: '< 1%',
    notes: 'MOS > 4.0 for toll quality. Codec G.711 uses 87 Kbps per call. G.729 uses 32 Kbps.',
  },
  {
    app: 'Video Conferencing',
    icon: Video,
    latency: '< 200 ms',
    jitter: '< 30 ms',
    packetLoss: '< 0.5%',
    notes: 'HD video needs 2-4 Mbps per participant. Zoom/Teams/WebEx. Enable QoS markings.',
  },
  {
    app: 'Remote Desktop / VDI',
    icon: Monitor,
    latency: '< 100 ms',
    jitter: '< 20 ms',
    packetLoss: '< 0.1%',
    notes: 'Citrix, VMware Horizon, RDP. Very sensitive to latency spikes. Consider WAN optimization.',
  },
  {
    app: 'General Internet / SaaS',
    icon: Wifi,
    latency: '< 300 ms',
    jitter: '< 50 ms',
    packetLoss: '< 2%',
    notes: 'Web browsing, O365, Salesforce. TCP handles retransmits but UX degrades above thresholds.',
  },
];

interface MonitoringTierInfo {
  name: string;
  color: string;
  border: string;
  description: string;
  alertTypes: string[];
}

const MONITORING_TIERS: MonitoringTierInfo[] = [
  {
    name: 'MNS-Standard',
    color: 'bg-purple-50 dark:bg-purple-500/5',
    border: 'border-purple-200 dark:border-purple-500/20',
    description: 'Global site reachability monitoring from 5 geographic locations. Tests if the device is reachable from the public internet.',
    alertTypes: [
      'Unreachable from 2+ global site monitors',
    ],
  },
  {
    name: 'MNS-Circuit Performance',
    color: 'bg-sky-50 dark:bg-sky-500/5',
    border: 'border-sky-200 dark:border-sky-500/20',
    description: 'Monitors circuit health metrics via ping, SNMP polling, and bandwidth utilization. Detects performance degradation and outages.',
    alertTypes: [
      'PingLossPercent = 100.0',
      'idleInterval = ~600s',
      'InUtilizationPercent / OutUtilizationPercent',
      'InErrors / OutErrors',
      'StatusFlap = 1.0',
      'OutMbps / InMbps = 0.0 (Dentons)',
    ],
  },
  {
    name: 'MNS-Hardware MGMT',
    color: 'bg-rose-50 dark:bg-rose-500/5',
    border: 'border-rose-200 dark:border-rose-500/20',
    description: 'Monitors the CE (Customer Edge) device hardware via SNMP. Detects hardware faults, BGP/VPN issues, and resource exhaustion.',
    alertTypes: [
      'PingLossPercent = 100.0',
      'idleInterval = ~600s',
      'PeerState = 2.0 (BGP)',
      'Status = 1.0 (VPN)',
      'Uptime = No Data (SNMP)',
      'CpuUsage / memoryUtilization / diskUtilization',
      'InErrors / OutErrors',
      'StatusFlap = 1.0',
    ],
  },
];

// ────────────────────────────────────────────────────────────────
// Component
// ────────────────────────────────────────────────────────────────

export default function SDWanMetricsPage() {
  return (
    <div className="max-w-5xl mx-auto space-y-8">
      {/* Header */}
      <div>
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 bg-cyan-100 dark:bg-cyan-500/10 rounded-lg flex items-center justify-center">
            <BarChart3 className="w-5 h-5 text-cyan-600 dark:text-cyan-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
              SD-WAN Metrics & Monitoring
            </h1>
            <p className="text-sm text-slate-500 dark:text-slate-400">
              Performance thresholds, application profiles, and monitoring tiers reference
            </p>
          </div>
        </div>
      </div>

      {/* ─── Performance Thresholds ─── */}
      <div>
        <div className="flex items-center gap-2 mb-4">
          <Activity className="w-5 h-5 text-cyan-500" />
          <h2 className="text-lg font-semibold text-slate-900 dark:text-white">Performance Thresholds</h2>
        </div>

        {/* Threshold Table */}
        <div className="card !p-0 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-700">
                  <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Metric</th>
                  <th className="text-center px-4 py-3 text-xs font-semibold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider">🟢 Good</th>
                  <th className="text-center px-4 py-3 text-xs font-semibold text-amber-600 dark:text-amber-400 uppercase tracking-wider">🟡 Watch</th>
                  <th className="text-center px-4 py-3 text-xs font-semibold text-red-600 dark:text-red-400 uppercase tracking-wider">🔴 Degraded</th>
                </tr>
              </thead>
              <tbody>
                {METRICS.map((m, idx) => (
                  <tr key={m.name} className={idx < METRICS.length - 1 ? 'border-b border-slate-100 dark:border-slate-700/50' : ''}>
                    <td className="px-4 py-3">
                      <span className="font-semibold text-slate-800 dark:text-slate-200">{m.name}</span>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <span className="inline-block px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 dark:bg-emerald-500/15 text-emerald-700 dark:text-emerald-400">
                        {m.good}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <span className="inline-block px-3 py-1 rounded-full text-xs font-bold bg-amber-100 dark:bg-amber-500/15 text-amber-700 dark:text-amber-400">
                        {m.watch}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <span className="inline-block px-3 py-1 rounded-full text-xs font-bold bg-red-100 dark:bg-red-500/15 text-red-700 dark:text-red-400">
                        {m.degraded}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Metric Descriptions */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-4">
          {METRICS.map((m) => (
            <div key={m.name} className="card">
              <h4 className="text-sm font-semibold text-slate-800 dark:text-slate-200 mb-1">{m.name}</h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">{m.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* ─── Application Profiles ─── */}
      <div>
        <div className="flex items-center gap-2 mb-4">
          <Monitor className="w-5 h-5 text-cyan-500" />
          <h2 className="text-lg font-semibold text-slate-900 dark:text-white">Application SLA Profiles</h2>
        </div>
        <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">
          Recommended maximum thresholds per application type. Exceeding these will result in noticeable quality degradation.
        </p>
        <div className="card !p-0 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-700">
                  <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Application</th>
                  <th className="text-center px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Max Latency</th>
                  <th className="text-center px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Max Jitter</th>
                  <th className="text-center px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Max Pkt Loss</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Notes</th>
                </tr>
              </thead>
              <tbody>
                {APP_PROFILES.map((a, idx) => {
                  const Icon = a.icon;
                  return (
                    <tr key={a.app} className={idx < APP_PROFILES.length - 1 ? 'border-b border-slate-100 dark:border-slate-700/50' : ''}>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <Icon className="w-4 h-4 text-cyan-500 flex-shrink-0" />
                          <span className="font-semibold text-slate-800 dark:text-slate-200">{a.app}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-center font-mono text-slate-600 dark:text-slate-300">{a.latency}</td>
                      <td className="px-4 py-3 text-center font-mono text-slate-600 dark:text-slate-300">{a.jitter}</td>
                      <td className="px-4 py-3 text-center font-mono text-slate-600 dark:text-slate-300">{a.packetLoss}</td>
                      <td className="px-4 py-3 text-xs text-slate-500 dark:text-slate-400 max-w-[200px]">{a.notes}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* VoIP Quality */}
      <div className="card border-cyan-200 dark:border-cyan-500/30 !bg-cyan-50/50 dark:!bg-cyan-500/5">
        <div className="flex items-start gap-3">
          <Phone className="w-5 h-5 text-cyan-500 mt-0.5 flex-shrink-0" />
          <div>
            <h3 className="font-semibold text-cyan-800 dark:text-cyan-300">VoIP Quality Reference (MOS Score)</h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-3">
              <div className="text-center p-2 rounded-lg bg-white dark:bg-slate-800">
                <span className="text-lg font-bold text-emerald-600 dark:text-emerald-400">4.3 – 5.0</span>
                <p className="text-[10px] text-slate-500 mt-0.5">Excellent</p>
              </div>
              <div className="text-center p-2 rounded-lg bg-white dark:bg-slate-800">
                <span className="text-lg font-bold text-emerald-600 dark:text-emerald-400">4.0 – 4.3</span>
                <p className="text-[10px] text-slate-500 mt-0.5">Toll Quality</p>
              </div>
              <div className="text-center p-2 rounded-lg bg-white dark:bg-slate-800">
                <span className="text-lg font-bold text-amber-600 dark:text-amber-400">3.5 – 4.0</span>
                <p className="text-[10px] text-slate-500 mt-0.5">Acceptable</p>
              </div>
              <div className="text-center p-2 rounded-lg bg-white dark:bg-slate-800">
                <span className="text-lg font-bold text-red-600 dark:text-red-400">&lt; 3.5</span>
                <p className="text-[10px] text-slate-500 mt-0.5">Unusable</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ─── Monitoring Tiers ─── */}
      <div>
        <div className="flex items-center gap-2 mb-4">
          <BarChart3 className="w-5 h-5 text-cyan-500" />
          <h2 className="text-lg font-semibold text-slate-900 dark:text-white">Monitoring Tiers Reference</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {MONITORING_TIERS.map((tier) => (
            <div key={tier.name} className={`card ${tier.color} border ${tier.border}`}>
              <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200 mb-2">{tier.name}</h3>
              <p className="text-xs text-slate-600 dark:text-slate-400 mb-3 leading-relaxed">{tier.description}</p>
              <h4 className="text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1.5">Alert Types</h4>
              <ul className="space-y-1">
                {tier.alertTypes.map((at, i) => (
                  <li key={i} className="text-xs text-slate-600 dark:text-slate-300 flex gap-1.5">
                    <span className="mt-0.5">•</span>
                    <span className="font-mono">{at}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
