import { useState } from 'react';
import { Settings, User as UserIcon, Palette, Lock, Plug, AlertTriangle, HelpCircle } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { ProfileTab } from '../components/settings/ProfileTab';
import { AppearanceTab } from '../components/settings/AppearanceTab';
import { PasswordTab } from '../components/settings/PasswordTab';
import { IntegrationsTab } from '../components/settings/IntegrationsTab';
import { DangerZoneTab } from '../components/settings/DangerZoneTab';
import { ResetRequestTab } from '../components/settings/ResetRequestTab';

type TabId = 'profile' | 'appearance' | 'password' | 'reset-request' | 'integrations' | 'danger';

interface Tab { id: TabId; label: string; icon: typeof Settings; }

export default function SettingsPage() {
  const { isSuperAdmin } = useAuth();
  const [active, setActive] = useState<TabId>('profile');

  const tabs: Tab[] = [
    { id: 'profile', label: 'Profile', icon: UserIcon },
    { id: 'appearance', label: 'Appearance', icon: Palette },
    { id: 'password', label: 'Password', icon: Lock },
    { id: 'reset-request', label: 'Reset Help', icon: HelpCircle },
    { id: 'integrations', label: 'Integrations', icon: Plug },
    ...(isSuperAdmin ? [{ id: 'danger' as TabId, label: 'Danger Zone', icon: AlertTriangle }] : []),
  ];

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-lg bg-slate-100 dark:bg-slate-700/50 flex items-center justify-center">
          <Settings className="w-5 h-5 text-slate-600 dark:text-slate-300" />
        </div>
        <h1 className="text-xl font-bold text-slate-900 dark:text-white">Settings</h1>
      </div>

      <div className="flex gap-1 border-b border-slate-200 dark:border-slate-700 overflow-x-auto">
        {tabs.map((t) => (
          <button key={t.id} onClick={() => setActive(t.id)}
            className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
              active === t.id
                ? 'border-primary-500 text-primary-600 dark:text-primary-400'
                : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-300'
            } ${t.id === 'danger' ? '!text-red-500 dark:!text-red-400' : ''}`}>
            <t.icon className="w-4 h-4" />
            {t.label}
          </button>
        ))}
      </div>

      <div className="card">
        {active === 'profile' && <ProfileTab />}
        {active === 'appearance' && <AppearanceTab />}
        {active === 'password' && <PasswordTab />}
        {active === 'reset-request' && <ResetRequestTab />}
        {active === 'integrations' && <IntegrationsTab />}
        {active === 'danger' && isSuperAdmin && <DangerZoneTab />}
      </div>
    </div>
  );
}
