import { useState, useEffect, useCallback } from 'react';
import { Plus, BookOpen, Search, Loader2, RefreshCw } from 'lucide-react';
import toast from 'react-hot-toast';
import { useAuth } from '../hooks/useAuth';
import { getRunbooks, createRunbook, updateRunbook, deleteRunbook, type Runbook, type RunbookCategory, CATEGORY_META } from '../lib/runbooks/db';
import { seedRunbooksIfEmpty } from '../lib/runbooks/seed';
import { RunbookCard } from '../components/runbooks/RunbookCard';
import { RunbookEditorModal } from '../components/runbooks/RunbookEditorModal';
import { trackEvent } from '../lib/analytics/db';

const ALL_CATEGORIES = Object.keys(CATEGORY_META) as RunbookCategory[];

export default function RunbookEditorPage() {
  const { user, isAdmin } = useAuth();
  const [runbooks, setRunbooks] = useState<Runbook[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState<RunbookCategory | 'all'>('all');
  const [editingRunbook, setEditingRunbook] = useState<Runbook | null | undefined>(undefined); // undefined = modal closed, null = new

  const load = useCallback(async () => {
    setLoading(true);
    const data = await getRunbooks();
    setRunbooks(data);
    setLoading(false);
  }, []);

  useEffect(() => {
    if (!user) return;
    trackEvent(user.id, 'ai_assistant', 'page_open');
    // Seed if empty (graceful — no-op if table doesn't exist)
    seedRunbooksIfEmpty(user.id, `${user.firstName} ${user.lastName}`)
      .then(() => load());
  }, [user?.id]);

  const filtered = runbooks.filter(rb => {
    if (activeCategory !== 'all' && rb.category !== activeCategory) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      return rb.title.toLowerCase().includes(q) ||
             rb.content.toLowerCase().includes(q) ||
             rb.plainText.toLowerCase().includes(q);
    }
    return true;
  });

  const handleSave = async (data: { title: string; category: RunbookCategory; content: string; plainText: string }) => {
    if (!user) return;
    const userName = `${user.firstName} ${user.lastName}`;
    if (editingRunbook) {
      // Update existing
      const updated = await updateRunbook(editingRunbook.id, data, user.id, userName);
      if (updated) {
        setRunbooks(prev => prev.map(r => r.id === updated.id ? updated : r));
        toast.success('Runbook updated');
      } else {
        toast.error('Failed to update runbook');
      }
    } else {
      // Create new
      const created = await createRunbook(
        { ...data, isPinned: false, sortOrder: runbooks.length },
        user.id, userName,
      );
      if (created) {
        setRunbooks(prev => [created, ...prev]);
        toast.success('Runbook created');
      } else {
        toast.error('Failed to create runbook (table may not exist — see Supabase SQL)');
      }
    }
    setEditingRunbook(undefined);
  };

  const handleDelete = async (id: string) => {
    await deleteRunbook(id);
    setRunbooks(prev => prev.filter(r => r.id !== id));
    toast.success('Runbook deleted');
  };

  const countByCategory = (cat: RunbookCategory) => runbooks.filter(r => r.category === cat).length;

  return (
    <div className="max-w-4xl mx-auto space-y-5">
      {/* Header */}
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-primary-100 dark:bg-primary-500/10 rounded-lg flex items-center justify-center">
            <BookOpen className="w-5 h-5 text-primary-600 dark:text-primary-400" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">NOC Runbook Editor</h1>
            <p className="text-sm text-slate-500 dark:text-slate-400">Ticket scripts · Layer 1 · iPath fault types · Carrier escalation</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={load} className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 transition-colors" title="Refresh">
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
          {isAdmin && (
            <button
              onClick={() => setEditingRunbook(null)}
              className="btn-primary gap-1.5"
            >
              <Plus className="w-4 h-4" /> New Runbook
            </button>
          )}
        </div>
      </div>

      {/* Admin notice for non-admins */}
      {!isAdmin && (
        <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-blue-50 dark:bg-blue-500/10 border border-blue-200 dark:border-blue-500/20 text-xs text-blue-700 dark:text-blue-300">
          <BookOpen className="w-3.5 h-3.5 flex-shrink-0" />
          You can view and copy runbooks. Only Admins can create, edit, or delete them.
        </div>
      )}

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Search runbooks by title or content…"
          className="input-base pl-10 w-full"
        />
      </div>

      {/* Category tabs */}
      <div className="flex flex-wrap gap-1.5 border-b border-slate-200 dark:border-slate-700 pb-2">
        <button
          onClick={() => setActiveCategory('all')}
          className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
            activeCategory === 'all'
              ? 'bg-primary-500 text-white'
              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
          }`}
        >
          All ({runbooks.length})
        </button>
        {ALL_CATEGORIES.map(cat => {
          const count = countByCategory(cat);
          const meta = CATEGORY_META[cat];
          return (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                activeCategory === cat
                  ? 'bg-primary-500 text-white'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              {meta.label} ({count})
            </button>
          );
        })}
      </div>

      {/* Content */}
      {loading ? (
        <div className="flex items-center justify-center py-16 gap-2 text-slate-400">
          <Loader2 className="w-5 h-5 animate-spin" /> Loading runbooks…
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 text-slate-400">
          <BookOpen className="w-10 h-10 mx-auto mb-3 opacity-30" />
          <p className="text-sm font-medium">No runbooks found</p>
          {isAdmin && (
            <p className="text-xs mt-1">
              {runbooks.length === 0
                ? 'Create the Supabase tables first (see terminal for SQL), then create your first runbook.'
                : 'Try a different search or category.'}
            </p>
          )}
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map(rb => (
            <RunbookCard
              key={rb.id}
              runbook={rb}
              isAdmin={isAdmin}
              onEdit={setEditingRunbook}
              onDelete={handleDelete}
            />
          ))}
        </div>
      )}

      {/* Editor modal */}
      {editingRunbook !== undefined && (
        <RunbookEditorModal
          runbook={editingRunbook}
          onSave={handleSave}
          onClose={() => setEditingRunbook(undefined)}
        />
      )}
    </div>
  );
}
