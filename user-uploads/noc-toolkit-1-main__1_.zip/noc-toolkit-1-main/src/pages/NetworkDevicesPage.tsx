import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Router,
  Search,
  ChevronDown,
  ChevronRight,
  Sparkles,
  Wifi,
  Shield,
  Radio,
  Monitor,
  Server,
} from 'lucide-react';

// ────────────────────────────────────────────────────────────────
// Types
// ────────────────────────────────────────────────────────────────

type Tier = 'common' | 'intermediate' | 'advanced';

interface Issue {
  title: string;
  tier: Tier;
  steps: string[];
  aiPrompt: string;
}

interface DeviceCategory {
  id: string;
  label: string;
  icon: typeof Router;
  blurb: string;
  models: string;
  issues: Issue[];
}

// ────────────────────────────────────────────────────────────────
// Data
// ────────────────────────────────────────────────────────────────

const TIER_META: Record<Tier, { label: string; color: string; dot: string }> = {
  common: { label: 'Common', color: 'text-emerald-600 dark:text-emerald-400', dot: 'bg-emerald-500' },
  intermediate: { label: 'Intermediate', color: 'text-amber-600 dark:text-amber-400', dot: 'bg-amber-500' },
  advanced: { label: 'Advanced', color: 'text-red-600 dark:text-red-400', dot: 'bg-red-500' },
};

const CATEGORIES: DeviceCategory[] = [
  // ─── Cisco Meraki ──────────────────────────────────────────
  {
    id: 'meraki',
    label: 'Cisco Meraki',
    icon: Wifi,
    blurb: 'Cloud-managed firewalls, access points, switches, and cellular gateways.',
    models: 'MX (Firewall/SD-WAN) · MR (Access Points) · MS (Switches) · MG (Cellular Gateway)',
    issues: [
      {
        title: 'Meraki Dashboard unreachable',
        tier: 'common',
        steps: [
          'Verify the device has internet access — check upstream link LED (solid green = OK).',
          'Try accessing dashboard.meraki.com from a device on the same LAN.',
          'Power cycle the Meraki device — unplug for 15 seconds, reconnect.',
          'Check if the device shows in the Meraki Dashboard under Organization → Inventory. If "Offline", the WAN uplink may be down.',
          'Verify DNS resolution: the device must be able to resolve *.meraki.com.',
          'If behind another firewall, ensure outbound TCP 443 and UDP 7351 are allowed.',
        ],
        aiPrompt: 'A Meraki device is showing offline in the dashboard. Walk me through all possible causes and how to restore cloud connectivity.',
      },
      {
        title: 'Firmware mismatch after scheduled update',
        tier: 'common',
        steps: [
          'In Dashboard: Organization → Firmware Upgrades → check the scheduled version vs. current.',
          'If the update failed, click "Retry" or reschedule to a maintenance window.',
          'Verify the device rebooted after update — check Event Log for "Device rebooted" entry.',
          'If device is on an older firmware and won\'t update: power cycle, wait 10 min for it to pull the new image.',
          'For MX: ensure WAN bandwidth is sufficient for the firmware download (~100-200 MB).',
        ],
        aiPrompt: 'A Meraki device failed to update firmware. What are the common causes and how do I force a firmware update?',
      },
      {
        title: 'VLAN not passing traffic',
        tier: 'common',
        steps: [
          'Dashboard → Addressing & VLANs → verify the VLAN exists with correct subnet and DHCP range.',
          'Check the switchport connecting to the device: Security & SD-WAN → Addressing & VLANs → verify VLAN is tagged.',
          'On MS switches: confirm the port is set to the correct VLAN (Trunk vs. Access mode).',
          'Check inter-VLAN routing: Security & SD-WAN → Firewall → verify no deny rules blocking the VLAN.',
          'Test by connecting a laptop directly to the VLAN port — run ipconfig/ifconfig to check DHCP assignment.',
        ],
        aiPrompt: 'Traffic on a specific VLAN is not passing through our Meraki MX. Help me troubleshoot VLAN routing and DHCP issues.',
      },
      {
        title: 'VPN Auto tunnel flapping',
        tier: 'intermediate',
        steps: [
          'Dashboard → Security & SD-WAN → Site-to-site VPN → check tunnel status (green/amber/red).',
          'Verify both MX devices have stable WAN links — check uplink utilization and latency.',
          'Check NAT traversal: if behind another NAT device, enable UDP hole punching or switch to a direct WAN IP.',
          'Review VPN event logs for "Tunnel down" / "Tunnel up" patterns — correlate with WAN link drops.',
          'If one side is on a cellular failover (MG), tunnels may flap due to IP changes — enable Dynamic DNS.',
          'Check MTU: Site-to-site VPN has overhead. If WAN MTU is < 1500, set VPN MTU to 1400.',
        ],
        aiPrompt: 'Meraki Auto VPN tunnels keep flapping between two MX sites. Walk me through diagnosing whether it is WAN instability, NAT traversal, or MTU issues.',
      },
      {
        title: 'DHCP pool exhaustion',
        tier: 'intermediate',
        steps: [
          'Dashboard → Addressing & VLANs → check DHCP lease usage per VLAN.',
          'If pool is > 80% used: expand the subnet or shorten the lease time (default is 1 day).',
          'Check for rogue DHCP clients — Dashboard → Clients → sort by DHCP lease and look for unknown MACs.',
          'Consider reserving IPs for critical devices and narrowing the DHCP range.',
          'If a specific VLAN is exhausted, check whether devices from another VLAN are being placed there due to trunk misconfig.',
        ],
        aiPrompt: 'The DHCP pool on our Meraki VLAN is running out of addresses. How do I identify the cause and expand capacity?',
      },
      {
        title: 'Content filtering blocking legitimate traffic',
        tier: 'intermediate',
        steps: [
          'Dashboard → Security & SD-WAN → Content Filtering → check which category is blocked.',
          'Look up the blocked URL in the Event Log (search for "Content filtering block").',
          'Add the domain to the whitelist: Content Filtering → Whitelisted URLs.',
          'If the site is miscategorized: submit a re-categorization request to Cisco Talos.',
          'Temporarily disable content filtering for the client IP to confirm it is the cause.',
        ],
        aiPrompt: 'Meraki content filtering is blocking a business-critical website. How do I whitelist it and verify the policy?',
      },
      {
        title: 'HA (warm spare) failover not triggering',
        tier: 'advanced',
        steps: [
          'Dashboard → Appliance Status → verify both primary and spare show as "Online".',
          'Check virtual IP (VIP): both MX units must share the same VIP. If VIP is missing, re-enable warm spare.',
          'Verify physical connectivity: the spare must be on the same LAN segment as the primary.',
          'Test failover: Dashboard → Security & SD-WAN → Warm spare → "Swap" to force failover.',
          'Check uplink monitoring: if the primary WAN is up but not passing traffic, the spare may not detect the failure. Configure uplink health checks.',
          'Review event log for "Warm spare transition" events.',
        ],
        aiPrompt: 'Our Meraki MX warm spare is not taking over when the primary fails. Walk me through verifying HA configuration and forcing failover.',
      },
      {
        title: 'SNMP polling gaps / monitoring data missing',
        tier: 'advanced',
        steps: [
          'Dashboard → Network-wide → General → SNMP → verify SNMP is enabled (v2c or v3).',
          'Confirm the community string / credentials match your NMS (LogicMonitor, PRTG, etc.).',
          'Check firewall rules: the Meraki must allow inbound SNMP (UDP 161) from your collector IP.',
          'If using v3: verify Auth Protocol (SHA/MD5), Privacy Protocol (AES/DES), and credentials match exactly.',
          'Test with snmpwalk from the collector: snmpwalk -v2c -c <community> <device-ip>.',
          'If behind NAT: SNMP may not traverse NAT properly — use the LAN IP or set up a local collector.',
        ],
        aiPrompt: 'SNMP polling to our Meraki device has gaps in LogicMonitor. Help me verify SNMP configuration and connectivity.',
      },
    ],
  },

  // ─── SD-WAN ────────────────────────────────────────────────
  {
    id: 'sdwan',
    label: 'SD-WAN',
    icon: Radio,
    blurb: 'VMware VeloCloud, Fortinet SD-WAN, Versa, Cato Networks — overlay tunnels, dynamic multipath, and orchestrator management.',
    models: 'VeloCloud Edge (510/520/540/610/620/640/840/860/3400/3800) · FortiGate SD-WAN · Versa FlexVNF · Cato Socket',
    issues: [
      {
        title: 'Edge device showing offline in orchestrator',
        tier: 'common',
        steps: [
          'Verify physical connectivity: check LEDs on the Edge — power, WAN link lights.',
          'Power cycle the Edge device — unplug for 30 seconds.',
          'Check the WAN uplink: can you ping the gateway from the Edge CLI (if accessible)?',
          'Verify DNS: the Edge must resolve the orchestrator FQDN (e.g., vco.velocloud.net).',
          'Check firewall/ACL upstream: outbound TCP 443 must be allowed to the orchestrator IP.',
          'If the Edge recently moved or changed WAN IP: it may need to re-register with the orchestrator.',
        ],
        aiPrompt: 'Our VeloCloud Edge is showing offline in the orchestrator. Walk me through all the common causes from physical to application layer.',
      },
      {
        title: 'Tunnel down between Edge and gateway/hub',
        tier: 'common',
        steps: [
          'In orchestrator: Monitor → Edges → select the Edge → Tunnels tab — check status.',
          'Verify both WAN links are up and passing traffic (Monitor → Transport).',
          'If behind NAT: confirm UDP 2426 (VCMP) is not blocked by upstream firewall.',
          'Check if the hub/gateway side is also showing tunnel down — could be a cloud-side issue.',
          'Review Edge Events for "Tunnel down" entries and correlate with WAN link events.',
          'If using multiple WAN links: check if the tunnel is only down on one transport.',
        ],
        aiPrompt: 'An SD-WAN tunnel between our Edge and the hub is down. Help me systematically diagnose whether it is WAN, NAT, or orchestrator config.',
      },
      {
        title: 'DNS not resolving through SD-WAN overlay',
        tier: 'common',
        steps: [
          'Check Business Policy: verify DNS traffic (UDP 53) is routed through the correct path (direct vs. backhaul).',
          'Test DNS from a client behind the Edge: nslookup google.com.',
          'Try a public DNS server (8.8.8.8) to isolate whether it is the configured DNS or the path.',
          'Check Edge DNS settings: Configure → Device → DNS — verify primary/secondary DNS servers.',
          'If using private DNS through the overlay: ensure the tunnel to the hub carrying DNS is up.',
        ],
        aiPrompt: 'DNS queries are failing for clients behind our SD-WAN Edge. Help me check business policies and DNS configuration.',
      },
      {
        title: 'High latency / jitter / packet loss on overlay',
        tier: 'intermediate',
        steps: [
          'Monitor → QoE (Quality of Experience) → check latency, jitter, and packet loss per link.',
          'Compare underlay performance: run a speed test or iperf from a device on the same WAN link (bypass SD-WAN).',
          'If only one WAN link is degraded: check with the carrier for congestion or outage.',
          'Review Business Policy: is latency-sensitive traffic (VoIP, video) assigned to the best-performing link?',
          'Check for link saturation: Monitor → Transport → bandwidth usage. If > 80%, traffic steering may be sub-optimal.',
          'For VeloCloud: check DMPO (Dynamic Multipath Optimization) — enable forward error correction (FEC) or packet duplication for critical apps.',
          'Thresholds: Latency > 150ms, Jitter > 30ms, Packet Loss > 1% = degraded. See SD-WAN Metrics page.',
        ],
        aiPrompt: 'We are seeing high latency and jitter on our SD-WAN overlay. Walk me through diagnosing whether it is the underlay, overlay config, or traffic saturation.',
      },
      {
        title: 'Policy-based routing not working / traffic taking wrong path',
        tier: 'intermediate',
        steps: [
          'Configure → Business Policy → verify the rule order (rules are processed top-down, first match wins).',
          'Check the application classification: is the traffic being identified correctly? Monitor → Top Applications.',
          'Verify the link steering setting: "Auto", "Transport Group", or "Link" — ensure the desired WAN is specified.',
          'If using application-aware routing: the system may override your policy if the preferred link is degraded.',
          'Test by creating a temporary rule at the top for the specific source/destination with explicit link steering.',
        ],
        aiPrompt: 'Traffic is not following our SD-WAN business policy rules. Help me debug policy ordering, application classification, and link steering.',
      },
      {
        title: 'Link failover not triggering when primary WAN degrades',
        tier: 'intermediate',
        steps: [
          'Check failover settings: Configure → Device → WAN Interfaces → link failover thresholds.',
          'Verify the link is actually detected as degraded by the Edge — Monitor → Link Health.',
          'If the link is physically up but degraded (high loss/latency): SD-WAN may not treat it as "down". Adjust SLA thresholds.',
          'Check VRRP/HA settings if running dual Edges — failover between Edges is separate from link failover.',
          'For VeloCloud: enable "Link Conditioning" to compensate for degraded links before failing over.',
          'Test by disconnecting the primary WAN cable — does failover occur within expected time (usually < 1 min)?',
        ],
        aiPrompt: 'Our SD-WAN is not failing over to the backup WAN link when the primary degrades. Help me check SLA thresholds and failover configuration.',
      },
      {
        title: 'BGP over SD-WAN — peering not establishing',
        tier: 'advanced',
        steps: [
          'Verify BGP is enabled on the Edge: Configure → Device → Routing → BGP.',
          'Check neighbor configuration: ASN, neighbor IP, password (if MD5 auth is used).',
          'Ensure the BGP peering IP is reachable from the Edge — ping from Edge CLI.',
          'If BGP runs over the overlay: verify the tunnel to the hub/peer is up and stable.',
          'Check route advertisements: ensure the Edge is advertising the correct prefixes.',
          'Review BGP event logs in the orchestrator for "Neighbor down" or "Hold timer expired" messages.',
          'If flapping: check underlying circuit stability — BGP hold timer default is 180s, so circuit flaps < 180s may not drop BGP.',
        ],
        aiPrompt: 'BGP peering over our SD-WAN overlay is not establishing. Walk me through verifying the BGP configuration, tunnel health, and route advertisements.',
      },
      {
        title: 'DMPO tuning — FEC / packet duplication not improving quality',
        tier: 'advanced',
        steps: [
          'VeloCloud: Configure → Business Policy → select the rule → Link Steering → enable DMPO.',
          'Choose FEC (Forward Error Correction) for links with < 5% packet loss.',
          'Choose Packet Duplication for critical real-time traffic (VoIP) on links with > 5% loss.',
          'Note: FEC adds ~10-15% bandwidth overhead; Duplication doubles bandwidth usage.',
          'Monitor improvement: QoE tab → compare before/after latency, jitter, packet loss.',
          'If both links are severely degraded (> 10% loss each), DMPO cannot fully compensate — escalate to carrier.',
          'Ensure the Edge has sufficient CPU/memory — DMPO processing is CPU-intensive on lower-end models.',
        ],
        aiPrompt: 'I need to tune DMPO (Dynamic Multipath Optimization) on VeloCloud to improve VoIP quality. Walk me through FEC vs. duplication trade-offs.',
      },
    ],
  },

  // ─── Fortinet FortiGate ────────────────────────────────────
  {
    id: 'fortinet',
    label: 'Fortinet FortiGate',
    icon: Shield,
    blurb: 'Next-gen firewalls with VPN, UTM, IPS, and SD-WAN capabilities.',
    models: 'FortiGate 40F/60F/80F/100F/200F/400F/600F/1000F/3000F series',
    issues: [
      {
        title: 'Interface showing down',
        tier: 'common',
        steps: [
          'CLI: get system interface physical — check the port status.',
          'Verify cable is connected and link LED is lit on the FortiGate port.',
          'Check if the interface is administratively down: show system interface <port> → look for "set status down".',
          'If the port connects to a switch: verify the switch port is enabled and has correct VLAN.',
          'Try a different cable or port to rule out physical failure.',
        ],
        aiPrompt: 'A FortiGate interface is showing as down. Walk me through physical and administrative checks to restore it.',
      },
      {
        title: 'HA out of sync',
        tier: 'common',
        steps: [
          'CLI: diagnose sys ha status — check sync status.',
          'If "out of sync": run "execute ha synchronize start" to force a sync.',
          'Verify HA heartbeat interfaces: both units must have the same HA interface connected.',
          'Check firmware versions: both units MUST be on the same firmware for HA to sync.',
          'Review HA event logs: diagnose debug application hatalk -1 → look for sync errors.',
          'If persistent: check HA priority, ensure correct primary/secondary election.',
        ],
        aiPrompt: 'Our FortiGate HA cluster is out of sync. Help me diagnose and force synchronization between primary and secondary.',
      },
      {
        title: 'Firewall policy denying traffic unexpectedly',
        tier: 'common',
        steps: [
          'Policy & Objects → Firewall Policy → verify rule order (top-down, first match).',
          'Check the implicit deny at the bottom — this catches all unmatched traffic.',
          'Use the Policy Lookup tool: CLI "diagnose firewall iprope lookup <src> <dst> <port>".',
          'Enable logging on the deny rule: edit the policy → Log Allowed Traffic → All Sessions.',
          'Check UTM profiles: even if the policy allows traffic, a Web Filter / IPS / Application Control profile may block it.',
          'FortiView → All Sessions → filter by source/destination to see which policy matched.',
        ],
        aiPrompt: 'Traffic is being blocked by our FortiGate firewall but the policy should allow it. Help me trace which rule or UTM profile is blocking.',
      },
      {
        title: 'IPSec VPN tunnel renegotiation / frequent drops',
        tier: 'intermediate',
        steps: [
          'CLI: diagnose vpn ike log filter dst-addr4 <peer-ip> → diagnose debug app ike -1 → diagnose debug enable.',
          'Check Phase 1: proposal mismatch (encryption, hash, DH group, lifetime) between both sides.',
          'Check Phase 2: SA lifetime, PFS settings, proxy IDs must match.',
          'If behind NAT: enable "set nattraversal enable" in Phase 1.',
          'Check DPD (Dead Peer Detection): if enabled on one side only, tunnels may drop when idle.',
          'Verify route to the peer: execute router info routing-table all → ensure the peer IP is reachable.',
          'If tunnel flaps with traffic: check MTU — set "set fragmentation before-encryption" in Phase 2.',
        ],
        aiPrompt: 'Our FortiGate IPSec VPN tunnel keeps dropping and renegotiating. Walk me through Phase 1 and Phase 2 diagnosis.',
      },
      {
        title: 'SSL-VPN authentication failures',
        tier: 'intermediate',
        steps: [
          'Check user credentials: User & Authentication → verify the user exists and password is correct.',
          'If using LDAP/RADIUS: diagnose test authserver ldap <server> <user> <pass>.',
          'Check the SSL-VPN portal settings: VPN → SSL-VPN Settings → verify authentication source (local/LDAP/RADIUS).',
          'Check certificate: if using client certificates, verify the CA is trusted on the FortiGate.',
          'Review SSL-VPN event logs: Log & Report → VPN Events → look for "SSL VPN login failed".',
          'If using FortiToken MFA: verify the token seed is synced — User & Authentication → FortiTokens.',
        ],
        aiPrompt: 'Users cannot authenticate to our FortiGate SSL-VPN. Help me troubleshoot LDAP, RADIUS, and MFA issues.',
      },
      {
        title: 'UTM profile blocking legitimate traffic',
        tier: 'intermediate',
        steps: [
          'Identify which UTM is blocking: FortiView → Threats → filter by source IP.',
          'Web Filter: check the category and override if needed — Security Profiles → Web Filter → FortiGuard Category.',
          'Application Control: check if the app is in a blocked category — Security Profiles → Application Control.',
          'IPS: check for false positive — Security Profiles → IPS → add an exemption for the signature.',
          'DNS Filter: if blocking at DNS level, check Security Profiles → DNS Filter.',
          'Temporarily remove the UTM profile from the policy to confirm it is the cause, then add targeted exemptions.',
        ],
        aiPrompt: 'Our FortiGate UTM profile is blocking legitimate business traffic. Help me identify which security profile is responsible and add exemptions.',
      },
      {
        title: 'Conserve mode — high memory usage',
        tier: 'advanced',
        steps: [
          'CLI: diagnose hardware sysinfo memory — check free/used memory.',
          'Conserve mode activates at ~88% memory usage (red threshold), exits at ~82% (green threshold).',
          'In conserve mode: new sessions are limited, proxy-based features degrade, AV scanning stops.',
          'Check top memory consumers: diagnose sys top → sort by MEM%.',
          'Common causes: too many concurrent sessions, proxy-based inspection on large traffic, memory leak in firmware.',
          'Immediate action: consider rebooting during a maintenance window if memory does not recover.',
          'Long-term: switch heavy inspection from proxy to flow mode, upgrade to a higher-spec FortiGate, or update firmware.',
        ],
        aiPrompt: 'Our FortiGate has entered conserve mode due to high memory usage. What are the immediate steps to restore service and prevent recurrence?',
      },
      {
        title: 'NP6/NP7 hardware offloading issues',
        tier: 'advanced',
        steps: [
          'NP offloading accelerates traffic by bypassing CPU. If sessions aren\'t offloaded, CPU spikes.',
          'CLI: diagnose npu np6 session-stats — check offloaded vs. non-offloaded sessions.',
          'Reasons traffic won\'t offload: UTM inspection enabled, traffic shaping, multicast, IPv6 (on older NPs).',
          'To verify: disable UTM on a policy temporarily → check if sessions offload.',
          'Hardware limitation: certain FortiGate models have NP capacity limits — check datasheet.',
          'If NP errors: diagnose npu np6 anomaly — look for packet errors. May indicate hardware fault.',
          'For Susser Bank FortiGate alerts: reach out to Karthik, Otukho, Anirudh, or Perry.',
        ],
        aiPrompt: 'Sessions on our FortiGate are not being hardware-offloaded to the NP6/NP7 chip. Help me diagnose why and optimize offloading.',
      },
    ],
  },

  // ─── Carrier Routers & Modems ──────────────────────────────
  {
    id: 'carrier-cpe',
    label: 'Carrier Routers & Modems',
    icon: Server,
    blurb: 'ISP-provided CPE devices — Adtran, Calix, Nokia ONT, Cisco ISR, Zhone.',
    models: 'Adtran NetVanta · Calix 700GE/800GE · Nokia ONT (G-240G/G-010G) · Cisco ISR 1100/4000 · Zhone MXK',
    issues: [
      {
        title: 'Power cycle and LED status interpretation',
        tier: 'common',
        steps: [
          'Unplug the device from power, wait 30 seconds, reconnect.',
          'Power LED: solid green = normal. Blinking or off = power issue.',
          'WAN/DSL/Fiber LED: solid green = link up. Blinking = trying to sync. Off = no signal.',
          'LAN LED: solid/blinking green = connected client. Off = no device connected.',
          'Alarm LED (if present): red = critical fault. Amber = warning. Off = normal.',
          'If LEDs show no WAN: check the demarcation point (demarc) and report to carrier.',
        ],
        aiPrompt: 'Help me interpret the LED patterns on a carrier-provided router/modem and determine if the issue is the device or the circuit.',
      },
      {
        title: 'Factory reset procedure',
        tier: 'common',
        steps: [
          'WARNING: Factory reset will erase all configuration. Only do this if authorized.',
          'Most CPE: hold the reset button (small pinhole on back) for 10-15 seconds until LEDs flash.',
          'Cisco ISR: rommon mode → "confreg 0x2142" → reset → reconfigure.',
          'Adtran: hold reset button for 10 seconds or CLI "boot system factory-default".',
          'Nokia ONT: typically managed by the carrier — contact carrier NOC before resetting.',
          'After reset: device will need reconfiguration. Ensure you have the config backup.',
        ],
        aiPrompt: 'I need to factory reset a carrier-provided CPE device. Walk me through the procedure for common models and what to expect afterward.',
      },
      {
        title: 'PPPoE re-authentication failing',
        tier: 'intermediate',
        steps: [
          'Verify PPPoE credentials (username/password) are correct — check with carrier if unsure.',
          'CLI (Cisco): show pppoe session — check session status.',
          'Clear and re-establish: clear pppoe session → interface pppoe re-negotiate.',
          'Check VLAN tagging: some carriers require PPPoE on a specific VLAN (e.g., VLAN 201 for AT&T).',
          'Verify the MTU: PPPoE reduces effective MTU to 1492. Set interface MTU accordingly.',
          'If MAC-locked: carrier may have locked the PPPoE session to the old device MAC. Contact carrier to release.',
        ],
        aiPrompt: 'PPPoE authentication is failing on our carrier CPE. Help me verify credentials, VLAN tagging, and MTU settings.',
      },
      {
        title: 'DHCP vs. static IP configuration issues',
        tier: 'intermediate',
        steps: [
          'Check with carrier whether the circuit is DHCP or static IP.',
          'For DHCP: verify the WAN interface is set to "ip address dhcp". Run "release" then "renew".',
          'For static: verify IP, subnet mask, gateway, and DNS are configured exactly per carrier handoff sheet.',
          'Common mistake: entering the gateway IP as the interface IP, or wrong subnet mask.',
          'If DHCP is not assigning: check the carrier ONT/modem is in routing mode, not bridge mode.',
          'Verify no duplicate IP: ping the assigned IP from another device — if it responds before config, there is a conflict.',
        ],
        aiPrompt: 'Help me troubleshoot IP assignment issues on a carrier CPE — DHCP not assigning or static IP not routing correctly.',
      },
      {
        title: 'NAT/PAT issues — internal hosts cannot reach internet',
        tier: 'intermediate',
        steps: [
          'Verify NAT is configured: show ip nat translations (Cisco).',
          'Check the NAT inside/outside interfaces are assigned correctly.',
          'Verify the ACL for NAT matches the internal subnet.',
          'If double-NAT: the carrier modem may also be NATing. Put it in bridge mode or DMZ the router WAN IP.',
          'For PAT (overload): ensure "ip nat inside source list <acl> interface <wan> overload" is configured.',
          'Test: from an internal host, traceroute to 8.8.8.8 — check where the path stops.',
        ],
        aiPrompt: 'Internal hosts behind our carrier CPE cannot reach the internet. Help me diagnose NAT/PAT configuration issues.',
      },
      {
        title: 'Bridge mode configuration',
        tier: 'advanced',
        steps: [
          'Bridge mode makes the carrier modem/ONT a pure Layer 2 device — your router handles PPPoE/DHCP/NAT.',
          'AT&T BGW: Access the gateway at 192.168.1.254 → Firewall → IP Passthrough → enable for your router MAC.',
          'Comcast XB7/XB8: Log into admin portal or call Comcast to enable bridge mode. Device will reboot.',
          'Spectrum: Some modems are already in bridge mode. If not, call Spectrum to disable router functionality.',
          'After enabling bridge mode: your router WAN interface should get the public IP directly.',
          'Test: from your router, show ip interface → WAN should show a public IP, not 10.x or 192.168.x.',
          'Warning: bridge mode disables WiFi and LAN ports on the carrier device.',
        ],
        aiPrompt: 'I need to put a carrier modem into bridge mode so our router gets the public IP. Walk me through the process for common ISPs.',
      },
      {
        title: 'VLAN tagging to carrier / 802.1Q trunk',
        tier: 'advanced',
        steps: [
          'Some carriers deliver service on a tagged VLAN (e.g., AT&T uses VLAN 201 for residential fiber).',
          'Configure a sub-interface on the router: interface GigabitEthernet0/0.201 → encapsulation dot1Q 201.',
          'Assign the WAN IP/DHCP to the sub-interface, not the physical interface.',
          'Verify the physical interface has no IP and is "no shutdown".',
          'Test: show interface GigabitEthernet0/0.201 — should show "up/up" with correct IP.',
          'If VLAN tagged traffic is not passing: check the connecting cable goes directly to the ONT, not through an unmanaged switch.',
        ],
        aiPrompt: 'Our carrier requires VLAN tagging on the handoff. Help me configure 802.1Q sub-interfaces on the router.',
      },
      {
        title: 'MTU / MSS clamping for PPPoE and tunnels',
        tier: 'advanced',
        steps: [
          'PPPoE overhead reduces MTU from 1500 to 1492. Tunnels (GRE, IPSec) reduce further.',
          'Symptoms of MTU issues: large file transfers fail, HTTPS sites partially load, VoIP works but video breaks.',
          'Set interface MTU: interface <wan> → ip mtu 1492 (for PPPoE).',
          'Set TCP MSS clamping: ip tcp adjust-mss 1452 (for PPPoE) or lower for tunnels.',
          'Test: ping with DF bit set — "ping -f -l 1472 8.8.8.8" (Windows). Reduce size until ping succeeds.',
          'For IPSec over PPPoE: ip tcp adjust-mss 1380 is a safe starting point.',
          'Apply MSS clamping on the inside interface (LAN-facing), not the WAN.',
        ],
        aiPrompt: 'We are seeing intermittent connectivity issues that look like MTU problems (large transfers fail, small packets work). Help me set correct MTU and MSS clamping.',
      },
    ],
  },

  // ─── Combo Devices ─────────────────────────────────────────
  {
    id: 'combo',
    label: 'Combo Devices',
    icon: Monitor,
    blurb: 'All-in-one ISP modem + router + WiFi gateway units.',
    models: 'Comcast XB7/XB8 · AT&T BGW210/BGW320 · Verizon G3100/CR1000A · Spectrum SAC2V1K/SAX1V1K · T-Mobile 5G Gateway',
    issues: [
      {
        title: 'Reboot / power cycle',
        tier: 'common',
        steps: [
          'Unplug from power. Wait 30 seconds. Reconnect.',
          'If battery-backed (AT&T BGW): press and hold the red reset button briefly, or remove the battery pack before unplugging.',
          'Wait 2-3 minutes for full boot and WAN sync.',
          'Check all LEDs return to normal (see device-specific LED guide).',
          'Comcast XB7/XB8: solid white light = online and working. Blinking white = booting.',
          'AT&T BGW320: solid green broadband light = connected.',
        ],
        aiPrompt: 'Walk me through the reboot procedure and LED interpretation for common combo ISP gateway devices.',
      },
      {
        title: 'WiFi password reset',
        tier: 'common',
        steps: [
          'Default WiFi password is usually on the sticker on the device.',
          'Comcast: log into 10.0.0.1 → Connection → WiFi → Edit to change SSID/password.',
          'AT&T: log into 192.168.1.254 → Home Network → WiFi → change password.',
          'Verizon: log into 192.168.1.1 → WiFi Settings → change password.',
          'After changing: all connected devices will be disconnected and need to rejoin.',
          'Consider setting a strong WPA3/WPA2 password with AES encryption.',
        ],
        aiPrompt: 'How do I reset the WiFi password on common ISP combo devices?',
      },
      {
        title: 'Bridge mode / IP passthrough',
        tier: 'common',
        steps: [
          'Bridge mode makes the ISP device a pure modem — your own router handles routing/WiFi.',
          'Comcast XB7/XB8: log into 10.0.0.1 → Advanced → Bridge Mode → Enable. Or use the Xfinity app.',
          'AT&T BGW320: 192.168.1.254 → Firewall → IP Passthrough → Passthrough Mode: DHCPS-fixed → select your router MAC.',
          'Verizon G3100: does not support full bridge mode. Use DMZ or IP passthrough instead.',
          'Spectrum: call Spectrum to disable router/WiFi functionality, or request a modem-only device.',
          'After enabling: WiFi and routing on the ISP device will be disabled.',
          'Test: your router should receive the public WAN IP directly.',
        ],
        aiPrompt: 'I need to put an ISP combo device into bridge mode or IP passthrough for our enterprise router. Walk me through the steps for each ISP.',
      },
      {
        title: 'Double-NAT detection and resolution',
        tier: 'intermediate',
        steps: [
          'Double-NAT occurs when both the ISP device and your router are NATing traffic.',
          'Symptoms: VPN failures, online gaming issues, certain apps not working, Port forwarding not functioning.',
          'Detect: traceroute to 8.8.8.8 from a LAN device — if you see two private IP hops, you have double-NAT.',
          'Also: check your router WAN IP — if it is 10.x, 172.16-31.x, or 192.168.x, you are behind NAT.',
          'Fix: enable bridge mode / IP passthrough on the ISP device (see above).',
          'Alternative: set up a DMZ on the ISP device pointing to your router WAN IP.',
          'If bridge mode is not available: use the ISP device as the only router (disable routing on your device).',
        ],
        aiPrompt: 'I suspect we have a double-NAT situation with the ISP combo device and our router. Help me confirm and resolve it.',
      },
      {
        title: 'Port forwarding / DMZ configuration',
        tier: 'intermediate',
        steps: [
          'Port forwarding: forward specific external ports to an internal device IP:port.',
          'Comcast: 10.0.0.1 → Advanced → Port Forwarding → add rule (protocol, external port, internal IP, internal port).',
          'AT&T: 192.168.1.254 → Firewall → NAT/Gaming → add rule.',
          'Verizon: 192.168.1.1 → Firewall → Port Forwarding → add rule.',
          'DMZ: forwards ALL ports to a single internal IP — less secure but simpler.',
          'If port forwarding not working: disable SIP ALG, check if the ISP blocks the port, ensure no double-NAT.',
          'Verify with external port check tool: canyouseeme.org from outside the network.',
        ],
        aiPrompt: 'I need to set up port forwarding on an ISP combo device. Walk me through common ISPs and troubleshooting when it does not work.',
      },
      {
        title: 'Disabling ISP WiFi for enterprise AP deployment',
        tier: 'advanced',
        steps: [
          'When deploying Meraki/Ruckus/Aruba APs behind an ISP device, disable the ISP WiFi to avoid interference.',
          'Comcast XB7/XB8: 10.0.0.1 → Connection → WiFi → Disable both 2.4 GHz and 5 GHz. Or enable bridge mode.',
          'AT&T BGW320: 192.168.1.254 → Home Network → WiFi → uncheck "Wireless Enabled" for both bands.',
          'Verizon G3100: 192.168.1.1 → WiFi Settings → toggle off both bands.',
          'Also disable the ISP mesh/extender pods if any are connected.',
          'Verify: use a WiFi scanner app — the ISP SSID should no longer be broadcasting.',
          'If the ISP re-enables WiFi after firmware update: re-disable or request ISP to lock the setting.',
        ],
        aiPrompt: 'I need to disable WiFi on an ISP combo device because we are deploying enterprise APs. Walk me through each ISP and potential gotchas.',
      },
      {
        title: 'Extracting PPPoE credentials from ISP device',
        tier: 'advanced',
        steps: [
          'Some ISPs pre-configure PPPoE on the combo device. You may need the credentials to use your own router.',
          'AT&T: credentials are embedded in the BGW firmware. Use IP Passthrough instead of extracting PPPoE.',
          'CenturyLink/Lumen: often allows you to get PPPoE credentials from your account portal or by calling support.',
          'Frontier: request PPPoE username and password from Frontier business support.',
          'If no option to extract: use the ISP device in bridge/passthrough mode as the PPPoE client, and your router behind it.',
          'Note: using your own PPPoE client may void ISP support — verify with the carrier first.',
        ],
        aiPrompt: 'I need PPPoE credentials from the ISP device to set up our own router. What are my options for each major ISP?',
      },
      {
        title: 'Bypass mode (advanced ISP gateway replacement)',
        tier: 'advanced',
        steps: [
          'Bypass mode replaces the ISP device entirely with your own equipment.',
          'AT&T Fiber: requires 802.1X authentication. You need the ONT certificate or use wpa_supplicant to clone the BGW auth.',
          'Comcast: if using a DOCSIS modem, you can return the XB7/8 and use your own DOCSIS 3.1 modem.',
          'Verizon Fios: the ONT has an Ethernet port. Connect your router directly and call Verizon to switch from coax to Ethernet.',
          'Spectrum: request a modem-only device or use your own approved DOCSIS modem.',
          'Warning: bypassing the ISP device may void support. ISP will troubleshoot only up to the demarc.',
          'Verify all services still work after bypass (VoIP, IPTV, etc. may require the ISP device).',
        ],
        aiPrompt: 'I want to bypass the ISP combo device and use our own router directly on the fiber/coax. Walk me through the process and risks for each ISP.',
      },
    ],
  },
];

// ────────────────────────────────────────────────────────────────
// Component
// ────────────────────────────────────────────────────────────────

export default function NetworkDevicesPage() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState(CATEGORIES[0].id);
  const [search, setSearch] = useState('');
  const [expandedIssues, setExpandedIssues] = useState<Set<string>>(new Set());

  const activeCategory = CATEGORIES.find((c) => c.id === activeTab) ?? CATEGORIES[0];

  const filteredIssues = activeCategory.issues.filter((issue) => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return (
      issue.title.toLowerCase().includes(q) ||
      issue.steps.some((s) => s.toLowerCase().includes(q))
    );
  });

  const groupedByTier = (['common', 'intermediate', 'advanced'] as Tier[]).map((tier) => ({
    tier,
    issues: filteredIssues.filter((i) => i.tier === tier),
  }));

  const toggleIssue = (key: string) => {
    setExpandedIssues((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  };

  const handleAskAi = (prompt: string) => {
    const encoded = encodeURIComponent(prompt);
    navigate(`/ai-assistant?prefill=${encoded}`);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div>
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 bg-orange-100 dark:bg-orange-500/10 rounded-lg flex items-center justify-center">
            <Router className="w-5 h-5 text-orange-600 dark:text-orange-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
              vCom Provided Network Devices
            </h1>
            <p className="text-sm text-slate-500 dark:text-slate-400">
              Troubleshooting guides for all managed network equipment — tiered by difficulty
            </p>
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search issues, steps, device types..."
          className="input-base !pl-10 text-sm"
        />
      </div>

      {/* Tabs */}
      <div className="flex gap-1 overflow-x-auto pb-1 -mx-1 px-1">
        {CATEGORIES.map((cat) => {
          const Icon = cat.icon;
          const isActive = cat.id === activeTab;
          return (
            <button
              key={cat.id}
              onClick={() => { setActiveTab(cat.id); setSearch(''); }}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-orange-500 text-white shadow-sm'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              <Icon className="w-4 h-4" />
              {cat.label}
            </button>
          );
        })}
      </div>

      {/* Category Info */}
      <div className="card">
        <div className="flex items-start gap-3">
          <activeCategory.icon className="w-5 h-5 text-orange-500 mt-0.5 flex-shrink-0" />
          <div>
            <h2 className="font-semibold text-slate-900 dark:text-white">{activeCategory.label}</h2>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-0.5">{activeCategory.blurb}</p>
            <p className="text-xs text-slate-400 dark:text-slate-500 mt-1 font-mono">{activeCategory.models}</p>
          </div>
        </div>
      </div>

      {/* Issues by Tier */}
      {groupedByTier.map(({ tier, issues }) => {
        if (issues.length === 0) return null;
        const meta = TIER_META[tier];
        return (
          <div key={tier}>
            <div className="flex items-center gap-2 mb-3">
              <span className={`w-2.5 h-2.5 rounded-full ${meta.dot}`} />
              <h3 className={`text-sm font-semibold ${meta.color}`}>
                {meta.label} Issues
              </h3>
              <span className="text-xs text-slate-400">({issues.length})</span>
            </div>
            <div className="space-y-2">
              {issues.map((issue, idx) => {
                const key = `${tier}-${idx}`;
                const isOpen = expandedIssues.has(key);
                return (
                  <div key={key} className="card !p-0 overflow-hidden">
                    <button
                      onClick={() => toggleIssue(key)}
                      className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors"
                    >
                      {isOpen ? (
                        <ChevronDown className="w-4 h-4 text-slate-400 flex-shrink-0" />
                      ) : (
                        <ChevronRight className="w-4 h-4 text-slate-400 flex-shrink-0" />
                      )}
                      <span className="text-sm font-medium text-slate-800 dark:text-slate-200">
                        {issue.title}
                      </span>
                    </button>
                    {isOpen && (
                      <div className="px-4 pb-4 pt-1 ml-7 border-t border-slate-100 dark:border-slate-700/50">
                        <ol className="space-y-2">
                          {issue.steps.map((step, si) => (
                            <li key={si} className="flex gap-2 text-sm text-slate-600 dark:text-slate-300">
                              <span className="text-xs font-bold text-slate-400 mt-0.5 min-w-[18px]">{si + 1}.</span>
                              <span className="leading-relaxed">{step}</span>
                            </li>
                          ))}
                        </ol>
                        <button
                          onClick={() => handleAskAi(issue.aiPrompt)}
                          className="mt-3 flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-purple-50 dark:bg-purple-500/10 text-purple-600 dark:text-purple-400 hover:bg-purple-100 dark:hover:bg-purple-500/20 transition-colors"
                        >
                          <Sparkles className="w-3.5 h-3.5" />
                          Ask AI for more help
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        );
      })}

      {filteredIssues.length === 0 && (
        <div className="text-center py-12 text-slate-500 dark:text-slate-400 text-sm">
          No issues match your search. Try different keywords.
        </div>
      )}
    </div>
  );
}
