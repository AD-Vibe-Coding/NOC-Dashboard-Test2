import { useState } from 'react';
import { Wrench } from 'lucide-react';
import { MaintenanceForm } from '../components/maintenance/MaintenanceForm';
import { MaintenanceOutput } from '../components/maintenance/MaintenanceOutput';
import { parseMaintenanceEmail } from '../utils/maintenanceParser';
import { trackEvent } from '../lib/analytics/db';
import { useAuth } from '../hooks/useAuth';
import type { MaintenanceData, MaintenanceType } from '../types';

export default function MaintenancePage() {
  const { user } = useAuth();
  const [result, setResult] = useState<{ data: MaintenanceData; type: MaintenanceType } | null>(null);

  const handleGenerate = (rawEmail: string, type: MaintenanceType) => {
    const data = parseMaintenanceEmail(rawEmail);
    // Auto-detect type from carrier email if user left it as scheduled but email says emergency
    const lower = rawEmail.toLowerCase();
    let finalType = type;
    if (lower.includes('emergency maintenance') || lower.includes('demand maintenance') || lower.includes('emergency notification')) {
      finalType = 'emergency';
    }
    setResult({ data, type: finalType });
    if (user) trackEvent(user.id, 'maintenance', `generate_${finalType}`);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 bg-primary-100 dark:bg-primary-500/10 rounded-lg flex items-center justify-center">
            <Wrench className="w-5 h-5 text-primary-600 dark:text-primary-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Maintenance Note Generator</h1>
            <p className="text-sm text-slate-500 dark:text-slate-400">Paste a carrier email → get a vCom formatted customer notification</p>
          </div>
        </div>
      </div>

      <div className="card">
        <MaintenanceForm onGenerate={handleGenerate} />
      </div>

      {result && (
        <MaintenanceOutput data={result.data} type={result.type} />
      )}
    </div>
  );
}
