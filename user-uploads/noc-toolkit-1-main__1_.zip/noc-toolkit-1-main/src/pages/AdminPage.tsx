import { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { useLocation } from 'react-router-dom';
import {
  Shield, Users, Lock, Key, Check, X, Copy, RotateCcw,
  AlertTriangle, ChevronDown, Search, UserCheck, UserX, Clock,
  BadgeCheck, Eye, EyeOff, Bell, Send, Trash2, Megaphone,
  Info, CheckCircle, AlertCircle, Activity, RefreshCw, Wifi, WifiOff,
} from 'lucide-react';
import toast from 'react-hot-toast';
import { useAuth } from '../hooks/useAuth';
import { getAllUsers, adminResetPassword } from '../lib/auth/db';
import { approveRequest, rejectRequest, getAllRequests } from '../lib/auth/resetRequests';
import { useNotifications } from '../context/NotificationContext';
import { getAllNotificationsAdmin, deleteNotification, type Notification, type NotificationType } from '../lib/notifications/db';
import type { User } from '../types/auth';
import type { PasswordResetRequest } from '../lib/auth/resetRequests';
import { ROLE_LABELS } from '../types/auth';

// ─── Helpers ──────────────────────────────────────────────────────────────────
function genTempPassword() {
  const chars = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
  let out = 'Temp';
  for (let i = 0; i < 6; i++) out += chars[Math.floor(Math.random() * chars.length)];
  return out;
}

function getPwStatus(u: User) {
  if (u.mustChangePassword) return { label: 'Default / Reset', color: 'bg-amber-100 text-amber-700 dark:bg-amber-500/20 dark:text-amber-300' };
  return { label: 'Changed ✓', color: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-300' };
}

function timeAgo(iso: string) {
  const diff = Math.floor((Date.now() - new Date(iso).getTime()) / 1000);
  if (diff < 60) return 'just now';
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  return `${Math.floor(diff / 86400)}d ago`;
}

// ─── Sub-components ───────────────────────────────────────────────────────────
function RolePill({ role }: { role: User['role'] }) {
  const colors: Record<User['role'], string> = {
    super_admin: 'bg-violet-100 text-violet-700 dark:bg-violet-500/20 dark:text-violet-300',
    admin: 'bg-blue-100 text-blue-700 dark:bg-blue-500/20 dark:text-blue-300',
    user: 'bg-slate-100 text-slate-600 dark:bg-slate-700 dark:text-slate-300',
  };
  return <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-medium ${colors[role]}`}>{ROLE_LABELS[role]}</span>;
}

function NotifTypePill({ type }: { type: NotificationType }) {
  const map: Record<NotificationType, { label: string; className: string; Icon: typeof Info }> = {
    info:    { label: 'Info',    className: 'bg-blue-100 text-blue-700 dark:bg-blue-500/20 dark:text-blue-300',       Icon: Info },
    success: { label: 'Success', className: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-300', Icon: CheckCircle },
    warning: { label: 'Warning', className: 'bg-amber-100 text-amber-700 dark:bg-amber-500/20 dark:text-amber-300',   Icon: AlertTriangle },
    error:   { label: 'Error',   className: 'bg-red-100 text-red-700 dark:bg-red-500/20 dark:text-red-300',           Icon: AlertCircle },
    system:  { label: 'System',  className: 'bg-violet-100 text-violet-700 dark:bg-violet-500/20 dark:text-violet-300', Icon: Megaphone },
  };
  const { label, className, Icon } = map[type];
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium ${className}`}>
      <Icon className="w-3 h-3" /> {label}
    </span>
  );
}

// ─── Reset Password Modal ─────────────────────────────────────────────────────
function ResetPasswordModal({ target, onClose }: { target: User; onClose: () => void }) {
  const tempPw = '1234567'; // always reset to default — user must change on next login
  const [showPw, setShowPw] = useState(true);
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const { send } = useNotifications();
  const { user } = useAuth();

  const apply = async () => {
    setLoading(true);
    // Always resets to default password '1234567' — user must change on next login
    await adminResetPassword(target.id);
    send(target.id, 'Password Reset by Admin',
      `Your password has been reset to the default by ${user?.firstName} ${user?.lastName}. Log in with password: 1234567 and change it immediately.`,
      'warning', { link: '/settings' });
    setLoading(false);
    setDone(true);
    toast.success(`Password reset for ${target.firstName} ${target.lastName}`);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="w-full max-w-md bg-white dark:bg-slate-800 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-700">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-700">
          <div className="flex items-center gap-2">
            <Key className="w-5 h-5 text-amber-500" />
            <h2 className="text-base font-semibold text-slate-900 dark:text-white">Reset Password</h2>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="px-6 py-5 space-y-4">
          <div className="flex items-center gap-3 p-3 rounded-lg bg-slate-50 dark:bg-slate-700/50">
            <div className="w-9 h-9 rounded-full bg-primary-500 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
              {target.firstName[0]}{target.lastName[0]}
            </div>
            <div>
              <p className="text-sm font-semibold text-slate-900 dark:text-white">{target.firstName} {target.lastName}</p>
              <p className="text-xs text-slate-500 dark:text-slate-400">{target.email}</p>
            </div>
          </div>

          {!done ? (
            <>
              <div className="flex items-start gap-2 p-3 rounded-lg bg-amber-50 dark:bg-amber-500/10 border border-amber-200 dark:border-amber-500/20 text-xs text-amber-700 dark:text-amber-300">
                <AlertTriangle className="w-4 h-4 mt-0.5 flex-shrink-0" />
                User will be required to change this on next login. Share via a secure channel only.
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">Temporary Password</label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <input type={showPw ? 'text' : 'password'} value={tempPw} readOnly
                      className="input-base pr-10 font-mono text-sm bg-slate-50 dark:bg-slate-700/50" />
                    <button type="button" onClick={() => setShowPw(v => !v)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400">
                      {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  <button onClick={() => { navigator.clipboard.writeText(tempPw); toast.success('Copied!'); }}
                    className="px-3 py-2 rounded-lg bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-600 dark:text-slate-300 transition-colors">
                    <Copy className="w-4 h-4" />
                  </button>
                </div>
              </div>
              <div className="flex gap-2 pt-1">
                <button onClick={onClose} className="flex-1 px-4 py-2 rounded-lg text-sm font-medium border border-slate-200 dark:border-slate-600 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors">
                  Cancel
                </button>
                <button onClick={apply} disabled={loading} className="flex-1 btn-primary justify-center">
                  {loading ? <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Check className="w-4 h-4" />}
                  Apply Reset
                </button>
              </div>
            </>
          ) : (
            <div className="text-center py-4">
              <div className="w-12 h-12 bg-emerald-100 dark:bg-emerald-500/20 rounded-full flex items-center justify-center mx-auto mb-3">
                <Check className="w-6 h-6 text-emerald-600 dark:text-emerald-400" />
              </div>
              <p className="text-sm font-semibold text-slate-900 dark:text-white mb-1">Password reset applied!</p>
              <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">{target.firstName} will be notified and must change password on next login.</p>
              <button onClick={onClose} className="btn-primary">Done</button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── Compose Notification Panel ───────────────────────────────────────────────
function ComposeNotification({ users, onSent }: { users: User[]; onSent: () => void }) {
  const { send } = useNotifications();
  const [targetId, setTargetId] = useState<string>('all');
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [type, setType] = useState<NotificationType>('info');
  const [link, setLink] = useState('');
  const [sending, setSending] = useState(false);
  const [sendMode, setSendMode] = useState<'now' | 'scheduled'>('now');
  const [scheduledAt, setScheduledAt] = useState('');
  const [scheduledPending, setScheduledPending] = useState<ReturnType<typeof setTimeout> | null>(null);
  const [scheduledLabel, setScheduledLabel] = useState<string | null>(null);

  const doSend = useCallback(async () => {
    send(targetId, title.trim(), message.trim(), type, { link: link.trim() || undefined });
    toast.success(
      targetId === 'all'
        ? `📢 Broadcast sent — all users will see it within 30 seconds`
        : `✅ Notification sent to ${users.find(u => u.id === targetId)?.firstName ?? 'user'}`
    );
    setTitle(''); setMessage(''); setLink(''); setScheduledAt(''); setScheduledLabel(null);
    onSent();
  }, [targetId, title, message, type, link, send, users, onSent]);

  const handleSend = async () => {
    if (!title.trim() || !message.trim()) { toast.error('Title and message are required'); return; }

    if (sendMode === 'scheduled') {
      if (!scheduledAt) { toast.error('Please pick a date and time to schedule'); return; }
      const fireAt = new Date(scheduledAt);
      const delay = fireAt.getTime() - Date.now();
      if (delay <= 0) { toast.error('Scheduled time must be in the future'); return; }
      if (scheduledPending) clearTimeout(scheduledPending);
      const t = setTimeout(doSend, delay);
      setScheduledPending(t);
      setScheduledLabel(fireAt.toLocaleString());
      toast.success(`⏰ Scheduled for ${fireAt.toLocaleString()}`, { duration: 6000 });
      setSending(false);
      return;
    }

    setSending(true);
    await doSend();
    setSending(false);
  };

  const cancelScheduled = () => {
    if (scheduledPending) clearTimeout(scheduledPending);
    setScheduledPending(null);
    setScheduledLabel(null);
    toast('Scheduled notification cancelled');
  };

  return (
    <div className="card space-y-4">
      <div className="flex items-center gap-2 mb-1">
        <Megaphone className="w-4 h-4 text-violet-500" />
        <h3 className="text-sm font-semibold text-slate-900 dark:text-white">Compose Notification</h3>
        <span className="text-[10px] text-slate-400">Admins &amp; Super Admins only</span>
      </div>

      {/* Scheduled pending banner */}
      {scheduledLabel && (
        <div className="flex items-center justify-between gap-3 px-3 py-2 rounded-lg bg-amber-50 dark:bg-amber-500/10 border border-amber-200 dark:border-amber-500/30 text-xs text-amber-700 dark:text-amber-300">
          <span className="flex items-center gap-1.5"><Clock className="w-3.5 h-3.5" /> Scheduled for <strong>{scheduledLabel}</strong></span>
          <button onClick={cancelScheduled} className="text-red-500 hover:underline text-[11px] font-medium">Cancel</button>
        </div>
      )}

      {/* Send mode toggle */}
      <div className="flex rounded-lg overflow-hidden border border-slate-200 dark:border-slate-700 w-fit">
        <button
          onClick={() => setSendMode('now')}
          className={`px-4 py-1.5 text-xs font-medium transition-colors ${sendMode === 'now' ? 'bg-primary-500 text-white' : 'bg-white dark:bg-slate-800 text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700'}`}
        >
          ⚡ Send Now
        </button>
        <button
          onClick={() => setSendMode('scheduled')}
          className={`px-4 py-1.5 text-xs font-medium transition-colors ${sendMode === 'scheduled' ? 'bg-amber-500 text-white' : 'bg-white dark:bg-slate-800 text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700'}`}
        >
          ⏰ Schedule
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Send To</label>
          <select value={targetId} onChange={e => setTargetId(e.target.value)} className="input-base w-full">
            <option value="all">📢 All Users (Broadcast)</option>
            <optgroup label="Specific User">
              {users.map(u => (
                <option key={u.id} value={u.id}>{u.firstName} {u.lastName} ({ROLE_LABELS[u.role]})</option>
              ))}
            </optgroup>
          </select>
        </div>
        <div>
          <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Type</label>
          <select value={type} onChange={e => setType(e.target.value as NotificationType)} className="input-base w-full">
            <option value="info">ℹ️ Info</option>
            <option value="success">✅ Success</option>
            <option value="warning">⚠️ Warning</option>
            <option value="error">🚨 Alert / Error</option>
            <option value="system">📢 System Announcement</option>
          </select>
        </div>
      </div>

      {/* Scheduled time picker — only when mode is scheduled */}
      {sendMode === 'scheduled' && (
        <div>
          <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
            Schedule Date & Time <span className="text-red-400">*</span>
          </label>
          <input
            type="datetime-local"
            value={scheduledAt}
            onChange={e => setScheduledAt(e.target.value)}
            min={new Date(Date.now() + 60000).toISOString().slice(0, 16)}
            className="input-base w-full"
          />
          <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-0.5">
            The notification will fire automatically at this time (keep this tab open)
          </p>
        </div>
      )}

      <div>
        <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Title <span className="text-red-400">*</span></label>
        <input type="text" value={title} onChange={e => setTitle(e.target.value)}
          placeholder="e.g. Scheduled Maintenance Tonight"
          maxLength={80}
          className="input-base w-full" />
      </div>

      <div>
        <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Message <span className="text-red-400">*</span></label>
        <textarea value={message} onChange={e => setMessage(e.target.value)}
          placeholder="e.g. The NOC Toolkit will be down for maintenance from 11PM–1AM PST tonight."
          rows={3}
          maxLength={400}
          className="input-base w-full resize-none" />
        <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-0.5 text-right">{message.length}/400</p>
      </div>

      <div>
        <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Link (optional)</label>
        <input type="text" value={link} onChange={e => setLink(e.target.value)}
          placeholder="e.g. /settings or /noc-tools"
          className="input-base w-full" />
        <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-0.5">Internal path only — users can click to navigate directly</p>
      </div>

      <button onClick={handleSend} disabled={sending || !title.trim() || !message.trim()} className={`w-full justify-center ${sendMode === 'scheduled' ? 'btn-secondary border-amber-400 text-amber-600 dark:text-amber-400' : 'btn-primary'}`}>
        {sending
          ? <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
          : sendMode === 'scheduled' ? <Clock className="w-4 h-4" /> : <Send className="w-4 h-4" />}
        {sendMode === 'scheduled' ? 'Schedule Notification' : targetId === 'all' ? 'Broadcast to All Users' : 'Send Now'}
      </button>
    </div>
  );
}

// ─── Main Admin Page ──────────────────────────────────────────────────────────
export default function AdminPage() {
  const { user, isSuperAdmin, isAdmin } = useAuth();
  const { refresh: refreshNotifs, send } = useNotifications();
  const [users, setUsers] = useState<User[]>([]);
  const [requests, setRequests] = useState<PasswordResetRequest[]>([]);
  const [allNotifs, setAllNotifs] = useState<Notification[]>([]);
  const [search, setSearch] = useState('');
  const [resetTarget, setResetTarget] = useState<User | null>(null);

  const location = useLocation();
  const validTabs = ['users', 'requests', 'notifications', 'keepalive', 'roles'] as const;
  type TabKey = typeof validTabs[number];
  const urlTab = useMemo(() => {
    const t = new URLSearchParams(location.search).get('tab');
    return validTabs.includes(t as TabKey) ? (t as TabKey) : 'users';
  }, [location.search]);
  const [tab, setTab] = useState<TabKey>(urlTab);

  // Sync tab when URL changes (e.g. notification click navigates to /admin?tab=requests)
  useEffect(() => { setTab(urlTab); }, [urlTab]);

  const load = useCallback(async () => {
    const [u, r, n] = await Promise.all([
      getAllUsers(),
      getAllRequests(),
      getAllNotificationsAdmin(),
    ]);
    setUsers(u);
    setRequests(r);
    setAllNotifs(n);
  }, []);

  useEffect(() => { load(); }, [load]);

  // ── Guard ──────────────────────────────────────────────────────────────────
  if (!isAdmin) {
    return (
      <div className="max-w-xl mx-auto mt-20 text-center">
        <Shield className="w-12 h-12 text-slate-400 mx-auto mb-4" />
        <h2 className="text-lg font-semibold text-slate-900 dark:text-white mb-2">Access Restricted</h2>
        <p className="text-sm text-slate-500">Admin or Super Admin access required.</p>
      </div>
    );
  }

  const filtered = users.filter(u =>
    `${u.firstName} ${u.lastName} ${u.email} ${u.role}`.toLowerCase().includes(search.toLowerCase())
  );
  const pendingCount = requests.filter(r => r.status === 'pending').length;
  const changedCount = users.filter(u => !u.mustChangePassword).length;

  const handleApprove = async (req: PasswordResetRequest) => {
    // Always reset to default '1234567' — user must change on next login
    await adminResetPassword(req.userId);
    await approveRequest(req.id, `${user!.firstName} ${user!.lastName}`);
    await send(req.userId, 'Password Reset Approved',
      `Your reset was approved by ${user!.firstName}. Log in with password: 1234567 and change it immediately in Settings.`,
      'success', { link: '/settings' });
    load(); refreshNotifs();
    toast.success('Approved! User password reset to: 1234567', { duration: 8000, icon: '🔑' });
  };

  const handleReject = async (req: PasswordResetRequest) => {
    await rejectRequest(req.id, `${user!.firstName} ${user!.lastName}`);
    await send(req.userId, 'Password Reset Rejected', `Your reset was reviewed by ${user!.firstName}. Contact them directly if you still need access.`, 'warning');
    load(); refreshNotifs();
    toast.success('Request rejected');
  };

  const handleDeleteNotif = async (id: string) => {
    await deleteNotification(id);
    load(); refreshNotifs();
  };

  const TABS = [
    { key: 'users' as const,         label: 'Users',             icon: Users,     badge: null },
    { key: 'requests' as const,      label: 'Password Resets',   icon: Key,       badge: pendingCount || null },
    { key: 'notifications' as const, label: 'Notifications',     icon: Bell,      badge: null },
    { key: 'keepalive' as const,     label: 'Keep-Alive',        icon: Activity,  badge: null },
    ...(isSuperAdmin ? [{ key: 'roles' as const, label: 'Roles', icon: BadgeCheck, badge: null }] : []),
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-violet-100 dark:bg-violet-500/10 rounded-lg flex items-center justify-center">
            <Shield className="w-5 h-5 text-violet-600 dark:text-violet-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Admin Controls</h1>
            <p className="text-sm text-slate-500 dark:text-slate-400">
              {users.length} users · {changedCount} passwords changed · {pendingCount} pending reset{pendingCount !== 1 ? 's' : ''}
            </p>
          </div>
        </div>
        {pendingCount > 0 && (
          <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-amber-100 dark:bg-amber-500/20 text-amber-700 dark:text-amber-300 text-xs font-semibold animate-pulse">
            <AlertTriangle className="w-3.5 h-3.5" />
            {pendingCount} pending reset{pendingCount > 1 ? 's' : ''} need approval
          </span>
        )}
      </div>

      {/* Tab bar */}
      <div className="flex gap-1 border-b border-slate-200 dark:border-slate-700 overflow-x-auto">
        {TABS.map(t => {
          const Icon = t.icon;
          return (
            <button key={t.key} onClick={() => setTab(t.key)}
              className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 -mb-px transition-colors whitespace-nowrap ${
                tab === t.key
                  ? 'border-violet-500 text-violet-600 dark:text-violet-400'
                  : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-300'
              }`}>
              <Icon className="w-4 h-4" />
              {t.label}
              {t.badge != null && t.badge > 0 && (
                <span className="w-5 h-5 rounded-full bg-amber-500 text-white text-[10px] flex items-center justify-center font-bold">
                  {t.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* ── Tab: Users ─────────────────────────────────────────────────────────── */}
      {tab === 'users' && (
        <div className="space-y-4">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input type="text" value={search} onChange={e => setSearch(e.target.value)}
              placeholder="Search by name, email or role…" className="input-base pl-9" />
          </div>

          <div className="card !p-0 overflow-x-auto">
            <table className="w-full text-sm min-w-[480px]">
              <thead className="bg-slate-50 dark:bg-slate-700/40 border-b border-slate-200 dark:border-slate-700">
                <tr>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 dark:text-slate-400">User</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 dark:text-slate-400 hidden sm:table-cell">Role</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 dark:text-slate-400">Password</th>
                  <th className="text-right px-4 py-3 text-xs font-semibold text-slate-500 dark:text-slate-400">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-700/50">
                {filtered.map(u => {
                  const pw = getPwStatus(u);
                  const isMe = u.id === user?.id;
                  return (
                    <tr key={u.id} className={`hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors ${isMe ? 'bg-primary-50/30 dark:bg-primary-500/5' : ''}`}>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0 ${
                            u.role === 'super_admin' ? 'bg-violet-500' : u.role === 'admin' ? 'bg-blue-500' : 'bg-slate-400'
                          }`}>{u.firstName[0]}{u.lastName[0]}</div>
                          <div className="min-w-0">
                            <p className="text-sm font-medium text-slate-900 dark:text-white">
                              {u.firstName} {u.lastName}
                              {isMe && <span className="ml-1 text-[10px] text-primary-500 font-semibold">(you)</span>}
                            </p>
                            <p className="text-xs text-slate-500 dark:text-slate-400 truncate">{u.email}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 hidden sm:table-cell"><RolePill role={u.role} /></td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-medium ${pw.color}`}>{pw.label}</span>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <button onClick={() => setResetTarget(u)}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-amber-50 hover:bg-amber-100 dark:bg-amber-500/10 dark:hover:bg-amber-500/20 text-amber-700 dark:text-amber-300 transition-colors border border-amber-200 dark:border-amber-500/20">
                          <RotateCcw className="w-3 h-3" /> Reset PW
                        </button>
                      </td>
                    </tr>
                  );
                })}
                {filtered.length === 0 && (
                  <tr><td colSpan={4} className="px-4 py-8 text-center text-sm text-slate-500 dark:text-slate-400">No users found.</td></tr>
                )}
              </tbody>
            </table>
          </div>
          <p className="text-xs text-slate-400 dark:text-slate-500">
            {users.length} total users · {changedCount} have changed from default
          </p>
        </div>
      )}

      {/* ── Tab: Password Reset Requests ─────────────────────────────────────── */}
      {tab === 'requests' && (
        <div className="space-y-4">
          {requests.length === 0 ? (
            <div className="card text-center py-12">
              <Lock className="w-10 h-10 text-slate-300 dark:text-slate-600 mx-auto mb-3" />
              <p className="text-sm font-semibold text-slate-500 dark:text-slate-400">No password reset requests yet</p>
              <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">When a user requests a reset it will appear here.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {requests.map(req => (
                <div key={req.id} className={`card flex items-center gap-4 flex-wrap ${req.status === 'pending' ? 'border-l-4 border-amber-400' : ''}`}>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="text-sm font-semibold text-slate-900 dark:text-white">{req.userName}</p>
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium ${
                        req.status === 'pending'  ? 'bg-amber-100 text-amber-700 dark:bg-amber-500/20 dark:text-amber-300' :
                        req.status === 'approved' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-300' :
                        'bg-red-100 text-red-700 dark:bg-red-500/20 dark:text-red-300'
                      }`}>{req.status}</span>
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400">{req.userEmail}</p>
                    <div className="flex items-center gap-1 mt-1 text-[11px] text-slate-400 dark:text-slate-500">
                      <Clock className="w-3 h-3" />
                      {new Date(req.requestedAt).toLocaleString()}
                      {req.approvedBy && ` · ${req.status} by ${req.approvedBy}`}
                    </div>
                  </div>
                  {req.status === 'pending' && (
                    <div className="flex gap-2 flex-shrink-0">
                      <button onClick={() => handleApprove(req)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-500/10 dark:hover:bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 transition-colors">
                        <UserCheck className="w-3.5 h-3.5" /> Approve
                      </button>
                      <button onClick={() => handleReject(req)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-red-50 hover:bg-red-100 dark:bg-red-500/10 dark:hover:bg-red-500/20 text-red-700 dark:text-red-300 transition-colors">
                        <UserX className="w-3.5 h-3.5" /> Reject
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ── Tab: Notifications ───────────────────────────────────────────────── */}
      {tab === 'notifications' && (
        <div className="space-y-6">
          {/* Compose */}
          {/* Supabase requirement notice */}
          <div className="flex items-start gap-2 p-3 rounded-lg bg-blue-50 dark:bg-blue-500/10 border border-blue-200 dark:border-blue-500/20 text-xs text-blue-700 dark:text-blue-300">
            <Info className="w-3.5 h-3.5 mt-0.5 flex-shrink-0" />
            <div>
              <strong>Cross-browser delivery requires the Supabase table.</strong> If you haven't run the SQL yet, run this in Supabase SQL Editor:
              <pre className="mt-1.5 bg-blue-100 dark:bg-blue-900/30 rounded p-2 text-[10px] overflow-x-auto whitespace-pre-wrap font-mono select-all">{`CREATE TABLE IF NOT EXISTS notifications (
  id text PRIMARY KEY, target_user_id text NOT NULL,
  title text NOT NULL, message text NOT NULL,
  type text NOT NULL DEFAULT 'info', read boolean NOT NULL DEFAULT false,
  link text, created_at timestamptz NOT NULL DEFAULT now(),
  created_by text, created_by_name text
);
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;`}</pre>
              <p className="mt-1 opacity-80">Once created, notifications will reach other users within <strong>30 seconds</strong>.</p>
            </div>
          </div>

          <ComposeNotification users={users} onSent={() => { load(); refreshNotifs(); }} />

          {/* History */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-2">
                <Bell className="w-4 h-4" /> Sent Notifications
                <span className="text-xs font-normal text-slate-400">({allNotifs.length} total)</span>
              </h3>
              {allNotifs.length > 0 && (
                <button onClick={() => { load(); }} className="text-xs text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition-colors">
                  Refresh
                </button>
              )}
            </div>

            {allNotifs.length === 0 ? (
              <div className="card text-center py-10">
                <Bell className="w-8 h-8 text-slate-300 dark:text-slate-600 mx-auto mb-2" />
                <p className="text-sm text-slate-500 dark:text-slate-400">No notifications sent yet</p>
              </div>
            ) : (
              <div className="card !p-0 overflow-hidden">
                <div className="divide-y divide-slate-100 dark:divide-slate-700/40 max-h-96 overflow-y-auto">
                  {allNotifs.slice(0, 50).map(n => (
                    <div key={n.id} className="flex items-start gap-3 px-4 py-3 hover:bg-slate-50 dark:hover:bg-slate-700/20 transition-colors group">
                      <div className="mt-0.5 flex-shrink-0">
                        <NotifTypePill type={n.type} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-semibold text-slate-900 dark:text-white">{n.title}</p>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 line-clamp-1">{n.message}</p>
                        <div className="flex items-center gap-2 mt-1 text-[10px] text-slate-400 dark:text-slate-500">
                          <span>{timeAgo(n.createdAt)}</span>
                          <span>·</span>
                          <span>To: {n.targetUserId === 'all' ? '📢 All Users' : users.find(u => u.id === n.targetUserId)?.firstName + ' ' + users.find(u => u.id === n.targetUserId)?.lastName || n.targetUserId}</span>
                          {n.read && <span className="text-emerald-500">· read</span>}
                        </div>
                      </div>
                      <button onClick={() => handleDeleteNotif(n.id)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10 opacity-0 group-hover:opacity-100 transition-all flex-shrink-0">
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ── Tab: Role Management ─────────────────────────────────────────────── */}
      {tab === 'roles' && isSuperAdmin && (
        <div className="space-y-4">
          <div className="flex items-start gap-2 p-3 rounded-lg bg-violet-50 dark:bg-violet-500/10 border border-violet-200 dark:border-violet-500/20">
            <Shield className="w-4 h-4 text-violet-500 mt-0.5 flex-shrink-0" />
            <p className="text-xs text-violet-700 dark:text-violet-300 leading-relaxed">
              Role changes are immediate. <strong>Super Admin</strong> = full access.
              <strong> Admin</strong> = manage users + passwords. <strong>User</strong> = standard NOC tools.
            </p>
          </div>
          <div className="card !p-0 overflow-x-auto">
            <table className="w-full text-sm min-w-[400px]">
              <thead className="bg-slate-50 dark:bg-slate-700/40 border-b border-slate-200 dark:border-slate-700">
                <tr>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 dark:text-slate-400">User</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 dark:text-slate-400">Current Role</th>
                  <th className="text-right px-4 py-3 text-xs font-semibold text-slate-500 dark:text-slate-400">Change Role</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-700/50">
                {users.map(u => {
                  const isMe = u.id === user?.id;
                  return (
                    <tr key={u.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <div className={`w-7 h-7 rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0 ${
                            u.role === 'super_admin' ? 'bg-violet-500' : u.role === 'admin' ? 'bg-blue-500' : 'bg-slate-400'
                          }`}>{u.firstName[0]}{u.lastName[0]}</div>
                          <span className="text-sm font-medium text-slate-900 dark:text-white">
                            {u.firstName} {u.lastName}
                            {isMe && <span className="ml-1 text-[10px] text-primary-500">(you)</span>}
                          </span>
                        </div>
                      </td>
                      <td className="px-4 py-3"><RolePill role={u.role} /></td>
                      <td className="px-4 py-3 text-right">
                        {isMe
                          ? <span className="text-xs text-slate-400 italic">Cannot change own role</span>
                          : <RoleSelector targetUser={u} onChanged={load} currentUser={user!} />
                        }
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ── Tab: Keep-Alive ──────────────────────────────────────────────────── */}
      {tab === 'keepalive' && isAdmin && <SandboxKeepAlive />}

      {/* Reset password modal */}
      {resetTarget && (
        <ResetPasswordModal
          target={resetTarget}
          onClose={() => { setResetTarget(null); load(); }}
        />
      )}
    </div>
  );
}

// ─── Sandbox Keep-Alive Component ────────────────────────────────────────────
const SANDBOXES = [
  {
    id: 'sriram',
    label: "Sriram's Sandbox",
    devs: 'https://devs.ai/shared/c4c97493-3c29-4ff4-a6bc-1f4c2444c97c',
    vercel: 'https://sb-588rfyfw5y3s.vercel.run/',
    owner: 'sriram.parisa@appdirect.com',
    note: 'Primary NOC Toolkit',
  },
  {
    id: 'manager',
    label: "Manager's Sandbox",
    devs: 'https://devs.ai/shared/6ece0510-8e7b-4e64-8879-75008e676ef9',
    vercel: 'https://sb-48rvj5c9ycdl.vercel.run/',
    owner: 'anirudh.kukudala@appdirect.com',
    note: 'Manager Dashboard',
  },
];

const PING_INTERVAL_MS = 5 * 60 * 1000; // 5 minutes

type ReachState = 'idle' | 'pinging' | 'reachable' | 'unavailable';
type HttpState  = 'idle' | 'checking' | 'alive' | 'sleeping' | 'stopped' | 'error';

type SandboxStatus = {
  reach: ReachState;       // no-cors client-side result
  http: HttpState;         // server-side proxy result
  httpCode: number | null;
  responseMs: number | null;
  lastChecked: Date | null;
};

function SandboxKeepAlive() {
  const INTERVAL = PING_INTERVAL_MS / 1000; // seconds
  const [countdown, setCountdown]   = useState(INTERVAL);
  const [pingCount, setPingCount]   = useState(0);
  const [lastPinged, setLastPinged] = useState<Date | null>(null);
  const [log, setLog]               = useState<string[]>([]);
  const [iframeKey, setIframeKey]   = useState(0); // increment to force iframe reload
  const [statuses, setStatuses]     = useState<Record<string, SandboxStatus>>(
    Object.fromEntries(SANDBOXES.map(s => [s.id, {
      reach: 'idle', http: 'idle', httpCode: null, responseMs: null, lastChecked: null,
    }]))
  );

  const addLog = useCallback((msg: string) =>
    setLog(prev => [`[${new Date().toLocaleTimeString()}] ${msg}`, ...prev].slice(0, 40)), []);

  // ── Dual-path ping: no-cors (browser) + server-side proxy ────────────────
  const pingSingle = useCallback(async (s: typeof SANDBOXES[0]) => {
    // Mark as pinging
    setStatuses(prev => ({
      ...prev,
      [s.id]: { ...prev[s.id], reach: 'pinging', http: 'checking' },
    }));

    // 1️⃣  Client-side no-cors fetch (exactly as user's HTML code)
    //     Always resolves if server sends ANY response → "Reachable"
    //     Throws only on total network failure → "Unavailable"
    const clientPing = fetch(s.vercel, { method: 'GET', mode: 'no-cors' })
      .then(() => 'reachable' as const)
      .catch(() => 'unavailable' as const);

    // 2️⃣  Server-side proxy fetch — gives REAL HTTP status code
    const start = Date.now();
    const serverPing = fetch(`/api/sandbox-ping?url=${encodeURIComponent(s.vercel)}`, { cache: 'no-store' })
      .then(r => r.json() as Promise<{ ok: boolean; status: number; error: string | null }>)
      .catch(() => ({ ok: false, status: 0, error: 'proxy error' }));

    const [reach, data] = await Promise.all([clientPing, serverPing]);
    const ms      = Date.now() - start;
    const code    = (data as any).status as number;

    let http: HttpState = 'alive';
    if      (code === 410)              http = 'stopped';
    else if (code === 502 || code === 503) http = 'sleeping';
    else if (code === 0 || !(data as any).ok) http = 'error';

    setStatuses(prev => ({
      ...prev,
      [s.id]: { reach, http, httpCode: code || null, responseMs: ms, lastChecked: new Date() },
    }));

    const reachLabel = reach === 'reachable' ? '✓ Reachable' : '✗ Unavailable';
    addLog(`${s.label} → Browser: ${reachLabel} | HTTP ${code || '?'} (${ms}ms) → ${http.toUpperCase()}`);
  }, [addLog]);

  const pingAll = useCallback(async () => {
    addLog('━━ Pinging all sandboxes ━━');
    await Promise.all(SANDBOXES.map(s => pingSingle(s)));
    setPingCount(c => c + 1);
    setLastPinged(new Date());
    setCountdown(INTERVAL);
    setIframeKey(k => k + 1); // force iframe reload — best way to wake sandbox
  }, [pingSingle, addLog, INTERVAL]);

  // Auto-ping on mount + every 5 min
  useEffect(() => {
    pingAll();
    const id = setInterval(pingAll, PING_INTERVAL_MS);
    return () => clearInterval(id);
  }, [pingAll]);

  // Countdown ticker
  useEffect(() => {
    const id = setInterval(() => setCountdown(c => (c <= 1 ? INTERVAL : c - 1)), 1000);
    return () => clearInterval(id);
  }, [INTERVAL]);

  const fmt = (s: number) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;

  // Combined badge — uses HTTP status as ground truth, browser reach as fallback
  const badge = (st: SandboxStatus) => {
    if (st.http === 'checking' || st.reach === 'pinging')
      return { label: '↻ Pinging…', cls: 'bg-blue-100 text-blue-700 dark:bg-blue-500/20 dark:text-blue-300 animate-pulse', dot: 'bg-blue-400 animate-pulse', border: 'border-slate-200 dark:border-slate-700' };
    if (st.http === 'stopped')
      return { label: '✕ Stopped (410)', cls: 'bg-red-100 text-red-700 dark:bg-red-500/20 dark:text-red-300', dot: 'bg-red-500', border: 'border-red-300 dark:border-red-500/40' };
    if (st.http === 'sleeping')
      return { label: '◑ Sleeping (502)', cls: 'bg-amber-100 text-amber-700 dark:bg-amber-500/20 dark:text-amber-300', dot: 'bg-amber-500 animate-pulse', border: 'border-amber-300 dark:border-amber-500/40' };
    if (st.reach === 'reachable' || st.http === 'alive')
      return { label: '● Alive', cls: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-300', dot: 'bg-emerald-500 animate-pulse', border: 'border-emerald-300 dark:border-emerald-500/40' };
    if (st.reach === 'unavailable')
      return { label: '✗ Unavailable', cls: 'bg-red-100 text-red-700 dark:bg-red-500/20 dark:text-red-300', dot: 'bg-red-500', border: 'border-red-300 dark:border-red-500/40' };
    return { label: '○ Idle', cls: 'bg-slate-100 text-slate-500 dark:bg-slate-700 dark:text-slate-400', dot: 'bg-slate-400', border: 'border-slate-200 dark:border-slate-700' };
  };

  return (
    <div className="space-y-5">

      {/* ── Header ────────────────────────────────────────────────────────── */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-2 flex-wrap">
          <Activity className="w-4 h-4 text-emerald-500 animate-pulse" />
          <span className="text-sm font-semibold text-slate-900 dark:text-white">Sandbox Keep-Alive</span>
          <span className="text-xs text-slate-400">Auto-pings every 5 min — keep this page open on a NOC screen</span>
        </div>
        <button onClick={pingAll}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-primary-500 hover:bg-primary-600 text-white transition-colors">
          <RefreshCw className="w-3.5 h-3.5" /> Ping Now
        </button>
      </div>

      {/* ── Stats row ────────────────────────────────────────────────────── */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: 'Next Ping In', value: fmt(countdown), cls: 'text-primary-600 dark:text-primary-400' },
          { label: 'Total Pings',  value: String(pingCount), cls: 'text-emerald-600 dark:text-emerald-400' },
          { label: 'Last Pinged',  value: lastPinged ? lastPinged.toLocaleTimeString() : '—', cls: 'text-slate-700 dark:text-slate-200 text-sm' },
        ].map(c => (
          <div key={c.label} className="card text-center py-4 border border-slate-200 dark:border-slate-700">
            <p className="text-[10px] text-slate-400 uppercase tracking-widest mb-1">{c.label}</p>
            <p className={`text-2xl font-mono font-bold ${c.cls}`}>{c.value}</p>
          </div>
        ))}
      </div>

      {/* ── Sandbox cards ────────────────────────────────────────────────── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {SANDBOXES.map(s => {
          const st  = statuses[s.id];
          const b   = badge(st);
          return (
            <div key={s.id} className={`card border-2 space-y-3 ${b.border}`}>

              {/* Card header */}
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="text-sm font-bold text-slate-900 dark:text-white">{s.label}</p>
                  <p className="text-[10px] text-slate-400 mt-0.5">{s.owner}</p>
                </div>
                <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold whitespace-nowrap ${b.cls}`}>
                  <span className={`w-2 h-2 rounded-full ${b.dot}`} />
                  {b.label}
                </span>
              </div>

              {/* Status rows */}
              <div className="space-y-1.5 text-[11px]">
                <div className="flex items-center justify-between px-2 py-1 rounded-md bg-slate-50 dark:bg-slate-800/50">
                  <span className="text-slate-500">Browser (no-cors)</span>
                  <span className={`font-semibold ${st.reach === 'reachable' ? 'text-emerald-600 dark:text-emerald-400' : st.reach === 'unavailable' ? 'text-red-600 dark:text-red-400' : 'text-slate-400'}`}>
                    {st.reach === 'reachable' ? '✓ Reachable' : st.reach === 'unavailable' ? '✗ Unavailable' : st.reach === 'pinging' ? '↻ Checking…' : '— Idle'}
                  </span>
                </div>
                <div className="flex items-center justify-between px-2 py-1 rounded-md bg-slate-50 dark:bg-slate-800/50">
                  <span className="text-slate-500">Server (real HTTP)</span>
                  <span className={`font-semibold font-mono ${
                    st.http === 'alive' ? 'text-emerald-600 dark:text-emerald-400' :
                    st.http === 'stopped' ? 'text-red-600 dark:text-red-400' :
                    st.http === 'sleeping' ? 'text-amber-600 dark:text-amber-400' :
                    st.http === 'checking' ? 'text-blue-500 animate-pulse' : 'text-slate-400'
                  }`}>
                    {st.http === 'checking' ? '↻ Checking…' : st.httpCode ? `HTTP ${st.httpCode}` : '— Idle'}
                  </span>
                </div>
                {st.responseMs != null && (
                  <div className="flex items-center justify-between px-2 py-1 rounded-md bg-slate-50 dark:bg-slate-800/50">
                    <span className="text-slate-500">Response time</span>
                    <span className="font-mono text-slate-600 dark:text-slate-300">{st.responseMs}ms</span>
                  </div>
                )}
              </div>

              {/* Status callout */}
              {st.http === 'stopped' && (
                <div className="flex items-start gap-1.5 p-2 rounded-lg bg-red-50 dark:bg-red-500/10 text-[10px] text-red-700 dark:text-red-300">
                  <AlertTriangle className="w-3 h-3 mt-0.5 flex-shrink-0" />
                  <span><strong>410 SANDBOX_STOPPED</strong> — Permanently killed. Needs manual restart inside Devs.ai. No ping can revive it.</span>
                </div>
              )}
              {st.http === 'sleeping' && (
                <div className="flex items-start gap-1.5 p-2 rounded-lg bg-amber-50 dark:bg-amber-500/10 text-[10px] text-amber-700 dark:text-amber-300">
                  <Info className="w-3 h-3 mt-0.5 flex-shrink-0" />
                  <span><strong>502 Sleeping</strong> — Ping sent to wake it. Open the link in 10–15 seconds and it should load.</span>
                </div>
              )}
              {st.http === 'alive' && (
                <div className="flex items-start gap-1.5 p-2 rounded-lg bg-emerald-50 dark:bg-emerald-500/10 text-[10px] text-emerald-700 dark:text-emerald-300">
                  <CheckCircle className="w-3 h-3 mt-0.5 flex-shrink-0" />
                  <span><strong>200 Alive</strong> — Sandbox is running. Team can access it right now.</span>
                </div>
              )}

              {/* Action buttons */}
              <div className="flex gap-2 flex-wrap">
                <a href={s.vercel} target="_blank" rel="noopener noreferrer"
                  className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px] font-semibold bg-primary-500 hover:bg-primary-600 text-white transition-colors">
                  <Wifi className="w-3 h-3" /> Open Sandbox
                </a>
                <a href={s.devs} target="_blank" rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px] font-medium bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-600 dark:text-slate-300 transition-colors">
                  <Shield className="w-3 h-3" /> Devs.ai
                </a>
                <button onClick={() => pingSingle(s)} disabled={st.http === 'checking'}
                  className="inline-flex items-center justify-center gap-1 px-2.5 py-1.5 rounded-lg text-[11px] font-medium bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-600 dark:text-slate-300 transition-colors disabled:opacity-50">
                  <RefreshCw className={`w-3 h-3 ${st.http === 'checking' ? 'animate-spin' : ''}`} /> Re-ping
                </button>
              </div>

              {/* Hidden iframe — loads the VERCEL URL directly (most effective wake-up method) */}
              <div className="overflow-hidden rounded-md border border-slate-200 dark:border-slate-700" style={{ height: 80 }}>
                <p className="text-[9px] text-slate-400 px-2 pt-1">↓ Live iframe ping (Vercel sandbox)</p>
                <iframe
                  key={`${s.id}-${iframeKey}`}
                  src={s.vercel}
                  title={`Keep-alive: ${s.label}`}
                  sandbox="allow-scripts allow-same-origin"
                  style={{ width: '100%', height: 60, border: 'none', opacity: 0.4 }}
                  loading="lazy"
                />
              </div>

              {st.lastChecked && (
                <p className="text-[9px] text-slate-400 dark:text-slate-500 text-right">
                  Last checked {st.lastChecked.toLocaleTimeString()}
                </p>
              )}
            </div>
          );
        })}
      </div>

      {/* ── Activity log ─────────────────────────────────────────────────── */}
      <div className="card border border-slate-200 dark:border-slate-700">
        <div className="flex items-center gap-2 mb-2">
          <Clock className="w-3.5 h-3.5 text-slate-400" />
          <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">Ping Log</span>
          <span className="text-[10px] text-slate-400">(last 40 events)</span>
        </div>
        <div className="bg-slate-900 dark:bg-slate-950 rounded-lg p-3 h-40 overflow-y-auto font-mono text-[10px] text-emerald-400 space-y-0.5">
          {log.length === 0
            ? <p className="text-slate-500">Waiting for first ping…</p>
            : log.map((l, i) => <p key={i} className={l.includes('STOPPED') ? 'text-red-400' : l.includes('SLEEPING') || l.includes('FAILED') ? 'text-amber-400' : l.includes('ALIVE') ? 'text-emerald-400' : 'text-slate-400'}>{l}</p>)
          }
        </div>
      </div>

      {/* Info note */}
      <div className="flex items-start gap-2 p-3 rounded-lg bg-blue-50 dark:bg-blue-500/10 border border-blue-200 dark:border-blue-500/20 text-[11px] text-blue-700 dark:text-blue-300">
        <Info className="w-3.5 h-3.5 mt-0.5 flex-shrink-0" />
        <p>
          <strong>How it works:</strong> This page sends a real server-side HTTP request to each sandbox URL every <strong>5 minutes</strong> and shows the actual HTTP status code.
          {' '}<strong>200 = Alive</strong>, <strong>502 = Sleeping (waking it up)</strong>, <strong>410 = Permanently stopped (manual Devs.ai restart needed)</strong>.
          Keep this Admin page open on a NOC screen for continuous keep-alive. The GitHub Actions workflow also pings every 5–10 min as a backup.
        </p>
      </div>
    </div>
  );
}

function RoleSelector({ targetUser, onChanged, currentUser }: { targetUser: User; onChanged: () => void; currentUser: User }) {
  const [loading, setLoading] = useState(false);
  const { send } = useNotifications();
  const isSuperAdmin = currentUser.role === 'super_admin';

  const change = async (newRole: User['role']) => {
    if (newRole === targetUser.role) return;

    // Enforce: only super admins can assign admin or super_admin roles
    if ((newRole === 'admin' || newRole === 'super_admin') && !isSuperAdmin) {
      toast.error('Only Super Admins can assign Admin or Super Admin roles.', { duration: 5000, icon: '🔒' });
      return;
    }

    setLoading(true);
    const { updateUser } = await import('../lib/auth/db');
    await updateUser(targetUser.id, { role: newRole });
    send(targetUser.id, 'Your Role Has Changed', `Your role was updated to ${ROLE_LABELS[newRole]} by ${currentUser.firstName} ${currentUser.lastName}.`, 'info');
    onChanged();
    setLoading(false);
    toast.success(`${targetUser.firstName}'s role → ${ROLE_LABELS[newRole]}`);
  };

  return (
    <div className="relative inline-block">
      <select
        value={targetUser.role}
        onChange={e => change(e.target.value as User['role'])}
        disabled={loading}
        className="text-xs font-medium rounded-lg bg-slate-100 dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-slate-200 px-3 py-1.5 pr-7 appearance-none cursor-pointer focus:outline-none focus:ring-2 focus:ring-violet-500 disabled:opacity-50"
      >
        <option value="user">Normal User</option>
        {/* Admin and Super Admin options only shown to super admins */}
        {isSuperAdmin && <option value="admin">Admin</option>}
        {isSuperAdmin && <option value="super_admin">Super Admin</option>}
        {/* Non-super admins see locked options */}
        {!isSuperAdmin && targetUser.role === 'admin' && <option value="admin" disabled>Admin (locked)</option>}
        {!isSuperAdmin && targetUser.role === 'super_admin' && <option value="super_admin" disabled>Super Admin (locked)</option>}
      </select>
      <ChevronDown className="w-3.5 h-3.5 absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400" />
      {!isSuperAdmin && (
        <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-0.5 text-right">
          Only Super Admins can assign elevated roles
        </p>
      )}
    </div>
  );
}
