import { useMemo, useState } from 'react';
import { Phone } from 'lucide-react';
import { CARRIERS, ESCALATIONS } from '../data/carrierContacts';
import { filterCarriers, getAllServiceTypes, type CarrierFilter } from '../utils/carrierSearch';
import { buildCarrierSystemPrompt } from '../utils/carrierAIPrompt';
import { sendMessage, type AIMessage } from '../lib/devs-ai/client';
import {
  searchConfluence,
  formatConfluenceContext,
} from '../lib/confluence/client';
import { useAISettings } from '../hooks/useAISettings';
import { CarrierCard } from '../components/carriers/CarrierCard';
import { CarrierFilters } from '../components/carriers/CarrierFilters';
import { CarrierSearchBar } from '../components/carriers/CarrierSearchBar';
import { AICarrierResults } from '../components/carriers/AICarrierResults';
import type { CarrierCategory } from '../types';

export default function CarrierContactsPage() {
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<CarrierCategory | 'All'>('All');
  const [serviceType, setServiceType] = useState<string | 'All'>('All');
  const [aiMode, setAiMode] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);
  const [aiAnswer, setAiAnswer] = useState('');
  const [visibleCount, setVisibleCount] = useState(40);

  const { modelOverride, confluence, confluenceReady } = useAISettings();

  const serviceTypes = useMemo(() => getAllServiceTypes(CARRIERS), []);

  const filtered = useMemo(() => {
    const f: CarrierFilter = { query, category, serviceType };
    return filterCarriers(CARRIERS, f);
  }, [query, category, serviceType]);

  const visible = filtered.slice(0, visibleCount);

  const handleAiSubmit = async () => {
    if (!query.trim()) return;
    setAiLoading(true);
    setAiError(null);
    setAiAnswer('');

    try {
      // Optionally ground in Confluence
      let confluenceBlock = '';
      if (confluenceReady) {
        const res = await searchConfluence(confluence, query.trim(), 5);
        if (res.error) {
          // Soft-fail — keep going with carrier directory only
          console.warn('Confluence search failed:', res.error);
        } else if (res.results.length) {
          confluenceBlock = formatConfluenceContext(res.results);
        }
      }

      const messages: AIMessage[] = [
        { role: 'system', content: buildCarrierSystemPrompt(CARRIERS) },
        {
          role: 'user',
          content: confluenceBlock
            ? `${confluenceBlock}\n\n---\nUser question: ${query.trim()}`
            : query.trim(),
        },
      ];

      let acc = '';
      await sendMessage(
        messages,
        (delta) => {
          acc += delta;
          setAiAnswer(acc);
        },
        () => setAiLoading(false),
        (err) => {
          setAiError(err);
          setAiLoading(false);
        },
        { model: modelOverride || undefined },
      );
    } catch (err) {
      setAiError(err instanceof Error ? err.message : 'AI request failed');
      setAiLoading(false);
    }
  };

  const clearAi = () => {
    setAiAnswer('');
    setAiError(null);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-5">
      <div>
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 bg-primary-100 dark:bg-primary-500/10 rounded-lg flex items-center justify-center">
            <Phone className="w-5 h-5 text-primary-600 dark:text-primary-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Carrier Contacts</h1>
            <p className="text-sm text-slate-500 dark:text-slate-400">
              {CARRIERS.length} carriers · NOC numbers, emails, portals, escalation tiers, outage maps
            </p>
          </div>
        </div>
      </div>

      {/* Search + AI */}
      <CarrierSearchBar
        query={query}
        onQueryChange={(q) => {
          setQuery(q);
          setVisibleCount(40);
        }}
        aiMode={aiMode}
        onAiToggle={() => setAiMode((v) => !v)}
        onAiSubmit={handleAiSubmit}
        confluenceActive={confluenceReady}
      />

      {/* Filters */}
      <CarrierFilters
        category={category}
        onCategoryChange={(c) => { setCategory(c); setVisibleCount(40); }}
        serviceType={serviceType}
        onServiceTypeChange={(s) => { setServiceType(s); setVisibleCount(40); }}
        serviceTypes={serviceTypes}
        totalCount={CARRIERS.length}
        filteredCount={filtered.length}
      />

      {/* AI answer (above results) */}
      <AICarrierResults loading={aiLoading} error={aiError} answer={aiAnswer} onClear={clearAi} />

      {/* Results */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {visible.map((c) => {
          const esc = ESCALATIONS[c.name];
          return (
            <CarrierCard
              key={c.name}
              carrier={c}
              buyersClub={esc?.['Buyers Club'] ?? []}
              brokerage={esc?.['Brokerage'] ?? []}
            />
          );
        })}
      </div>

      {filtered.length === 0 && (
        <div className="card text-center text-sm text-slate-500 dark:text-slate-400">
          No carriers match your filters.
        </div>
      )}

      {visible.length < filtered.length && (
        <div className="text-center">
          <button
            onClick={() => setVisibleCount((v) => v + 40)}
            className="btn-secondary"
          >
            Load more ({filtered.length - visible.length} remaining)
          </button>
        </div>
      )}
    </div>
  );
}
