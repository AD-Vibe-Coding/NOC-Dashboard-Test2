import { useState, useMemo, useEffect, lazy, Suspense } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import {
  Network, BookOpen, Phone, Wrench, FileText, Zap, BarChart3, Sparkles, Loader2, ExternalLink, RefreshCw,
} from 'lucide-react';
// BookOpen is imported above — used in scripts tab banner
import { MobilitySmartSearch } from '../components/mobility/MobilitySmartSearch';
import { MobilityTree } from '../components/mobility/MobilityTree';
import { ConfluencePageRenderer } from '../components/mobility/ConfluencePageRenderer';
import { EscalationMatrix } from '../components/network/EscalationMatrix';
import type { PageNode } from '../lib/confluence/restClient';
import { NETWORK_ESCALATIONS } from '../data/networkEscalations';

const NetworkDevicesPage   = lazy(() => import('./NetworkDevicesPage'));
const NOCScriptsPage       = lazy(() => import('./NOCScriptsPage'));
const FaultTypesPage       = lazy(() => import('./FaultTypesPage'));
const SDWanMetricsPage     = lazy(() => import('./SDWanMetricsPage'));

// ────────────────────────────────────────────────────────────────────
// HARD-CODED Network root page — this is the SINGLE source of truth.
// Maps to: https://vikicloud.atlassian.net/wiki/spaces/TS/pages/150765794/Network
//
// We DELIBERATELY do NOT use localStorage caching for the root id here:
// previous versions cached an auto-discovered root that turned out to be
// the Mobility page, and the Network tab kept showing Mobility content.
// Pinning the constant guarantees Network is always Network.
// ────────────────────────────────────────────────────────────────────
const NETWORK_ROOT_ID  = '150765794';
const NETWORK_ROOT_URL = 'https://vikicloud.atlassian.net/wiki/spaces/TS/pages/150765794/Network';

// Sanity: nuke any old cached values so a stale Mobility id can't leak in.
if (typeof window !== 'undefined') {
  try {
    localStorage.removeItem('noc_toolkit_network_root_id');
    localStorage.removeItem('noc_toolkit_network_root_id_v2');
  } catch { /* ignore */ }
}

type TabKey = 'overview' | 'pages' | 'escalation' | 'troubleshooting' | 'scripts' | 'fault-types' | 'sdwan';

interface Tab {
  key: TabKey;
  label: string;
  icon: typeof Network;
  blurb: string;
}

const TABS: Tab[] = [
  { key: 'overview',         label: 'Overview',                  icon: Network,    blurb: 'AI search · live carrier highlights · network status snapshot.' },
  { key: 'pages',            label: 'Network Pages',             icon: BookOpen,   blurb: 'Live tree of every Network page in Confluence — click any title to read full content.' },
  { key: 'escalation',       label: 'Carrier Escalation',        icon: Phone,      blurb: 'L1 → L5 escalation matrix for every Network carrier — color-coded by urgency.' },
  { key: 'troubleshooting',  label: 'Troubleshooting',           icon: Wrench,     blurb: 'Device-specific troubleshooting playbooks (Meraki, Fortinet, Cisco, etc.).' },
  { key: 'scripts',          label: 'NOC Scripts',               icon: FileText,   blurb: 'Ready-to-run scripts for common NOC operational tasks.' },
  { key: 'fault-types',      label: 'iPath Fault Types',         icon: Zap,        blurb: 'LogicMonitor / iPath fault types with severities and NOC actions.' },
  { key: 'sdwan',            label: 'SD-WAN',                    icon: BarChart3,  blurb: 'SD-WAN performance thresholds, application profiles, and monitoring.' },
];

const EXAMPLE_QUERIES = [
  'How do I troubleshoot a circuit-down ticket?',
  'AT&T MPLS escalation matrix',
  'iPath fault type Unreachable',
  'VeloCloud SD-WAN troubleshooting',
  'Comcast Metro-E support number',
  'NOC script for password reset',
];

export default function NetworkPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const [tab, setTab] = useState<TabKey>((searchParams.get('tab') as TabKey) || 'overview');
  const [selectedPageId, setSelectedPageId] = useState<string | null>(null);
  const [readerMinimized, setReaderMinimized] = useState(false);
  // Always pinned — no fallback, no localStorage, no discovery.
  const rootId = NETWORK_ROOT_ID;

  // Sync tab → URL
  useEffect(() => {
    const params = new URLSearchParams(searchParams);
    if (tab === 'overview') params.delete('tab');
    else params.set('tab', tab);
    setSearchParams(params, { replace: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab]);

  const handleTreeSelect = (page: PageNode) => setSelectedPageId(page.id);
  const handleSearchOpen = (pageId: string) => {
    setSelectedPageId(pageId);
    setTab('pages');
    setTimeout(() => {
      document.getElementById('network-renderer')?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  const askAIAboutSection = (label: string, blurb: string) => {
    const prompt = `Help me with the "${label}" section of the NOC Network reference. Context: ${blurb}\n\nMy question: `;
    navigate(`/ai-assistant?prompt=${encodeURIComponent(prompt)}`);
  };

  return (
    <div className="max-w-7xl mx-auto space-y-5">
      {/* Page header */}
      <div className="flex items-start gap-3 flex-wrap">
        <div className="w-10 h-10 bg-primary-100 dark:bg-primary-500/10 rounded-lg flex items-center justify-center">
          <Network className="w-5 h-5 text-primary-600 dark:text-primary-400" />
        </div>
        <div className="min-w-0 flex-1">
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Network</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Live Confluence knowledge base · carrier escalation matrix · troubleshooting · iPath · SD-WAN
          </p>
        </div>
        <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-violet-50 dark:bg-violet-500/10 text-violet-700 dark:text-violet-300 text-[11px] font-medium">
          <Sparkles className="w-3 h-3" /> Powered by Viki / Confluence · auto-grounded AI
        </div>
      </div>

      {/* Locked-root indicator: this Network page can ONLY ever load /pages/150765794/Network */}
      <div className="flex items-center gap-2 flex-wrap text-[11px]">
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-primary-50 dark:bg-primary-500/10 text-primary-700 dark:text-primary-300 font-semibold">
          <Network className="w-3 h-3" /> Network root
        </span>
        <span className="text-slate-500 dark:text-slate-400">→</span>
        <a
          href={NETWORK_ROOT_URL}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1 font-mono text-slate-600 dark:text-slate-300 hover:text-primary-600 dark:hover:text-primary-400 hover:underline truncate max-w-full"
          title="Open in Confluence"
        >
          /wiki/spaces/TS/pages/150765794/Network
          <ExternalLink className="w-3 h-3 flex-shrink-0" />
        </a>
        <span className="px-1.5 py-0.5 rounded bg-emerald-50 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 font-semibold">
          ✓ pinned · cannot drift to Mobility
        </span>
      </div>

      {/* Big AI search at the very top of every tab — scoped to Network root */}
      <MobilitySmartSearch
        key={`smart-${rootId}`}
        rootId={rootId}
        onOpenPage={handleSearchOpen}
        examples={EXAMPLE_QUERIES}
        placeholder={'Ask anything about Network — "AT&T circuit down troubleshooting", "VeloCloud BFD timers"…'}
        scopeLabel="Network"
      />

      {/* Tab bar */}
      <div className="flex flex-wrap gap-2 border-b border-slate-200 dark:border-slate-700 pb-1 pt-2">
        {TABS.map((t) => {
          const Icon = t.icon;
          const isActive = tab === t.key;
          return (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`inline-flex items-center gap-2 px-3 py-2 rounded-t-lg text-sm font-medium transition-all border-b-2 -mb-px ${
                isActive
                  ? 'border-primary-500 text-primary-700 dark:text-primary-300 bg-primary-50/50 dark:bg-primary-500/5'
                  : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800/50'
              }`}
            >
              <Icon className="w-4 h-4" />
              {t.label}
            </button>
          );
        })}
      </div>

      <div className="flex items-center justify-between -mt-2 flex-wrap gap-2">
        <p className="text-xs text-slate-500 dark:text-slate-400">
          {TABS.find((t) => t.key === tab)?.blurb}
        </p>
        <button
          onClick={() => askAIAboutSection(TABS.find((t) => t.key === tab)!.label, TABS.find((t) => t.key === tab)!.blurb)}
          className="inline-flex items-center gap-1 px-2 py-0.5 text-[11px] font-medium rounded-full bg-violet-50 dark:bg-violet-500/10 hover:bg-violet-100 dark:hover:bg-violet-500/20 text-violet-700 dark:text-violet-300"
        >
          <Sparkles className="w-3 h-3" /> Ask AI about this section
        </button>
      </div>

      {/* ─── Tab: Overview ──────────────────────────────────── */}
      {tab === 'overview' && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <StatCard label="Network carriers tracked" value={String(NETWORK_ESCALATIONS.length)} icon={Phone} color="emerald" />
            <StatCard label="Confluence connected" value="Yes · Space TS" icon={BookOpen} color="violet" />
            <StatCard label="Auto-refresh" value="every 15 s" icon={RefreshCw} color="primary" />
            <StatCard label="AI grounding" value="Mobility + Network" icon={Sparkles} color="amber" />
          </div>

          <div className="card">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-sm font-semibold text-slate-900 dark:text-white">Top Network carriers</h2>
              <button onClick={() => setTab('escalation')} className="text-[11px] text-primary-600 dark:text-primary-400 hover:underline">View full matrix →</button>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
              {NETWORK_ESCALATIONS.slice(0, 8).map((c) => {
                const l1 = c.tiers.L1;
                return (
                  <a
                    key={c.key}
                    href={l1?.phones[0] ? `tel:${l1.phones[0].replace(/[^0-9+]/g, '')}` : undefined}
                    onClick={(e) => { if (!l1?.phones[0]) { e.preventDefault(); setTab('escalation'); } }}
                    className="block px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 hover:border-primary-300 dark:hover:border-primary-500/40 transition-colors"
                  >
                    <p className="text-xs font-semibold text-slate-900 dark:text-white truncate">{c.name}</p>
                    {l1?.phones[0] && <p className="text-[11px] font-mono text-primary-600 dark:text-primary-400">{l1.phones[0]}</p>}
                  </a>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ─── Tab: Network Pages ─────────────────────────────── */}
      {tab === 'pages' && (
        <div
          className={readerMinimized ? 'grid grid-cols-1 gap-4' : 'grid grid-cols-1 lg:grid-cols-[320px_1fr] gap-4'}
          id="network-renderer"
        >
          <div className={readerMinimized ? 'w-full' : 'lg:sticky lg:top-20 lg:self-start lg:h-[calc(100vh-7rem)]'}>
            {/* key={rootId} forces a full remount on root change so no stale state leaks */}
            <MobilityTree key={`tree-${rootId}`} rootId={rootId} selectedId={selectedPageId} onSelect={handleTreeSelect} scopeLabel="Network" />
          </div>
          {!readerMinimized && (
            <div>
              <ConfluencePageRenderer pageId={selectedPageId} minimizable onMinimize={() => setReaderMinimized(true)} />
            </div>
          )}
          {readerMinimized && selectedPageId && (
            <div className="flex justify-end">
              <button onClick={() => setReaderMinimized(false)} className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md bg-primary-500 hover:bg-primary-600 text-white">
                <Sparkles className="w-3.5 h-3.5" /> Show reader panel
              </button>
            </div>
          )}
        </div>
      )}

      {/* ─── Tab: Carrier Escalation ────────────────────────── */}
      {tab === 'escalation' && <EscalationMatrix />}

      {/* ─── Tab: Troubleshooting ────────────────────────────── */}
      {tab === 'troubleshooting' && (
        <Suspense fallback={<LoadingPanel />}>
          <NetworkDevicesPage />
        </Suspense>
      )}

      {/* ─── Tab: NOC Scripts ────────────────────────────────── */}
      {tab === 'scripts' && (
        <Suspense fallback={<LoadingPanel />}>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <p className="text-xs text-slate-500 dark:text-slate-400">Pre-built NOC ticket scripts. For the full editable runbook library:</p>
              <a
                href="/runbooks"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-primary-500 hover:bg-primary-600 text-white transition-colors"
              >
                <BookOpen className="w-3.5 h-3.5" /> Open Runbook Editor →
              </a>
            </div>
            <NOCScriptsPage />
          </div>
        </Suspense>
      )}

      {/* ─── Tab: iPath Fault Types ─────────────────────────── */}
      {tab === 'fault-types' && (
        <Suspense fallback={<LoadingPanel />}>
          <FaultTypesPage />
        </Suspense>
      )}

      {/* ─── Tab: SD-WAN ────────────────────────────────────── */}
      {tab === 'sdwan' && (
        <Suspense fallback={<LoadingPanel />}>
          <SDWanMetricsPage />
        </Suspense>
      )}
    </div>
  );
}

function StatCard({
  label, value, icon: Icon, color,
}: { label: string; value: string; icon: typeof Network; color: 'emerald' | 'violet' | 'primary' | 'amber' }) {
  const colorMap = {
    emerald: 'bg-emerald-100 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400',
    violet:  'bg-violet-100  dark:bg-violet-500/10  text-violet-600  dark:text-violet-400',
    primary: 'bg-primary-100 dark:bg-primary-500/10 text-primary-600 dark:text-primary-400',
    amber:   'bg-amber-100   dark:bg-amber-500/10   text-amber-600   dark:text-amber-400',
  };
  return (
    <div className="card">
      <div className="flex items-center gap-2 mb-1">
        <div className={`w-7 h-7 rounded-md ${colorMap[color]} flex items-center justify-center`}>
          <Icon className="w-3.5 h-3.5" />
        </div>
        <p className="text-[10px] uppercase tracking-wider text-slate-500 dark:text-slate-400 font-semibold">{label}</p>
      </div>
      <p className="text-base font-bold text-slate-900 dark:text-white">{value}</p>
    </div>
  );
}

function LoadingPanel() {
  return (
    <div className="card flex items-center justify-center py-10 text-slate-500">
      <Loader2 className="w-5 h-5 mr-2 animate-spin" /> Loading…
    </div>
  );
}
