import { useState, useEffect } from 'react';
import { BookOpen, ExternalLink, FileCode2, MessageSquare } from 'lucide-react';
import { ChatInterface } from '../components/ai/ChatInterface';
import { PCAPAnalyzer } from '../components/ai/PCAPAnalyzer';
import { AIBadge } from '../components/ai/AIBadge';
import { DevsAiBadge } from '../components/ui/Brand';
import { trackEvent } from '../lib/analytics/db';
import { useAuth } from '../hooks/useAuth';

const CONFLUENCE_URL = 'https://vikicloud.atlassian.net/wiki';
type AITab = 'chat' | 'pcap';

export default function AIAssistantPage() {
  const { user } = useAuth();
  const [showPop, setShowPop] = useState(false);
  const [aiTab, setAiTab] = useState<AITab>('chat');
  useEffect(() => { if (user) trackEvent(user.id, 'ai_assistant', 'page_open'); }, []);

  return (
    // Make the chat consume the available viewport — counters Layout's p-4 / lg:p-6 padding.
    <div className="-m-4 lg:-m-6 flex flex-col bg-white dark:bg-slate-900"
         style={{ height: 'calc(100dvh - 4rem)' }}>
      {/* Page header */}
      <div className="flex items-center justify-between px-4 lg:px-6 py-3 border-b border-slate-200 dark:border-slate-700/60 bg-white dark:bg-slate-900">
        <div className="flex items-center gap-3 min-w-0">
          <div className="flex-shrink-0">
            <AIBadge size="md" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-base font-semibold text-slate-900 dark:text-white leading-tight">
                NOC Assistant
              </h1>
              <DevsAiBadge size="xs" model="IT Specialist" />
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
              AppDirect · vCom BU · Auto-grounded with the entire vikicloud Confluence wiki
            </p>
          </div>
        </div>
        <div className="relative">
          <button
            onClick={() => setShowPop((s) => !s)}
            className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-[11px] font-semibold bg-emerald-50 dark:bg-emerald-500/15 hover:bg-emerald-100 dark:hover:bg-emerald-500/25 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-500/30 transition-colors"
            title="Click for details"
          >
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <BookOpen className="w-3 h-3" />
            Viki / Confluence connected
          </button>
          {showPop && (
            <div className="absolute top-full right-0 mt-2 w-72 p-3 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xl z-30">
              <p className="text-xs font-semibold text-slate-900 dark:text-white mb-1">Viki / Confluence connected</p>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mb-2">
                Every chat is automatically grounded with the top 8 most-relevant pages from the <strong>entire vikicloud Confluence</strong> instance (every space — not just TS). Citations appear inline as <span className="font-mono">[1] [2] …</span> with a Sources block at the end.
              </p>
              <div className="space-y-1 text-[11px]">
                <div className="flex justify-between"><span className="text-slate-500">Scope</span><span className="font-mono text-slate-700 dark:text-slate-300">all spaces</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Top results</span><span className="text-slate-700 dark:text-slate-300">8</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Search passes</span><span className="text-slate-700 dark:text-slate-300">title + text (parallel)</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Auto-ground</span><span className="text-emerald-600 dark:text-emerald-400 font-medium">on</span></div>
              </div>
              <a
                href={CONFLUENCE_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-2 inline-flex items-center gap-1 text-[11px] text-primary-600 dark:text-primary-400 hover:underline"
              >
                Open Viki wiki <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          )}
        </div>
      </div>

      {/* Tab switcher */}
      <div className="flex items-center gap-1 px-4 lg:px-6 py-2 border-b border-slate-200 dark:border-slate-700/60 bg-white dark:bg-slate-900 flex-shrink-0">
        <button
          onClick={() => setAiTab('chat')}
          className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
            aiTab === 'chat'
              ? 'bg-primary-100 dark:bg-primary-500/20 text-primary-700 dark:text-primary-300'
              : 'text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <MessageSquare className="w-3.5 h-3.5" /> NOC Chat
        </button>
        <button
          onClick={() => setAiTab('pcap')}
          className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
            aiTab === 'pcap'
              ? 'bg-primary-100 dark:bg-primary-500/20 text-primary-700 dark:text-primary-300'
              : 'text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <FileCode2 className="w-3.5 h-3.5" /> PCAP Analyzer
        </button>
      </div>

      {/* Content — fills remaining height */}
      <div className="flex-1 min-h-0 overflow-hidden">
        {aiTab === 'chat' ? <ChatInterface /> : <PCAPAnalyzer />}
      </div>
    </div>
  );
}
