import { useState, useMemo } from 'react';
import {
  Smartphone, Phone, BookOpen, Wrench, RefreshCw, Sparkles,
  AlertCircle, Search, Filter,
} from 'lucide-react';
import { useMobilityRefresh } from '../hooks/useMobilityRefresh';
import { CarrierContactCard } from '../components/mobility/CarrierContactCard';
import { MobilitySmartSearch } from '../components/mobility/MobilitySmartSearch';
import { MobilityTree } from '../components/mobility/MobilityTree';
import { ConfluencePageRenderer } from '../components/mobility/ConfluencePageRenderer';
import { DeviceTroubleshootingTab } from '../components/mobility/DeviceTroubleshootingTab';
import type { MobilityCarrier } from '../lib/mobility/carriers';
import type { PageNode } from '../lib/confluence/restClient';

// ────────────────────────────────────────────────────────────────────
// HARD-CODED Mobility root page — single source of truth.
// Maps to: https://vikicloud.atlassian.net/wiki/spaces/TS/pages/45648574/Mobility
// Network has its own pinned constant in NetworkPage.tsx (150765794).
// ────────────────────────────────────────────────────────────────────
const MOBILITY_ROOT_ID  = '45648574';
const MOBILITY_ROOT_URL = 'https://vikicloud.atlassian.net/wiki/spaces/TS/pages/45648574/Mobility';

type TabKey = 'carriers' | 'knowledge' | 'devices';

interface Tab {
  key: TabKey;
  label: string;
  icon: typeof Phone;
  blurb: string;
}

const TABS: Tab[] = [
  { key: 'knowledge', label: 'Knowledge Base — Mobility', icon: BookOpen, blurb: 'Live tree of every Mobility page in Confluence — click any title to read the full content with images and attachments.' },
  { key: 'carriers', label: 'Carrier Support', icon: Phone, blurb: 'Live phone numbers, emails, and portals — auto-refreshed every 60 s via the AI agent.' },
  { key: 'devices', label: 'Device Troubleshooting', icon: Wrench, blurb: 'iPhone, iPad, Android, SIM / eSIM L1 troubleshooting playbooks.' },
];

function formatAge(date: Date | null): string {
  if (!date) return 'never';
  const sec = Math.floor((Date.now() - date.getTime()) / 1000);
  if (sec < 60) return `${sec}s ago`;
  if (sec < 3600) return `${Math.floor(sec / 60)}m ago`;
  return `${Math.floor(sec / 3600)}h ago`;
}

export default function MobilityPage() {
  const [tab, setTab] = useState<TabKey>('knowledge');
  const [selectedPageId, setSelectedPageId] = useState<string | null>(null);
  const [carrierQuery, setCarrierQuery] = useState('');
  const [carrierCategory, setCarrierCategory] = useState<'all' | MobilityCarrier['category']>('all');
  const [readerMinimized, setReaderMinimized] = useState(false);

  const { carriers, lastUpdated, isRefreshing, error, refresh, stalenessClass } = useMobilityRefresh();

  const visibleCarriers = useMemo(() => {
    const q = carrierQuery.trim().toLowerCase();
    return carriers.filter((c) => {
      if (carrierCategory !== 'all' && c.category !== carrierCategory) return false;
      if (!q) return true;
      return c.name.toLowerCase().includes(q) ||
             c.shortName.toLowerCase().includes(q) ||
             (c.tier1Phone ?? '').includes(q) ||
             (c.notes ?? '').toLowerCase().includes(q);
    });
  }, [carriers, carrierQuery, carrierCategory]);

  const stalenessColor =
    stalenessClass === 'fresh' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-300'
    : stalenessClass === 'aging' ? 'bg-amber-100 text-amber-700 dark:bg-amber-500/20 dark:text-amber-300'
    : 'bg-red-100 text-red-700 dark:bg-red-500/20 dark:text-red-300';
  const stalenessText = stalenessClass === 'fresh' ? 'Live' : stalenessClass === 'aging' ? 'Aging' : 'Stale';

  const handleTreeSelect = (page: PageNode) => {
    setSelectedPageId(page.id);
  };

  const handleSearchOpen = (pageId: string) => {
    setSelectedPageId(pageId);
    // Scroll to renderer
    setTimeout(() => {
      document.getElementById('page-renderer')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);
  };

  return (
    <div className="max-w-7xl mx-auto space-y-5">
      {/* Page header */}
      <div className="flex items-start gap-3 flex-wrap">
        <div className="w-10 h-10 bg-primary-100 dark:bg-primary-500/10 rounded-lg flex items-center justify-center">
          <Smartphone className="w-5 h-5 text-primary-600 dark:text-primary-400" />
        </div>
        <div className="min-w-0 flex-1">
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Mobility</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Live Confluence knowledge base · carrier support · device troubleshooting
          </p>
        </div>
        <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-violet-50 dark:bg-violet-500/10 text-violet-700 dark:text-violet-300 text-[11px] font-medium">
          <Sparkles className="w-3 h-3" /> Powered by gpt-5 + direct Confluence REST
        </div>
      </div>

      {/* Big AI search — hero */}
      <MobilitySmartSearch key={`mob-smart-${MOBILITY_ROOT_ID}`} rootId={MOBILITY_ROOT_ID} onOpenPage={handleSearchOpen} scopeLabel="Mobility" />

      {/* Tab bar */}
      <div className="flex flex-wrap gap-2 border-b border-slate-200 dark:border-slate-700 pb-1 pt-2">
        {TABS.map((t) => {
          const Icon = t.icon;
          const isActive = tab === t.key;
          return (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`inline-flex items-center gap-2 px-3 py-2 rounded-t-lg text-sm font-medium transition-all border-b-2 -mb-px ${
                isActive
                  ? 'border-primary-500 text-primary-700 dark:text-primary-300 bg-primary-50/50 dark:bg-primary-500/5'
                  : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800/50'
              }`}
            >
              <Icon className="w-4 h-4" />
              {t.label}
            </button>
          );
        })}
      </div>

      <p className="text-xs text-slate-500 dark:text-slate-400 -mt-2">
        {TABS.find((t) => t.key === tab)?.blurb}
      </p>

      {/* ─── Tab: Knowledge Base — Mobility ─────────────────── */}
      {tab === 'knowledge' && (
        <div
          className={readerMinimized
            ? 'grid grid-cols-1 gap-4'
            : 'grid grid-cols-1 lg:grid-cols-[320px_1fr] gap-4'}
          id="page-renderer"
        >
          <div className={readerMinimized
            ? 'w-full'
            : 'lg:sticky lg:top-20 lg:self-start lg:h-[calc(100vh-7rem)]'}>
            <MobilityTree key={`mob-tree-${MOBILITY_ROOT_ID}`} rootId={MOBILITY_ROOT_ID} selectedId={selectedPageId} onSelect={handleTreeSelect} scopeLabel="Mobility" />
          </div>
          {!readerMinimized && (
            <div className="relative">
              <ConfluencePageRenderer pageId={selectedPageId} minimizable onMinimize={() => setReaderMinimized(true)} />
            </div>
          )}
          {readerMinimized && selectedPageId && (
            <div className="flex justify-end">
              <button
                onClick={() => setReaderMinimized(false)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md bg-primary-500 hover:bg-primary-600 text-white shadow-sm"
              >
                <Sparkles className="w-3.5 h-3.5" /> Show reader panel
              </button>
            </div>
          )}
        </div>
      )}

      {/* ─── Tab: Carrier Support ────────────────────────────── */}
      {tab === 'carriers' && (
        <div className="space-y-4">
          <div className="card !p-3 flex items-center flex-wrap gap-3">
            <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[11px] font-medium ${stalenessColor}`}>
              <span className={`w-1.5 h-1.5 rounded-full ${stalenessClass === 'fresh' ? 'bg-emerald-500 animate-pulse' : stalenessClass === 'aging' ? 'bg-amber-500' : 'bg-red-500'}`} />
              {stalenessText}
            </span>
            <span className="text-xs text-slate-600 dark:text-slate-300">
              Last verified <span className="font-semibold">{formatAge(lastUpdated)}</span>
              {lastUpdated && (
                <span className="text-slate-400 dark:text-slate-500"> · {lastUpdated.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', timeZone: 'America/Los_Angeles' })} PT</span>
              )}
            </span>
            {error && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-300">
                <AlertCircle className="w-3 h-3" /> {error.slice(0, 60)}
              </span>
            )}
            <button
              onClick={refresh}
              disabled={isRefreshing}
              className="ml-auto inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-md bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 disabled:opacity-50"
            >
              <RefreshCw className={`w-3 h-3 ${isRefreshing ? 'animate-spin' : ''}`} />
              {isRefreshing ? 'Verifying...' : 'Refresh now'}
            </button>
          </div>

          <div className="flex flex-wrap gap-2">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text" value={carrierQuery} onChange={(e) => setCarrierQuery(e.target.value)}
                placeholder="Search carriers…"
                className="w-full pl-10 pr-3 py-2 text-sm rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-primary-500"
              />
            </div>
            <div className="relative">
              <Filter className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
              <select
                value={carrierCategory}
                onChange={(e) => setCarrierCategory(e.target.value as typeof carrierCategory)}
                className="pl-9 pr-8 py-2 text-sm rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
              >
                <option value="all">All categories</option>
                <option value="att">AT&T</option>
                <option value="verizon">Verizon</option>
                <option value="tmobile">T-Mobile</option>
                <option value="other">Other</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {visibleCarriers.map((c) => <CarrierContactCard key={c.key} carrier={c} />)}
          </div>
          {visibleCarriers.length === 0 && (
            <div className="card text-center py-6 text-sm text-slate-500">No carriers match.</div>
          )}
        </div>
      )}

      {/* ─── Tab: Device Troubleshooting ─────────────────────── */}
      {tab === 'devices' && <DeviceTroubleshootingTab />}
    </div>
  );
}
