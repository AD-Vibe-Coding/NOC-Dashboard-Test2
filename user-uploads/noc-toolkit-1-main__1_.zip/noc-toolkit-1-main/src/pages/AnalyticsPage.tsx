import { useState, useEffect } from 'react';
import { BarChart3, Users, Brain, Activity, TrendingUp, Loader2, ShieldOff } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { useNavigate } from 'react-router-dom';
import { getAllUsers } from '../lib/auth/db';
import { getUsageEvents, TOOL_LABELS, AI_TOOLS, type UsageEvent, type ToolName } from '../lib/analytics/db';
import type { User } from '../types/auth';

// ── Helpers ────────────────────────────────────────────────────────────────
function last7Days(): string[] {
  return Array.from({ length: 7 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (6 - i));
    return d.toISOString().slice(0, 10);
  });
}

function dayLabel(iso: string) {
  return new Date(iso + 'T12:00:00').toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
}

// ── Stat card ──────────────────────────────────────────────────────────────
function StatCard({ label, value, sub, icon: Icon, color }: { label: string; value: string | number; sub?: string; icon: React.ElementType; color: string }) {
  return (
    <div className="card flex items-start gap-4">
      <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${color}`}>
        <Icon className="w-5 h-5" />
      </div>
      <div>
        <p className="text-2xl font-bold text-slate-900 dark:text-white">{value}</p>
        <p className="text-xs font-medium text-slate-600 dark:text-slate-300">{label}</p>
        {sub && <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-0.5">{sub}</p>}
      </div>
    </div>
  );
}

// ── Bar chart row ──────────────────────────────────────────────────────────
function BarRow({ label, value, max, color }: { label: string; value: number; max: number; color: string }) {
  const pct = max > 0 ? Math.round((value / max) * 100) : 0;
  return (
    <div className="flex items-center gap-3 py-1.5">
      <span className="text-xs text-slate-600 dark:text-slate-300 w-40 flex-shrink-0 truncate">{label}</span>
      <div className="flex-1 bg-slate-100 dark:bg-slate-700/50 rounded-full h-2.5 overflow-hidden">
        <div className={`h-full rounded-full transition-all duration-700 ${color}`} style={{ width: `${pct}%` }} />
      </div>
      <span className="text-xs font-mono text-slate-500 dark:text-slate-400 w-8 text-right">{value}</span>
    </div>
  );
}

export default function AnalyticsPage() {
  const { user, isSuperAdmin } = useAuth();
  const navigate = useNavigate();
  const [events, setEvents] = useState<UsageEvent[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedUser, setSelectedUser] = useState<string>('all');

  useEffect(() => {
    if (!isSuperAdmin) { navigate('/'); return; }
    Promise.all([getUsageEvents(2000), getAllUsers()]).then(([evs, usrs]) => {
      setEvents(evs);
      setUsers(usrs);
      setLoading(false);
    });
  }, [isSuperAdmin]);

  const filtered = selectedUser === 'all' ? events : events.filter(e => e.userId === selectedUser);

  // Tool usage counts
  const toolCounts = Object.keys(TOOL_LABELS).reduce((acc, tool) => {
    acc[tool as ToolName] = filtered.filter(e => e.tool === tool).length;
    return acc;
  }, {} as Record<ToolName, number>);
  const maxToolCount = Math.max(...Object.values(toolCounts), 1);
  const sortedTools = (Object.entries(toolCounts) as [ToolName, number][]).sort((a, b) => b[1] - a[1]);

  // AI vs non-AI
  const aiCount = filtered.filter(e => AI_TOOLS.includes(e.tool)).length;
  const nonAiCount = filtered.length - aiCount;
  const aiPct = filtered.length > 0 ? Math.round((aiCount / filtered.length) * 100) : 0;

  // Activity last 7 days
  const days = last7Days();
  const dayActivity = days.map(day => ({
    day,
    count: filtered.filter(e => e.createdAt.slice(0, 10) === day).length,
  }));
  const maxDay = Math.max(...dayActivity.map(d => d.count), 1);

  // Per-user summary
  const userSummary = users.map(u => ({
    user: u,
    total: events.filter(e => e.userId === u.id).length,
    lastSeen: events.filter(e => e.userId === u.id)[0]?.createdAt ?? null,
    topTool: (() => {
      const uc = events.filter(e => e.userId === u.id);
      if (!uc.length) return '—';
      const cnt = {} as Record<string, number>;
      uc.forEach(e => { cnt[e.tool] = (cnt[e.tool] || 0) + 1; });
      const top = Object.entries(cnt).sort((a, b) => b[1] - a[1])[0];
      return top ? TOOL_LABELS[top[0] as ToolName] || top[0] : '—';
    })(),
  })).sort((a, b) => b.total - a.total);

  if (loading) return (
    <div className="flex items-center justify-center py-24 text-slate-500">
      <Loader2 className="w-6 h-6 animate-spin mr-2" /> Loading analytics…
    </div>
  );

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-violet-100 dark:bg-violet-500/10 rounded-lg flex items-center justify-center">
            <BarChart3 className="w-5 h-5 text-violet-600 dark:text-violet-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Usage Analytics</h1>
            <p className="text-sm text-slate-500 dark:text-slate-400">Platform usage insights — Super Admin only</p>
          </div>
        </div>
        {/* User filter */}
        <select
          value={selectedUser}
          onChange={e => setSelectedUser(e.target.value)}
          className="input-base text-sm min-w-52"
        >
          <option value="all">All Users</option>
          {users.map(u => (
            <option key={u.id} value={u.id}>{u.firstName} {u.lastName}</option>
          ))}
        </select>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Total Events" value={filtered.length} sub={selectedUser === 'all' ? 'platform-wide' : 'for this user'} icon={Activity} color="bg-blue-100 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400" />
        <StatCard label="Active Users" value={new Set(events.map(e => e.userId)).size} sub={`of ${users.length} total`} icon={Users} color="bg-emerald-100 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="AI Usage" value={`${aiPct}%`} sub={`${aiCount} AI events`} icon={Brain} color="bg-violet-100 dark:bg-violet-500/10 text-violet-600 dark:text-violet-400" />
        <StatCard label="Most Used" value={sortedTools[0] ? TOOL_LABELS[sortedTools[0][0]] : '—'} sub={sortedTools[0] ? `${sortedTools[0][1]} uses` : ''} icon={TrendingUp} color="bg-amber-100 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Tool Usage Bar Chart */}
        <div className="card space-y-2">
          <h2 className="text-sm font-semibold text-slate-900 dark:text-white mb-3 flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-primary-500" /> Tool Usage
          </h2>
          {sortedTools.map(([tool, count]) => (
            <BarRow
              key={tool}
              label={TOOL_LABELS[tool]}
              value={count}
              max={maxToolCount}
              color={AI_TOOLS.includes(tool) ? 'bg-violet-500' : 'bg-primary-500'}
            />
          ))}
          <div className="flex items-center gap-3 pt-2 text-[10px] text-slate-400">
            <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-primary-500 inline-block" /> Regular tools</span>
            <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-violet-500 inline-block" /> AI-powered</span>
          </div>
        </div>

        {/* AI Donut + Activity */}
        <div className="space-y-4">
          {/* AI vs Non-AI donut */}
          <div className="card">
            <h2 className="text-sm font-semibold text-slate-900 dark:text-white mb-3 flex items-center gap-2">
              <Brain className="w-4 h-4 text-violet-500" /> AI vs Regular Usage
            </h2>
            <div className="flex items-center gap-5">
              <div
                className="w-20 h-20 rounded-full flex-shrink-0"
                style={{
                  background: `conic-gradient(#8b5cf6 0% ${aiPct}%, #3b82f6 ${aiPct}% 100%)`,
                }}
              />
              <div className="space-y-1.5">
                <div className="flex items-center gap-2 text-xs">
                  <span className="w-2.5 h-2.5 rounded-full bg-violet-500 inline-block" />
                  <span className="text-slate-600 dark:text-slate-300">AI-powered — <strong>{aiCount}</strong> ({aiPct}%)</span>
                </div>
                <div className="flex items-center gap-2 text-xs">
                  <span className="w-2.5 h-2.5 rounded-full bg-blue-500 inline-block" />
                  <span className="text-slate-600 dark:text-slate-300">Regular tools — <strong>{nonAiCount}</strong> ({100 - aiPct}%)</span>
                </div>
              </div>
            </div>
          </div>

          {/* 7-day activity */}
          <div className="card">
            <h2 className="text-sm font-semibold text-slate-900 dark:text-white mb-3 flex items-center gap-2">
              <Activity className="w-4 h-4 text-emerald-500" /> Activity — Last 7 Days
            </h2>
            <div className="flex items-end gap-1 h-16">
              {dayActivity.map(({ day, count }) => (
                <div key={day} className="flex-1 flex flex-col items-center gap-0.5" title={`${dayLabel(day)}: ${count} events`}>
                  <div
                    className="w-full rounded-t bg-emerald-500 transition-all duration-700 min-h-[2px]"
                    style={{ height: `${maxDay > 0 ? Math.max(4, (count / maxDay) * 56) : 4}px` }}
                  />
                  <span className="text-[8px] text-slate-400 truncate w-full text-center">{new Date(day + 'T12:00:00').toLocaleDateString('en-US', { weekday: 'short' })}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Per-user table */}
      <div className="card !p-0 overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-100 dark:border-slate-700 flex items-center gap-2">
          <Users className="w-4 h-4 text-slate-400" />
          <h2 className="text-sm font-semibold text-slate-900 dark:text-white">Per-User Breakdown</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead className="bg-slate-50 dark:bg-slate-700/30">
              <tr>
                {['Name', 'Role', 'Total Events', 'Top Tool', 'Last Seen'].map(h => (
                  <th key={h} className="text-left px-4 py-2.5 font-medium text-slate-500 dark:text-slate-400">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-700/50">
              {userSummary.map(({ user: u, total, lastSeen, topTool }) => (
                <tr key={u.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                  <td className="px-4 py-2.5 font-medium text-slate-900 dark:text-white">{u.firstName} {u.lastName}</td>
                  <td className="px-4 py-2.5">
                    <span className={`px-1.5 py-0.5 rounded text-[10px] font-medium ${
                      u.role === 'super_admin' ? 'bg-violet-100 text-violet-700 dark:bg-violet-500/20 dark:text-violet-300' :
                      u.role === 'admin' ? 'bg-blue-100 text-blue-700 dark:bg-blue-500/20 dark:text-blue-300' :
                      'bg-slate-100 text-slate-600 dark:bg-slate-700 dark:text-slate-300'
                    }`}>{u.role.replace('_', ' ')}</span>
                  </td>
                  <td className="px-4 py-2.5 font-mono">{total}</td>
                  <td className="px-4 py-2.5 text-slate-600 dark:text-slate-300">{topTool}</td>
                  <td className="px-4 py-2.5 text-slate-400">
                    {lastSeen ? new Date(lastSeen).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
