import { HelpCircle } from 'lucide-react';
import { Accordion, AccordionItem } from '../components/ui/Accordion';

const faqs = [
  {
    question: 'Is my data safe?',
    answer: `Yes, absolutely. Everything runs 100% in your web browser. No data is sent to any server, stored in any database, or shared with anyone. When you paste a carrier email, it's processed entirely by JavaScript running in your browser. When you close the tab, the data is gone. The only things stored locally are your theme preference and AI API key (if configured).`,
  },
  {
    question: 'Where are my pasted emails stored?',
    answer: `Nowhere. Your pasted emails exist only in browser memory (RAM) while you're using the tool. They are never written to disk, sent to a server, or stored in any persistent way. When you navigate away from the page or close the browser tab, the email content is completely gone.`,
  },
  {
    question: 'Can my company see what I paste?',
    answer: `No. There is no server to intercept or log your data. This application is a static web page — think of it like a calculator app on your phone. The only network requests this tool makes are to load the page itself and, optionally, to the OpenAI API if you configure the AI assistant. Your IT department would only see that you accessed the website URL, not what you typed or pasted into it.`,
  },
  {
    question: 'Does the AI chat store my conversations?',
    answer: `No, conversations are stored in browser memory only and disappear when you refresh the page or close the tab. If you use the AI assistant, your messages are sent directly from your browser to OpenAI's API — no intermediate server is involved. OpenAI's data handling policies apply to those requests. Your API key is stored in localStorage (your browser only) and is never sent to any server other than OpenAI.`,
  },
  {
    question: 'What carriers does the maintenance parser support?',
    answer: `The parser handles 7+ carrier-specific formats with high accuracy: AT&T IP Services, AT&T VPN, Spectrum Business, Windstream (Emergency/Demand/Scheduled), Nitel, Uniti Fiber, Expereo. It also has a generic fallback for Lumen/CenturyLink/Level 3, Frontier, Comcast, Cogent, Crown Castle, Zayo, Verizon, Cox, T-Mobile and more. Always review the output before sending — every carrier formats emails slightly differently.`,
  },
  {
    question: 'How current is the Carrier Contacts directory?',
    answer: `The directory contains 200+ US carriers with NOC phone numbers, support emails, customer portals, and tiered escalation contacts (Buyers' Club & Brokerage). It is sourced from vCom's internal carrier contact list. Each major carrier (Comcast, Spectrum, AT&T, Verizon, T-Mobile, Cox, Frontier, Lumen, etc.) has a direct link to its official outage map; smaller carriers fall back to DownDetector.`,
  },
  {
    question: 'Can the AI search fetch live outage data?',
    answer: `No — the AI search uses OpenAI's Chat Completions API which doesn't have live web browsing. The AI search is grounded in our local carrier directory plus the model's general knowledge of major US carriers. For live outage status, click the "Outage Map" button on any carrier card to jump to the carrier's official status page.`,
  },
  {
    question: 'Can I use this offline?',
    answer: `Most tools work offline once the page has loaded — the Maintenance Note Generator, IP/Subnet Calculator, and Carrier Contacts directory all run entirely in your browser. The only features that require an internet connection are the AI Assistant and AI search inside Carrier Contacts (both call OpenAI), and the Outage Map links (which open carrier websites).`,
  },
  {
    question: 'Who built this?',
    answer: `This toolkit was built by Sriram Parisa. It was designed based on the real-world needs of NOC and SOC engineers, with a focus on privacy, efficiency, and ease of use.`,
  },
  {
    question: 'Is this open source?',
    answer: `Please contact the developer for information about licensing and open source availability.`,
  },
  {
    question: 'How accurate is the maintenance parser?',
    answer: `The parser handles most standard carrier email formats very well. It uses multiple regex patterns and fallback strategies to detect fields. However, carrier email formats vary widely and change over time. The confidence indicators (✅ Found, ⚠️ Guessed, ❌ Not Found) help you quickly identify which fields need manual review. Always verify the generated note before sending it to customers.`,
  },
];

export default function FAQPage() {
  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div>
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 bg-primary-100 dark:bg-primary-500/10 rounded-lg flex items-center justify-center">
            <HelpCircle className="w-5 h-5 text-primary-600 dark:text-primary-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Frequently Asked Questions</h1>
            <p className="text-sm text-slate-500 dark:text-slate-400">Common questions about the NOC Toolkit</p>
          </div>
        </div>
      </div>

      <Accordion>
        {faqs.map((faq, idx) => (
          <AccordionItem key={idx} title={faq.question} defaultOpen={idx === 0}>
            <p className="text-sm leading-relaxed">{faq.answer}</p>
          </AccordionItem>
        ))}
      </Accordion>
    </div>
  );
}
