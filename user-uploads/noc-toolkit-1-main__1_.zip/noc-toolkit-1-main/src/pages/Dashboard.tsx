import { Link } from 'react-router-dom';
import {
  Wrench,
  Globe,
  Phone,
  Smartphone,
  BookOpen,
  Shield,
  Zap,
  Lock,
  Lightbulb,
  Router,
  BarChart3,
  FileText,
  type LucideIcon,
} from 'lucide-react';
import { Card } from '../components/ui/Card';
import { CompanyBadge, DevsAiBadge } from '../components/ui/Brand';
import { LiveClock } from '../components/ui/LiveClock';
import { useAuth } from '../hooks/useAuth';
import { AIBadge } from '../components/ai/AIBadge';
import { TeamStatusTracker } from '../components/dashboard/TeamStatusTracker';
import { ShiftRoster } from '../components/dashboard/ShiftRoster';

type Tool = {
  path: string;
  title: string;
  description: string;
  icon?: LucideIcon;
  ai?: boolean;
  color?: string;
};

const tools: Tool[] = [
  { path: '/maintenance', title: 'Maintenance Note Generator', description: 'Parse carrier emails into formatted customer notifications', icon: Wrench, color: 'bg-blue-100 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400' },
  { path: '/noc-tools', title: 'NOC Tools', description: 'IP/Subnet Calc, Ping Test, WHOIS Lookup, and AI Wireshark log analysis', icon: Wrench, color: 'bg-emerald-100 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400' },
  { path: '/carriers', title: 'Carrier Contacts', description: 'NOC numbers, support emails, escalation tiers & outage maps for 200+ US carriers', icon: Phone, color: 'bg-amber-100 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400' },
  { path: '/mobility', title: 'Mobility Troubleshooting', description: 'iPhone, iPad, Android phones & tablets, plus SIM/eSIM management', icon: Smartphone, color: 'bg-indigo-100 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400' },
  { path: '/network-hub/scripts', title: 'NOC Scripts', description: '28 ready-to-use NOC communication scripts', icon: FileText, color: 'bg-orange-100 dark:bg-orange-500/10 text-orange-600 dark:text-orange-400' },
  { path: '/network-hub/devices', title: 'Network Devices', description: 'Cisco Meraki, SD-WAN, Fortinet, carrier routers & combo devices', icon: Router, color: 'bg-orange-100 dark:bg-orange-500/10 text-orange-600 dark:text-orange-400' },
  { path: '/network-hub/fault-types', title: 'iPath Fault Types', description: 'All 14 LogicMonitor alert types with MNS tiers & NOC action steps', icon: Zap, color: 'bg-red-100 dark:bg-red-500/10 text-red-600 dark:text-red-400' },
  { path: '/network-hub/sdwan-metrics', title: 'SD-WAN Metrics', description: 'Latency, jitter, packet loss & MOS thresholds', icon: BarChart3, color: 'bg-cyan-100 dark:bg-cyan-500/10 text-cyan-600 dark:text-cyan-400' },
  { path: '/ai-assistant', title: 'AI Assistant', description: 'Grounded with your Confluence wiki. Rewrite notes, summarize emails, draft updates', ai: true, color: '' },
  { path: '/documentation', title: 'Documentation', description: 'Complete guide to all tools and features', icon: BookOpen, color: 'bg-cyan-100 dark:bg-cyan-500/10 text-cyan-600 dark:text-cyan-400' },
];

const tips = [
  { icon: Zap, title: 'Quick Tip', text: 'Paste a raw carrier email into the Maintenance Note Generator — it auto-detects carrier, circuit ID, dates, and timezone.' },
  { icon: Lock, title: 'Privacy First', text: '100% client-side. No data is stored on any server. Everything stays in your browser.' },
  { icon: Lightbulb, title: 'Did You Know?', text: 'The IP Calculator shows a visual map of every IP in the subnet, color-coded by role.' },
];

export default function Dashboard() {
  const { user } = useAuth();
  return (
    <div className="max-w-6xl mx-auto space-y-8">
      <div className="text-center py-6">
        {user && (
          <p className="text-sm text-slate-500 dark:text-slate-400 mb-2">
            Welcome back, <span className="font-semibold text-slate-700 dark:text-slate-200">{user.firstName}</span>
          </p>
        )}
        <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-primary-50 dark:bg-primary-500/10 rounded-full mb-4">
          <Shield className="w-4 h-4 text-primary-500" />
          <span className="text-xs font-medium text-primary-600 dark:text-primary-400">Network Operations Center</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-bold text-slate-900 dark:text-white mb-3">NOC Operations Toolkit</h1>
        <p className="text-lg text-slate-500 dark:text-slate-400 max-w-2xl mx-auto mb-4">Your all-in-one workstation for daily NOC operations</p>
        <div className="flex items-center justify-center gap-2 flex-wrap mb-3">
          <CompanyBadge size="sm" />
          <DevsAiBadge size="sm" />
        </div>
        <div className="inline-flex">
          <LiveClock className="px-3 py-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-sm" />
        </div>
      </div>

      <TeamStatusTracker />
      <ShiftRoster />

      <div>
        <h2 className="text-lg font-semibold text-slate-900 dark:text-white mb-4">Tools</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {tools.map((tool) => {
            const Icon = tool.icon;
            return (
              <Link key={tool.path} to={tool.path} className="block">
                <Card hoverable className="h-full">
                  <div className="flex items-start gap-3">
                    {tool.ai ? (
                      <div className="flex-shrink-0"><AIBadge size="md" px={40} /></div>
                    ) : Icon ? (
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${tool.color ?? ''}`}>
                        <Icon className="w-5 h-5" />
                      </div>
                    ) : null}
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-slate-900 dark:text-white text-sm mb-1">{tool.title}</h3>
                      <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">{tool.description}</p>
                    </div>
                  </div>
                </Card>
              </Link>
            );
          })}
        </div>
      </div>

      <div>
        <h2 className="text-lg font-semibold text-slate-900 dark:text-white mb-4">Quick Tips</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {tips.map((tip, idx) => (
            <div key={idx} className="card">
              <div className="flex items-center gap-2 mb-2">
                <tip.icon className="w-4 h-4 text-primary-500" />
                <span className="text-sm font-semibold text-slate-700 dark:text-slate-300">{tip.title}</span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">{tip.text}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
