import { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Shield, Eye, EyeOff, LogIn, Clock, CheckCircle, Key, ArrowLeft, Send } from 'lucide-react';
import toast from 'react-hot-toast';
import { useAuth } from '../hooks/useAuth';
import { CompanyBadge, DevsAiBadge } from '../components/ui/Brand';
import { signInWithPopup } from '../lib/auth/auth-popup';
import { getUserByEmail, getAllUsers } from '../lib/auth/db';
import { createResetRequest, hasActivePendingRequest } from '../lib/auth/resetRequests';
import { createNotification } from '../lib/notifications/db';

export default function LoginPage() {
  const { login, user, loginWithGoogle } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [showFallback, setShowFallback] = useState(false);

  // Forgot password state
  const [showForgot, setShowForgot] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotLoading, setForgotLoading] = useState(false);
  const [forgotDone, setForgotDone] = useState(false);

  const pwChanged = new URLSearchParams(location.search).get('pw') === 'changed';
  if (user) { navigate('/', { replace: true }); return null; }
  const from = (location.state as { from?: { pathname: string } })?.from?.pathname || '/';

  const handleGoogleSignIn = async () => {
    setGoogleLoading(true);
    try {
      await signInWithPopup('google');
      const err = await loginWithGoogle();
      if (err) { toast.error(err, { duration: 6000 }); return; }
      toast.success('Welcome back!');
      navigate(from, { replace: true });
    } catch (err: any) {
      const msg = String(err?.message || err || 'Google sign-in failed');
      if (msg.includes('not authorized') || msg.includes('not_authorized')) {
        toast.error('You are not authorized. Contact Sriram or Anirudh.', { duration: 6000 });
      } else if (msg.includes('appdirect') || msg.includes('domain')) {
        toast.error('Only @appdirect.com accounts are allowed.', { duration: 6000 });
      } else {
        toast.error(msg);
      }
    } finally {
      setGoogleLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password) return;
    setLoading(true);
    const err = await login(username.trim(), password);
    setLoading(false);
    if (err) { toast.error(err); return; }
    toast.success('Welcome back!');
    navigate(from, { replace: true });
  };

  const handleForgotSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const email = forgotEmail.trim().toLowerCase();
    if (!email) return;

    // Must be @appdirect.com
    if (!email.endsWith('@appdirect.com')) {
      toast.error('Please enter your @appdirect.com work email.');
      return;
    }

    setForgotLoading(true);
    try {
      // Look up user by email in Supabase
      const foundUser = await getUserByEmail(email);
      if (!foundUser) {
        toast.error('No account found with that email. Contact Sriram or Anirudh.');
        setForgotLoading(false);
        return;
      }

      // Check for existing pending request
      const alreadyPending = await hasActivePendingRequest(foundUser.id);
      if (alreadyPending) {
        toast('A reset request is already pending for this account. An admin will approve it shortly.', { icon: 'ℹ️' });
        setForgotDone(true);
        setForgotLoading(false);
        return;
      }

      // Create the reset request
      await createResetRequest(foundUser.id, `${foundUser.firstName} ${foundUser.lastName}`, foundUser.email);

      // Notify ALL admins and super admins immediately
      const allUsers = await getAllUsers();
      const admins = allUsers.filter(u => u.role === 'admin' || u.role === 'super_admin');
      await Promise.all(admins.map(admin =>
        createNotification(
          admin.id,
          '🔑 Password Reset Request',
          `${foundUser.firstName} ${foundUser.lastName} (${foundUser.email}) has requested a password reset from the login page. Click to review and approve.`,
          'warning',
          { link: '/admin?tab=requests' }
        )
      ));

      setForgotDone(true);
      toast.success('Reset request submitted! An admin will approve it shortly.');
    } catch (err: any) {
      toast.error('Something went wrong. Try again or contact Sriram directly.');
    } finally {
      setForgotLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-900 px-4">
      <div className="w-full max-w-sm">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-14 h-14 mx-auto bg-primary-500 rounded-2xl flex items-center justify-center mb-4">
            <Shield className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white mb-1">NOC Toolkit</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">Sign in to access operations tools</p>
          <div className="flex items-center justify-center gap-2 mt-3">
            <CompanyBadge size="xs" />
            <DevsAiBadge size="xs" />
          </div>
        </div>

        {pwChanged && (
          <div className="flex items-center gap-2 p-3 mb-4 rounded-lg bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-200 dark:border-emerald-500/30 text-xs text-emerald-700 dark:text-emerald-300">
            <CheckCircle className="w-4 h-4 flex-shrink-0" />
            Password changed successfully! Please sign in with your new password.
          </div>
        )}

        {/* ── Forgot Password View ─────────────────────────────── */}
        {showForgot ? (
          <div className="card space-y-4">
            <div className="flex items-center gap-2 mb-1">
              <Key className="w-4 h-4 text-amber-500" />
              <span className="text-sm font-semibold text-slate-900 dark:text-white">Request Password Reset</span>
            </div>

            {forgotDone ? (
              <div className="space-y-4">
                <div className="flex items-start gap-3 p-4 rounded-xl bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-200 dark:border-emerald-500/20">
                  <CheckCircle className="w-5 h-5 text-emerald-500 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-semibold text-emerald-800 dark:text-emerald-200">Request submitted!</p>
                    <p className="text-xs text-emerald-700 dark:text-emerald-300 mt-1 leading-relaxed">
                      All admins have been notified. Once approved, you'll receive a temporary password — ask your admin directly if urgent.
                    </p>
                    <div className="flex items-center gap-1 mt-2 text-[11px] text-emerald-600 dark:text-emerald-400">
                      <Clock className="w-3 h-3" />
                      Typically approved within one shift
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => { setShowForgot(false); setForgotDone(false); setForgotEmail(''); }}
                  className="w-full flex items-center justify-center gap-1.5 text-xs text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 transition-colors py-1"
                >
                  <ArrowLeft className="w-3.5 h-3.5" /> Back to sign in
                </button>
              </div>
            ) : (
              <form onSubmit={handleForgotSubmit} className="space-y-3">
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                  Enter your <span className="font-medium">@appdirect.com</span> work email. We'll notify all admins immediately so they can set a temporary password for you.
                </p>
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">
                    Work Email <span className="text-red-400">*</span>
                  </label>
                  <input
                    type="email"
                    value={forgotEmail}
                    onChange={e => setForgotEmail(e.target.value)}
                    placeholder="firstname.lastname@appdirect.com"
                    className="input-base"
                    autoFocus
                    required
                  />
                </div>
                <button
                  type="submit"
                  disabled={forgotLoading || !forgotEmail.trim()}
                  className="btn-primary w-full justify-center"
                >
                  {forgotLoading
                    ? <span className="animate-spin w-4 h-4 border-2 border-white/30 border-t-white rounded-full" />
                    : <Send className="w-4 h-4" />}
                  {forgotLoading ? 'Submitting…' : 'Submit Reset Request'}
                </button>
                <button
                  type="button"
                  onClick={() => { setShowForgot(false); setForgotEmail(''); }}
                  className="w-full flex items-center justify-center gap-1.5 text-xs text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 transition-colors py-1"
                >
                  <ArrowLeft className="w-3.5 h-3.5" /> Back to sign in
                </button>
              </form>
            )}
          </div>

        ) : (
          /* ── Normal Sign-In View ──────────────────────────────── */
          <div className="card space-y-4">
            {/* Google Sign-In */}
            <button
              onClick={handleGoogleSignIn}
              disabled={googleLoading}
              className="w-full flex items-center justify-center gap-3 px-4 py-3 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-medium text-sm transition-all shadow-sm"
            >
              {googleLoading ? (
                <span className="animate-spin w-5 h-5 border-2 border-slate-400 border-t-primary-500 rounded-full" />
              ) : (
                <svg className="w-5 h-5" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                </svg>
              )}
              {googleLoading ? 'Signing in…' : 'Sign in with Google'}
            </button>

            <div className="flex items-center gap-2 text-[11px] text-slate-400 dark:text-slate-500">
              <div className="flex-1 h-px bg-slate-200 dark:bg-slate-700" />
              <span>@appdirect.com only · NOC team members</span>
              <div className="flex-1 h-px bg-slate-200 dark:bg-slate-700" />
            </div>

            {/* Password fallback */}
            {!showFallback ? (
              <button
                type="button"
                onClick={() => setShowFallback(true)}
                className="w-full text-[11px] text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-slate-300 text-center transition-colors"
              >
                Use password instead →
              </button>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-3 pt-1 border-t border-slate-200 dark:border-slate-700">
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">Email</label>
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="firstname.lastname@appdirect.com"
                    className="input-base"
                    autoFocus
                    autoComplete="username"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">Password</label>
                  <div className="relative">
                    <input
                      type={showPw ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••"
                      className="input-base pr-10"
                      autoComplete="current-password"
                    />
                    <button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300">
                      {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
                <button type="submit" disabled={loading || !username.trim() || !password} className="btn-primary w-full">
                  {loading ? <span className="animate-spin w-4 h-4 border-2 border-white/30 border-t-white rounded-full" /> : <LogIn className="w-4 h-4" />}
                  Sign in
                </button>
                {/* Forgot password link */}
                <button
                  type="button"
                  onClick={() => {
                    // Pre-fill email from the username field if they typed it
                    if (username.trim()) setForgotEmail(username.trim());
                    setShowForgot(true);
                    setShowFallback(false);
                  }}
                  className="w-full text-center text-[11px] text-amber-600 dark:text-amber-400 hover:text-amber-700 dark:hover:text-amber-300 transition-colors pt-1"
                >
                  🔑 Forgot password? Request a reset →
                </button>
              </form>
            )}

            <div className="flex items-center justify-center gap-1 text-[10px] text-slate-400 dark:text-slate-500">
              <Clock className="w-3 h-3" />
              Sessions last 9 hours · one full shift
            </div>
          </div>
        )}
      </div>
    </div>
  );
}


