import "dotenv/config";
import type { VercelRequest, VercelResponse } from '@vercel/node';

export default async function handler(req: VercelRequest, res: VercelResponse) {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'Content-Type',
    });
    return res.end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { model, messages } = req.body;
    const apiKey = process.env.AI_API_KEY;
    const platformUrl = process.env.AI_PLATFORM_URL || 'https://devs.ai';
    const agentId = model || process.env.AI_AGENT_ID;

    if (!apiKey) {
      return res.status(500).json({ error: 'AI_API_KEY not configured' });
    }

    const upstream = await fetch(`${platformUrl}/api/v1/chats/completions`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ model: agentId, messages, stream: true }),
    });

    res.writeHead(upstream.status, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      Connection: 'keep-alive',
    });

    if (!upstream.body) {
      return res.end();
    }

    const reader = (upstream.body as ReadableStream<Uint8Array>).getReader();
    const pump = async () => {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        res.write(value);
      }
      res.end();
    };
    pump().catch(() => res.end());
  } catch (err) {
    return res
      .status(500)
      .json({ error: err instanceof Error ? err.message : 'Server error' });
  }
}
