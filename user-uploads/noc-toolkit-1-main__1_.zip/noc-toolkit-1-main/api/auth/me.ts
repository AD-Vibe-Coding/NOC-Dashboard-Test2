import type { IncomingMessage, ServerResponse } from "node:http";
import { loadSession } from "./_lib/session.js";

export default async function handler(req: IncomingMessage, res: ServerResponse) {
  const session = await loadSession(req);
  res.statusCode = 200;
  res.setHeader("Content-Type", "application/json");
  if (!session) {
    res.end(JSON.stringify({ user: null }));
    return;
  }

  const supabaseUrl = process.env.VITE_SUPABASE_URL ?? '';
  const supabaseServiceKey = process.env.VITE_SUPABASE_SERVICE_ROLE_KEY;
  const supabaseAnonKey = process.env.VITE_SUPABASE_ANON_KEY;
  const supabaseKey = supabaseServiceKey ?? supabaseAnonKey ?? '';
  let nocUser: Record<string, unknown> | null = null;

  // Look up by EMAIL — our users table uses email as the primary identity for Google auth
  if (supabaseUrl && supabaseKey && session.email) {
    try {
      const email = session.email.toLowerCase().trim();
      const r = await fetch(
        `${supabaseUrl}/rest/v1/users?email=eq.${encodeURIComponent(email)}&select=*&limit=1`,
        {
          headers: {
            apikey: supabaseKey,
            Authorization: `Bearer ${supabaseKey}`,
            Accept: 'application/json',
          },
        }
      );
      if (r.ok) {
        const rows = (await r.json()) as Array<Record<string, unknown>>;
        if (rows.length > 0) nocUser = rows[0];
      }
    } catch { /* non-fatal — session still valid */ }
  }

  const firstName = (nocUser?.first_name as string) ?? '';
  const lastName = (nocUser?.last_name as string) ?? '';
  const fullName = `${firstName} ${lastName}`.trim() || (session.name ?? null);

  res.end(JSON.stringify({
    user: {
      id: nocUser?.id ?? session.sub,
      email: session.email ?? null,
      name: fullName,
      picture: session.picture ?? null,
      provider: session.provider,
      role: nocUser?.role ?? null,
      firstName: firstName || null,
      lastName: lastName || null,
      authorized: !!nocUser,
    },
  }));
}
