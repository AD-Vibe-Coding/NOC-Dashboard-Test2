# Maintenance Note Generator — Complete Specification

> **Version:** 1.0  
> **Last updated:** May 2026  
> **Author:** Sriram Parisa / NOC Toolkit  
> **Purpose:** This document fully describes the carrier maintenance email parser so that any developer, AI, or third party can replicate, extend, or audit it.

---

## 1. Overview

The Maintenance Note Generator parses raw carrier maintenance emails and produces a formatted **vCom customer notification**. It extracts 8 fields:

| # | Field | Example |
|---|---|---|
| 1 | Carrier name | AT&T |
| 2 | Circuit ID | IUEC.991754..ATI |
| 3 | Location / Address | 1801 5TH AV N BIRMINGHAM, AL 35203 |
| 4 | Start time | May 28, 2026, 12:00AM (CDT) |
| 5 | End time | May 28, 2026, 06:00AM (CDT) |
| 6 | Duration | up to 6 hours |
| 7 | Reason | IOS UPGRADE |
| 8 | Timezone | CDT |

Each field has a **confidence level**: `found` (✅), `guessed` (⚠️), or `not_found` (❌).

---

## 2. Architecture

```
Raw email text
      │
      ▼
┌──────────────────┐
│ detectCarrierType │  → identifies which carrier sent the email
└───────┬──────────┘
        │
        ▼
┌──────────────────┐
│ Carrier-specific  │  → one of 8 parser functions
│ parser function   │
└───────┬──────────┘
        │
        ▼
┌──────────────────┐
│ Duration calc     │  → calculates from start/end times if not explicit
└───────┬──────────┘
        │
        ▼
┌──────────────────┐
│ Output assembly   │  → MaintenanceData object with 8 fields + confidence
└──────────────────┘
```

**Files:**

| File | Purpose |
|---|---|
| `src/utils/maintenanceParser.ts` | Carrier detection, 8 parsers, duration calc, note generation |
| `src/utils/timezoneDetector.ts` | State/city→timezone mapping, DST calculation, UTC conversion |

---

## 3. Carrier Detection

The function `detectCarrierType(text)` checks the email body against keyword patterns **in priority order** (first match wins):

| Priority | Carrier | Internal Type | Detection Keywords |
|---|---|---|---|
| 1 | AT&T VPN | `att_vpn` | `"at&t planned maintenance event"` AND `"vpn"` |
| 2 | AT&T IP Services | `att_ip` | `"dear at&t ip services customer"` OR `"at&t network engineers"` |
| 3 | Spectrum Business | `spectrum` | `"spectrum business"` AND `"maintenance notifications"` |
| 4 | Windstream | `windstream` | `"windstream"` AND (`"maintenance notification"` OR `"wmt"`) |
| 5 | Nitel | `nitel` | `"nitel"` OR (`"nit"` AND `"scheduled maintenance"`) |
| 6 | Uniti Fiber | `uniti` | `"uniti fiber"` OR `"uniti"` |
| 7 | Expereo | `expereo` | `"expereo"` |
| 8 | Lumen | `lumen` | `"lumen"` OR `"centurylink"` OR `"level 3"` OR `"level3"` |
| 9 | Comcast | `comcast` | `"comcast"` |
| 10 | Frontier | `frontier` | `"frontier"` |
| 11+ | Generic fallback | `generic` | Scans for: Zayo, Cogent, Crown Castle, Verizon, Telia, NTT, Megaport, Equinix, T-Mobile, Cox |

**Important:** AT&T VPN is checked BEFORE AT&T IP because VPN emails also contain "AT&T" — the VPN-specific keyword `"vpn"` disambiguates. Both display as `"AT&T"` in the output.

If no carrier is detected → `type: 'generic'`, `display: '[Carrier Not Found]'`, `confidence: 'not_found'`.

---

## 4. Maintenance Type Detection

`detectMaintenanceType(text)` returns `'emergency'` or `'scheduled'`:

| Type | Keywords |
|---|---|
| Emergency | `"emergency maintenance"`, `"emergency notification"`, `"demand maintenance"` |
| Scheduled | `"scheduled maintenance"`, `"planned maintenance"`, `"please take note of this maintenance"` |

If neither matches, the user's manual toggle (from the UI) is used.

---

## 5. Carrier-Specific Parsers

### 5.1 AT&T IP Services (`parseATTIP`)

**Email signature:** `"Dear AT&T IP Services Customer"` or contains `"AT&T network engineers"`

| Field | Regex / Logic |
|---|---|
| Circuit ID | `/listed as a contact\.\s*\n?\s*([A-Z]{2,6}\.[A-Z0-9]+\.\.[A-Z]+)/i` then fallback: `/\b([A-Z]{2,6}\.\d{4,}\.\.[A-Z]{2,4})\b/` |
| Address | `/Address:\s*(.+?)(?:\n\|Please note)/i` |
| Reason | `/performing a\(n\)\s*(.+?)\.?\s*\n/i` |
| Start/End | `/performed on\s+(\d{2}\/\d{2}\/\d{4})\s*,\s*during the maintenance window of\s*(\d{1,2}:\d{2}\s*[AP]M)\s*-\s*(\d{1,2}:\d{2}\s*[AP]M)\s*,\s*local time/i` |
| Timezone | GAR city lookup → `cityTimezones` map, then address state → `stateTimezones` map |

**AT&T IP times are "local time"** — the parser detects the timezone from the GAR city name or the address state, then appends the correct DST-aware abbreviation (e.g., "CDT" in summer, "CST" in winter).

---

### 5.2 AT&T VPN (`parseATTVPN`)

**Email signature:** Contains `"at&t planned maintenance event"` AND `"vpn"`

| Field | Regex / Logic |
|---|---|
| Circuit ID | `/\b([A-Z]{2,6}\d{5,}[A-Z]{2,4})\b/` then fallback: `/\b(BFEC\d+)\b/i` |
| Reason | Hardcoded: `"network change (LCE / HW / Code upgrade)"` — AT&T VPN emails rarely specify |
| Start/End | `/Activity Date\/Time \(GMT\):\s*(.+)/i` → split on `" to "` or `" - "` → each half converted from UTC to local |
| Timezone | Detect from address state, then `convertUTCToTimezone()` to produce local times |
| Address | `/Location:\s*(.+)/i` or fallback generic |

**AT&T VPN times are in GMT/UTC** — the parser detects the local timezone from the address, then converts UTC→local using DST-aware offset calculation.

---

### 5.3 Spectrum Business (`parseSpectrum`)

**Email signature:** `"spectrum business"` AND `"maintenance notifications"`

| Field | Regex / Logic |
|---|---|
| Address | `/Location Description\s*\n(.+)/i` |
| Circuit ID | `/Account Number\s*\n(.+)/i` then fallback: generic circuit patterns |
| Start/End | `/Maintenance Window Start\s*\n(.+)/i` and `/Maintenance Window End\s*\n(.+)/i` |
| Timezone | `/Time Zone\s*\n(.+)/i` → maps to standard timezone name |
| Reason | `/Description\s*\n(.+)/i` → splits on `|`, takes first meaningful segment |
| Duration | Calculated from parsed start/end times |

Spectrum uses a **table-like format** with `Field Name\nValue` on consecutive lines. The parser looks for these exact field headers.

---

### 5.4 Windstream (`parseWindstream`)

**Email signature:** `"windstream"` AND (`"maintenance notification"` OR `"wmt"`)

| Field | Regex / Logic |
|---|---|
| Circuit ID | `/Service ID[:\s]+(.+)/i` then fallback: `/WMT[\s-]?(\d+)/i` (ticket number) |
| Address | `/Location[:\s]+(.+)/i` |
| Reason | `/Maintenance Reason[:\s]+(.+)/i` or `/Purpose[:\s]+(.+)/i` |
| Start/End | `/Start[:\s]+(.+)/i` and `/End[:\s]+(.+)/i` |
| Timezone | Explicit from text, typically ET — uses `detectTimezone()` |

Windstream has three sub-types: Emergency, Demand, and Scheduled. All are parsed the same way; the maintenance type is detected by `detectMaintenanceType()`.

---

### 5.5 Nitel (`parseNitel`)

**Email signature:** `"nitel"` or (`"nit"` AND `"scheduled maintenance"`)

| Field | Regex / Logic |
|---|---|
| Circuit ID | `/NIT-?\d+-\d+/i` or `/Service ID[:\s]+(.+)/i` |
| Address | `/Location[:\s]+(.+)/i` |
| Reason | `/Reason[:\s]+(.+)/i` or `/Description[:\s]+(.+)/i` |
| Start/End | `/Start[:\s]+(.+)/i` and `/End[:\s]+(.+)/i` |
| Timezone | `detectTimezone()` from text |

---

### 5.6 Uniti Fiber (`parseUniti`)

**Email signature:** `"uniti fiber"` or `"uniti"`

| Field | Regex / Logic |
|---|---|
| Circuit ID | `/NCC-\d+/i` or fallback generic |
| Address | `/Location[:\s]+(.+)/i` or `/Address[:\s]+(.+)/i` |
| Reason | `/Reason[:\s]+(.+)/i` or hardcoded `"fiber maintenance / software upgrade"` |
| Start/End | Looks for UTC times → converts to local. Pattern: `/Start.*?(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2})/i` |
| Timezone | UTC in email → converted to address-based local timezone |

---

### 5.7 Expereo (`parseExpereo`)

**Email signature:** `"expereo"`

| Field | Regex / Logic |
|---|---|
| Circuit ID | `/SVC-?\d+/i` or `/Service ID[:\s]+(.+)/i` |
| Address | `/Location[:\s]+(.+)/i` |
| Reason | `/Description[:\s]+(.+)/i` or `/Reason[:\s]+(.+)/i` |
| Start/End | UTC datetime patterns → converted to local |
| Timezone | UTC → auto-detect local from address |

---

### 5.8 Generic Parser (`parseGeneric`)

**Used for:** Lumen, Comcast, Frontier, Zayo, Cogent, Crown Castle, Verizon, Telia, NTT, Megaport, Equinix, T-Mobile, Cox, and any unrecognized carrier.

This parser uses broad regex patterns that work across most carrier email formats:

| Field | Regex / Logic |
|---|---|
| Circuit ID | Tries 15+ patterns in order: `/Circuit\s*(?:ID)?[:\s]+(.+)/i`, `/Order\s*#[:\s]+(.+)/i`, `/Account[:\s]+(.+)/i`, `/Service ID[:\s]+(.+)/i`, and various alphanumeric patterns like `/\b[A-Z]{2,6}\.\d{4,}\.\.[A-Z]{2,4}\b/`, `/\b\d{2,4}\/[A-Z]{4}\/\d{5,}\/[A-Z]{4}\b/` |
| Address | `/(?:Address\|Location\|Site)[:\s]+(.+)/i` with multiple fallbacks |
| Reason | `/(?:Reason\|Purpose\|Description\|Activity)[:\s]+(.+)/i` |
| Start/End | `/(?:Start\|Begin\|From)[:\s]+(.+)/i` and `/(?:End\|Until\|To\|Completion)[:\s]+(.+)/i` |
| Timezone | `detectTimezone()` — scans for explicit abbreviations, state codes, city names |

---

## 6. Timezone Detection Pipeline

`detectTimezone(text)` in `timezoneDetector.ts` uses a **6-step waterfall**:

| Step | Method | Confidence | Example |
|---|---|---|---|
| 1 | Explicit TZ abbreviation in text | `found` | `"12:00 AM CDT"` → Central |
| 2 | "Time Zone" field (Spectrum) | `found` | `"Time Zone\nPacific"` → Pacific |
| 3 | GAR city name (AT&T) | `found` | `"maintenance on Birmingham GAR"` → Central |
| 4 | State code before zip in address | `found` | `", AL 35203"` → Central |
| 5 | State code in address line | `found` | `"Address: ... AL"` → Central |
| 6 | Any 2-letter state code in text | `guessed` | `"AL"` anywhere → Central |

### State → Timezone Map (all 50 states + DC)

| Timezone | States |
|---|---|
| **Eastern** | CT, DC, DE, FL, GA, IN, KY, MA, MD, ME, MI, NC, NH, NJ, NY, OH, PA, RI, SC, VA, VT, WV |
| **Central** | AL, AR, IA, IL, KS, LA, MN, MO, MS, ND, NE, OK, SD, TN, TX, WI |
| **Mountain** | AZ, CO, ID, MT, NM, UT, WY |
| **Pacific** | CA, NV, OR, WA |
| **Alaska** | AK |
| **Hawaii** | HI |

### City → Timezone Map (AT&T GAR locations)

Eastern: Atlanta, Charlotte, Cleveland, Miami, New York, Philadelphia, Pittsburgh, Boston, Detroit, Jacksonville, Tampa, Augusta

Central: Madison, Chicago, Dallas, Houston, San Antonio, Kansas City, Minneapolis, Milwaukee, Nashville, Birmingham, St Louis, Memphis, Wichita, Oklahoma City

Mountain: Denver, Phoenix, Salt Lake, Colorado Springs, Albuquerque

Pacific: Los Angeles, San Francisco, Seattle, Portland, Sacramento, San Diego, San Jose, Las Vegas

### DST Calculation

US DST: **2nd Sunday of March** through **1st Sunday of November**.

```
isDSTForDate(date):
  marchSecondSunday = March 8 + (7 - dayOfWeek(March 1)) % 7
  novFirstSunday = Nov 1 + (7 - dayOfWeek(Nov 1)) % 7
  return date >= marchSecondSunday AND date < novFirstSunday
```

### Timezone Abbreviations (DST-aware)

| Timezone | Standard | Daylight |
|---|---|---|
| Eastern | EST | EDT |
| Central | CST | CDT |
| Mountain | MST | MDT |
| Pacific | PST | PDT |
| Alaska | AKST | AKDT |
| Hawaii | HST | HST (no DST) |

### UTC → Local Conversion

Used by AT&T VPN and Uniti (which provide times in UTC):

```
offsets = {
  Eastern: [-5, -4],  // [standard, daylight]
  Central: [-6, -5],
  Mountain: [-7, -6],
  Pacific: [-8, -7],
  Alaska: [-9, -8],
  Hawaii: [-10, -10],
}
localTime = utcTime + offset[isDST ? 1 : 0] hours
```

---

## 7. Duration Calculation

If the carrier parser doesn't extract an explicit duration, the system tries 3 strategies:

| Priority | Strategy |
|---|---|
| 1 | **Carrier-specific duration regex** — e.g., `/up to (\d+)\s*(hour|minute)/i` |
| 2 | **Calculate from start/end times** — `calculateDurationFromTimes(startStr, endStr)` extracts hours from AM/PM times and computes the difference |
| 3 | **Fallback** — `"[Duration Not Found]"` with confidence `not_found` |

`calculateDurationFromTimes` logic:
- Extract hour values from time strings (handles `12:00AM` = 0, `12:00PM` = 12, etc.)
- If end < start, assumes next-day window (adds 24 hours)
- Returns `"up to N hours"` format

---

## 8. Output Note Template

### Rich HTML (for Outlook / Slack / Word)

```html
<div>
  <p>Hello Team,</p>
  <p>Please be advised, <strong>{carrier}</strong> will be performing
     <strong>{type}</strong> maintenance that will impact your service
     at location <strong>{address}</strong>.</p>
  <p>Your vCom provided circuit <strong>{circuitId}</strong> will be
     subject to an outage lasting <strong>{duration}</strong> during
     this maintenance window (Please note this is an estimate and no
     guarantee of actual impact). This maintenance is for
     <strong>{reason}</strong></p>
  <ul>
    <li><strong>Start time:</strong> {startTime}</li>
    <li><strong>End time:</strong> {endTime}</li>
  </ul>
  <p>If you experience service issues after that window, you may need
     to reboot your equipment. If you continue to have any problems,
     call our toll-free Technical Support number
     <strong>800-804-8266 opt 3</strong>, and refer to this ticket
     for further assistance.</p>
</div>
```

### Plain Text (for terminals / plain-text fields)

```
Hello Team,

Please be advised, {carrier} will be performing {type} maintenance
that will impact your service at location {address}.

Your vCom provided circuit {circuitId} will be subject to an outage
lasting {duration} during this maintenance window (Please note this
is an estimate and no guarantee of actual impact). This maintenance
is for {reason}

• Start time: {startTime}
• End time: {endTime}

If you experience service issues after that window, you may need to
reboot your equipment. If you continue to have any problems, call
our toll-free Technical Support number 800-804-8266 opt 3, and refer
to this ticket for further assistance.
```

---

## 9. How to Add a New Carrier

1. **Add a detection rule** in `detectCarrierType()`:
   ```ts
   if (lower.includes('newcarrier')) {
     return { type: 'newcarrier', display: 'NewCarrier', confidence: 'found' };
   }
   ```
   Place it ABOVE the generic fallback section, in priority order (more specific keywords first).

2. **Create a parser function** `parseNewCarrier(text)`:
   ```ts
   function parseNewCarrier(text: string): Partial<MaintenanceData> {
     let circuitId = field('[Circuit ID Not Found]', 'not_found');
     // ... regex patterns specific to this carrier's email format
     return { circuitId, address, reason, startTime, endTime, timezone };
   }
   ```

3. **Wire it into the router** in `parseMaintenanceEmail()`:
   ```ts
   case 'newcarrier': parsed = parseNewCarrier(text); break;
   ```

4. **Add to SUPPORTED_CARRIERS list**:
   ```ts
   { name: 'NewCarrier', format: 'Description of their email format' },
   ```

5. **Test** with 3-5 real maintenance emails from the carrier, verifying all 8 fields parse with `found` confidence.

---

## 10. TypeScript Types

```ts
type ConfidenceLevel = 'found' | 'guessed' | 'not_found';

interface ParsedField<T = string> {
  value: T;
  confidence: ConfidenceLevel;
}

interface MaintenanceData {
  carrier: ParsedField;
  address: ParsedField;
  circuitId: ParsedField;
  startTime: ParsedField;
  endTime: ParsedField;
  duration: ParsedField;
  reason: ParsedField;
  timezone: ParsedField;
}

type MaintenanceType = 'scheduled' | 'emergency';

type CarrierType = 'att_ip' | 'att_vpn' | 'spectrum' | 'windstream'
  | 'nitel' | 'uniti' | 'expereo' | 'lumen' | 'comcast'
  | 'frontier' | 'generic';
```

---

## 11. File Locations

| File | Lines | Description |
|---|---|---|
| `src/utils/maintenanceParser.ts` | ~665 | All parsing logic — self-contained, no React dependencies |
| `src/utils/timezoneDetector.ts` | ~180 | Timezone detection — self-contained, no dependencies |
| `src/components/maintenance/MaintenanceForm.tsx` | ~100 | UI: paste area + carrier list + type toggle |
| `src/components/maintenance/MaintenanceOutput.tsx` | ~170 | UI: parsed fields display + formatted note + copy buttons |
| `src/components/maintenance/ConfidenceIndicator.tsx` | ~30 | UI: colored ✅ ⚠️ ❌ badges |
| `src/types/index.ts` | Shared types | `MaintenanceData`, `MaintenanceType`, `ConfidenceLevel` |

---

## 12. Supported Carriers (19 total)

| # | Carrier | Parser | Email Format |
|---|---|---|---|
| 1 | AT&T | `parseATTIP` / `parseATTVPN` | IP: GAR/local times. VPN: GMT/UTC times. Unified display. |
| 2 | Spectrum Business | `parseSpectrum` | Table-based with field headers |
| 3 | Windstream | `parseWindstream` | Emergency/Demand/Scheduled, ET times, WMT tickets |
| 4 | Nitel | `parseNitel` | NIT service IDs, ticket-based |
| 5 | Uniti Fiber | `parseUniti` | NCC tickets, UTC times |
| 6 | Expereo | `parseExpereo` | International SVC IDs, UTC times |
| 7 | Lumen / CenturyLink / Level 3 | `parseGeneric` | Standard format |
| 8 | Comcast | `parseGeneric` | Standard format |
| 9 | Frontier | `parseGeneric` | Standard format |
| 10 | Zayo | `parseGeneric` | Generic |
| 11 | Cogent | `parseGeneric` | Generic |
| 12 | Crown Castle | `parseGeneric` | Generic |
| 13 | Verizon | `parseGeneric` | Generic |
| 14 | Telia | `parseGeneric` | Generic |
| 15 | NTT | `parseGeneric` | Generic |
| 16 | Megaport | `parseGeneric` | Generic |
| 17 | Equinix | `parseGeneric` | Generic |
| 18 | T-Mobile | `parseGeneric` | Generic |
| 19 | Cox | `parseGeneric` | Generic |

---

## 13. Quick Reference: Regex Patterns by Field

### Circuit ID patterns (tried in order)

```
/listed as a contact\.\s*\n?\s*([A-Z]{2,6}\.[A-Z0-9]+\.\.[A-Z]+)/i     — AT&T IP
/\b([A-Z]{2,6}\.\d{4,}\.\.[A-Z]{2,4})\b/                               — AT&T IP fallback
/\b([A-Z]{2,6}\d{5,}[A-Z]{2,4})\b/                                     — AT&T VPN
/\b(BFEC\d+)\b/i                                                        — AT&T VPN fallback
/Account Number\s*\n(.+)/i                                               — Spectrum
/Service ID[:\s]+(.+)/i                                                  — Windstream / Nitel
/NIT-?\d+-\d+/i                                                          — Nitel ticket
/NCC-\d+/i                                                               — Uniti
/SVC-?\d+/i                                                              — Expereo
/Circuit\s*(?:ID)?[:\s]+(.+)/i                                          — Generic
/\b\d{2,4}\/[A-Z]{4}\/\d{5,}\/[A-Z]{4}\b/                             — Generic (Lumen style)
```

### Date/time patterns

```
/performed on\s+(\d{2}\/\d{2}\/\d{4}).*?(\d{1,2}:\d{2}\s*[AP]M)\s*-\s*(\d{1,2}:\d{2}\s*[AP]M)/i  — AT&T IP
/Activity Date\/Time \(GMT\):\s*(.+)/i                                    — AT&T VPN (UTC)
/Maintenance Window Start\s*\n(.+)/i                                      — Spectrum
/Start[:\s]+(.+)/i                                                        — Windstream / Generic
/\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}/                                       — ISO format (Uniti/Expereo)
/\d{2}\/\d{2}\/\d{4}\s+\d{1,2}:\d{2}\s*[AP]M/i                         — US date format
```

---

*End of specification. These two files (`maintenanceParser.ts` + `timezoneDetector.ts`) are completely standalone — zero React or UI dependencies. You can drop them into any TypeScript/JavaScript project and call `parseMaintenanceEmail(rawText)` to get structured data.*
