# NOC Operations Toolkit — Complete Project Blueprint

> **Purpose:** This document is a full architectural specification, feature list,
> AI prompt library, UI design system, file inventory, and step-by-step
> recreation guide. Hand it to any developer or AI (Devs.ai, ChatGPT, Cursor,
> Copilot) and they can rebuild the entire application from scratch.

---

## Table of Contents

1. [Project Overview](#1-project-overview)
2. [Tech Stack & Dependencies](#2-tech-stack--dependencies)
3. [Environment Variables](#3-environment-variables)
4. [File Tree (every file)](#4-file-tree)
5. [Architecture](#5-architecture)
6. [UI Design System](#6-ui-design-system)
7. [Page-by-Page Feature Spec](#7-page-by-page-feature-spec)
8. [AI Integration (Devs.ai)](#8-ai-integration-devsai)
9. [AI System Prompts (full text)](#9-ai-system-prompts)
10. [Confluence Wiki Grounding](#10-confluence-wiki-grounding)
11. [Clipboard Engine](#11-clipboard-engine)
12. [Maintenance Parser Spec](#12-maintenance-parser-spec)
13. [Carrier Contact Database](#13-carrier-contact-database)
14. [Branding Components](#14-branding-components)
15. [Planned: Supabase Auth](#15-planned-supabase-auth)
16. [Planned: Future Features](#16-planned-future-features)
17. [How to Recreate Step-by-Step](#17-how-to-recreate-step-by-step)

---

## 1. Project Overview

**App Name:** NOC Operations Toolkit
**Built by:** Sriram Parisa
**Company:** AppDirect — vCom Business Unit
**AI Platform:** Devs.ai (IT Specialist agent)
**Purpose:** All-in-one workstation for Network Operations Center (NOC) and
Security Operations Center (SOC) engineers. Replaces scattered bookmarks,
spreadsheets, and tribal knowledge with a single, fast, dark-mode web app.

**Current stats:**
- 68 source files
- ~8,900 lines of TypeScript/TSX
- 12 pages, 13+ routes
- 19 supported carrier formats
- 200+ carrier NOC contacts
- 28 NOC communication scripts
- 14 iPath/LogicMonitor fault types
- 5 network device categories × 3 troubleshooting tiers
- AI assistant with scope guard + Confluence grounding

---

## 2. Tech Stack & Dependencies

| Layer | Technology |
|---|---|
| Framework | React 18 + TypeScript 5.4 |
| Build | Vite 5 |
| Styling | Tailwind CSS 3.4 + `@tailwindcss/typography` |
| Routing | React Router DOM 6.22 |
| Icons | Lucide React 0.344 |
| AI rendering | `react-markdown` 10 |
| Toasts | `react-hot-toast` 2.4 |
| AI Platform | Devs.ai (custom SSE proxy) |
| Production deploy | Vercel (`@vercel/node` 3) |

### package.json dependencies

```json
{
  "dependencies": {
    "@tailwindcss/typography": "^0.5.19",
    "@vercel/node": "^3.2.29",
    "lucide-react": "^0.344.0",
    "react": "^18.3.1",
    "react-dom": "^18.3.1",
    "react-hot-toast": "^2.4.1",
    "react-markdown": "^10.1.0",
    "react-router-dom": "^6.22.3"
  },
  "devDependencies": {
    "@types/react": "^18.3.1",
    "@types/react-dom": "^18.3.1",
    "@vitejs/plugin-react": "^4.2.1",
    "autoprefixer": "^10.4.18",
    "postcss": "^8.4.35",
    "tailwindcss": "^3.4.1",
    "typescript": "^5.4.2",
    "vite": "^5.1.6"
  }
}
```

---

## 3. Environment Variables

File: `.env` (root of project)

```env
AI_API_KEY=sk-<your-devs-ai-api-key>
AI_AGENT_ID=d3f4d2d4-4dc3-4964-9d93-9d0a9703cec7
AI_PLATFORM_URL=https://devs.ai
VITE_AI_AGENT_ID=d3f4d2d4-4dc3-4964-9d93-9d0a9703cec7
```

**Rules:**
- `AI_API_KEY` — NEVER prefixed with `VITE_`, NEVER in browser code
- `VITE_AI_AGENT_ID` — safe to expose (just an identifier, not a secret)
- Vite auto-loads `.env` in dev; Vercel injects env vars at runtime

**Planned (Supabase):**
```env
VITE_SUPABASE_URL=https://auxdlvsvmuepyztyewyy.supabase.co
VITE_SUPABASE_ANON_KEY=eyJ...
```

---

## 4. File Tree

```
project/
├── .env                           # API keys (never committed)
├── index.html                     # SPA entry (has devs-inspect.js)
├── package.json                   # Dependencies
├── tsconfig.json                  # TypeScript config
├── tsconfig.node.json             # Node TS config
├── vite.config.ts                 # Vite + AI proxy + Confluence proxy
├── tailwind.config.js             # Tailwind + typography plugin
├── postcss.config.js              # PostCSS
├── vercel.json                    # Vercel deploy config
├── api/
│   └── ai/
│       └── chat.ts                # Production serverless AI proxy
├── docs/
│   ├── maintenance-parser-spec.md # Parser specification
│   └── NOC-TOOLKIT-COMPLETE-BLUEPRINT.md  # THIS FILE
├── src/
│   ├── main.tsx                   # React entry (BrowserRouter + ThemeProvider)
│   ├── App.tsx                    # Route definitions (13 routes)
│   ├── index.css                  # Global styles, Tailwind layers, animations
│   ├── vite-env.d.ts              # Vite type declarations
│   │
│   ├── types/
│   │   └── index.ts               # All TypeScript interfaces
│   │
│   ├── context/
│   │   └── ThemeContext.tsx        # Dark/light theme provider
│   │
│   ├── hooks/
│   │   ├── useTheme.ts            # Theme toggle hook (localStorage)
│   │   ├── useLocalStorage.ts     # Generic localStorage hook
│   │   ├── useClipboard.ts        # Legacy clipboard hook
│   │   └── useAISettings.ts       # AI model override + Confluence config
│   │
│   ├── lib/
│   │   ├── clipboard-rich.ts      # Rich copy engine (4-tier fallback)
│   │   ├── devs-ai/
│   │   │   └── client.ts          # SSE streaming client for Devs.ai
│   │   └── confluence/
│   │       └── client.ts          # Confluence search + context formatter
│   │
│   ├── data/
│   │   ├── carrierContacts.ts     # 200+ US carrier NOC contacts (auto-generated)
│   │   └── outageMaps.ts          # Carrier outage map URLs
│   │
│   ├── utils/
│   │   ├── maintenanceParser.ts   # 8 carrier-specific parsers + generic
│   │   ├── timezoneDetector.ts    # US state/city → timezone, DST-aware
│   │   ├── subnetCalculator.ts    # CIDR calculator engine
│   │   ├── carrierSearch.ts       # Fuzzy carrier search + AI summarizer
│   │   ├── carrierAIPrompt.ts     # Carrier AI system prompt builder
│   │   └── clipboard.ts           # Legacy plain-text clipboard util
│   │
│   ├── components/
│   │   ├── ui/                    # Reusable UI primitives
│   │   │   ├── Button.tsx
│   │   │   ├── Card.tsx
│   │   │   ├── Input.tsx
│   │   │   ├── Textarea.tsx
│   │   │   ├── Toggle.tsx
│   │   │   ├── Accordion.tsx
│   │   │   ├── Badge.tsx
│   │   │   ├── ThemeToggle.tsx
│   │   │   └── Brand.tsx          # CompanyBadge + DevsAiBadge
│   │   │
│   │   ├── layout/
│   │   │   ├── Layout.tsx         # Shell (Navbar + Sidebar + Footer + Outlet)
│   │   │   ├── Navbar.tsx         # Top bar with branding + theme toggle
│   │   │   ├── Sidebar.tsx        # Left nav with collapsible groups
│   │   │   └── Footer.tsx         # Bottom attribution bar
│   │   │
│   │   ├── ai/
│   │   │   ├── AIBadge.tsx        # Custom SVG mark (gradient squircle + nodes)
│   │   │   ├── ChatInterface.tsx  # Full chat UI (NOC_SYSTEM_PROMPT, streaming)
│   │   │   ├── ChatMessage.tsx    # Single message bubble (markdown rendered)
│   │   │   ├── MessageActions.tsx # Copy/Plain/Regenerate buttons per message
│   │   │   ├── PromptStarters.tsx # 8 starter prompts with icons
│   │   │   └── SettingsModal.tsx  # AI model override + Confluence config
│   │   │
│   │   ├── maintenance/
│   │   │   ├── MaintenanceForm.tsx    # Email input + carrier list + generate
│   │   │   ├── MaintenanceOutput.tsx  # Parsed fields + formatted note + copy
│   │   │   └── ConfidenceIndicator.tsx # Green/amber/red confidence dots
│   │   │
│   │   ├── subnet/
│   │   │   ├── SubnetCalculator.tsx   # CIDR input + results
│   │   │   ├── CIDRReferenceTable.tsx # /0 to /32 reference
│   │   │   └── IPVisualMap.tsx        # Color-coded IP grid
│   │   │
│   │   └── carriers/
│   │       ├── CarrierSearchBar.tsx   # Search + AI toggle
│   │       ├── CarrierFilters.tsx     # Category filters
│   │       ├── CarrierCard.tsx        # Expandable carrier info
│   │       ├── EscalationTierTable.tsx # Tiered escalation contacts
│   │       ├── AICarrierResults.tsx   # AI search results panel
│   │       ├── PhoneLink.tsx          # Click-to-call phone link
│   │       ├── EmailLink.tsx          # Click-to-email link
│   │       └── OutageMapButton.tsx    # Link to carrier outage page
│   │
│   └── pages/
│       ├── Dashboard.tsx              # 11-tile grid + tips + branding
│       ├── MaintenancePage.tsx        # Wrapper for form + output
│       ├── SubnetPage.tsx             # Wrapper for calculator
│       ├── CarrierContactsPage.tsx    # Search + filter + cards + AI search
│       ├── MobilityPage.tsx           # 5-tab device troubleshooting
│       ├── NOCScriptsPage.tsx         # 28 scripts with copy buttons
│       ├── NetworkDevicesPage.tsx     # 5-tab device categories, 3 tiers
│       ├── FaultTypesPage.tsx         # 14 iPath/LM fault types
│       ├── SDWanMetricsPage.tsx       # Thresholds + monitoring tiers
│       ├── AIAssistantPage.tsx        # Chat wrapper with header
│       ├── DocumentationPage.tsx      # User guide
│       ├── FAQPage.tsx                # FAQ accordion
│       └── NotFound.tsx               # 404
```

---

## 5. Architecture

### Data Flow

```
User types in chat input
        │
        ▼
ChatInterface.tsx
  ├── If Confluence enabled: POST /api/confluence/search (via Vite proxy)
  │     └── Vite middleware → Confluence Cloud REST API (Basic auth)
  │           └── Returns page excerpts → formatted as context block
  │
  ├── Prepends: [system prompt] + [confluence context] + [user message]
  │
  └── POST /api/ai/chat (via Vite proxy in dev, Vercel function in prod)
        └── Vite middleware / Vercel handler
              └── POST https://devs.ai/api/v1/chats/completions
                    Headers: Authorization: Bearer <AI_API_KEY>
                    Body: { model: <agent_id>, messages: [...], stream: true }
                    Response: SSE stream
                          │
                          ▼
                    client.ts SSE parser
                    ├── event: message.delta → onDelta(text chunk)
                    ├── event: message.complete → onComplete()
                    └── event: message.error → onError(msg)
```

### Routing

```
/                       → Dashboard (11 tiles)
/maintenance            → Maintenance Note Generator
/subnet                 → IP / Subnet Calculator
/carriers               → Carrier Contacts (200+ carriers)
/mobility               → Mobility Troubleshooting (5 tabs)
/network-hub/scripts    → NOC Scripts (28 scripts)
/network-hub/devices    → Network Devices (5 categories × 3 tiers)
/network-hub/fault-types → iPath Fault Types (14 LM alerts)
/network-hub/sdwan-metrics → SD-WAN Metrics & Monitoring Tiers
/ai-assistant           → AI Assistant (streaming chat)
/documentation          → Documentation
/faq                    → FAQ
```

---

## 6. UI Design System

### Theme
- **Dark mode by default** (`<html class="dark">`)
- Toggle via ThemeContext (persisted in localStorage)
- Colors: Tailwind slate palette for surfaces, custom primary (blue) + accent (emerald)

### Color Palette

```js
primary: { 50-900 } // Blue (#3B82F6 at 500)
accent:  { 50-900 } // Emerald (#10B981 at 500)
```

### Typography
- Body: `Inter` (weights: 300-800)
- Code: `JetBrains Mono` (weights: 400-600)

### Component Patterns
- Cards: `bg-white dark:bg-slate-800 rounded-xl shadow-sm border p-6`
- Inputs: `rounded-lg bg-white dark:bg-slate-800 border focus:ring-2 focus:ring-primary-500`
- Buttons: `btn-primary`, `btn-secondary`, `btn-ghost`, `btn-danger`
- Badges: `badge-success`, `badge-warning`, `badge-danger`
- Animations: `animate-fade-in` (0.3s ease-out translateY), `animate-slide-in`

### Layout
- Fixed top navbar (h-16, backdrop-blur)
- Fixed left sidebar (w-64, collapsible on mobile)
- Main content area with Footer
- All pages max-width constrained (`max-w-5xl mx-auto` or full-bleed for chat)

---

## 7. Page-by-Page Feature Spec

### Dashboard (`/`)
- Hero section with Shield icon + "Network Operations Center" badge
- Title: "NOC Operations Toolkit"
- Company badges: `CompanyBadge` (AppDirect · vCom BU) + `DevsAiBadge`
- 11 tool tiles in 3-column grid (responsive: 1→2→3 cols)
- 3 Quick Tips cards
- Each tile: icon + title + description, hover effect, links to page

### Maintenance Note Generator (`/maintenance`)
- Toggle: Scheduled vs Emergency
- Supported carriers badge (expandable, shows all 19 carriers)
- Large textarea for raw email paste
- "Generate vCom Note" button
- Output: parsed fields grid (8 fields with confidence indicators)
- Formatted note preview
- Copy button (rich HTML) + Plain button (text only)
- Confidence: green dot = found, amber = guessed, red = not found

### IP / Subnet Calculator (`/subnet`)
- CIDR input (e.g., `192.168.1.0/24`)
- Results: network, mask, wildcard, gateway, usable range, broadcast, total/usable IPs
- Visual IP map (color-coded grid: network=gray, gateway=blue, usable=green, broadcast=red)
- CIDR reference table (/0 through /32)

### Carrier Contacts (`/carriers`)
- Search bar with AI toggle
- Category filters (Business / Residential / Both)
- Expandable carrier cards (200+ carriers)
- Each card: name, category badge, services list, all phones/emails/URLs
- Expandable escalation tier table (Buyers Club + Brokerage paths)
- AI-powered search: streams answer from carrier-grounded prompt
- Outage map buttons per carrier

### Mobility Troubleshooting (`/mobility`)
- 5 tabs: iPhone, Android Phone, iPad, Android Tablet, SIM/eSIM Management
- Each tab: device icon + blurb + expandable issues
- Each issue: title, numbered steps, "Ask AI" button (prefills AI assistant)
- Quick Actions at bottom (WiFi, Cellular, Factory Reset)
- APN reference tables per carrier

### NOC Scripts (`/network-hub/scripts`)
- Search bar to filter scripts
- 28 scripts, each with:
  - Number badge + title
  - Expandable preview (click to expand)
  - Copy button (rich HTML with bold + bullets)
  - Plain button (text only)
- Scripts cover: acknowledgement, down hard, circuit down, outage confirmed, ETR, closing, maintenance, packet loss, gateway offline, IP whitelisting, flap notification, and more

### Network Devices (`/network-hub/devices`)
- 5 tabs: Cisco Meraki, SD-WAN, Fortinet FortiGate, Carrier Routers & Modems, Combo Devices
- Each tab: device models listed, issues grouped by tier:
  - 🟢 Common (green badge)
  - 🟡 Intermediate (amber badge)
  - 🔴 Advanced (red badge)
- Each issue: expandable with numbered steps + "Ask AI" button
- Search bar filters across all tabs

### iPath Fault Types (`/network-hub/fault-types`)
- 14 LogicMonitor fault types from iPath tickets
- Each fault: name, value, severity badge (Critical/Warning/Info), MNS tier tags
- Full description paragraph (exact operational text)
- NOC Action Steps as numbered list
- Special notes highlighted (Dentons, Susser Bank, escalation contacts)
- "Extra Troubleshooting: Check Alerts" callout box
- Search + filter by severity and monitoring tier
- Escalation contacts: Otukho, Ani, Perry, Karthik, Anirudh, Engineering Chat, _MNSChanges

### SD-WAN Metrics (`/network-hub/sdwan-metrics`)
- Performance thresholds table (Latency/Jitter/Packet Loss/MOS) with green/amber/red cells
- Application SLA profiles (VoIP, Video Conferencing, VDI, SaaS/Web)
- VoIP MOS quality reference
- Monitoring Tiers comparison (MNS-Standard vs Circuit Performance vs Hardware MGMT)

### AI Assistant (`/ai-assistant`)
- Full-height chat interface with streaming responses
- Custom AIBadge in header
- DevsAiBadge showing active model
- Settings button → modal for model override + Confluence config
- Wiki connected/off badge
- Empty state with 8 prompt starters
- Messages rendered with ReactMarkdown (prose-invert)
- Per-message actions: Copy (rich), Plain, Regenerate
- Scope guard: refuses off-topic questions

### Documentation (`/documentation`)
- Expandable sections covering all features
- Quick-start guide
- Feature descriptions
- Tool-specific instructions

### FAQ (`/faq`)
- Accordion-style Q&A
- Covers: privacy, carriers, AI, building the toolkit

---

## 8. AI Integration (Devs.ai)

### Architecture: Server-Mediated Proxy

```
Browser → /api/ai/chat (same-origin) → Server → https://devs.ai/api/v1/chats/completions
```

**Dev mode:** Vite middleware plugin (`aiProxyPlugin()` in vite.config.ts)
**Production:** Vercel serverless function (`api/ai/chat.ts`)

### SSE Stream Format (NOT OpenAI format)

```
event: message.delta
data: {"type":"message.delta","content":{"type":"text","text":"chunk"}}

event: message.complete
data: {"type":"message.complete"}
```

### Client Implementation (`src/lib/devs-ai/client.ts`)

Key functions:
- `sendMessage(messages, onDelta, onComplete, onError, opts)` — callback-based streaming
- `streamMessage(messages, opts)` — async generator wrapper

The SSE parser handles: buffering, partial chunks, keep-alive comments (`:` lines), blank-line event boundaries, named events.

### Agent: IT Specialist
- Agent ID: `d3f4d2d4-4dc3-4964-9d93-9d0a9703cec7`
- Description: "I am an expert in all things IT!"
- Used for both main chat and carrier AI search

---

## 9. AI System Prompts

### Main NOC Assistant Prompt (ChatInterface.tsx)

The system prompt is ~3000 words covering:

1. **SCOPE GUARD** — refuses jokes, chitchat, creative writing, recipes, sports, news, politics, personal advice, entertainment, off-topic. Returns exact one-line refusal.
2. **Networking Fundamentals** — OSI, TCP/IP, IPv4/IPv6, subnetting, VLANs, STP, LAG, ARP
3. **Routing** — BGP (eBGP/iBGP, communities, route-maps), OSPF, EIGRP, static, MPLS
4. **Switching** — L2/L3, port security, DHCP snooping, DAI, storm-control
5. **Core Services** — DNS, DHCP, NAT, NTP, SNMP, syslog, 802.1X/RADIUS
6. **CCNA/CCNP depth** — certification-level answers
7. **Network Security / SOC** — zero trust, IDS/IPS, SIEM, SOAR, EDR/XDR, MITRE ATT&CK
8. **Packet Analysis** — Wireshark display + BPF capture filters, TCP analysis, TLS handshake
9. **Log Analysis** — syslog, FortiAnalyzer, Cisco ASA, Palo Alto, SolarWinds, LogicMonitor
10. **CLI Tools** — ping, traceroute, nslookup, dig, netstat, ss, arp, ipconfig, ifconfig, curl, openssl
11. **Well-Known Ports** — full table of common + malware ports
12. **Network Devices** — NID, ONT, routers, L2/L3 switches, SD-WAN edges, firewalls
13. **Vendor CLIs** — Cisco IOS/IOS-XE, FortiOS, JunOS, Aruba/HPE, Meraki Dashboard
14. **Monitoring** — LogicMonitor, SolarWinds, PRTG, Zabbix, Datadog, Nagios
15. **Mobility** — iOS/Android troubleshooting, SIM/eSIM, APN, carrier portals
16. **Operational Writing** — daily notes, email summarization, escalation drafting, shift handovers
17. **OUTPUT RULES** — markdown formatting, lead with answer, structured for scanning

### Carrier AI Prompt (carrierAIPrompt.ts)

Built dynamically with `buildCarrierSystemPrompt(carriers)`:
- Scope guard (same refusal line)
- Injects full carrier directory summary (names, phones, emails, services)
- Rules: prefer directory data, format as scannable bullets, never invent contacts
- Outage map guidance

### Prompt Starters (8 starters)

1. "Rewrite my daily notes" — shift handover formatter
2. "Summarize an email thread" — TL;DR + decisions + action items
3. "Carrier maintenance update" — customer-facing draft
4. "iPhone won't connect to cellular" — troubleshooting checklist
5. "Explain a /29 subnet" — subnet mask, IPs, example table
6. "Write an escalation script" — carrier NOC call script
7. "Decode a Wireshark filter" — token-by-token explanation
8. "Cisco ↔ Fortinet translator" — cross-vendor command mapping

---

## 10. Confluence Wiki Grounding

**How it works:**
1. User configures Confluence in AI Settings (base URL, email, API token, optional space key)
2. When user sends a message, the app auto-searches Confluence for related pages
3. Top 5 page excerpts are prepended to the user's message as context
4. The AI cites Confluence pages inline as [1], [2], etc.

**Server proxy:** `/api/confluence/search` in vite.config.ts
- Avoids CORS with Atlassian Cloud
- Sends Basic auth with user's token (stored in localStorage, sent per-request)
- CQL query: `type = "page" AND text ~ "query"` (optionally filtered by space)

---

## 11. Clipboard Engine

File: `src/lib/clipboard-rich.ts`

**4-tier fallback strategy:**
1. `ClipboardItem` API (modern browsers) — HTML + plain text
2. Isolated `<iframe>` + `execCommand('copy')` — clean neutral theme (no dark bg leak)
3. `navigator.clipboard.writeText()` — plain text only
4. Hidden `<textarea>` + `execCommand('copy')` — last resort

**Key function:** `sanitizeForClipboard(html)` — strips all `style`, `class`, `bgcolor`, `color`, `face`, `background`, `dir`, `data-*` attributes and `<style>`/`<script>` elements.

**Result:** Bold, bullets, headings preserved in Outlook/Slack/Word/ServiceNow. No dark background bleeding through.

---

## 12. Maintenance Parser Spec

See `docs/maintenance-parser-spec.md` for the full 500-line specification.

**Quick summary:**
- 8 carrier-specific parsers + generic fallback
- 19 supported carriers (AT&T unified, Spectrum, Windstream, Nitel, Uniti, Expereo, Lumen, Comcast, Frontier, Zayo, Cogent, Crown Castle, Verizon, Telia, NTT, Megaport, Equinix, T-Mobile, Cox)
- Extracts 8 fields: carrier, circuit ID, address, start time, end time, duration, reason, timezone
- DST-aware timezone detection (state→TZ mapping, city→TZ mapping, explicit abbreviation detection)
- UTC→local conversion for carriers that report in GMT/UTC
- Confidence indicators: found (green), guessed (amber), not_found (red)

---

## 13. Carrier Contact Database

File: `src/data/carrierContacts.ts`
- Auto-generated from Excel spreadsheet via `scripts/parseCarriers.py` + `scripts/jsonToTs.cjs`
- 200+ US carriers with: name, category, services (with phones/emails/URLs/notes)
- Separate escalation data: Buyers Club + Brokerage paths, up to 11 tiers per carrier

File: `src/data/outageMaps.ts`
- Maps carrier names to their public outage/status page URLs

---

## 14. Branding Components

File: `src/components/ui/Brand.tsx`

**CompanyBadge:** `AppDirect · vCom BU` — Shield icon, primary-colored chip
**DevsAiBadge:** `Devs.ai` — Sparkles icon, violet chip, optional model id inline

File: `src/components/ai/AIBadge.tsx`

Custom SVG mark — gradient indigo→purple→cyan squircle with 4 circuit nodes + glowing core. Used in: chat avatars, sidebar, header, dashboard, empty state. Self-contained (no deps), `useId()` for unique gradient IDs.

**Placed in:** Navbar, Footer, Dashboard hero, AI Assistant header, AI Settings modal, Chat empty state

---

## 15. Planned: Supabase Auth

**Supabase project:** `https://auxdlvsvmuepyztyewyy.supabase.co`

Planned features:
- Email/password login (no Google Workspace approval needed)
- Super admin: `sriram.parisa@appdirect.com`
- Roles: super_admin, admin, user
- Block/unblock users
- AI usage tracking per user
- Admin-editable carrier contacts
- Protected routes + logout

---

## 16. Planned: Future Features

- Wireshark filter cheatsheet page (searchable)
- Ports reference page (well-known + registered + malware, searchable)
- Network CLI cheatsheet (side-by-side Win/Linux/macOS/Cisco/Fortinet)
- Log analyzer paste-in tool
- Vendor command translator page
- CCNA/CCNP quiz mode
- RCA/outage drafter
- Visually-styled "refused" messages in chat
- "Powered by Devs.ai" caption on every AI response
- Badge watermark in copied maintenance notes

---

## 17. How to Recreate Step-by-Step

### Phase 1: Project Setup (5 min)

1. Create a new Vite + React + TypeScript project
2. Install dependencies from package.json above
3. Set up Tailwind CSS with the config from Section 6
4. Create `.env` with your Devs.ai credentials
5. Set up `vite.config.ts` with AI proxy plugin + Confluence proxy plugin

### Phase 2: Foundation (15 min)

6. Create the type definitions (`src/types/index.ts`)
7. Create the ThemeContext and useTheme hook
8. Create UI primitives: Button, Card, Input, Textarea, Toggle, Badge, Accordion, ThemeToggle
9. Create Brand.tsx (CompanyBadge + DevsAiBadge)
10. Create AIBadge.tsx (custom SVG)
11. Create Layout components: Layout, Navbar, Sidebar, Footer
12. Create main.tsx and App.tsx with all routes

### Phase 3: Core Tools (30 min)

13. Create the maintenance parser (`maintenanceParser.ts` + `timezoneDetector.ts`)
14. Create MaintenancePage with form + output + confidence indicators
15. Create the subnet calculator (`subnetCalculator.ts`)
16. Create SubnetPage with calculator + CIDR table + IP visual map
17. Import carrier contact data (`carrierContacts.ts` + `outageMaps.ts`)
18. Create CarrierContactsPage with search, filters, cards, escalation tables

### Phase 4: AI Integration (20 min)

19. Create `src/lib/devs-ai/client.ts` (SSE streaming client)
20. Create `src/lib/confluence/client.ts`
21. Add AI proxy to vite.config.ts
22. Create ChatInterface.tsx with full NOC_SYSTEM_PROMPT
23. Create ChatMessage.tsx, MessageActions.tsx, PromptStarters.tsx
24. Create SettingsModal.tsx (model override + Confluence config)
25. Create AIAssistantPage.tsx wrapper
26. Create `api/ai/chat.ts` for production

### Phase 5: Clipboard Engine (10 min)

27. Create `src/lib/clipboard-rich.ts` with 4-tier fallback
28. Wire into MaintenanceOutput, MessageActions, NOCScriptsPage

### Phase 6: Network Troubleshooting (20 min)

29. Create MobilityPage (5 tabs, issues with steps + Ask AI)
30. Create NOCScriptsPage (28 scripts with copy buttons)
31. Create NetworkDevicesPage (5 device categories × 3 tiers)
32. Create FaultTypesPage (14 iPath/LM fault types)
33. Create SDWanMetricsPage (thresholds + monitoring tiers)

### Phase 7: Dashboard & Polish (10 min)

34. Create Dashboard with 11 tiles + tips + branding
35. Create DocumentationPage and FAQPage
36. Wire all routes in App.tsx and Sidebar
37. Test TypeScript compilation (`npx tsc --noEmit`)
38. Deploy to Vercel

---

## Quick-Start Prompt for Another AI

If recreating in a new Devs.ai App Builder, paste this prompt:

> Recreate the NOC Operations Toolkit. Tech stack: React 18 + TypeScript + Vite 5 + Tailwind CSS 3.4 + Lucide icons + react-markdown + react-hot-toast + react-router-dom.
>
> It's a dark-mode web app for NOC/SOC engineers at AppDirect (vCom BU), powered by Devs.ai AI.
>
> Features: Maintenance Note Generator (19 carrier parsers, DST-aware timezone detection, rich clipboard copy), IP/Subnet Calculator (visual IP map, CIDR reference), Carrier Contacts (200+ carriers with escalation tiers, AI-powered search), Mobility Troubleshooting (iPhone/Android/iPad/SIM), NOC Scripts (28 one-click-copy scripts), Network Devices (Meraki/SD-WAN/Fortinet/carrier routers/combo devices with 3-tier troubleshooting), iPath Fault Types (14 LogicMonitor alerts with MNS tiers and NOC action steps), SD-WAN Metrics (latency/jitter/packet-loss/MOS thresholds), AI Assistant (streaming SSE chat with scope guard, Confluence wiki grounding, 8 prompt starters).
>
> Branding: AppDirect · vCom BU badge, Devs.ai badge, custom AIBadge SVG. Dark mode default. Inter + JetBrains Mono fonts.
>
> I'll provide the full project blueprint document and paste files one by one. Start with package.json.

---

*Generated by NOC Toolkit · Sriram Parisa · AppDirect · vCom BU · Powered by Devs.ai*
