#!/usr/bin/env python3
"""Parse carrier_contact_list.xlsx into clean JSON for the TypeScript app."""
import json
import re
from pathlib import Path
import openpyxl

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / 'user-uploads' / 'carrier_contact_list.xlsx'
OUT_DIR = ROOT / 'scripts'

PHONE_RE = re.compile(r"\(?(\d{3})\)?[\s\-\.\)]*[\s\-]*(\d{3})[\s\-\.\)]*[\s\-]*(\d{4})")
EMAIL_RE = re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}")
URL_RE = re.compile(r"https?://[^\s,]+", re.I)


def normalize_phone(raw):
    if not raw:
        return None
    s = str(raw).replace(' ', '').replace('--', '-').replace('..', '.')
    m = PHONE_RE.search(s)
    if not m:
        return None
    return f"1-{m.group(1)}-{m.group(2)}-{m.group(3)}"


def extract_phones(*cells):
    phones = []
    for c in cells:
        if c is None:
            continue
        # A cell can carry multiple phones
        for m in PHONE_RE.finditer(str(c).replace('--', '-').replace('..', '.')):
            p = f"1-{m.group(1)}-{m.group(2)}-{m.group(3)}"
            if p not in phones:
                phones.append(p)
    return phones


def extract_emails(*cells):
    emails = []
    for c in cells:
        if c is None:
            continue
        for m in EMAIL_RE.finditer(str(c)):
            e = m.group(0).strip().rstrip('.,;:').lower()
            if e not in emails:
                emails.append(e)
    return emails


def extract_urls(*cells):
    urls = []
    for c in cells:
        if c is None:
            continue
        for m in URL_RE.finditer(str(c)):
            u = m.group(0).strip().rstrip('.,;:>')
            if u not in urls:
                urls.append(u)
    return urls


def extract_notes(*cells):
    """Notes = remainder after stripping phones/emails/urls."""
    parts = []
    for c in cells:
        if c is None:
            continue
        s = str(c).strip()
        if not s:
            continue
        # Strip extracted bits
        s = PHONE_RE.sub('', s)
        s = EMAIL_RE.sub('', s)
        s = URL_RE.sub('', s)
        s = re.sub(r'[\s\-,;:|()]+', ' ', s).strip(' ,-')
        if len(s) > 3:
            parts.append(s)
    return ' | '.join(parts) if parts else None


def categorize(carrier_name):
    """Classify Business / Residential / Both based on name."""
    n = carrier_name.lower()
    if any(b in n for b in ['business', 'enterprise', 'commercial', 'wholesale', '-acc', '-apex',
                             '-alliance', '-national', 'wireless', 'wholesale']):
        return 'Business'
    # Residential-leaning brand names with no business marker
    if n in ['comcast', 'spectrum', 'optimum', 'altice', 'wow', 'wow!', 'cox communications',
            'verizon-east', 'directv', 'frontier', 'centurylink', 'at&t', 'verizon', 'sprint',
            'tds', 'tds telecom', 'midco', 'mediacom business']:
        return 'Both'
    return 'Both'


def main():
    wb = openpyxl.load_workbook(SRC, data_only=True)

    # ------------------------------------------------------------------
    # Sheet 1: Carrier contact list
    # ------------------------------------------------------------------
    ws = wb['carrier contact list']
    carriers = {}  # name -> { services: [...], phones, emails, urls, notes, category }

    for row in ws.iter_rows(values_only=True):
        if not row or not row[0]:
            continue
        carrier_name = str(row[0]).strip()
        if not carrier_name:
            continue
        service = str(row[1]).strip() if row[1] else 'General'
        rest = row[2:]
        phones = extract_phones(*rest)
        emails = extract_emails(*rest)
        urls = extract_urls(*rest)
        notes = extract_notes(*rest)

        if carrier_name not in carriers:
            carriers[carrier_name] = {
                'name': carrier_name,
                'category': categorize(carrier_name),
                'services': {},
                'all_phones': [],
                'all_emails': [],
                'all_urls': [],
            }
        c = carriers[carrier_name]
        if service not in c['services']:
            c['services'][service] = {
                'service': service,
                'phones': [],
                'emails': [],
                'urls': [],
                'notes': [],
            }
        s = c['services'][service]
        for p in phones:
            if p not in s['phones']:
                s['phones'].append(p)
            if p not in c['all_phones']:
                c['all_phones'].append(p)
        for e in emails:
            if e not in s['emails']:
                s['emails'].append(e)
            if e not in c['all_emails']:
                c['all_emails'].append(e)
        for u in urls:
            if u not in s['urls']:
                s['urls'].append(u)
            if u not in c['all_urls']:
                c['all_urls'].append(u)
        if notes and notes not in s['notes']:
            s['notes'].append(notes)

    # Convert services dict to list
    carrier_list = []
    for name, c in carriers.items():
        services = list(c['services'].values())
        for s in services:
            s['notes'] = ' | '.join(s['notes']) if s['notes'] else None
        carrier_list.append({
            'name': c['name'],
            'category': c['category'],
            'services': services,
            'allPhones': c['all_phones'],
            'allEmails': c['all_emails'],
            'allUrls': c['all_urls'],
        })
    carrier_list.sort(key=lambda x: x['name'].lower())

    # ------------------------------------------------------------------
    # Sheet 2: NOC escalations contacts
    # ------------------------------------------------------------------
    ws2 = wb['NOC escalations contacts']
    escalations = {}  # carrier -> { 'Buyers Club': [tiers], 'Brokerage': [tiers] }

    for row in ws2.iter_rows(values_only=True):
        if not row or not row[0]:
            continue
        channel_raw = str(row[0]).strip()
        carrier = str(row[1]).strip() if row[1] else None
        if not carrier:
            continue
        tier_val = row[2]
        try:
            tier = int(float(tier_val)) if tier_val is not None else 0
        except Exception:
            tier = 0
        name = str(row[3]).strip() if row[3] else None
        title = str(row[4]).strip() if row[4] else None
        rest = row[5:]
        phones = extract_phones(*rest, name, title)
        emails = extract_emails(*rest, name, title)
        urls = extract_urls(*rest)
        notes = extract_notes(*rest)

        # Clean name/title — sometimes phones leak in
        if name:
            name = PHONE_RE.sub('', name).strip(' ,-')
        if title:
            title = PHONE_RE.sub('', title).strip(' ,-')

        # Channel normalization
        channel = 'Buyers Club' if "buyers" in channel_raw.lower() else 'Brokerage'
        if carrier not in escalations:
            escalations[carrier] = {'Buyers Club': [], 'Brokerage': []}
        escalations[carrier][channel].append({
            'tier': tier,
            'name': name,
            'title': title,
            'phones': phones,
            'emails': emails,
            'urls': urls,
            'notes': notes,
        })

    # Sort tiers per channel
    for c, channels in escalations.items():
        for ch in channels:
            channels[ch].sort(key=lambda x: x['tier'])

    out = {
        'carriers': carrier_list,
        'escalations': escalations,
    }

    out_path = OUT_DIR / 'carrier_data.json'
    out_path.write_text(json.dumps(out, indent=2))
    print(f"Wrote {out_path}")
    print(f"  Carriers: {len(carrier_list)}")
    print(f"  Carriers with escalations: {len(escalations)}")
    # Print a few categories distribution
    cat_counts = {}
    for c in carrier_list:
        cat_counts[c['category']] = cat_counts.get(c['category'], 0) + 1
    print(f"  Categories: {cat_counts}")


if __name__ == '__main__':
    main()
