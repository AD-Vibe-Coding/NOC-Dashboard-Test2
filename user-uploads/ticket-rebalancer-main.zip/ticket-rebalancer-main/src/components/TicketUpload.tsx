import { Card, Group, Stack, Text, Badge, ActionIcon, Tooltip } from "@mantine/core";
import { Dropzone } from "@mantine/dropzone";
import { IconFileSpreadsheet, IconUpload, IconX, IconTrash } from "@tabler/icons-react";
import type { RawTicket } from "../lib/types";
import { parseTicketFile } from "../lib/parse-tickets";
import { useState } from "react";
import { notifications } from "@mantine/notifications";

interface Props {
  tickets: RawTicket[] | null;
  fileName: string | null;
  onLoad: (tickets: RawTicket[], fileName: string) => void;
  onClear: () => void;
}

export function TicketUpload({ tickets, fileName, onLoad, onClear }: Props) {
  const [busy, setBusy] = useState(false);

  async function handleDrop(files: File[]) {
    if (files.length === 0) return;
    const file = files[0];
    setBusy(true);
    try {
      const parsed = await parseTicketFile(file);
      if (parsed.length === 0) {
        notifications.show({
          color: "yellow",
          title: "No tickets parsed",
          message: "File loaded but no rows had a recognizable Ticket ID column.",
        });
      } else {
        notifications.show({
          color: "teal",
          title: "Tickets loaded",
          message: `Parsed ${parsed.length} ticket(s) from ${file.name}.`,
        });
        onLoad(parsed, file.name);
      }
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : String(e);
      notifications.show({
        color: "red",
        title: "Failed to parse file",
        message: msg,
      });
    } finally {
      setBusy(false);
    }
  }

  return (
    <Card withBorder radius="lg" p="lg">
      <Stack gap="sm">
        <Group justify="space-between" align="center">
          <Group gap="xs">
            <IconFileSpreadsheet size={20} />
            <Text fw={600}>1. iPath Ticket Export</Text>
          </Group>
          {tickets && (
            <Group gap="xs">
              <Badge color="teal" variant="light">
                {tickets.length} tickets
              </Badge>
              <Tooltip label="Clear">
                <ActionIcon variant="subtle" color="red" onClick={onClear}>
                  <IconTrash size={16} />
                </ActionIcon>
              </Tooltip>
            </Group>
          )}
        </Group>

        {!tickets ? (
          <Dropzone
            onDrop={handleDrop}
            loading={busy}
            accept={{
              "text/csv": [".csv"],
              "application/vnd.ms-excel": [".xls"],
              "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet":
                [".xlsx"],
            }}
            maxFiles={1}
          >
            <Group justify="center" gap="md" mih={120} style={{ pointerEvents: "none" }}>
              <Dropzone.Accept>
                <IconUpload size={40} stroke={1.5} />
              </Dropzone.Accept>
              <Dropzone.Reject>
                <IconX size={40} stroke={1.5} />
              </Dropzone.Reject>
              <Dropzone.Idle>
                <IconFileSpreadsheet size={40} stroke={1.5} />
              </Dropzone.Idle>
              <Stack gap={2}>
                <Text size="sm" fw={500}>
                  Drop the iPath export here, or click to select
                </Text>
                <Text size="xs" c="dimmed">
                  Accepts CSV, XLSX, XLS — headers like "Ticket", "Owner", "Stage", "Priority", "Service" are auto-detected.
                </Text>
              </Stack>
            </Group>
          </Dropzone>
        ) : (
          <Text size="sm" c="dimmed">
            Loaded: <Text component="span" c="bright">{fileName}</Text>
          </Text>
        )}
      </Stack>
    </Card>
  );
}
