import {
  Card,
  Group,
  Stack,
  Text,
  TextInput,
  Button,
  Badge,
  Alert,
  Tabs,
} from "@mantine/core";
import { DateInput } from "@mantine/dates";
import {
  IconCalendar,
  IconCloud,
  IconRefresh,
  IconAlertTriangle,
  IconUpload,
  IconExternalLink,
} from "@tabler/icons-react";
import { Dropzone } from "@mantine/dropzone";
import { useState } from "react";
import dayjs from "dayjs";
import { notifications } from "@mantine/notifications";
import {
  buildRosterForDate,
  csvToGrid,
  fetchRosterCsv,
} from "../lib/parse-roster";
import type { RosterEntry } from "../lib/types";
import * as XLSX from "xlsx";

const DEFAULT_SHEET_ID = "14t85Jg97RXmjDg3cwBQOnYGVYoBZUPuTrHGz-SKtZA4";
const DEFAULT_GID = "1411338244";

interface Props {
  date: Date | null;
  onDate: (d: Date | null) => void;
  roster: RosterEntry[] | null;
  warnings: string[];
  onRoster: (
    entries: RosterEntry[],
    prevEntries: RosterEntry[],
    warnings: string[],
    source: string,
  ) => void;
  source: string | null;
}

export function RosterSource({
  date,
  onDate,
  roster,
  warnings,
  onRoster,
  source,
}: Props) {
  const [sheetId, setSheetId] = useState(DEFAULT_SHEET_ID);
  const [gid, setGid] = useState(DEFAULT_GID);
  const [loading, setLoading] = useState(false);
  const [fetchError, setFetchError] = useState<string | null>(null);

  async function loadFromGoogle() {
    if (!date) {
      notifications.show({ color: "yellow", message: "Pick a date first." });
      return;
    }
    setLoading(true);
    setFetchError(null);
    try {
      const csv = await fetchRosterCsv(sheetId.trim(), gid.trim());
      const grid = csvToGrid(csv);
      const today = buildRosterForDate(grid, dayjs(date));
      // Also extract the previous day's column from the same grid — needed
      // for the Shift 5 → Shift 1 handoff (overnight agents start 7 PM
      // yesterday, so their roster cell is in yesterday's column).
      const prev = buildRosterForDate(grid, dayjs(date).subtract(1, "day"));
      if (today.columnIndex === null) {
        notifications.show({
          color: "yellow",
          title: "Date column not found",
          message: `No header in row 1 matched ${dayjs(date).format("D-MMM")}. Roster loaded but everyone is marked unavailable.`,
        });
      }
      onRoster(today.entries, prev.entries, today.warnings, "Google Sheet");
      const prevHit = prev.columnIndex !== null;
      notifications.show({
        color: "teal",
        title: "Roster loaded",
        message:
          `${today.entries.filter((e) => e.available).length} on shift on ${dayjs(date).format("D-MMM")}` +
          (prevHit
            ? ` · also pulled ${dayjs(date).subtract(1, "day").format("D-MMM")} for overnight handoff`
            : ` · previous day not found in sheet — overnight handoff will be limited`),
      });
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : String(e);
      setFetchError(msg);
      notifications.show({
        color: "red",
        title: "Failed to load roster",
        message: msg,
        autoClose: 8000,
      });
    } finally {
      setLoading(false);
    }
  }

  async function handleFileDrop(files: File[]) {
    if (!files.length || !date) {
      if (!date) notifications.show({ color: "yellow", message: "Pick a date first." });
      return;
    }
    const file = files[0];
    setLoading(true);
    try {
      let grid: string[][];
      const ext = file.name.toLowerCase().split(".").pop();
      if (ext === "csv" || ext === "tsv" || ext === "txt") {
        const text = await file.text();
        grid = csvToGrid(text);
      } else {
        const buf = await file.arrayBuffer();
        const wb = XLSX.read(buf, { type: "array" });
        const ws = wb.Sheets[wb.SheetNames[0]];
        grid = XLSX.utils.sheet_to_json<string[]>(ws, {
          header: 1,
          defval: "",
          raw: false,
        }) as unknown as string[][];
      }
      const today = buildRosterForDate(grid, dayjs(date));
      const prev = buildRosterForDate(grid, dayjs(date).subtract(1, "day"));
      if (today.columnIndex === null) {
        notifications.show({
          color: "yellow",
          title: "Date column not found",
          message: `No header in row 1 matched ${dayjs(date).format("D-MMM")}.`,
        });
      }
      onRoster(today.entries, prev.entries, today.warnings, `File: ${file.name}`);
      const prevHit = prev.columnIndex !== null;
      notifications.show({
        color: "teal",
        title: "Roster loaded",
        message:
          `${today.entries.filter((e) => e.available).length} on shift on ${dayjs(date).format("D-MMM")}` +
          (prevHit
            ? ` · also pulled ${dayjs(date).subtract(1, "day").format("D-MMM")} for overnight handoff`
            : ` · previous day not found in sheet`),
      });
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : String(e);
      notifications.show({
        color: "red",
        title: "Failed to parse roster file",
        message: msg,
      });
    } finally {
      setLoading(false);
    }
  }

  const availableCount = roster?.filter((r) => r.available).length ?? 0;

  return (
    <Card withBorder radius="lg" p="lg">
      <Stack gap="md">
        <Group justify="space-between" align="center">
          <Group gap="xs">
            <IconCalendar size={20} />
            <Text fw={600}>2. NOC Roster (PST)</Text>
          </Group>
          {roster && (
            <Group gap="xs">
              <Badge variant="light" color="teal">
                {availableCount} available
              </Badge>
              <Badge variant="light" color="gray">
                {roster.length - availableCount} off
              </Badge>
            </Group>
          )}
        </Group>

        <DateInput
          label="Roster date"
          value={date}
          onChange={(v) => onDate(typeof v === "string" ? new Date(v) : v)}
          placeholder="Pick a date"
          valueFormat="ddd, MMM D, YYYY"
          leftSection={<IconCalendar size={16} />}
        />

        <Tabs defaultValue="google">
          <Tabs.List>
            <Tabs.Tab value="google" leftSection={<IconCloud size={14} />}>
              Google Sheet
            </Tabs.Tab>
            <Tabs.Tab value="upload" leftSection={<IconUpload size={14} />}>
              Upload CSV/XLSX
            </Tabs.Tab>
          </Tabs.List>

          <Tabs.Panel value="google" pt="sm">
            <Stack gap="xs">
              <TextInput
                label="Sheet ID"
                value={sheetId}
                onChange={(e) => setSheetId(e.currentTarget.value)}
                description="The long ID from the sheet URL between /d/ and /edit"
              />
              <TextInput
                label="Tab GID"
                value={gid}
                onChange={(e) => setGid(e.currentTarget.value)}
                description="The number after #gid= in the sheet URL"
              />
              <Group justify="space-between">
                <Text size="xs" c="dimmed">
                  Sheet must be shared as "Anyone with the link can view".
                </Text>
                <Group gap="xs">
                  <Button
                    component="a"
                    href={`https://docs.google.com/spreadsheets/d/${sheetId}/edit#gid=${gid}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    variant="subtle"
                    size="xs"
                    leftSection={<IconExternalLink size={12} />}
                  >
                    Open sheet
                  </Button>
                  <Button
                    leftSection={<IconRefresh size={14} />}
                    onClick={loadFromGoogle}
                    loading={loading}
                    disabled={!date}
                  >
                    Load roster
                  </Button>
                </Group>
              </Group>

              {fetchError && (
                <Alert
                  color="red"
                  variant="light"
                  icon={<IconAlertTriangle size={16} />}
                  title="Could not load the sheet"
                  withCloseButton
                  onClose={() => setFetchError(null)}
                >
                  <Stack gap="xs">
                    <Text size="xs">{fetchError}</Text>
                    <Text size="xs" c="dimmed" fw={600}>
                      Quick fixes:
                    </Text>
                    <Text size="xs" c="dimmed">
                      1. Open the sheet → <Text component="span" fw={600}>Share</Text> →
                      under "General access" set to{" "}
                      <Text component="span" fw={600}>"Anyone with the link"</Text> ·{" "}
                      <Text component="span" fw={600}>Viewer</Text>. Org-locked sheets
                      can't be read by this app.
                    </Text>
                    <Text size="xs" c="dimmed">
                      2. Confirm the Tab GID matches the tab you actually want — the
                      number after <Text component="span" ff="monospace">#gid=</Text> in
                      the sheet URL changes per tab.
                    </Text>
                    <Text size="xs" c="dimmed">
                      3. If the sheet must stay private, switch to the{" "}
                      <Text component="span" fw={600}>Upload CSV/XLSX</Text> tab and
                      drop a downloaded copy (File → Download → CSV).
                    </Text>
                  </Stack>
                </Alert>
              )}
            </Stack>
          </Tabs.Panel>

          <Tabs.Panel value="upload" pt="sm">
            <Dropzone
              onDrop={handleFileDrop}
              loading={loading}
              accept={{
                "text/csv": [".csv"],
                "application/vnd.ms-excel": [".xls"],
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet":
                  [".xlsx"],
              }}
              maxFiles={1}
            >
              <Group justify="center" mih={80} style={{ pointerEvents: "none" }}>
                <IconUpload size={28} stroke={1.5} />
                <Text size="sm">
                  Drop a roster export (CSV/XLSX) — same horizontal calendar layout
                </Text>
              </Group>
            </Dropzone>
          </Tabs.Panel>
        </Tabs>

        {source && roster && (
          <Text size="xs" c="dimmed">
            Source: <Text component="span" c="bright">{source}</Text>
            {date && ` · ${dayjs(date).format("ddd, MMM D, YYYY")}`}
          </Text>
        )}

        {warnings.length > 0 && (
          <Alert
            color="yellow"
            variant="light"
            icon={<IconAlertTriangle size={16} />}
            title={`${warnings.length} roster warning(s)`}
          >
            <Stack gap={2}>
              {warnings.slice(0, 5).map((w, i) => (
                <Text size="xs" key={i}>
                  • {w}
                </Text>
              ))}
              {warnings.length > 5 && (
                <Text size="xs" c="dimmed">
                  …and {warnings.length - 5} more
                </Text>
              )}
            </Stack>
          </Alert>
        )}
      </Stack>
    </Card>
  );
}

export { DEFAULT_SHEET_ID, DEFAULT_GID };
