import {
  Card,
  Stack,
  Group,
  Text,
  Slider,
  NumberInput,
  Switch,
  Tooltip,
  ActionIcon,
  SegmentedControl,
  Select,
  Alert,
} from "@mantine/core";
import {
  IconAdjustments,
  IconHelp,
  IconClockHour4,
  IconFlame,
} from "@tabler/icons-react";
import type { RebalanceOptions } from "../lib/rebalance";
import { SHIFT_TRANSITIONS } from "../lib/shifts";

interface Props {
  options: RebalanceOptions;
  onChange: (next: RebalanceOptions) => void;
}

export function RebalanceSettings({ options, onChange }: Props) {
  const isShiftMode = options.mode === "shift-handoff";

  return (
    <Card withBorder radius="lg" p="lg">
      <Stack gap="md">
        <Group gap="xs">
          <IconAdjustments size={20} />
          <Text fw={600}>3. Rebalance Rules</Text>
        </Group>

        <Stack gap={4}>
          <Text size="sm" fw={500}>
            Mode
          </Text>
          <SegmentedControl
            value={options.mode}
            onChange={(v) =>
              onChange({ ...options, mode: v as RebalanceOptions["mode"] })
            }
            data={[
              { label: "Full team balance", value: "full" },
              {
                label: "Shift handoff (hot SLA only)",
                value: "shift-handoff",
              },
            ]}
            fullWidth
          />
        </Stack>

        {isShiftMode && (
          <Stack gap="xs">
            <Alert
              variant="light"
              color="orange"
              icon={<IconFlame size={16} />}
              title="Shift handoff mode"
            >
              <Text size="xs">
                Only SLA tickets in stage <b>Pending Carrier Action / Update</b>{" "}
                with priority <b>Critical</b> or <b>High</b> will be considered
                for redistribution. All other tickets are left untouched.
              </Text>
            </Alert>
            <Select
              label="Shift transition"
              description="Pick the handoff window. Each transition runs at its scheduled posting time."
              value={options.shiftTransitionId ?? "5-to-1"}
              onChange={(v) =>
                onChange({ ...options, shiftTransitionId: v ?? "5-to-1" })
              }
              data={SHIFT_TRANSITIONS.map((t) => ({
                value: t.id,
                label: t.label,
              }))}
              leftSection={<IconClockHour4 size={14} />}
            />
            {(() => {
              const sel = SHIFT_TRANSITIONS.find(
                (t) => t.id === (options.shiftTransitionId ?? "5-to-1"),
              );
              if (!sel?.sourceDateOffset) return null;
              return (
                <Alert variant="light" color="blue" radius="md">
                  <Text size="xs">
                    <b>Cross-day handoff:</b> Source agents (Shift{" "}
                    {sel.sourceShifts.join(", ")}) are pulled from the{" "}
                    <b>previous day's</b> roster column, since they clocked in
                    at 7 PM the night before. The roster loader fetches both
                    days automatically.
                  </Text>
                </Alert>
              );
            })()}
          </Stack>
        )}

        {!isShiftMode && (
          <>
            <Stack gap={4}>
              <Group gap={4}>
                <Text size="sm" fw={500}>
                  Tolerance band: ±{options.band.toFixed(1)}
                </Text>
                <Tooltip label="Agents with weight outside mean ± band are flagged.">
                  <ActionIcon variant="subtle" size="xs">
                    <IconHelp size={12} />
                  </ActionIcon>
                </Tooltip>
              </Group>
              <Slider
                min={0.5}
                max={10}
                step={0.5}
                value={options.band}
                onChange={(v) => onChange({ ...options, band: v })}
                marks={[
                  { value: 1, label: "1" },
                  { value: 3, label: "3" },
                  { value: 5, label: "5" },
                  { value: 10, label: "10" },
                ]}
              />
            </Stack>

            <Group grow>
              <NumberInput
                label="Min movable weight"
                description="Skip ultra-light tickets"
                value={options.minMoveWeight}
                onChange={(v) =>
                  onChange({
                    ...options,
                    minMoveWeight: typeof v === "number" ? v : 0.25,
                  })
                }
                min={0}
                step={0.05}
                decimalScale={2}
              />
              <NumberInput
                label="Max movable weight"
                description="Skip very heavy active tickets"
                value={options.maxMoveWeight}
                onChange={(v) =>
                  onChange({
                    ...options,
                    maxMoveWeight: typeof v === "number" ? v : 3,
                  })
                }
                min={0}
                step={0.5}
                decimalScale={2}
              />
            </Group>

            <NumberInput
              label="Max ticket age (days) — optional"
              description="Skip tickets older than this. Leave blank for no limit."
              value={options.maxAgeDays ?? ""}
              onChange={(v) =>
                onChange({
                  ...options,
                  maxAgeDays: typeof v === "number" ? v : undefined,
                })
              }
              min={0}
              step={1}
            />

            <Switch
              label="Tier-matched moves only"
              description="Prefer routing within the same tier (T1↔T1, T2↔T2). Falls back to cross-tier if no match."
              checked={options.enforceTierMatch}
              onChange={(e) =>
                onChange({
                  ...options,
                  enforceTierMatch: e.currentTarget.checked,
                })
              }
            />
          </>
        )}
      </Stack>
    </Card>
  );
}
