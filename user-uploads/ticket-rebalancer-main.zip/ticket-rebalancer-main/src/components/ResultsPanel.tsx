import {
  Card,
  Stack,
  Group,
  Text,
  Badge,
  Table,
  Tabs,
  Code,
  Button,
  ScrollArea,
  CopyButton,
  Alert,
  SimpleGrid,
  Paper,
  Tooltip,
} from "@mantine/core";
import {
  IconClipboardCheck,
  IconCopy,
  IconChartBar,
  IconArrowsExchange,
  IconCode,
  IconAlertTriangle,
  IconCircleCheck,
  IconClockHour4,
  IconFlame,
} from "@tabler/icons-react";
import type { RebalanceResult, AgentLoad } from "../lib/types";
import { formatForSlack } from "../lib/slack-format";
import { SHIFTS, type ShiftId } from "../lib/shifts";

function shiftLabelFor(id: ShiftId): string {
  const s = SHIFTS.find((x) => x.id === id);
  return s ? `Shift ${s.id} — ${s.name}` : `Shift ${id}`;
}

interface Props {
  result: RebalanceResult;
}

function bandColor(band: AgentLoad["band"]): string {
  if (band === "over") return "red";
  if (band === "under") return "yellow";
  if (band === "ok") return "teal";
  return "gray";
}

function StatTile({
  label,
  value,
  hint,
  accent,
}: {
  label: string;
  value: string;
  hint?: string;
  accent?: "red" | "orange" | "yellow" | "blue";
}) {
  return (
    <Paper
      withBorder
      p="md"
      radius="md"
      style={
        accent
          ? { borderColor: `var(--mantine-color-${accent}-6)` }
          : undefined
      }
    >
      <Stack gap={2}>
        <Text
          size="xs"
          c={accent ?? "dimmed"}
          tt="uppercase"
          fw={700}
          lts={0.5}
        >
          {label}
        </Text>
        <Text size="xl" fw={700} c={accent}>
          {value}
        </Text>
        {hint && (
          <Text size="xs" c="dimmed">
            {hint}
          </Text>
        )}
      </Stack>
    </Paper>
  );
}

export function ResultsPanel({ result }: Props) {
  const slackText = formatForSlack(result);

  const sortedLoads = [...result.agentLoads].sort((a, b) => {
    // Available first, then by ticket count desc (heaviest queues at top),
    // tie-break on weight desc so similarly-stuffed agents still rank by load.
    if (a.available !== b.available) return a.available ? -1 : 1;
    if (b.ticketCount !== a.ticketCount) return b.ticketCount - a.ticketCount;
    return b.weight - a.weight;
  });

  const overCount = result.agentLoads.filter((l) => l.band === "over").length;
  const underCount = result.agentLoads.filter((l) => l.band === "under").length;
  // Team-wide active P1/P2/P3 counts. Active = stage Pending Carrier
  // Action / Update; P1 = Critical, P2 = High, P3 = Medium priority.
  const totalP1 = result.agentLoads.reduce((s, l) => s + l.p1Count, 0);
  const totalP2 = result.agentLoads.reduce((s, l) => s + l.p2Count, 0);
  const totalP3 = result.agentLoads.reduce((s, l) => s + l.p3Count, 0);
  // Active tickets in stage Pending Carrier Action / Update whose due date
  // falls on the analysis date.
  const totalDueToday = result.agentLoads.reduce(
    (s, l) => s + l.dueToday,
    0,
  );
  // Aging buckets — total tickets older than 10 / 30 days across the team.
  const totalAge10 = result.agentLoads.reduce((s, l) => s + l.ageOver10, 0);
  const totalAge30 = result.agentLoads.reduce((s, l) => s + l.ageOver30, 0);

  return (
    <Card withBorder radius="lg" p="lg">
      <Stack gap="md">
        <Group justify="space-between" align="center">
          <Group gap="xs">
            <IconClipboardCheck size={20} />
            <Text fw={600}>Results — {result.date}</Text>
          </Group>
          {result.movesSuggested.length === 0 ? (
            <Badge color="teal" leftSection={<IconCircleCheck size={12} />}>
              Balanced
            </Badge>
          ) : (
            <Badge color="orange">
              {result.movesSuggested.length} move(s) suggested
            </Badge>
          )}
        </Group>

        {result.shiftTransition && (
          <Alert
            color="orange"
            variant="light"
            icon={<IconFlame size={16} />}
            title={`Shift handoff: ${result.shiftTransition.label}`}
          >
            <Group gap="xs">
              <IconClockHour4 size={14} />
              <Text size="sm">{result.shiftTransition.context}</Text>
            </Group>
            <Text size="xs" c="dimmed" mt={4}>
              Only SLA tickets in stage Pending Carrier Action / Update with
              Critical or High priority are eligible to move.
            </Text>
          </Alert>
        )}

        <SimpleGrid cols={{ base: 2, sm: 5 }} spacing="sm">
          <StatTile
            label="Active P1"
            value={totalP1.toString()}
            hint="Critical · Pending Carrier"
            accent="red"
          />
          <StatTile
            label="Active P2"
            value={totalP2.toString()}
            hint="High · Pending Carrier"
            accent="orange"
          />
          <StatTile
            label="Active P3"
            value={totalP3.toString()}
            hint="Medium · Pending Carrier"
            accent="yellow"
          />
          <StatTile
            label="Due Today"
            value={totalDueToday.toString()}
            hint="Pending Carrier · due today"
            accent="blue"
          />
          <StatTile label="Total Tickets" value={result.totalTickets.toString()} />
        </SimpleGrid>

        <SimpleGrid cols={{ base: 2, sm: 4, md: 7 }} spacing="sm">
          <StatTile
            label="Age > 10 days"
            value={totalAge10.toString()}
            hint="aging tickets"
            accent="orange"
          />
          <StatTile
            label="Age > 30 days"
            value={totalAge30.toString()}
            hint="stale tickets"
            accent="red"
          />
          <StatTile
            label="Total Weight"
            value={result.totalWeight.toFixed(2)}
          />
          <StatTile
            label="Available"
            value={result.availableAgents.toString()}
            hint="agents on shift"
          />
          <StatTile
            label="Mean Load"
            value={result.meanLoad.toFixed(2)}
            hint={`±${result.band} band`}
          />
          <StatTile label="Overloaded" value={overCount.toString()} />
          <StatTile label="Underloaded" value={underCount.toString()} />
        </SimpleGrid>

        {result.warnings.length > 0 && (
          <Alert
            color="yellow"
            variant="light"
            icon={<IconAlertTriangle size={16} />}
            title="Notes"
          >
            <Stack gap={2}>
              {result.warnings.map((w, i) => (
                <Text size="xs" key={i}>
                  • {w}
                </Text>
              ))}
            </Stack>
          </Alert>
        )}

        <Tabs defaultValue="loads">
          <Tabs.List>
            <Tabs.Tab value="loads" leftSection={<IconChartBar size={14} />}>
              Per-agent load
            </Tabs.Tab>
            <Tabs.Tab value="moves" leftSection={<IconArrowsExchange size={14} />}>
              Suggested moves ({result.movesSuggested.length})
            </Tabs.Tab>
            <Tabs.Tab value="slack" leftSection={<IconCode size={14} />}>
              Slack message
            </Tabs.Tab>
          </Tabs.List>

          <Tabs.Panel value="loads" pt="md">
            <ScrollArea>
              <Table highlightOnHover striped="even" verticalSpacing="xs">
                <Table.Thead>
                  <Table.Tr>
                    <Table.Th>Agent</Table.Th>
                    <Table.Th>Tier</Table.Th>
                    <Table.Th>Avail</Table.Th>
                    <Table.Th>Shift</Table.Th>
                    <Table.Th ta="right">Tickets</Table.Th>
                    <Table.Th ta="right" title="Stage = Pending Carrier Action / Update AND Priority = Critical or High">
                      Hot 🔥
                    </Table.Th>
                    <Table.Th ta="right" title="Stage = Pending Customer Response — parked tickets waiting on the customer">
                      Pend Cust 👤
                    </Table.Th>
                    <Table.Th ta="right" title="Active tickets (Pending Carrier Action / Update) due on the analysis date">
                      Due Today 📅
                    </Table.Th>
                    <Table.Th ta="right" title="Tickets owned by this agent with age > 10 days">
                      Age &gt;10
                    </Table.Th>
                    <Table.Th ta="right" title="Tickets owned by this agent with age > 30 days — stale">
                      Age &gt;30
                    </Table.Th>
                    <Table.Th ta="right">Weight</Table.Th>
                    <Table.Th ta="right">Δ vs mean</Table.Th>
                    <Table.Th>Band</Table.Th>
                  </Table.Tr>
                </Table.Thead>
                <Table.Tbody>
                  {sortedLoads.map((l) => (
                    <Table.Tr key={l.name}>
                      <Table.Td>{l.name}</Table.Td>
                      <Table.Td>
                        {l.tier ? (
                          <Badge variant="light" size="sm">
                            {l.tier}
                          </Badge>
                        ) : (
                          <Text c="dimmed" size="xs">
                            —
                          </Text>
                        )}
                      </Table.Td>
                      <Table.Td>
                        <Badge
                          variant="light"
                          color={l.available ? "teal" : "gray"}
                          size="sm"
                        >
                          {l.available ? "On shift" : "Off"}
                        </Badge>
                      </Table.Td>
                      <Table.Td>
                        {l.shiftId ? (
                          <Tooltip label={shiftLabelFor(l.shiftId)}>
                            <Badge variant="outline" size="sm" radius="sm">
                              S{l.shiftId}
                            </Badge>
                          </Tooltip>
                        ) : (
                          <Text c="dimmed" size="xs">
                            —
                          </Text>
                        )}
                      </Table.Td>
                      <Table.Td ta="right">{l.ticketCount}</Table.Td>
                      <Table.Td ta="right">
                        {l.hotTickets > 0 ? (
                          <Badge
                            color="red"
                            variant="filled"
                            size="sm"
                            radius="sm"
                          >
                            {l.hotTickets}
                          </Badge>
                        ) : (
                          <Text c="dimmed" size="xs">
                            0
                          </Text>
                        )}
                      </Table.Td>
                      <Table.Td ta="right">
                        {l.pendingCustomer > 0 ? (
                          <Badge
                            color="grape"
                            variant="light"
                            size="sm"
                            radius="sm"
                          >
                            {l.pendingCustomer}
                          </Badge>
                        ) : (
                          <Text c="dimmed" size="xs">
                            0
                          </Text>
                        )}
                      </Table.Td>
                      <Table.Td ta="right">
                        {l.dueToday > 0 ? (
                          <Badge
                            color="blue"
                            variant="filled"
                            size="sm"
                            radius="sm"
                          >
                            {l.dueToday}
                          </Badge>
                        ) : (
                          <Text c="dimmed" size="xs">
                            0
                          </Text>
                        )}
                      </Table.Td>
                      <Table.Td ta="right">
                        {l.ageOver10 > 0 ? (
                          <Badge
                            color="orange"
                            variant="light"
                            size="sm"
                            radius="sm"
                          >
                            {l.ageOver10}
                          </Badge>
                        ) : (
                          <Text c="dimmed" size="xs">
                            0
                          </Text>
                        )}
                      </Table.Td>
                      <Table.Td ta="right">
                        {l.ageOver30 > 0 ? (
                          <Badge
                            color="red"
                            variant="filled"
                            size="sm"
                            radius="sm"
                          >
                            {l.ageOver30}
                          </Badge>
                        ) : (
                          <Text c="dimmed" size="xs">
                            0
                          </Text>
                        )}
                      </Table.Td>
                      <Table.Td ta="right">
                        <Text fw={500}>{l.weight.toFixed(2)}</Text>
                      </Table.Td>
                      <Table.Td ta="right">
                        {l.available ? (
                          <Text c={l.delta > 0 ? "red" : l.delta < 0 ? "yellow" : "dimmed"}>
                            {l.delta >= 0 ? "+" : ""}
                            {l.delta.toFixed(2)}
                          </Text>
                        ) : (
                          <Text c="dimmed">—</Text>
                        )}
                      </Table.Td>
                      <Table.Td>
                        {l.band === "n/a" ? (
                          <Text c="dimmed" size="xs">
                            —
                          </Text>
                        ) : (
                          <Badge color={bandColor(l.band)} variant="filled" size="sm">
                            {l.band === "over" ? "OVER" : l.band === "under" ? "UNDER" : "ok"}
                          </Badge>
                        )}
                      </Table.Td>
                    </Table.Tr>
                  ))}
                </Table.Tbody>
              </Table>
            </ScrollArea>
          </Tabs.Panel>

          <Tabs.Panel value="moves" pt="md">
            {result.movesSuggested.length === 0 ? (
              <Alert color="teal" icon={<IconCircleCheck size={16} />}>
                All available agents are within the tolerance band — no moves required.
              </Alert>
            ) : (
              <ScrollArea>
                <Table highlightOnHover striped="even" verticalSpacing="xs">
                  <Table.Thead>
                    <Table.Tr>
                      <Table.Th>Ticket</Table.Th>
                      <Table.Th>From</Table.Th>
                      <Table.Th></Table.Th>
                      <Table.Th>To</Table.Th>
                      <Table.Th>Service</Table.Th>
                      <Table.Th>Priority</Table.Th>
                      <Table.Th>Stage</Table.Th>
                      <Table.Th ta="right">Weight</Table.Th>
                    </Table.Tr>
                  </Table.Thead>
                  <Table.Tbody>
                    {result.movesSuggested.map((m, i) => (
                      <Table.Tr key={i}>
                        <Table.Td>
                          <Code>{m.ticket.ticket}</Code>
                        </Table.Td>
                        <Table.Td>{m.from}</Table.Td>
                        <Table.Td>
                          <IconArrowsExchange size={14} />
                        </Table.Td>
                        <Table.Td>
                          <Text fw={500}>{m.to}</Text>
                        </Table.Td>
                        <Table.Td>
                          <Text size="sm">{m.ticket.service}</Text>
                        </Table.Td>
                        <Table.Td>
                          <Badge
                            size="sm"
                            variant="light"
                            color={
                              m.ticket.priorityBand === "Critical"
                                ? "red"
                                : m.ticket.priorityBand === "High"
                                ? "orange"
                                : "blue"
                            }
                          >
                            {m.ticket.priorityBand}
                          </Badge>
                        </Table.Td>
                        <Table.Td>
                          <Text size="sm" c="dimmed">
                            {m.ticket.stageNorm === "Unknown"
                              ? m.ticket.stage
                              : m.ticket.stageNorm}
                          </Text>
                        </Table.Td>
                        <Table.Td ta="right">{m.ticket.weight.toFixed(2)}</Table.Td>
                      </Table.Tr>
                    ))}
                  </Table.Tbody>
                </Table>
              </ScrollArea>
            )}
          </Tabs.Panel>

          <Tabs.Panel value="slack" pt="md">
            <Stack gap="sm">
              <Group justify="space-between">
                <Text size="sm" c="dimmed">
                  Paste this directly into <Code>#test-ani</Code>. The fixed-width blocks
                  render correctly in Slack.
                </Text>
                <CopyButton value={slackText}>
                  {({ copied, copy }) => (
                    <Button
                      size="xs"
                      leftSection={<IconCopy size={14} />}
                      color={copied ? "teal" : "blue"}
                      onClick={copy}
                    >
                      {copied ? "Copied!" : "Copy for Slack"}
                    </Button>
                  )}
                </CopyButton>
              </Group>
              <Code block style={{ whiteSpace: "pre-wrap", maxHeight: 480, overflow: "auto" }}>
                {slackText}
              </Code>
            </Stack>
          </Tabs.Panel>
        </Tabs>
      </Stack>
    </Card>
  );
}
