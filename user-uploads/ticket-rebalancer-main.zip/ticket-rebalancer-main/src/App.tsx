import { useMemo, useState } from "react";
import {
  AppShell,
  Container,
  Title,
  Text,
  Group,
  Stack,
  SimpleGrid,
  Button,
  Alert,
  Badge,
} from "@mantine/core";
import {
  IconChartHistogram,
  IconPlayerPlay,
  IconRefresh,
  IconInfoCircle,
} from "@tabler/icons-react";
import dayjs from "dayjs";

import { TicketUpload } from "./components/TicketUpload";
import { RosterSource } from "./components/RosterSource";
import { RebalanceSettings } from "./components/RebalanceSettings";
import { ResultsPanel } from "./components/ResultsPanel";
import type { RawTicket, RebalanceResult, RosterEntry } from "./lib/types";
import { scoreTickets } from "./lib/parse-tickets";
import {
  rebalance,
  rebalanceShiftHandoff,
  DEFAULT_OPTIONS,
  type RebalanceOptions,
} from "./lib/rebalance";

export default function App() {
  const [tickets, setTickets] = useState<RawTicket[] | null>(null);
  const [ticketFileName, setTicketFileName] = useState<string | null>(null);

  const [date, setDate] = useState<Date | null>(new Date());
  const [roster, setRoster] = useState<RosterEntry[] | null>(null);
  // Previous-day roster column — used as the SOURCE for shift-5 → shift-1
  // handoff, since overnight agents clock in at 7 PM the previous calendar
  // day and their cell lives in yesterday's column.
  const [rosterPrev, setRosterPrev] = useState<RosterEntry[] | null>(null);
  const [rosterWarnings, setRosterWarnings] = useState<string[]>([]);
  const [rosterSource, setRosterSource] = useState<string | null>(null);

  const [options, setOptions] = useState<RebalanceOptions>(DEFAULT_OPTIONS);
  const [result, setResult] = useState<RebalanceResult | null>(null);

  const canRun = !!tickets && !!roster && !!date;

  // Tickets in stage "Pending Complete" are effectively closed-out work and
  // are excluded from load math + rebalance suggestions.
  const EXCLUDED_STAGES = ["Pending Complete"] as const;

  const scoredPreview = useMemo(() => {
    if (!tickets) return null;
    return scoreTickets(tickets).filter(
      (t) => !EXCLUDED_STAGES.includes(t.stageNorm as (typeof EXCLUDED_STAGES)[number]),
    );
  }, [tickets]);

  function runAnalysis() {
    if (!tickets || !roster || !date) return;
    const scoredAll = scoreTickets(tickets);
    const scored = scoredAll.filter(
      (t) => !EXCLUDED_STAGES.includes(t.stageNorm as (typeof EXCLUDED_STAGES)[number]),
    );
    const excludedCount = scoredAll.length - scored.length;
    const dateLabel = dayjs(date).format("ddd, MMM D, YYYY");

    const r =
      options.mode === "shift-handoff"
        ? rebalanceShiftHandoff(
            scored,
            roster,
            dateLabel,
            options.shiftTransitionId ?? "5-to-1",
            options,
            rosterPrev ?? undefined,
            date,
          )
        : rebalance(scored, roster, dateLabel, options, date);

    const stageNote =
      excludedCount > 0
        ? [`Excluded ${excludedCount} ticket(s) in stage "Pending Complete" from load math.`]
        : [];
    r.warnings = [...stageNote, ...rosterWarnings, ...r.warnings];
    setResult(r);
  }

  function reset() {
    setTickets(null);
    setTicketFileName(null);
    setRoster(null);
    setRosterPrev(null);
    setRosterWarnings([]);
    setRosterSource(null);
    setResult(null);
    setOptions(DEFAULT_OPTIONS);
  }

  return (
    <AppShell header={{ height: 64 }} padding={0}>
      <AppShell.Header>
        <Container size="xl" h="100%">
          <Group h="100%" justify="space-between" align="center">
            <Group gap="xs">
              <IconChartHistogram size={26} />
              <Stack gap={0}>
                <Title order={4}>Ticket Bin Reviewer</Title>
                <Text size="xs" c="dimmed">
                  NOC ownership rebalance — suggestions only, never auto-assigns
                </Text>
              </Stack>
            </Group>
            <Group gap="xs">
              {tickets && (
                <Badge variant="light" color="blue">
                  {tickets.length} tickets
                </Badge>
              )}
              {scoredPreview && (
                <Badge variant="light" color="grape">
                  Σ weight {scoredPreview.reduce((s, t) => s + t.weight, 0).toFixed(2)}
                </Badge>
              )}
              <Button
                size="xs"
                variant="subtle"
                leftSection={<IconRefresh size={14} />}
                onClick={reset}
              >
                Reset
              </Button>
            </Group>
          </Group>
        </Container>
      </AppShell.Header>

      <AppShell.Main>
        <Container size="xl" py="xl">
          <Stack gap="lg">
            <Alert
              variant="light"
              color="blue"
              icon={<IconInfoCircle size={16} />}
              title="How it works"
            >
              <Text size="sm">
                Upload an iPath ticket export, load the NOC roster for a target date, and
                review weighted-load imbalances. The app suggests reassignments using the
                Service × Priority × Stage weight matrix and your tolerance band — final
                changes still happen manually in iPath.
              </Text>
            </Alert>

            <SimpleGrid cols={{ base: 1, md: 2 }} spacing="lg">
              <TicketUpload
                tickets={tickets}
                fileName={ticketFileName}
                onLoad={(t, name) => {
                  setTickets(t);
                  setTicketFileName(name);
                  setResult(null);
                }}
                onClear={() => {
                  setTickets(null);
                  setTicketFileName(null);
                  setResult(null);
                }}
              />
              <RosterSource
                date={date}
                onDate={(d) => {
                  setDate(d);
                  setResult(null);
                }}
                roster={roster}
                warnings={rosterWarnings}
                onRoster={(entries, prevEntries, warnings, source) => {
                  setRoster(entries);
                  setRosterPrev(prevEntries);
                  setRosterWarnings(warnings);
                  setRosterSource(source);
                  setResult(null);
                }}
                source={rosterSource}
              />
            </SimpleGrid>

            <RebalanceSettings
              options={options}
              onChange={(next) => {
                setOptions(next);
                setResult(null);
              }}
            />

            <Group justify="center">
              <Button
                size="lg"
                leftSection={<IconPlayerPlay size={18} />}
                disabled={!canRun}
                onClick={runAnalysis}
              >
                Analyze & Suggest Rebalance
              </Button>
            </Group>

            {result && <ResultsPanel result={result} />}
          </Stack>
        </Container>
      </AppShell.Main>
    </AppShell>
  );
}
